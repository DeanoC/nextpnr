import json,copy
from pathlib import Path
p=Path('/tmp/pcxt-replicate-cpu-reference-20261022/candidate');q=Path('/tmp/pcxt-replicate-leased-20261022/candidate')
a=json.loads((p/'routed.json').read_text());b=json.loads((q/'routed.json').read_text());x=a['modules']['top'];y=b['modules']['top'];mapping={}
assert x['netnames'].keys()==y['netnames'].keys()
for name,net in x['netnames'].items():
 other=y['netnames'][name];assert len(net['bits'])==len(other['bits'])
 for bit,dest in zip(net['bits'],other['bits']):
  if isinstance(bit,int):
   if bit in mapping:assert mapping[bit]==dest
   mapping[bit]=dest
  else:assert bit==dest
assert len(set(mapping.values()))==len(mapping)
def bits(v):return [mapping[n] if isinstance(n,int) else n for n in v]
for net in x['netnames'].values():net['bits']=bits(net['bits'])
for cell in x['cells'].values():cell['connections']={k:bits(v) for k,v in cell['connections'].items()}
for port in x['ports'].values():port['bits']=bits(port['bits'])
assert x['settings']['gpurouter/cpu']!=y['settings']['gpurouter/cpu']
x['settings']['gpurouter/cpu']=y['settings']['gpurouter/cpu']
assert a==b
r={'identical_after_bijective_bit_renumbering_and_cpu_backend_setting':True,'mapped_bits':len(mapping)}
(p/'normalized-graph-comparison.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
