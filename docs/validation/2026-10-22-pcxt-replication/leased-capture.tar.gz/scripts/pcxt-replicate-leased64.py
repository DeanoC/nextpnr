from pathlib import Path
import sys,json,shutil,os,time,subprocess,importlib.util
root=Path('/tmp/pcxt-replicate-leased64-20261022');root.mkdir(exist_ok=False)
prior=Path('/tmp/pcxt-replicate-leased-20261022')
s=importlib.util.spec_from_file_location('guard','/home/deano/harnesses/pcxt-compiler-repair/nextpnr/mistral/routed_swap.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
runnerroot=Path('/home/deano/harnesses/worktrees/fes/silver-delta/out/dev/pcxt-board/sources/misteross');sys.path[:0]=[str(runnerroot),str(runnerroot/'scripts')]
from fes_build_common import _run_command,_is_gpu_nextpnr,granted_gpu_ids
shutil.copytree(prior/'baseline',root/'baseline')
base=json.loads((root/'baseline/receipt.json').read_text())
g.write_json(root/'baseline-reuse.json',{'source':str(prior/'baseline'),'receipt_sha256':g.digest(prior/'baseline/receipt.json'),'rerouted':False,'charged_here_seconds':0})
cmd=json.loads((prior/'candidate/receipt.json').read_text())['command']
cmd[cmd.index('--critical-swap-budget')+1]='64'
assert _is_gpu_nextpnr(cmd)
assert g.digest(Path(cmd[0]))==base['binary_sha256']
env=dict(os.environ,FES_GPU_LEASE_OWNER='pcxt-agent',GPU_LEASE_MAX_PER_OWNER='2',NEXTPNR_REQUIRE_GPU='1')
def run():
 out=root/'candidate';out.mkdir()
 receipt={'command':cmd,'binary_sha256':base['binary_sha256'],'timeout':600,'environment':{k:env[k] for k in ('FES_GPU_LEASE_OWNER','GPU_LEASE_MAX_PER_OWNER','NEXTPNR_REQUIRE_GPU')}}
 start=time.monotonic()
 try:
  with (out/'nextpnr.log').open('w') as log:r=_run_command(cmd,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600,gpu_label='pcxt265-guard-replicate64')
  receipt['gpu_grants']=granted_gpu_ids((out/'nextpnr.log').read_text())
  if not receipt['gpu_grants']:raise ValueError('No GPU lease grant')
  receipt['returncode']=r.returncode
 except Exception as e:receipt['exception']=str(e)
 receipt['charged_seconds']=time.monotonic()-start
 receipt['artifacts']={n:g.digest(out/n) for n in g.ARTIFACTS if (out/n).exists()}
 g.write_json(out/'receipt.json',receipt)
 return receipt
result=g.guarded_candidate(root,base,run)
print(json.dumps(result,indent=2))
