import pathlib,json,collections
p=pathlib.Path('/tmp/pcxt-replicate-leased-20261022')
summary={}
for name in ['baseline','candidate']:
 out=p/name
 if not (out/'timing.json').exists():continue
 t=json.load(open(out/'timing.json'));e=json.load(open(out/'endpoints.json'))
 rows=[x for group in e['endpoints'].values() for x in group]
 paths=[]
 for path in t['critical_paths']:
  ds=collections.defaultdict(float)
  for segment in path['path']:ds[segment['type']]+=segment['delay']
  paths.append(dict(launch=path['path'][0]['from'],capture=path['path'][-1]['to'],setup_ns=path['max_delay']-sum(ds.values()),delays_ns=dict(ds)))
 paths.sort(key=lambda x:x['setup_ns'])
 summary[name]=dict(fmax=t['fmax'],timing_summary=t['timing_summary'],complete=e['complete'],unsupported=len(e['unsupported']),endpoint_keys=len(e['endpoints']),failing_setup_rows=sum(x.get('setup_timed',False) and x['setup']<0 for x in rows),failing_related_hold_rows=sum(x.get('hold_related',False) and x['hold']<0 for x in rows),worst_paths=paths[:5],receipt=json.load(open(out/'receipt.json')))
if (p/'budget.json').exists():
 summary['budget']=json.load(open(p/'budget.json'));summary['remaining_incident_seconds']=21600-summary['budget']['charged_seconds']
if (p/'decision.json').exists():summary['decision']=json.load(open(p/'decision.json'))
(p/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ['baseline','candidate']:
 if name in summary:print(name,json.dumps({k:summary[name][k] for k in ['fmax','timing_summary','complete','unsupported','failing_setup_rows','failing_related_hold_rows']}))
print('Remaining',summary.get('remaining_incident_seconds'))
