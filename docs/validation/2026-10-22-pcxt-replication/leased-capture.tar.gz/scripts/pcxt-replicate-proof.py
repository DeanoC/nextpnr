import copy,json,pathlib,sys

def prove(old,new):
 assert old.keys()==new.keys()
 a,b=old['modules'],new['modules'];assert a.keys()==b.keys() and len(a)==1
 a,b=a[next(iter(a))],b[next(iter(b))]
 assert a.keys()==b.keys()
 for key in a.keys()-{'cells','netnames'}:assert a[key]==b[key],key
 ac,bc=a['cells'],b['cells'];assert ac.keys()<=bc.keys()
 added=sorted(bc.keys()-ac.keys());assert added
 aliases={};proof=[]
 for name in added:
  source=name.rsplit('$fanout_copy$',1)[0];assert source in ac
  c,s=bc[name],bc[source]
  assert c['type']==s['type'] and c['type'] in ['MISTRAL_ALUT'+str(i) for i in range(2,7)]
  assert c['parameters']==s['parameters'] and c['port_directions']==s['port_directions']
  assert c['connections'].keys()==s['connections'].keys()
  assert c['port_directions']['Q']=='output' and all(v=='input' for k,v in c['port_directions'].items() if k!='Q')
  cp=json.loads(bytes.fromhex(c['attributes']['FES_PINMAP_V1']));sp=json.loads(bytes.fromhex(s['attributes']['FES_PINMAP_V1']))
  assert cp['pins'].keys()==sp['pins'].keys()
  for pin in cp['pins']:assert cp['pins'][pin][0]==sp['pins'][pin][0]
  assert len(c['connections']['Q'])==len(s['connections']['Q'])==1
  q,sq=c['connections']['Q'][0],s['connections']['Q'][0]
  assert q not in aliases and q!=sq;aliases[q]=sq
  proof.append(dict(copy=name,source=source,type=c['type'],truth_table=c['parameters']['LUT']))
 def norm(bits):
  out=[]
  for bit in bits:
   seen=set()
   while bit in aliases:
    assert bit not in seen;seen.add(bit);bit=aliases[bit]
   out.append(bit)
  return out
 for row in proof:
  c,s=bc[row['copy']],bc[row['source']]
  for pin in c['connections']:
   if pin!='Q':assert norm(c['connections'][pin])==norm(s['connections'][pin])
 for name,c in ac.items():
  n=copy.deepcopy(bc[name]);n['connections']={k:norm(v) for k,v in n['connections'].items()}
  assert c==n,name
 assert a['netnames'].keys()<=b['netnames'].keys()
 for name,net in a['netnames'].items():assert net==b['netnames'][name],name
 assert set(b['netnames'])-set(a['netnames'])=={n+'$Q' for n in added}
 for n in added:assert b['netnames'][n+'$Q']['bits']==bc[n]['connections']['Q']
 return dict(equivalent=True,original_cells=len(ac),copies=proof,original_registers_and_parameters_unchanged=True)

if __name__=='__main__':
 root=pathlib.Path(sys.argv[1]);a=json.load(open(root/'baseline/placed.json'));b=json.load(open(root/'candidate/placed.json'))
 result=prove(a,b)
 mutant=copy.deepcopy(b);cells=mutant['modules'][next(iter(mutant['modules']))]['cells'];name=result['copies'][0]['copy'];mask=cells[name]['parameters']['LUT'];cells[name]['parameters']['LUT']=('1' if mask[0]=='0' else '0')+mask[1:]
 try:prove(a,mutant)
 except AssertionError:result['changed_mask_mutant_rejected']=True
 else:raise AssertionError('changed LUT accepted')
 (root/'equivalence.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
