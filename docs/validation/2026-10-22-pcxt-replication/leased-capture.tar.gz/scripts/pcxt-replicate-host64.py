from pathlib import Path
import json,subprocess,time,hashlib
root=Path('/tmp/pcxt-replicate-host64-20261022');root.mkdir(exist_ok=False)
cmd=json.loads(Path('/tmp/pcxt-replicate-final-20261022/candidate/invocation.json').read_text())['argv']
cmd[cmd.index('--critical-swap-budget')+1]='64'
(root/'invocation.json').write_text(json.dumps({'argv':cmd,'route_seconds':0,'hardware':False},indent=2)+'\n')
start=time.monotonic()
with (root/'nextpnr.log').open('w') as log:
 r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=600)
(root/'receipt.json').write_text(json.dumps({'returncode':r.returncode,'wall_seconds':time.monotonic()-start,'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.json')}},indent=2)+'\n')
print('host-only64 exit',r.returncode)
