from pathlib import Path
import json,subprocess,time,hashlib,os
root=Path('/tmp/pcxt-replicate-cpu-reference-20261022');root.mkdir(exist_ok=False)
old=Path('/tmp/pcxt-replicate-routes-20261022')
env=dict(os.environ);env.pop('NEXTPNR_REQUIRE_GPU',None)
for name in ['baseline','candidate']:
 out=root/name;out.mkdir()
 cmd=json.loads((old/name/'receipt.json').read_text())['command']
 cmd[0]='/tmp/pcxt-replicate-final-20261022/nextpnr-mistral'
 cmd+=['--gpu-cpu']
 receipt={'command':cmd,'evidence':'CPU reference diagnostic only','timeout':600,'binary_sha256':hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()}
 start=time.monotonic()
 try:
  with (out/'nextpnr.log').open('w') as log:
   r=subprocess.run(cmd,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
  receipt['returncode']=r.returncode
 except subprocess.TimeoutExpired:receipt['timeout_expired']=True
 receipt['wall_seconds']=time.monotonic()-start
 receipt['artifacts']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.json')}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,receipt.get('returncode'),receipt['wall_seconds'],flush=True)
