#!/bin/bash
set -eu
python3 /home/deano/harnesses/pcxt-compiler-repair/nextpnr/mistral/routed_swap.py \
 --binary /tmp/pcxt-replicate-final-20261022/nextpnr-mistral \
 --json /tmp/pcxt-replicate-final-20261022/input.json \
 --qsf /tmp/pcxt-pad-timing-20261022/source/sources/misteross/cores/fes-ramtest/constraints.qsf \
 --sdc /tmp/pcxt-pad-timing-20261022/source/sources/misteross/boards/de10nano/clocks.sdc \
 --guidance /tmp/pcxt-replicate-final-20261022/guidance.json \
 --output /tmp/pcxt-replicate-leased-20261022 \
 --device 5CSEBA6U23I7 --budget 32 --replicate --seed 1 --freq 100 \
 --router gpu --runner-root /home/deano/harnesses/worktrees/fes/silver-delta/out/dev/pcxt-board/sources/misteross \
 --timeout 600 --route-budget 21600
