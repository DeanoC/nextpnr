#ifndef VERSION_H
#define VERSION_H

#define GIT_DESCRIBE_STR "nextpnr-0.11.1-641-g6d02e632"

#endif
