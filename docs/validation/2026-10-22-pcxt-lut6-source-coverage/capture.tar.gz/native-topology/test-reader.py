from pathlib import Path
import json,hashlib,subprocess,copy,time
H=Path(__file__).resolve().parent;R=H.parent/'routed-lut6-swap-20261022/route-default/routed.json';D=H/'reader-validation';D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();raw=json.loads(R.read_text());m=next(iter(raw['modules'].values()));name='system.machine.cpu.cpu.u_eu_core.u_operand1_mux.lanes[10].combine';nets=[]
for pin in ('B','F'):
 bit=m['cells'][name]['connections'][pin][0];aliases=sorted(n for n,x in m['netnames'].items() if x['bits']==[bit]);drivers=[];users=[]
 for n,c in m['cells'].items():
  for p,bits in c['connections'].items():
   if bits==[bit]:
    if c['port_directions'][p]=='output':drivers.append({'cell':n,'port':p})
    elif c['port_directions'][p]=='input':users.append({'cell':n,'port':p})
    else:assert False
 assert len(drivers)==len(users)==1
 nets.append({'name':aliases[0],'aliases':aliases,'driver':drivers[0],'users':users,'bit':bit})
selection=D/'selection.json';selection.write_text(json.dumps({'schema':1,'nets':nets},sort_keys=True,indent=2)+'\n')
records=[]
def run(label,input_path,sel):
 output=D/(label+'-result.json');cmd=[str(H/'tree-reader'),str(input_path),str(sel),str(output)];start=time.monotonic()
 with (D/(label+'.log')).open('w') as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 records.append({'case':label,'argv':cmd,'returncode':result.returncode,'wall_seconds':time.monotonic()-start,'input_sha256':sha(input_path),'selection_sha256':sha(sel),'log_sha256':sha(D/(label+'.log'))})
 return result.returncode,output
rc,output=run('original-positive',R,selection);assert rc==0;proof=json.loads(output.read_text());assert proof['pass'];tree=proof['trees'][0]
for label,removed in [('missing_native_source',tree['driver']['source_wire']),('missing_native_sink',tree['complete_users'][0]['physical_sink_wires'][0])]:
 changed=copy.deepcopy(raw);module=next(iter(changed['modules'].values()));bit=nets[0]['bit']
 for alias,net in module['netnames'].items():
  if net['bits']!=[bit]:continue
  pieces=net['attributes']['ROUTING'].split(';');rows=[pieces[i:i+3] for i in range(0,len(pieces),3)];assert len([row for row in rows if row[0]==removed])==1;net['attributes']['ROUTING']=';'.join(item for row in rows if row[0]!=removed for item in row)
 path=D/(label+'.json');path.write_text(json.dumps(changed)+'\n');rc,out=run(label,path,selection);assert rc!=0 and not out.exists()
bad=copy.deepcopy({'schema':1,'nets':nets});bad['nets'][0]['users'][0]['port']='A';bad_selection=D/'wrong-user-selection.json';bad_selection.write_text(json.dumps(bad)+'\n');rc,out=run('wrong_complete_user',R,bad_selection);assert rc!=0 and not out.exists()
receipt={'pass':True,'helper_sha256':sha(H/'tree-reader'),'reference_sha256':sha(R),'records':records,'scope':'Host-only reader positive and actual corrupted-checkpoint/selection rejection tests; no route or timing claim'};(D/'receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print('PASS original and three native rejection cases')
