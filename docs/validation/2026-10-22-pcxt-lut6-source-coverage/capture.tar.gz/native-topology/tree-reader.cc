// Native topology only: no configuration, timing, placement or routing call.
#include "nextpnr.h"
#include "json_frontend.h"
#include "json11.hpp"
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
USING_NEXTPNR_NAMESPACE
using J=json11::Json;
static void need(bool value,const std::string &reason){if(!value)throw std::runtime_error(reason);}
static J read(const char *p){std::ifstream f(p);need(bool(f),"missing selection");std::string error;auto j=J::parse(std::string(std::istreambuf_iterator<char>(f),{}),error);need(error.empty(),error);return j;}
int main(int argc,char **argv){try{
 need(argc==4,"Usage: tree-reader routed.json selection.json output.json");
 ArchArgs args;args.device="5CSEBA6U23I7";Context c(args);std::ifstream in(argv[1]);need(parse_json(in,argv[1],&c),"JSON read failed");
 need(c.attrs.at(id_step).as_string()=="route","requires final routed checkpoint");
 for(auto &entry:c.cells)need(c.restore_cell_pin_map(entry.second.get()),"missing saved physical pin map");
 auto selection=read(argv[2]);need(selection["schema"].int_value()==1,"selection schema");auto selected=selection["nets"].array_items();
 need(!selected.empty()&&selected.size()<=32,"expected one to 32 selected changed nets");
 std::set<NetInfo*> distinct;J::array trees;
 for(const auto &item:selected){
  auto alias=item["name"].string_value();auto *net=c.getNetByAlias(c.id(alias));need(net&&distinct.insert(net).second,"missing or duplicate selected net");
  auto *driver=net->driver.cell;need(driver&&driver->getPort(net->driver.port)==net,"missing native driver backreference");
  need(driver->name.str(&c)==item["driver"]["cell"].string_value()&&net->driver.port.str(&c)==item["driver"]["port"].string_value(),"unexpected native driver");
  auto root=c.getNetinfoSourceWire(net);need(root!=WireId()&&net->wires.count(root),"missing native source wire");
  std::set<std::string> aliases,expected_aliases;for(const auto &a:c.net_aliases)if(a.second==net->name)aliases.insert(a.first.str(&c));
  for(const auto &a:item["aliases"].array_items()) { need(expected_aliases.insert(a.string_value()).second,"duplicate expected alias"); }
  need(aliases==expected_aliases,"complete alias inventory differs");
  std::set<std::pair<std::string,std::string>> expected_users,actual_users;
  for(const auto &u:item["users"].array_items())need(expected_users.emplace(u["cell"].string_value(),u["port"].string_value()).second,"duplicate expected user");
  J::object wires;J::array users;int roots=0;
  for(const auto &entry:net->wires){auto wire=entry.first;auto pip=entry.second.pip;need(c.getBoundWireNet(wire)==net,"foreign wire ownership");
   need(entry.second.strength<=STRENGTH_STRONG,"protected selected wire");J::object row{{"strength",int(entry.second.strength)}};
   if(pip==PipId()){++roots;need(wire==root,"additional or wrong root");row["pip"]=J();}
   else{auto src=c.getPipSrcWire(pip),dst=c.getPipDstWire(pip);need(dst==wire&&net->wires.count(src),"pip not joining saved endpoints");need(c.getBoundPipNet(pip)==net,"foreign pip ownership");row["pip"]=c.getPipName(pip).str(&c);row["source"]=c.getWireName(src).str(&c);row["destination"]=c.getWireName(dst).str(&c);}
   std::set<WireId> seen;for(auto cursor=wire;cursor!=root;){need(seen.insert(cursor).second,"route cycle");auto at=net->wires.find(cursor);need(at!=net->wires.end()&&at->second.pip!=PipId(),"disconnected route component");cursor=c.getPipSrcWire(at->second.pip);}wires.emplace(c.getWireName(wire).str(&c),row);
  }
  need(roots==1,"wrong root count");
  for(const auto &u:net->users){need(u.cell&&u.cell->ports.count(u.port),"missing user");const auto &port=u.cell->ports.at(u.port);need(port.net==net&&port.type==PORT_IN&&net->users.count(port.user_idx),"broken user slot");auto stored=net->users.at(port.user_idx);need(stored.cell==u.cell&&stored.port==u.port,"wrong indexed user backreference");
   need(actual_users.emplace(u.cell->name.str(&c),u.port.str(&c)).second,"duplicate logical user");auto all=c.getNetinfoSinkWires(net,u);need(all.size()!=0,"user has no native physical sinks");std::set<std::string> sinks;for(auto wire:all){need(net->wires.count(wire),"unreached native physical sink");sinks.insert(c.getWireName(wire).str(&c));}
   J::array sink_rows;for(const auto &s:sinks)sink_rows.push_back(s);users.push_back(J::object{{"cell",u.cell->name.str(&c)},{"port",u.port.str(&c)},{"physical_sink_wires",sink_rows}});
  }
  need(actual_users==expected_users&&actual_users.size()==1,"complete single-sink inventory differs");
  for(const auto &p:c.ports)need(p.second.net!=net,"unexpected public observer");
  J::array alias_rows;for(const auto &a:aliases)alias_rows.push_back(a);
  trees.push_back(J::object{{"selected_alias",alias},{"canonical_net",net->name.str(&c)},{"complete_aliases",alias_rows},{"driver",J::object{{"cell",driver->name.str(&c)},{"port",net->driver.port.str(&c)},{"source_wire",c.getWireName(root).str(&c)}}},{"complete_users",users},{"complete_tree",wires},{"all_native_sinks_reached",true},{"single_acyclic_source_root",true},{"foreign_ownership_absent",true}});
 }
 std::ofstream out(argv[3]);out<<J(J::object{{"pass",true},{"trees",trees},{"scope","Read-only native pip/source/sink interpretation of exact selected saved trees; no timing, configuration, route or RBF execution"}}).dump()<<"\n";return 0;
}catch(const std::exception &e){std::cerr<<"REJECTED: "<<e.what()<<"\n";return 1;}}
