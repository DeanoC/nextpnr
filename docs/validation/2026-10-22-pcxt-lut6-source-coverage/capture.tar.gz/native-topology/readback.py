#!/usr/bin/env python3
"""Run native topology interpretation only after complete paired graph proof."""
from pathlib import Path
import hashlib,json,subprocess,time
H=Path(__file__).resolve().parent; R=H.parent/'lut6-source-coverage-20261022'; P=R/'final-analysis/graph-proof.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(H/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
proof=json.loads(P.read_text()); assert proof['status']=='pass'; assert set(proof['graph_sha256'])=={'default','swap16'}
for case,want in proof['graph_sha256'].items():assert sha(R/f'route-{case}'/'routed.json')==want
build=json.loads((H/'build-receipt.json').read_text());assert build['pass'];assert sha(H/'tree-reader')==build['helper_binary_sha256'];assert sha(H/'tree-reader.cc')==build['helper_source_sha256'];assert sha(H/'frozen-manifest.json')==build['frozen_manifest_sha256']
accepted=proof['accepted_cells'];selected={case:[] for case in ['default','swap16']};bits=set()
for cell in accepted:
 assert len(cell['driver_user_alias_boundary'])==2
 for boundary in cell['driver_user_alias_boundary']:
  bit=boundary['bit'];assert bit not in bits;bits.add(bit);aliases=boundary['aliases'];assert aliases==sorted(set(aliases)) and aliases
  driver=boundary['drivers'];assert len(driver)==1 and driver[0][2]==0
  for case,key in [('default','before_users'),('swap16','after_users')]:
   users=boundary[key];assert len(users)==1 and users[0][2]==0
   selected[case].append({'name':aliases[0],'bit':bit,'aliases':aliases,'driver':{'cell':driver[0][0],'port':driver[0][1]},'users':[{'cell':u[0],'port':u[1]} for u in users]})
assert bits==set(proof['changed_canonical_net_bits'])
if not bits:
 save('readback-receipt.json',{'not_needed':True,'reason':'Complete graph proof records no accepted swap or changed route tree','graph_proof_sha256':sha(P)});print('No accepted swap: topology readback not needed.');raise SystemExit
outputs={};commands=[];started=time.monotonic()
for case,nets in selected.items():
 selection=H/f'{case}-selection.json';save(selection.name,{'schema':1,'nets':sorted(nets,key=lambda n:n['bit']),'graph_proof_sha256':sha(P)})
 output=H/f'{case}-topology.json';command=[str(H/'tree-reader'),str(R/f'route-{case}'/'routed.json'),str(selection),str(output)]
 with (H/f'{case}-topology.log').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 assert result.returncode==0,case
 data=json.loads(output.read_text());assert data['pass'] and len(data['trees'])==len(nets)
 outputs[case]=data;commands.append({'argv':command,'returncode':result.returncode,'selection_sha256':sha(selection),'output_sha256':sha(output)})
old={row['selected_alias']:row for row in outputs['default']['trees']};new={row['selected_alias']:row for row in outputs['swap16']['trees']};assert old.keys()==new.keys()
for name,before in old.items():
 after=new[name];assert before['driver']==after['driver'];assert before['complete_aliases']==after['complete_aliases'];root=before['driver']['source_wire'];assert before['complete_tree'][root]==after['complete_tree'][root]
 assert before['complete_users']!=after['complete_users'];assert before['complete_tree']!=after['complete_tree']
for case,want in proof['graph_sha256'].items():assert sha(R/f'route-{case}'/'routed.json')==want
save('readback-receipt.json',{'pass':True,'selected_nets':len(bits),'commands':commands,'build_receipt_sha256':sha(H/'build-receipt.json'),'graph_proof_sha256':sha(P),'helper_sha256':sha(H/'tree-reader'),'source_commit':build['source_commit'],'source_root_and_strength_unchanged':True,'wall_seconds':time.monotonic()-started,'charged_route_seconds':0,'scope':'Native physical source/pip/sink topology readback; no timing/configuration/RBF/hardware acceptance'})
print('PASS',len(bits),'complete selected trees in both graphs')
