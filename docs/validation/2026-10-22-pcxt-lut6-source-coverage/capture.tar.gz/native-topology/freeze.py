from pathlib import Path
import subprocess,json,hashlib,shutil
H=Path(__file__).resolve().parent;S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr'); B=S.parent/'build-candidate'; E=H.parent/'lut6-source-coverage-20261022';P=json.loads((E/'board-eligibility/build-plan.json').read_text());manifest={}; commit='243c829c'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(original,data,provenance):
 dest=H/'frozen'/str(original).lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 manifest[str(original)]={'copy':str(dest.relative_to(H)),'sha256':sha(dest),'bytes':len(data),'provenance':provenance}
 return str(dest)
for rel in subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=S,text=True).splitlines():
 if Path(rel).suffix not in ('.h','.hh','.hpp','.ipp','.inc'):continue
 data=subprocess.check_output(['git','show',f'{commit}:{rel}'],cwd=S);save(S/rel,data,'git:'+commit)
# Generated device/model headers and version are captured from the frozen build.
includes=[]
for arg in P['compile']:
 if arg.startswith('-I'):
  path=Path(arg[2:]).resolve()
  if path.exists() and not path.is_relative_to(S):includes.append(path)
for path in includes:
 for p in path.rglob('*'):
  if p.is_file() and p.suffix in ('.h','.hpp','.hh','.ipp','.inc'):save(p.resolve(),p.read_bytes(),'frozen build/model include')
for name,want in P['object_hashes'].items():
 p=Path(name);assert sha(p)==want,name; save(p,p.read_bytes(),'frozen e94f build object');assert sha(p)==want,name
out={'source_commit':subprocess.check_output(['git','rev-parse',commit],cwd=S,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse',commit+'^{tree}'],cwd=S,text=True).strip(),'production_sha256':P['binary_sha256'],'board_plan_sha256':sha(E/'board-eligibility/build-plan.json'),'files':manifest}
(H/'frozen-manifest.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print('FROZEN',len(manifest),'files',sha(H/'frozen-manifest.json'))
