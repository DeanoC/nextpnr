# Native CPU route topology readback

This isolated host helper reads final routed checkpoints and interprets selected route trees with native Mistral pip, source-wire and sink-wire APIs. It does not configure a bitstream, run timing, place cells, reroute nets or access a kit.

The compile surface is a private snapshot of committed nextpnr `243c829c` headers and the 81 link objects used by the frozen `e94f638e` production binary. `frozen-manifest.json` records every copied file and its provenance. Later compiler edits and shared builds are independent. `initial-build-failed-api.log` retains the initial helper API error; the correction uses the native SSOArray size API.

`readback.py` may run only after the complete paired graph proof at `../lut6-source-coverage-20261022/final-analysis/graph-proof.json`. It verifies both routed input hashes and uses precisely that proof's accepted-cell net boundaries, with exact equality to the complete changed-net inventory. If no swap was accepted it records that readback is unnecessary. Otherwise it checks every affected net in both graphs, including complete aliases, driver and indexed users, physical sink reachability, actual native pip endpoints and ownership, a single unchanged driver root and strength, and absence of disconnected components or cycles.

This supplements the complete serialized graph proof. It does not establish electrical delay, final native timing, RBF encoding, or hardware acceptance. Native indexed-store holes are rebuilt by the checkpoint reader and are covered separately by the transaction regression tests.
