#!/usr/bin/env python3
"""Immutable compact capture; verifies every member and exact offline replay."""
from pathlib import Path
import gzip
import hashlib
import io
import os
import json
import shutil
import subprocess
import sys
import tarfile
import tempfile
from support import HERE, ROOT, need, read, sha, paired_receipts, reference_folder

CAPTURE = HERE / 'capture'
SOURCE = CAPTURE / 'source'


def main():
    need(not CAPTURE.exists(), 'capture already exists; never overwrite immutable evidence')
    receipts = paired_receipts()
    need(read(HERE / 'summary.json')['status'] in ('complete_no_improvement','complete_local_improvement'), 'complete summary missing')
    need(read(HERE / 'graph-proof.json')['status'] == 'pass', 'complete graph proof missing')
    need(read(HERE / 'source-control-proof.json')['status'] == 'pass', 'source/control proof missing')
    need(read(HERE / 'checker-tests.json')['status'] == 'pass', 'checker self-tests missing')
    need(read(HERE / 'topology-proof.json')['status'] == 'pass', 'complete topology proof missing')
    need(read(ROOT / 'root-topology-readback/receipt.json')['pass'], 'independent root topology replay missing')
    SOURCE.mkdir(parents=True)
    recorded = {}
    omitted = {}

    def omit(original, reason):
        original = Path(original)
        need(original.is_file() and not original.is_symlink(), 'omitted native asset missing: ' + str(original))
        omitted[str(original)] = {'sha256': sha(original), 'size': original.stat().st_size, 'reason': reason}

    def retain(original, relative):
        original, relative = Path(original), Path(relative)
        need(original.is_file() and not original.is_symlink(), 'not a regular source file: ' + str(original))
        need(not relative.is_absolute() and '..' not in relative.parts, 'unsafe retained path')
        target = SOURCE / relative
        expected = sha(original)
        if target.exists():
            need(sha(target) == expected, 'different retained-path collision')
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, target)
        item = {'retained_path': str(relative), 'sha256': expected}
        if str(original) in recorded:
            need(recorded[str(original)]['sha256'] == expected, 'original source changed during capture')
        else:
            recorded[str(original)] = item

    def folder(original, relative):
        for path in sorted(Path(original).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                retain(path, Path(relative) / path.relative_to(original))

    final = read(ROOT / 'final-validation.json')
    for name, digest in final['files'].items():
        need(sha(ROOT / name) == digest, 'host admission evidence changed')
        retain(ROOT / name, name)
    for name in ('final-validation.json', 'committed-source-verification.json', 'reference-host-files.json',
                 'route.py', 'record-routes.py', 'route-accounting.json'):
        retain(ROOT / name, name)
    for name in ('route-default', 'route-swap16'):
        expected = set(read(ROOT/name/'receipt.json')['artifacts']) | {'receipt.json'}
        need({p.name for p in (ROOT/name).iterdir()} == expected, 'unexpected route file inventory')
        folder(ROOT/name, name)
    folder(ROOT/'independent-review', 'independent-review')
    folder(ROOT/'root-topology-readback', 'root-topology-readback')
    native = ROOT.parent/'cpu-route-topology-20261022'
    native_frozen = read(native/'frozen-manifest.json')
    for path in sorted(native.iterdir()):
        if not path.is_file(): continue
        if path.name in ('tree-reader','tree-reader.o'):
            omit(path, 'Native topology executable or build object; original identity retained, not executed offline')
        else: retain(path, Path('native-topology')/path.name)
    folder(native/'reader-validation', 'native-topology/reader-validation')
    # Keep all positive and mutated reader checkpoints, with their original hashes.
    reader_tests = read(native/'reader-validation/receipt.json')
    for rec in reader_tests['records']:
        path = Path(rec['argv'][1]); need(sha(path) == rec['input_sha256'], 'reader input identity changed')
        if str(path) not in recorded: retain(path, Path('references/reader-original.json'))
    for info in native_frozen['files'].values():
        path = native/info['copy']; need(sha(path) == info['sha256'], 'frozen topology compile surface changed')
        if path.suffix in ('.o','.a'):
            omit(path, 'Frozen native link object/library; exact hash retained in frozen-manifest, no archive execution')
        else: retain(path, Path('native-topology')/info['copy'])
    omit(ROOT/'nextpnr-mistral', 'Original production compiler omitted; full original source/binary receipts retained')
    omit(ROOT/'board-eligibility/native-probe', 'Original native eligibility helper omitted; two exact executions recorded')
    omit(ROOT/'board-eligibility/probe.o', 'Original native eligibility helper build object omitted')
    old = ROOT.parent / 'lut6-upstream-coverage-20261022'
    for path in sorted(old.iterdir()):
        if path.is_file() and path.name not in ('native-probe','probe.o'):
            retain(path, Path('counterexample') / path.name)
    omit(old/'native-probe', 'Original972 counterexample executable omitted; result and compiler identity retained')
    omit(old/'probe.o', 'Original972 counterexample helper build object omitted')
    for name in ('final-validation.json','source-commit-check.json'):
        retain(ROOT.parent/'routethrough-cache-20261022'/name, Path('references/cache-host')/name)
    for path in sorted((ROOT.parent/'routethrough-cache-20261022/source-validation/source').rglob('*')):
        if path.is_file():retain(path, Path('references/cache-source')/path.relative_to(ROOT.parent/'routethrough-cache-20261022/source-validation/source'))
    board = read(ROOT/'board-eligibility/build-plan.json')
    retain(board['input'], 'references/cache-placed.json')
    previous = read(ROOT/'reference-host-files.json')['predicted_timing']
    retain(previous['path'], 'references/cache-predicted-timing.json')
    for path in sorted(HERE.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.log', '.md'):
            retain(path, Path('final-analysis') / path.name)
    retain(HERE / 'README.md', 'README.md')
    references = {}
    all_receipts = list(receipts.values())
    for kind in ('route',):
        original = reference_folder(kind)
        relative = 'references/prior13' if kind == 'route' else 'references/prior-preparation'
        folder(original, relative)
        references[kind] = {'original_directory': str(original), 'retained_path': relative}
        all_receipts.append(read(original / 'receipt.json'))
    all_receipts += [read(ROOT / name / 'receipt.json') for name in ('prepare-default', 'prepare-zero')]
    for receipt in all_receipts:
        for info in receipt['inputs'].values():
            original = Path(info['path'])
            need(sha(original) == info['sha256'], 'external input digest differs')
            retain(original, Path('external-inputs') / (info['sha256'] + '-' + original.name))
    for receipt in receipts.values():
        for path, expected in receipt['immutable_evidence_sha256'].items():
            need(path in recorded and recorded[path]['sha256'] == expected, 'missing immutable recorded identity: ' + path)
    mode = {'scope': 'Exact offline replay of captured sources, graph and native reports. No original-path fallback or compiler execution.',
            'excluded_binary': {'original_path': receipts['default']['nextpnr_command'][0], 'sha256': receipts['default']['binary_sha256']},
            'excluded_binary_reason': 'Executable/object trees omitted; original binary hash and all21 frozen source identities remain bound.',
            'excluded_board_probe': {'sha256': read(ROOT/'board-eligibility/receipt.json')['files']['native-probe']},
            'excluded_counterexample_probe': {'sha256': read(old/'receipt.json')['files']['native-probe']},
            'references': references, 'recorded_files': recorded,
            'topology_original_directory': str(native), 'omitted_native_files': omitted,
            'omission_policy': 'Only executable/object/library payloads and Python bytecode caches are omitted. All mutated reader checkpoint payloads are retained. No native execution is performed by offline checks.',
            'recorded_only_native_identities': {'native_test_sha256': final['native_test_sha256'],
                'board_probe_object_hashes': board['object_hashes'],
                'counterexample_object_hashes': read(old/'build-plan.json')['object_hashes']}}
    (SOURCE / 'archive-mode.json').write_text(json.dumps(mode, indent=2, sort_keys=True) + '\n')
    files = [path for path in sorted(SOURCE.rglob('*')) if path.is_file()]
    manifest = {str(path.relative_to(SOURCE)): {'sha256': sha(path), 'size': path.stat().st_size} for path in files}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    (SOURCE / 'manifest.json').write_bytes(manifest_bytes)
    archive = CAPTURE / 'capture.tar.gz'
    with archive.open('wb') as stream, gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0, compresslevel=6) as compressed, tarfile.open(fileobj=compressed, mode='w|') as tar:
        for path in files:
            payload = path.read_bytes()
            info = tarfile.TarInfo(str(path.relative_to(SOURCE)))
            info.size = len(payload); info.mode = 0o644; info.mtime = 0
            tar.addfile(info, io.BytesIO(payload))
        info = tarfile.TarInfo('manifest.json'); info.size = len(manifest_bytes); info.mode = 0o644; info.mtime = 0
        tar.addfile(info, io.BytesIO(manifest_bytes))
    need(archive.stat().st_size < 100_000_000, 'capture exceeds100MB; retain it and choose explicit reviewed compaction')
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar.getmembers():
            relative = Path(member.name)
            need(member.isfile() and not relative.is_absolute() and '..' not in relative.parts, 'unsafe archive member')
        need(set(tar.getnames()) == set(manifest) | {'manifest.json'} and len(tar.getnames()) == len(manifest) + 1, 'archive member inventory differs')
        for name, item in manifest.items():
            payload = tar.extractfile(name).read()
            need(len(payload) == item['size'] and hashlib.sha256(payload).hexdigest() == item['sha256'], 'archive readback differs: ' + name)
        need(tar.extractfile('manifest.json').read() == manifest_bytes, 'embedded manifest differs')
    readback = {'status': 'pass', 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
                'verified_members_including_manifest': len(manifest) + 1, 'manifest_sha256': sha(SOURCE / 'manifest.json')}
    (CAPTURE / 'archive-readback.json').write_text(json.dumps(readback, indent=2, sort_keys=True) + '\n')
    extraction = Path(tempfile.mkdtemp(prefix='pcxt-lut6-origin-offline-', dir='/tmp'))
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar.getmembers():
            relative = Path(member.name)
            need(member.isfile() and not relative.is_absolute() and '..' not in relative.parts, 'unsafe extraction member')
        tar.extractall(extraction, filter='data')
    need({str(p.relative_to(extraction)) for p in extraction.rglob('*') if p.is_file()} == set(manifest) | {'manifest.json'}, 'fresh extraction inventory differs')
    for name, item in manifest.items():
        need(sha(extraction/name) == item['sha256'] and (extraction/name).stat().st_size == item['size'], 'fresh extraction bytes differ: ' + name)
    checks = []
    for script, outputs in (
        ('verify_sources.py', ['source-control-proof.json']),
        ('test_checks.py', ['checker-tests.json']),
        ('prove_graph.py', ['graph-proof.json', 'decision-ledger.json']),
        ('compare_timing.py', ['route-comparison.json']),
        ('summarize.py', ['summary.json']),
        ('verify_topology.py', ['topology-proof.json']),
    ):
        expected = {name: (extraction / 'final-analysis' / name).read_bytes() for name in outputs}
        completed = subprocess.run([sys.executable, str(extraction / 'final-analysis' / script)], cwd='/tmp',
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                   env={**os.environ, 'PYTHONDONTWRITEBYTECODE':'1'})
        (CAPTURE / ('offline-' + script + '.log')).write_text(completed.stdout)
        need(completed.returncode == 0, 'offline check failed: ' + script + '; retained ' + str(extraction))
        for name, payload in expected.items():
            need((extraction / 'final-analysis' / name).read_bytes() == payload, 'offline proof bytes differ: ' + name)
        checks.append({'script': script, 'returncode': 0, 'outputs': outputs, 'all_proof_bytes_identical': True})
    for path, item in recorded.items():
        need(sha(path) == item['sha256'], 'original evidence changed during capture')
    need(sha(ROOT / 'nextpnr-mistral') == mode['excluded_binary']['sha256'], 'original binary changed during capture')
    for path, item in omitted.items():
        need(sha(path) == item['sha256'], 'omitted original native payload changed during capture')
    result = {**readback, 'offline_extraction': str(extraction), 'all_offline_checks': checks,
              'scope': 'Complete retained source/control/graph/timing/topology receipt verification without compiler/device-model execution; no reroute, native replay or hardware acceptance.',
              'all_mutated_checkpoint_payloads_retained': True, 'explicit_omitted_native_files': len(omitted)}
    (CAPTURE / 'offline-readback.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
