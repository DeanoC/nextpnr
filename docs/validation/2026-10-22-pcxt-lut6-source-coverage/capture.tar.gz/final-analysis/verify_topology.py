#!/usr/bin/env python3
"""Offline verification of recorded native topology; never executes a compiler."""
from pathlib import Path
from copy import deepcopy
from support import ROOT,HERE,read,sha,need,write,verify_recorded,archive_mode
from prove_graph import graph_edges,route_tree


def native_directory():
    return ROOT/'native-topology' if archive_mode() else ROOT.parent/'cpu-route-topology-20261022'


def verify_asset(path, expected):
    mode=archive_mode()
    if path.exists():
        need(sha(path)==expected,'native retained asset hash differs: '+str(path));return
    need(mode is not None,'missing native original asset')
    relative=path.relative_to(ROOT/'native-topology')
    original=str(Path(mode['topology_original_directory'])/relative)
    need(mode['omitted_native_files'].get(original,{}).get('sha256')==expected,'missing explicit native omitted identity: '+original)


def verify_tree(tree,expected,raw):
    need(tree['selected_alias']==expected['name'] and tree['complete_aliases']==expected['aliases'],'native complete aliases differ')
    need(tree['driver']['cell']==expected['driver']['cell'] and tree['driver']['port']==expected['driver']['port'],'native driver differs')
    need(tree['complete_users'] and [{'cell':u['cell'],'port':u['port']} for u in tree['complete_users']]==expected['users'],'native complete users differ')
    root=tree['driver']['source_wire']; wires=tree['complete_tree']
    need(raw is not None and set(wires)==set(raw),'complete native/saved wire inventory differs')
    need(root in wires and {w for w,d in wires.items() if d['pip'] is None}=={root},'missing or multiple native roots')
    pips=set()
    for wire,row in wires.items():
        need(row['strength'] in (0,1,2) and raw[wire]==[row['pip'] or '',row['strength']],'native pip/strength differs')
        if row['pip'] is None:
            need(set(row)=={'pip','strength'},'unexpected root fields')
        else:
            need(set(row)=={'pip','strength','source','destination'},'missing native pip endpoint fields')
            need(row['destination']==wire and row['source'] in wires,'native pip endpoints do not join saved tree')
            need(row['pip']==row['source']+'.'+row['destination'],'native pip name/endpoints differ')
            need(row['pip'] not in pips,'duplicate native pip');pips.add(row['pip'])
        seen=set();cursor=wire
        while cursor!=root:
            need(cursor not in seen and cursor in wires,'cycle/disconnected native tree');seen.add(cursor)
            need(wires[cursor]['pip'] is not None,'extra native root');cursor=wires[cursor]['source']
    for user in tree['complete_users']:
        need(user['physical_sink_wires'] and len(user['physical_sink_wires'])==len(set(user['physical_sink_wires'])),'empty/duplicate native physical sinks')
        need(set(user['physical_sink_wires'])<=set(wires),'missing native physical sink')
    need(tree['all_native_sinks_reached'] and tree['single_acyclic_source_root'] and tree['foreign_ownership_absent'],'original native topology execution failed')


def main():
    n=native_directory();build=read(n/'build-receipt.json');capture=read(n/'readback-receipt.json');graph=read(HERE/'graph-proof.json')
    need(build['pass'] and capture['pass'] and graph['status']=='pass','missing complete native/graph proof')
    final=read(ROOT/'final-validation.json');commit=read(ROOT/'committed-source-verification.json')
    need(build['source_commit']==commit['commit'] and build['production_binary_sha256']==final['binary_sha256'],'native reader/compiler source identity differs')
    for name,key in [('tree-reader','helper_binary_sha256'),('tree-reader.cc','helper_source_sha256'),('frozen-manifest.json','frozen_manifest_sha256'),('build-commands.json','build_commands_sha256'),('build.log','build_log_sha256')]:verify_asset(n/name,build[key])
    need(capture['build_receipt_sha256']==sha(n/'build-receipt.json') and capture['helper_sha256']==build['helper_binary_sha256'],'native run/build identity differs')
    need(capture['graph_proof_sha256']==sha(HERE/'graph-proof.json'),'native selection graph proof differs')
    frozen=read(n/'frozen-manifest.json');need(frozen['source_commit']==commit['commit'] and frozen['tree']==commit['tree'] and frozen['production_sha256']==final['binary_sha256'],'native compile surface differs')
    header_count=object_count=0
    for info in frozen['files'].values():
        verify_asset(n/info['copy'],info['sha256'])
        if Path(info['copy']).suffix in ('.o','.a'):object_count+=1
        else:header_count+=1
    need(object_count==81 and header_count==310,'native source/object inventory differs')
    root=read(ROOT/'root-topology-readback/receipt.json')
    need(root['pass'] and root['helper_sha256']==build['helper_binary_sha256'] and root['independent_receipt_sha256']==sha(n/'readback-receipt.json'),'root native replay binding differs')
    need({x['case'] for x in root['results']}=={'default','swap16'} and len(root['results'])==2,'root native replay inventory differs')
    expected_by_case={k:[] for k in ('default','swap16')};changed=set()
    for cell in graph['accepted_cells']:
        need(len(cell['driver_user_alias_boundary'])==2,'transposition input boundary differs')
        for b in cell['driver_user_alias_boundary']:
            need(b['bit'] not in changed and len(b['drivers'])==1,'duplicate changed net or driver');changed.add(b['bit'])
            for case,users in [('default',b['before_users']),('swap16',b['after_users'])]:
                need(len(users)==1 and users[0][2]==0 and b['drivers'][0][2]==0,'not scalar single-sink selection')
                expected_by_case[case].append({'name':b['aliases'][0],'bit':b['bit'],'aliases':b['aliases'],'driver':{'cell':b['drivers'][0][0],'port':b['drivers'][0][1]},'users':[{'cell':u[0],'port':u[1]}for u in users]})
    need(changed==set(graph['changed_canonical_net_bits']) and len(changed)==capture['selected_nets'],'complete changed-net inventory differs')
    outcomes={};trees={}
    for case in ('default','swap16'):
        source=ROOT/('route-'+case)/'routed.json';need(sha(source)==graph['graph_sha256'][case],'routed input changed')
        selection=read(n/(case+'-selection.json'));expected=sorted(expected_by_case[case],key=lambda x:x['bit'])
        need(selection=={'schema':1,'nets':expected,'graph_proof_sha256':sha(HERE/'graph-proof.json')},'native exact selection differs')
        command=[x for x in capture['commands'] if Path(x['argv'][-1]).name==case+'-topology.json'];need(len(command)==1,'native command inventory')
        command=command[0];need(command['returncode']==0 and command['selection_sha256']==sha(n/(case+'-selection.json')) and command['output_sha256']==sha(n/(case+'-topology.json')),'native command hashes/result differ')
        independent=read(n/(case+'-topology.json'));need(independent['pass'] and len(independent['trees'])==len(expected),'native result inventory differs')
        root_record=next(x for x in root['results'] if x['case']==case)
        need(root_record['returncode']==0 and root_record['matches_independent_readback_bytes'] and root_record['result_sha256']==sha(ROOT/'root-topology-readback'/(case+'.json')),'root topology execution differs')
        need((n/(case+'-topology.json')).read_bytes()==(ROOT/'root-topology-readback'/(case+'.json')).read_bytes(),'root native replay bytes differ')
        module=next(iter(read(source)['modules'].values()));users,drivers,aliases,public=graph_edges(module)
        by_name={t['selected_alias']:t for t in independent['trees']};need(len(by_name)==len(expected),'duplicate native trees')
        outcomes[case]=[];trees[case]=by_name
        for chosen in expected:
            bit=chosen['bit'];need(aliases[bit]==chosen['aliases'] and bit not in public,'complete native aliases/public inventory differs')
            need(drivers[bit]==[[chosen['driver']['cell'],chosen['driver']['port'],0]] and users[bit]==[[chosen['users'][0]['cell'],chosen['users'][0]['port'],0]],'saved driver/user inventory differs')
            raw=[route_tree(module['netnames'][a]['attributes']['ROUTING']) for a in aliases[bit]];need(all(r==raw[0] for r in raw),'selected alias trees differ')
            tree=by_name[chosen['name']];verify_tree(tree,chosen,raw[0])
            outcomes[case].append({'bit':bit,'alias':chosen['name'],'wires':len(raw[0]),'source':tree['driver']['source_wire'],'users':tree['complete_users']})
    for name,old in trees['default'].items():
        new=trees['swap16'][name];source=old['driver']['source_wire']
        need(old['driver']==new['driver'] and old['complete_tree'][source]==new['complete_tree'][source],'original source root/strength differs')
    tests=read(n/'reader-validation/receipt.json');need(tests['pass'] and tests['helper_sha256']==build['helper_binary_sha256'],'native reader controls differ')
    need({x['case']for x in tests['records']}=={'original-positive','missing_native_source','missing_native_sink','wrong_complete_user'},'native reader control inventory differs')
    for rec in tests['records']:
        verify_recorded(rec['argv'][1],rec['input_sha256']);verify_recorded(rec['argv'][2],rec['selection_sha256'])
        need(sha(n/'reader-validation'/(rec['case']+'.log'))==rec['log_sha256'],'native rejection log changed')
        need(rec['returncode']==(0 if rec['case']=='original-positive' else 1),'native reader control result differs')
    # Reconstruct both actual corrupted checkpoints from the retained original.
    positive=next(x for x in tests['records'] if x['case']=='original-positive');original=read(verify_recorded(positive['argv'][1],positive['input_sha256']))
    witness=read(n/'reader-validation/original-positive-result.json')['trees'][0];first=read(n/'reader-validation/selection.json')['nets'][0]
    for name,removed in [('missing_native_source',witness['driver']['source_wire']),('missing_native_sink',witness['complete_users'][0]['physical_sink_wires'][0])]:
        expected=deepcopy(original);module=next(iter(expected['modules'].values()))
        for net in module['netnames'].values():
            if net['bits']!=[first['bit']]:continue
            pieces=net['attributes']['ROUTING'].split(';');rows=[pieces[i:i+3]for i in range(0,len(pieces),3)];need(sum(row[0]==removed for row in rows)==1,'mutation wire absent');net['attributes']['ROUTING']=';'.join(item for row in rows if row[0]!=removed for item in row)
        need(expected==read(n/'reader-validation'/(name+'.json')),'native negative mutation is not exact')
    result={'status':'pass','scope':'Offline verification of recorded native source/pip/sink evidence, not native execution or STA','source_commit':commit['commit'],'native_reader_sha256':build['helper_binary_sha256'],'retained_headers':header_count,'recorded_object_identities':object_count,'complete_selected_nets':len(changed),'every_selected_saved_edge_verified':True,'native_root_replay_bytes_equal':True,'all_original_source_roots_and_strengths_equal':True,'native_reader_controls_recorded_and_mutations_reconstructed':True,'cases':outcomes,'proof_inputs_sha256':{name:sha(path)for name,path in [('graph-proof',HERE/'graph-proof.json'),('native-readback',n/'readback-receipt.json'),('root-replay',ROOT/'root-topology-readback/receipt.json'),('reader-controls',n/'reader-validation/receipt.json')]},'checker_sha256':sha(__file__),'limits':['Native executions and negative-control results are retained receipts; executables and objects are omitted from the archive.','Offline topology validation uses saved native pip/source/sink identities; it does not execute the device model.','No reloaded STA, RBF re-encoding, electrical or hardware acceptance is claimed.']}
    write('topology-proof.json',result);print('PASS offline native topology readback:',len(changed),'selected nets')

if __name__=='__main__':main()
