#!/usr/bin/env python3
"""Read back frozen source admission and complete controls; never runs STA."""
import re
import json
from support import ROOT, HERE, read, sha, need, verify_recorded, verify_binary, archive_mode, write

def verify_origins(raw, report):
    """Independently traverse the complete actual checkpoint fanin, not intersections."""
    module=next(iter(raw['modules'].values()));cells=module['cells'];aliases=module['netnames'];drivers={}
    for name,cell in cells.items():
        for pin,direction in cell['port_directions'].items():
            if direction=='output':
                for bit in cell['connections'][pin]:
                    need(bit not in drivers,'ambiguous source driver');drivers[bit]=(name,pin)
    maps={name:json.loads(bytes.fromhex(cell['attributes']['FES_PINMAP_V1']))['pins'] for name,cell in cells.items() if 'FES_PINMAP_V1' in cell['attributes']}
    def bit(name):
        bits=aliases[name]['bits'];need(len(bits)==1,'not a scalar native alias');return bits[0]
    frame_identities=[]
    for frame in report['analyses']:
        frame_targets=[]
        for target in frame['targets']:
            inventory=target['origin_inventory'];rows={bit(row['net']):row for row in inventory['nets']}
            need(len(rows)==len(inventory['nets'])==inventory['unique_nets'] and not inventory['truncated'],'incomplete native origin inventory')
            seen=set();terminals=set();active=set()
            def walk(key):
                need(key not in active,'origin graph cycle')
                if key in seen:return
                active.add(key);seen.add(key);name,pin=drivers[key];cell=cells[name];kind=cell['type'];row=rows[key]
                need((row['driver'],row['port'],row['type'])==(name,pin,kind) and not row['public'],'native/raw source identity differs')
                need(row['native_hints']=={'available':True,'rows':[{'capture':'clocks[0]','capture_edge':0,'cut':False,'launch':'clocks[0]','launch_edge':0,'window':10000}]},'native source domain inventory differs')
                if kind=='MISTRAL_FF':
                    need(pin=='Q' and row['inputs']==[] and cell['connections']['CLK']==[bit('clocks[0]')] and maps[name]['CLK'][0]==0,'raw origin clock identity differs')
                    need(row['clocks']==[{'edge':0,'net':'clocks[0]','period':10000,'port':'CLK','state':0}],'native origin clock differs');terminals.add(key)
                else:
                    need(kind in ('MISTRAL_ALUT2','MISTRAL_ALUT3','MISTRAL_ALUT4','MISTRAL_ALUT5','MISTRAL_ALUT6','MISTRAL_BUF','MISTRAL_ALUT_ARITH') and not row['clocks'],'unexpected combinational origin')
                    need({x['pin'] for x in row['inputs']}=={pin for pin,direction in cell['port_directions'].items() if direction=='input'},'complete origin input inventory differs')
                    for entry in row['inputs']:
                        pin=entry['pin'];state=maps[name][pin][0];connection=cell['connections'][pin]
                        need(state==entry['state'] and entry['native_arc'],'native source pin/arc differs')
                        if entry['net']:
                            need(connection==[bit(entry['net'])],'raw source input alias differs');walk(connection[0])
                        else:need(connection==[] and state in (1,2),'silently missing source input')
                active.remove(key)
            walk(cells[target['cell']]['connections']['Q'][0])
            need(seen==set(rows) and terminals=={bit(row['net']) for row in inventory['terminal_origins']},'complete source/terminal identities differ')
            frame_targets.append((target['cell'],tuple(sorted(seen)),tuple(sorted(terminals))))
        frame_identities.append(sorted(frame_targets))
    need(len(frame_identities)==2 and frame_identities[0]==frame_identities[1],'structural inventory differs between timing frames')


def main():
    final=read(ROOT/'final-validation.json');committed=read(ROOT/'committed-source-verification.json')
    need(sha(ROOT/'final-validation.json')==committed['final_validation_sha256'],'final admission manifest changed')
    need(final['source_files']==committed['source_files'] and committed['all_recorded_source_bytes_match_commit'],'committed source inventory differs')
    need(final['binary_sha256']==committed['binary_sha256'],'binary identities differ')
    verify_binary(final['binary_sha256'],str(ROOT/'nextpnr-mistral') if archive_mode() is None else archive_mode()['excluded_binary']['original_path'])
    for p,h in final['files'].items():need(sha(ROOT/p)==h,'host file differs: '+p)
    for p,h in final['source_files'].items():need(sha(ROOT/'complete-source'/p)==h,'source differs: '+p)
    need(final['enabled_lut6_route_admission'] is True and final['validation']=={'passed':True,'source_coverage_count':6,'lut6_native_count':33,'lut6_cli_count':6,'actual_board_targets':3,'actual_board_frames':2,'actual_board_coverage_and_native_legality_pass':True},'incomplete host admission')
    for n,count in [('source-tests',6),('lut6-native',33),('cli',6)]:
        rec=read(ROOT/(n+'.receipt.json'));log=ROOT/(n+'.log');need(rec['returncode']==0 and sha(log)==rec['log_sha256'],'suite identity/result differs')
        text=log.read_text();expression=r'\[\s+PASSED\s+\]\s+'+str(count)+r' tests?\.' if n!='cli' else r'Ran '+str(count)+r' tests? in'
        need(re.search(expression,text) is not None,'suite count differs')
        if n=='cli':need(re.search(r'\nOK\s*$',text) is not None,'CLI result differs')
    build=read(ROOT/'build-identity.json');validation=read(ROOT/'validation.json')
    need(build['production_sha256']==final['binary_sha256'] and build['native_test_sha256']==final['native_test_sha256'],'test/build identity differs')
    need(validation['pass'] and validation['sources_and_binaries_unchanged'] and validation['build_identity_sha256']==sha(ROOT/'build-identity.json'),'validation identity differs')
    prior=final['prior_validation'];old=read(verify_recorded(prior['path'],prior['sha256']))
    need(prior['rerun_on_this_binary'] is False and old['enabled_lut6_route_admission'] is False,'earlier admission provenance changed')
    retained=read(ROOT/'retained-source-proof.json');need(sha(ROOT/'retained-source-proof.json')==prior['unchanged_source_proof_sha256'],'earlier source proof changed')
    for p,h in retained['unchanged_source_files'].items():need(old['source_files'][p]==h==final['source_files'][p],'earlier retained source differs')
    controls=[]
    for case in ['default','zero']:
        folder=ROOT/('prepare-'+case);rec=read(folder/'receipt.json');need(rec['returncode']==0 and rec['binary_sha256']==final['binary_sha256'],'control execution differs')
        for p,h in rec['artifacts'].items():need(sha(folder/p)==h,'control artifact differs')
        for item in rec['inputs'].values():verify_recorded(item['path'],item['sha256'])
        controls.append(folder)
    need((controls[0]/'placed.json').read_bytes()==(controls[1]/'placed.json').read_bytes(),'default/zero placed bytes differ')
    need((controls[0]/'predicted-timing.json').read_bytes()==(controls[1]/'predicted-timing.json').read_bytes(),'default/zero timing differs')
    board=read(ROOT/'board-eligibility/build-plan.json');reference=verify_recorded(board['input'],board['input_sha256'])
    before=read(reference);after=read(controls[0]/'placed.json')
    need(before.keys()==after.keys() and {k:v for k,v in before.items() if k!='creator'}=={k:v for k,v in after.items() if k!='creator'},'complete prior/current placement differs')
    # Compare every byte apart from the creator string, not just module subsets.
    def normalize(path):
        raw=path.read_text();return re.sub(r'"creator"\s*:\s*"(?:[^"\\]|\\.)*"','"creator":"normalized"',raw,count=1)
    need(normalize(reference)==normalize(controls[0]/'placed.json'),'prior placement has extra raw-byte differences')
    ref_timing_record=read(ROOT/'reference-host-files.json')['predicted_timing']
    prior_timing=verify_recorded(ref_timing_record['path'],ref_timing_record['sha256'])
    need(prior_timing.read_bytes()==(controls[0]/'predicted-timing.json').read_bytes(),'prior complete predicted timing differs')
    current=read(ROOT/'control-proof.json');need(sha(ROOT/'control-proof.json')==final['control_proof_sha256'],'control proof changed')
    need(current['default_zero_raw_bytes_equal'] and all(x['complete_modules_equal'] and x['all_bytes_except_creator_equal'] and x['predicted_timing_bytes_equal'] for x in current['controls']),'control proof incomplete')
    receipt=read(ROOT/'board-eligibility/receipt.json');need(receipt['returncode']==0 and receipt['objects_unchanged'] and receipt['source_unchanged'],'native probe provenance differs')
    for p,h in receipt['files'].items():
        if p=='native-probe' and archive_mode() is not None:
            need(archive_mode()['excluded_board_probe']['sha256']==h,'omitted helper identity differs')
        else:need(sha(ROOT/'board-eligibility'/p)==h,'native probe artifact differs')
    probe=read(ROOT/'board-eligibility/result.json');need(probe['all_ff_cache_mismatches']==0 and probe['all_selected_native_coverage_and_legality'],'native eligibility failed')
    need(sorted(x['with_clock_skew'] for x in probe['analyses'])==[False,True],'timing frame inventory differs')
    verify_origins(before,probe)
    inventories=[]
    for frame in probe['analyses']:
        need(not frame['have_loops'] and len(frame['targets'])==3,'native target inventory differs')
        for t in frame['targets']:
            need(t['source_coverage'] and t['downstream_coverage'] and t['native_location_legal'] and not t['origin_inventory']['truncated'],'native target guard failed')
            inventories.append({'cell':t['cell'],'skew':frame['with_clock_skew'],'unique_nets':t['origin_inventory']['unique_nets'],'terminal_origins':len(t['origin_inventory']['terminal_origins'])})
    counter=ROOT/'counterexample' if archive_mode() is not None else ROOT.parent/'lut6-upstream-coverage-20261022'
    counter_receipt=read(counter/'receipt.json');need(counter_receipt['compiler_commit']=='972d8ea681c66daeaa3a77749582d49dfc6d7cdc' and counter_receipt['linked_native_objects_unchanged'],'counterexample provenance differs')
    for p,h in counter_receipt['files'].items():
        if p=='native-probe' and archive_mode() is not None:need(archive_mode()['excluded_counterexample_probe']['sha256']==h,'omitted counterexample helper identity differs')
        else:need(sha(counter/p)==h,'counterexample artifact differs')
    cache_source=ROOT/'references/cache-source' if archive_mode() else ROOT.parent/'routethrough-cache-20261022/source-validation/source'
    for p,h in counter_receipt['source_files'].items():need(sha(cache_source/p)==h and old['source_files'][p]==h,'counterexample compiler source differs: '+p)
    counter_cases={x['case']:x for x in read(counter/'result.json')['cases']}
    need(set(counter_cases)=={'known','missing_clock','undriven','public_undriven','async_startpoint'},'counterexample case inventory differs')
    for name in ['known','missing_clock','undriven','public_undriven']:
        x=counter_cases[name];need(x['target_output_coverage_accepted'] and x['target_distinct_connected_inputs']==6 and x['rows']==counter_cases['known']['rows'] and x['hints']==counter_cases['known']['hints'],'omitted-origin witness differs')
    need(not counter_cases['async_startpoint']['target_output_coverage_accepted'],'true asynchronous source did not reject')
    independent_record=read(ROOT/'independent-review/readback-identity.json')
    for p,info in independent_record['files'].items():need(sha(ROOT/'independent-review'/p)==info['sha256'],'independent review artifact changed')
    need(receipt['plan_sha256']==sha(ROOT/'board-eligibility/build-plan.json') and board['binary_sha256']==final['binary_sha256'] and board['build_identity_sha256']==sha(ROOT/'build-identity.json'),'native board build provenance changed')
    independent=ROOT/'independent-review/result.json';need(independent.read_bytes()==(ROOT/'board-eligibility/result.json').read_bytes(),'independent native replay differs')
    result={'status':'pass','scope':'Immutable host-only source/controls/native-probe readback; no STA rerun or route/hardware qualification','committed_source':committed['commit'],'source_count':len(final['source_files']),'host_file_count':len(final['files']),'source_tests':6,'lut6_native_tests':33,'cli_tests':6,'prior_tests_rerun_on_this_binary':False,'default_zero_bytes_identical':True,'prior_complete_graph_and_raw_bytes_except_creator_equal':True,'independent_board_replay_bytes_equal':True,'all_native_origin_inventories':inventories}
    write('source-control-proof.json',result);print(result)
if __name__=='__main__':main()
