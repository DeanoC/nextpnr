#!/usr/bin/env python3
"""Deterministic outcome and accounting summary of the complete checks."""
from collections import Counter, defaultdict
from decimal import Decimal
import json
from support import HERE, ROOT, read, sha, write, need


def main():
    comparison, graph, ledger, accounting = [read(path) for path in
        (HERE / 'route-comparison.json', HERE / 'graph-proof.json', HERE / 'decision-ledger.json', ROOT / 'route-accounting.json')]
    artifacts = {name: {'default_sha256': sha(ROOT / 'route-default' / name), 'swap16_sha256': sha(ROOT / 'route-swap16' / name),
                        'byte_identical': (ROOT / 'route-default' / name).read_bytes() == (ROOT / 'route-swap16' / name).read_bytes()}
                 for name in ('diagnostic.rbf', 'routed.json', 'endpoints.json', 'timing.json')}
    families = {}
    for run in ('default','swap16'):
        grouped = defaultdict(list)
        for failure in comparison['every_setup_failure_each_run'][run]:
            source = failure['actual_saved_source_and_path']
            family = source['family_inferred_from_actual_launch_cell'] if source else 'saved witness unavailable'
            grouped[family].append(failure['native_row']['setup'])
        families[run] = {key: {'failures': len(values), 'worst_setup_ps': min(values)} for key, values in sorted(grouped.items())}
    charge = sum(Decimal(str(read(ROOT / ('route-' + name) / 'receipt.json')['charged_seconds'])) for name in ('default', 'swap16'))
    need(str(charge) == comparison['pair_charge_seconds'], 'current pair charge differs')
    need(accounting['completed_subsequent_runs'] == 34 and set(accounting['new_cases']) == {
        'out/lut6-source-coverage-20261022/route-default', 'out/lut6-source-coverage-20261022/route-swap16'}, 'root accounting capture differs')
    summary = {
        'status': 'complete_local_improvement' if ledger['kept'] else 'complete_no_improvement',
        'scope': 'Paired fresh full-route host diagnostic after native FF cache and source-origin admission corrections.',
        'binary_sha256': read(ROOT / 'final-validation.json')['binary_sha256'],
        'source_commit': read(ROOT / 'committed-source-verification.json'),
        'case_metrics': {name: {key: comparison['runs'][name][key] for key in
            ('rows', 'setup', 'hold', 'unsupported_count', 'complete', 'all_clock_summaries', 'all_fmax')} for name in ('default', 'swap16')},
        'actual_saved_source_failure_cohorts': families,
        'discovery': {key: ledger[key] for key in ('discovery_counts', 'tried', 'kept', 'budget', 'path_discovery_bound_reached')},
        'filter_reason_counts': dict(sorted(Counter(line.rsplit(': ', 1)[1] for line in ledger['all_filters']).items())),
        'all_final_artifacts_default_vs_swap16': artifacts,
        'default_vs_prior13': comparison['default_vs_prior_fixed_route_artifact_bytes'],
        'default_creator_only_complete_graph': comparison['default_vs_prior_fixed_complete_graph'],
        'all_native_rows_metadata_clocks_equal': comparison['endpoint_identity_inventory_equal'] and comparison['all_row_domain_windows_and_flags_equal'] and comparison['all_metadata_categories_equal'],
        'all_setup_and_hold_delta_counts': comparison['native_margin_delta_counts'],
        'complete_graph_counts': {key: graph[key] for key in ('complete_cells', 'complete_net_alias_records', 'complete_net_alias_classes', 'complete_public_ports')},
        'changed_LUT6_cells': len(graph['accepted_cells']), 'changed_canonical_net_bits': graph['changed_canonical_net_bits'],
        'pair_charge_seconds_from_receipts': str(charge), 'root_cumulative_charge': accounting,
        'accounting_scope': 'Independently recomputes this pair only; the 34-run cumulative total is root-supplied campaign accounting.',
        'artifact_hashes': {name: sha(HERE / name) for name in
            ('graph-proof.json', 'route-comparison.json', 'decision-ledger.json', 'checker-tests.json', 'source-control-proof.json')},
        'root_accounting_sha256': sha(ROOT / 'route-accounting.json'), 'checker_sha256': sha(__file__),
        'limits': ['The native inventory remains complete=false with105 unsupported identities; equality does not qualify coverage.',
                   'Local trial outcomes are reported separately from complete timing closure and the same-recipe seed gate.',
                   'Final reports expose the skewed native inventory; internal reference-free acceptance is separately enforced in source/tests, not independently emitted here.',
                   'No hardware ran; serialized route identity and byte comparisons are not electrical/board acceptance.']}
    need(ledger['kept'] == len(graph['accepted_cells']), 'accepted graph inventory differs')
    need(comparison['default_vs_prior_fixed_invariance_pass'], 'default control differs')
    need(comparison['independent_emitted_inventory_guard']['nonregression_and_inventory_pass'] and comparison['independent_complete_clock_guard']['pass'], 'complete native guard fails')
    if not ledger['kept']:need(all(item['byte_identical'] for item in artifacts.values()), 'rejected trials changed final artifacts')
    write('summary.json', summary)
    print(json.dumps({'status': summary['status'], 'pair_charge_seconds': str(charge),
                      'campaign_seconds': accounting['campaign_seconds'], 'all_four_artifacts_identical': all(item['byte_identical'] for item in artifacts.values()), 'tried': ledger['tried'], 'kept': ledger['kept']}, sort_keys=True))


if __name__ == '__main__':
    main()
