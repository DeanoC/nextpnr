#!/usr/bin/env python3
"""Append completed paired full-route receipts exactly once; queue-inclusive charges."""
from pathlib import Path
from decimal import Decimal
import hashlib,json
ROOT=Path(__file__).resolve().parent
TASK=ROOT.parent.parent
JOURNAL=TASK/'sources/misteross/docs/validation/2026-10-22-pcxt-pad-pipeline/continued-runs.jsonl'
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def main():
 existing=[json.loads(s) for s in JOURNAL.read_text().splitlines() if s.strip()]
 present={r['case'] for r in existing}; added=[]
 for name in ['route-default','route-swap16']:
  p=ROOT/name;case=str(p.relative_to(TASK));receipt_path=p/'receipt.json'
  if case in present:continue
  receipt=json.loads(receipt_path.read_text(),parse_float=Decimal)
  for artifact,digest in receipt['artifacts'].items():assert sha(p/artifact)==digest
  report=json.loads((p/'timing.json').read_text()) if (p/'timing.json').exists() else None
  record={'case':case,'charged_seconds_decimal':str(receipt['charged_seconds']),'clocks':report['timing_summary']['clocks'] if report else None,
          'core':'fes-pcxt diagnostic CGA Direct','evidence':'fresh paired leased host diagnostic; complete comparison determines retention; no timing closure or hardware acceptance',
          'gpu_log':[s for s in (p/'nextpnr.log').read_text().splitlines() if 'GPU lease:' in s or 'backend hip:' in s or 'backend cuda:' in s or 'GPU router time' in s],
          'hardware':False,'receipt':json.loads(receipt_path.read_text()),'receipt_sha256':sha(receipt_path),'timing_report_available':report is not None}
  added.append(record)
 with JOURNAL.open('a') as stream:
  for record in added:stream.write(json.dumps(record,sort_keys=True)+'\n')
 total=Decimal('14417.71786836162136')+sum((Decimal(r['charged_seconds_decimal']) for r in existing+added),Decimal(0))
 result={'completed_subsequent_runs':len(existing)+len(added),'new_cases':[r['case'] for r in added],'campaign_seconds':str(total)}
 (ROOT/'route-accounting.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
