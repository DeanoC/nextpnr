// Host-only structural/source admission probe after native route preparation.
// Predicted full STA is used only for the coverage API; no route or acceptance trial.
#include "nextpnr.h"
#include "json_frontend.h"
#include "timing.h"
#include "analogue_repair.h"
#include "json11.hpp"
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
USING_NEXTPNR_NAMESPACE
using J=json11::Json;
static const std::array<IdString,6> inputs{id_A,id_B,id_C,id_D,id_E,id_F};
static J hints(Context &c,TimingAnalyser &timing,CellPortKey key) {
    std::vector<TimingAnalyser::SetupWindowHint> rows;bool available=timing.get_setup_window_hints(key,rows);J::array result;
    for(const auto &r:rows) result.push_back(J::object{{"launch",r.launch.clock.str(&c)},{"launch_edge",int(r.launch.edge)},
        {"capture",r.capture.clock.str(&c)},{"capture_edge",int(r.capture.edge)},{"cut",r.cut},{"window",r.window?J(*r.window):J()}});
    return J::object{{"available",available},{"rows",result}};
}
// Separate diagnostic inventory, not an alternative acceptance predicate.
static J inventory(Context &c, TimingAnalyser &timing,NetInfo *root) {
    std::set<NetInfo*> done,visiting;J::array nets,terminals;unsigned work=0,maxdepth=0;bool truncated=false;
    auto walk=[&](auto &&self,NetInfo *net,unsigned depth)->void {
        if(!net||depth>64||++work>4096){truncated=true;return;}
        maxdepth=std::max(maxdepth,depth);if(done.count(net))return;
        if(visiting.count(net)){terminals.push_back(J::object{{"net",net->name.str(&c)},{"kind","cycle"}});return;}
        visiting.insert(net);auto *cell=net->driver.cell;int clocks=0;
        J::object row{{"net",net->name.str(&c)},{"fanout",int(net->users.entries())},{"depth",int(depth)},
            {"driver",cell?cell->name.str(&c):""},{"port",net->driver.port.str(&c)},
            {"type",cell?cell->type.str(&c):""}};
        bool public_net=false;for(const auto &p:c.ports)public_net|=p.second.net==net;row["public"]=public_net;
        if(cell) {
            auto cls=c.getPortTimingClass(cell,net->driver.port,clocks);row["timing_class"]=int(cls);
            row["native_hints"]=hints(c,timing,CellPortKey(net->driver));J::array ports,clock_rows;
            if(cls==TMG_REGISTER_OUTPUT) for(int i=0;i<clocks;++i){auto ci=c.getPortClockingInfo(cell,net->driver.port,i);auto *clk=cell->getPort(ci.clock_port);
                clock_rows.push_back(J::object{{"port",ci.clock_port.str(&c)},{"net",clk?clk->name.str(&c):""},
                    {"state",int(cell->get_pin_state(ci.clock_port))},{"edge",int(ci.edge)},
                    {"period",clk&&clk->clkconstr?J(clk->clkconstr->period.maxDelay()):J()}});}
            row["clocks"]=clock_rows;
            int width=cell->type==id_MISTRAL_ALUT6?6:cell->type==id_MISTRAL_ALUT5?5:cell->type==id_MISTRAL_ALUT4?4:
                cell->type==id_MISTRAL_ALUT3?3:cell->type==id_MISTRAL_ALUT2?2:cell->type==id_MISTRAL_BUF?1:0;
            bool arithmetic=cell->type==id_MISTRAL_ALUT_ARITH;
            if((width||arithmetic)&&cls==TMG_COMB_OUTPUT){
                auto pins=arithmetic?std::vector<IdString>{id_A,id_B,id_C,id_D0,id_D1,id_CI}:std::vector<IdString>(inputs.begin(),inputs.begin()+width);
                for(auto pin:pins){DelayQuad delay;bool arc=c.getCellDelay(cell,pin,net->driver.port,delay);auto *up=cell->getPort(pin);
                    ports.push_back(J::object{{"pin",pin.str(&c)},{"state",int(cell->get_pin_state(pin))},
                        {"net",up?up->name.str(&c):""},{"native_arc",arc}});if(up&&arc)self(self,up,depth+1);}
            } else terminals.push_back(row);
            row["inputs"]=ports;
        }else terminals.push_back(row);
        nets.push_back(row);visiting.erase(net);done.insert(net);
    };
    walk(walk,root,0);return J::object{{"nets",nets},{"terminal_origins",terminals},{"unique_nets",int(done.size())},
        {"truncated",truncated},{"diagnostic_visits",int(work)},{"maximum_depth",int(maxdepth)}};
}
int main(int argc,char **argv){try{
    if(argc!=3)throw std::runtime_error("probe placed.json report.json");
    ArchArgs args;args.device="5CSEBA6U23I7";Context c(args);std::ifstream in(argv[1]);
    if(!parse_json(in,argv[1],&c))throw std::runtime_error("parse failed");
    if(c.attrs.at(id_step).as_string()!="place")throw std::runtime_error("requires placed checkpoint");
    c.restore_placed_pin_maps();c.lab_pre_route();
    const std::map<std::string,std::string> targets{
        {"system.machine.cpu.cpu.u_eu_core.u_operand1_mux.lanes[10].combine","MISTRAL_MCOMB.15.35.54"},
        {"system.machine.cpu.cpu.u_eu_core.eu_alu_out_MISTRAL_ALUT6_Q","MISTRAL_COMB.10.31.36"},
        {"system.machine.cpu.cpu.u_eu_core.eu_alu_out_MISTRAL_ALUT6_Q_2","MISTRAL_COMB.10.34.43"}};
    J::array analyses;bool all=true;
    for(bool skew:{false,true}) {TimingAnalyser timing(&c);timing.with_clock_skew=skew;timing.setup(false,false,true);J::array rows;
        for(const auto &t:targets){auto *cell=c.cells.at(c.id(t.first)).get();
            if(cell->type!=id_MISTRAL_ALUT6||c.getBelName(cell->bel).str(&c)!=t.second)throw std::runtime_error("target identity changed");
            std::string sr,dr;bool source=critical_lut6_swap_source_coverage(&c,timing,cell,&sr);
            bool downstream=critical_lut6_swap_output_coverage(&c,timing,cell->getPort(id_Q),&dr);
            bool legal=c.isBelLocationValid(cell->bel,true);all&=source&&downstream&&legal&&!timing.have_loops;
            rows.push_back(J::object{{"cell",t.first},{"bel",t.second},{"source_coverage",source},{"source_reason",sr},
                {"downstream_coverage",downstream},{"downstream_reason",dr},{"native_location_legal",legal},
                {"origin_inventory",inventory(c,timing,cell->getPort(id_Q))}});
        }
        analyses.push_back(J::object{{"with_clock_skew",skew},{"have_loops",timing.have_loops},{"targets",rows}});
    }
    int mismatches=0;for(const auto &kv:c.cells){auto *cell=kv.second.get();if(cell->type==id_MISTRAL_FF&&
        (cell->ffInfo.datain!=cell->getPort(id_DATAIN)||cell->ffInfo.sdata!=cell->getPort(id_SDATA)))++mismatches;}
    std::ofstream out(argv[2]);out<<J(J::object{{"scope","host-only native route preparation and predicted full-STA source admission; no route or timing signoff"},
        {"analyses",analyses},{"all_selected_native_coverage_and_legality",all},{"all_ff_cache_mismatches",mismatches}}).dump()<<"\n";return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<"\n";return 1;}}
