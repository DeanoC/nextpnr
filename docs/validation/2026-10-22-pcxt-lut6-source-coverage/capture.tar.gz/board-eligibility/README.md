# CPU LUT6 source admission probe

All three intended CPU LUT6s pass the new upstream-origin guard, unchanged
output-cone coverage and native BEL/LAB legality in both clock-skew frames after
native `lab_pre_route`. The complete FF scan has zero cached DATAIN/SDATA
mismatches. This is host-only structural/admission evidence using predicted full
STA. It is neither a routed timing result nor a swap trial or hardware acceptance.

| Target suffix | Exact BEL | Unique source nets | Registered origins | Maximum depth |
| --- | --- | ---: | ---: | ---: |
| `eu_alu_out_MISTRAL_ALUT6_Q` | `MISTRAL_COMB.10.31.36` | 415 | 251 | 15 |
| `eu_alu_out_MISTRAL_ALUT6_Q_2` | `MISTRAL_COMB.10.34.43` | 239 | 156 | 8 |
| `u_operand1_mux.lanes[10].combine` | `MISTRAL_MCOMB.15.35.54` | 35 | 28 | 2 |

All names are prefixed `system.machine.cpu.cpu.u_eu_core.`. Every terminal is a
native `MISTRAL_FF` output with rising `clocks[0]`; the diagnostic inventories are
complete within their own bounds. The separate inventory records every visited
net, input state/native arc, native launch relationship, leaf clock, fanout and
public-port observation. It explains the selected circuit but is not an alternate
acceptance implementation: the reported admission result comes directly from the
production `critical_lut6_swap_source_coverage` and
`critical_lut6_swap_output_coverage` functions.

`run.py` binds the exact input checkpoint (fixed 972 default placement SHA
`7db82422b9819c2111cf5feb0b80c5e504cd946c98a257030be170560cb764ea`), source snapshot,
build identity, standalone helper source and every linked native object/archive.
It checks all bound bytes again after compilation/execution. Production binary
SHA is `e94f638ef244ca43daa607b53a375e895357ab74746d065c8e4e3ea9a9bab803`.
The three names and BELs are asserted before analysis. No placement, routing,
configuration-bitstream emission, acceptance callback or source edit occurs.

`result.json` contains both complete observed timing frames, and `receipt.json`
binds every command/output plus elapsed host time. The linked helper binary is
large and need not be included in compact evidence; its hash remains in the
receipt. Rebuilding requires the exact object inputs recorded in `build-plan.json`.
