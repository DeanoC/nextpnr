#!/usr/bin/env python3
import hashlib,json,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parent; P=R.parent; TASK=P.parent
BUILD=Path('/home/deano/harnesses/pcxt-compiler-repair/build-candidate')
SRC=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
identity=json.loads((P/'build-identity.json').read_text())
source=json.loads((P/'source-identity.json').read_text())
binary=BUILD/'nextpnr-mistral'; assert sha(binary)==identity['production_sha256']
for p,x in source['files'].items():assert sha(SRC/p)==x['sha256']
old=json.loads((TASK/'lut6-upstream-coverage-20261022/build-plan.json').read_text())
oldroot=str(TASK/'lut6-upstream-coverage-20261022')
compile=[x.replace(oldroot,str(R)) for x in old['compile']]
link=[x.replace(oldroot,str(R)) for x in old['link']]
objects={x:sha(x) for x in link if x.endswith(('.o','.a')) and Path(x).exists() and Path(x).parent!=R}
input=TASK/'routethrough-cache-20261022/prepare-default/placed.json'
assert sha(input)=='7db82422b9819c2111cf5feb0b80c5e504cd946c98a257030be170560cb764ea'
plan={'compile':compile,'link':link,'object_hashes':objects,'source_files':source['files'],
 'build_identity_sha256':sha(P/'build-identity.json'),'source_identity_sha256':sha(P/'source-identity.json'),
 'source_sha256':sha(R/'probe.cc'),'input':str(input),'input_sha256':sha(input),'binary_sha256':sha(binary)}
(R/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
start=time.monotonic(); receipt={'scope':'host-only admission probe; no placement or routing','commands':[],'charged_seconds':0}
with (R/'build.log').open('w') as log:
 for cmd in (compile,link):
  rc=subprocess.run(cmd,cwd=BUILD,stdout=log,stderr=subprocess.STDOUT).returncode;receipt['commands'].append({'argv':cmd,'returncode':rc})
  if rc:break
if not rc:
 cmd=[str(R/'native-probe'),str(input),str(R/'result.json')]
 with (R/'probe.log').open('w') as log:rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 receipt['commands'].append({'argv':cmd,'returncode':rc})
receipt['elapsed_seconds']=time.monotonic()-start
for p,h in objects.items():assert sha(p)==h
for p,x in source['files'].items():assert sha(SRC/p)==x['sha256']
assert sha(binary)==identity['production_sha256'] and sha(input)==plan['input_sha256']
receipt.update({'returncode':rc,'plan_sha256':sha(R/'build-plan.json'),'objects_unchanged':True,'source_unchanged':True,
 'files':{p.name:sha(p) for p in R.iterdir() if p.is_file() and p.name not in ('receipt.json','probe.o')}})
(R/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(rc,receipt['elapsed_seconds'],flush=True)
if rc:raise SystemExit(rc)
r=json.loads((R/'result.json').read_text())
for a in r['analyses']:
 for t in a['targets']:print(a['with_clock_skew'],t['cell'],t['source_coverage'],t['source_reason'],t['downstream_coverage'],t['downstream_reason'],flush=True)
