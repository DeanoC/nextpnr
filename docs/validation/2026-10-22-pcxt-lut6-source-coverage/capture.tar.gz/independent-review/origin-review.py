import json,pathlib,collections,hashlib
root=pathlib.Path('/home/deano/harnesses/worktrees/fes/silver-delta/out/dev/pcxt-board/out')
r=root/'lut6-source-coverage-20261022'; raw=json.loads((root/'routethrough-cache-20261022/prepare-default/placed.json').read_text());m=next(iter(raw['modules'].values()));cells=m['cells']; aliases=m['netnames']; report=json.loads((r/'board-eligibility/result.json').read_text())
driver={}
for name,c in cells.items():
 for p,d in c['port_directions'].items():
  if d=='output':
   for bit in c['connections'][p]:
    assert bit not in driver,(bit,driver.get(bit),(name,p))
    driver[bit]=(name,p)
pinmaps={name:json.loads(bytes.fromhex(c['attributes']['FES_PINMAP_V1']))['pins'] for name,c in cells.items() if 'FES_PINMAP_V1' in c['attributes']}
def bit(name):
 a=aliases[name]['bits'];assert len(a)==1;return a[0]
summary=[]
for analysis in report['analyses']:
 assert not analysis['have_loops']
 for target in analysis['targets']:
  inv=target['origin_inventory']; rows={bit(row['net']):row for row in inv['nets']}; assert len(rows)==len(inv['nets'])==inv['unique_nets']; assert not inv['truncated']
  seen=set(); terminals=set()
  def walk(b):
   if b in seen:return
   seen.add(b);name,p=driver[b];c=cells[name];typ=c['type'];row=rows[b]
   assert (row['driver'],row['port'],row['type'])==(name,p,typ)
   assert not row['public']; assert row['native_hints']['available']
   assert row['native_hints']['rows']==[{'capture':'clocks[0]','capture_edge':0,'cut':False,'launch':'clocks[0]','launch_edge':0,'window':10000}]
   if typ=='MISTRAL_FF':
    assert p=='Q';assert row['inputs']==[]; terminals.add(b)
    assert c['connections']['CLK']==[bit('clocks[0]')];state=pinmaps[name]['CLK'][0];assert state==0
    assert row['clocks']==[{'edge':0,'net':'clocks[0]','period':10000,'port':'CLK','state':state}];return
   assert typ.startswith('MISTRAL_ALUT') or typ=='MISTRAL_BUF',typ
   assert row['clocks']==[]
   expected={p for p,d in c['port_directions'].items() if d=='input'}
   recorded={i['pin'] for i in row['inputs']};assert recorded==expected,(name,recorded,expected)
   for inp in row['inputs']:
    p=inp['pin'];state=pinmaps[name][p][0]; assert inp['state']==state; con=c['connections'][p]
    assert inp['native_arc']
    if inp['net']:
     assert con==[bit(inp['net'])];walk(con[0])
    else:
     assert con==[] and state in (1,2),(name,p,con,state)
  walk(cells[target['cell']]['connections']['Q'][0]);assert seen==set(rows)
  assert terminals=={bit(row['net']) for row in inv['terminal_origins']}
  summary.append({'with_clock_skew':analysis['with_clock_skew'],'cell':target['cell'],'exact_net_inventory':len(seen),'exact_registered_origin_inventory':len(terminals),'all_terminal_clock_edges':['clocks[0]/rising'],'native_coverage_and_location':target['source_coverage'] and target['downstream_coverage'] and target['native_location_legal']})
assert all(x['native_coverage_and_location'] for x in summary)
out=pathlib.Path(__file__).with_name('origin-review.json');out.write_text(json.dumps({'pass':True,'checks':summary,'scope':'Independent raw checkpoint fanin walk; native masks/routed timing not claimed'},sort_keys=True,indent=2)+'\n');print(out);print(json.dumps(summary,indent=2))
