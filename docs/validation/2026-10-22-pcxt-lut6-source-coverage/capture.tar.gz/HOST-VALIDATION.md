# Bounded source-origin admission validation

The default-off routed LUT6 repair now checks complete upstream origins as well
as its downstream capture cone. A separate unchanged-972 native probe at
`../lut6-upstream-coverage-20261022/` proved the prior gap: a known clocked input
mixed with a missing-clock or undriven sibling retained the same apparently valid
native endpoint row. Native timing had omitted that origin. The new guard walks
actual supported LUT/BUF/carry arcs to characterized FF/M10K launches and compares
the exact structural launch identities against native timing. It rejects missing,
unknown, public, asynchronous, cut, malformed and over-bound origins.

The six focused native cases cover mixed omitted origins, valid multilevel
FF/M10K/phase/carry paths, explicit constants and inversions, public/async/cut
sources, incomplete or stale analysis, malformed clocks/identities, cycles,
depth and work bounds. The existing 33 native LUT6/coverage cases and six CLI cases
are rerun on the same frozen binary; final outcomes and log hashes are bound by
`final-validation.json` only after all receipts pass.

The actual-board host probe passes source coverage, downstream coverage and
native placement legality for all three intended CPU LUT6s in both skew frames.
Its exact 28/156/251 source-register inventories are explained in
`board-eligibility/README.md`. This uses predicted full STA after native
`lab_pre_route`, with zero stale FF data caches. It does not route or trial a swap.

Fresh default and explicit-zero CPU-only preparation are byte-identical. Both
preserve every module, every serialized byte except the compiler creator label,
and the complete predicted timing report relative to the earlier fixed-972
control. Source hashes, input receipts and full outputs are retained.

The earlier cache-eight/private-pair-77/private-CLI-six validation remains at its
original 972 commit and binary, with the unchanged source files checked explicitly;
those suites are not claimed as rerun on this guard-only revision. Their original
manifest remains immutable and explicitly disables its older enabled-LUT6 route
admission. The new manifest can authorize a fresh diagnostic route only when these
new host gates finish successfully. Routed setup/hold, complete clock inventory,
physical acceptance and hardware qualification remain separate requirements.
