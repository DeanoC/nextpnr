#!/usr/bin/env python3
"""Paired fresh routes of the frozen source-origin guard and route-through cache correction; root owns launch/leases."""
from pathlib import Path
import argparse
import concurrent.futures
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent
TASK = ROOT.parent.parent
REFERENCE = ROOT.parent / 'post-route-checkpoint-20261022/route-only'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def preflight():
    base = json.loads((REFERENCE / 'receipt.json').read_text())
    validation = json.loads((ROOT / 'final-validation.json').read_text())
    committed = json.loads((ROOT / 'committed-source-verification.json').read_text())
    assert committed['all_recorded_source_bytes_match_commit'] is True
    assert committed['final_validation_sha256'] == sha(ROOT / 'final-validation.json')
    assert committed['source_files'] == validation['source_files']
    assert validation['validation']['passed'] is True
    assert validation.get('enabled_lut6_route_admission') is True, 'upstream-origin admission must be verified before an enabled route'
    assert validation['validation']['source_coverage_count'] >= 6
    assert validation['validation']['lut6_native_count'] == 33
    assert validation['validation']['lut6_cli_count'] == 6
    assert sha(ROOT / 'nextpnr-mistral') == committed['binary_sha256'] == validation['binary_sha256']
    controls = json.loads((ROOT / 'control-proof.json').read_text())
    assert sha(ROOT / 'control-proof.json') == validation['control_proof_sha256']
    assert controls['default_zero_raw_bytes_equal']
    for case in controls['controls']:
        assert case['complete_modules_equal'] and case['all_bytes_except_creator_equal']
        assert case['predicted_timing_bytes_equal']
    command = base['nextpnr_command'][:]
    command[0] = str(ROOT / 'nextpnr-mistral')
    assert command[command.index('--seed') + 1] == '1'
    assert command[command.index('--freq') + 1] == '100.0'
    assert command[command.index('--critical-route-budget') + 1] == '32'
    assert command[command.index('--router') + 1] == 'gpu'
    assert '--rbf' in command and '--placer-heap-hard-block-windows' in command
    assert '--placer-heap-correct-spread' in command and '--balance-reduction-root' in command
    assert not any('private-pair' in value for value in command)
    assert not any(value in command for value in ('--no-route', '--no-pack', '--no-place', '--pack-only',
                                                   '--critical-lut6-swap-budget', '--critical-move-route-budget'))
    inputs = base['inputs']
    for item in inputs.values():
        assert sha(item['path']) == item['sha256']
    return command, inputs, committed, validation


def run(case):
    command, inputs, committed, validation = preflight()
    if case == 'swap16':
        command += ['--critical-lut6-swap-budget', '16']
    target = ROOT / ('route-' + case)
    target.mkdir(exist_ok=False)
    wrapped = [str(TASK / 'scripts/gpu-run'), '--phase-lease', '--owner', 'pcxt-timing',
               '--label', 'pcxt-lut6-origin-' + case, '--', *command]
    env = {'NEXTPNR_REQUIRE_GPU': '1', 'GPU_LEASE_MAX_PER_OWNER': '2'}
    immutable = {str(path): sha(path) for path in
                 (ROOT / 'source-identity.json', ROOT / 'final-validation.json',
                  ROOT / 'committed-source-verification.json', ROOT / 'control-proof.json',
                  REFERENCE / 'receipt.json', Path(__file__))}
    receipt = {
        'command': wrapped, 'nextpnr_command': command, 'binary_sha256': committed['binary_sha256'],
        'committed_source_verification': committed, 'final_validation': validation,
        'immutable_evidence_sha256': immutable, 'inputs': inputs, 'env': env,
        'recipe': 'original raw synthesis seed1/native hard-block windows/correct spreading/overflow17/route budget32; ' + case,
        'limit': 'native bounded router and optional 16 LUT6 trials; no external GPU-job termination',
        'evidence': 'fresh leased GPU host diagnostic; no timing closure, production seal or hardware acceptance',
    }
    started = time.monotonic()
    with (target / 'nextpnr.log').open('w') as log:
        receipt['returncode'] = subprocess.run(wrapped, cwd=target, env=dict(os.environ, **env),
                                               stdout=log, stderr=subprocess.STDOUT).returncode
    receipt['charged_seconds'] = time.monotonic() - started
    for item in inputs.values():
        assert sha(item['path']) == item['sha256']
    for path, digest in immutable.items():
        assert sha(path) == digest
    assert sha(ROOT / 'nextpnr-mistral') == receipt['binary_sha256']
    receipt['artifacts'] = {path.name: sha(path) for path in sorted(target.iterdir()) if path.is_file()}
    (target / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'case': case, 'returncode': receipt['returncode'],
                      'charged_seconds': receipt['charged_seconds']}), flush=True)
    return receipt


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    preflight()
    if args.check_only:
        print('Paired fresh-route preflight passed; no route launched.')
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(run, ['default', 'swap16']))
