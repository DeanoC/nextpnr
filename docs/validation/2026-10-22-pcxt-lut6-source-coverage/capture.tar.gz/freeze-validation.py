#!/usr/bin/env python3
"""Freeze host admission validation; no route launch or timing qualification."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
R=Path(__file__).resolve().parent; S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
OLD=R.parent/'routethrough-cache-20261022'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
build=load(R/'build-identity.json');source=load(R/'source-identity.json')
assert sha(R/'source-identity.json')==build['source_identity_sha256']
assert sha(R/'nextpnr-mistral')==build['production_sha256']
old=load(OLD/'final-validation.json')
assert sha(OLD/'final-validation.json')=='e60e7600e8dd3466b776d235ee9884fea048a8d14ddbc765583b6739911399dd'
assert old['validation']['passed'] and old['enabled_lut6_route_admission'] is False
sources=dict(old['source_files'])
for p,x in source['files'].items():sources[p]=x['sha256']
# Retain unchanged earlier private-pair/cache sources and precisely the new source revision.
unchanged={p:h for p,h in old['source_files'].items() if p not in source['files']}
for p,h in sources.items():
 assert sha(S/p)==h,(p,'live source differs')
 dest=R/'complete-source'/p;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==h
 else:shutil.copy2(S/p,dest)
for p,h in unchanged.items():
 raw=subprocess.check_output(['git','show','972d8ea681c66daeaa3a77749582d49dfc6d7cdc:'+p],cwd=S)
 assert hashlib.sha256(raw).hexdigest()==h
write(R/'retained-source-proof.json',{'earlier_commit':'972d8ea681c66daeaa3a77749582d49dfc6d7cdc',
 'earlier_final_validation_sha256':sha(OLD/'final-validation.json'),'unchanged_source_files':unchanged,
 'scope':'Earlier cache8/private77/CLI6 results are retained at their original 972 provenance; not rerun for this binary.'})
summary=load(R/'validation.json')
assert summary['pass'] is True and summary['sources_and_binaries_unchanged'] is True,summary
assert summary['build_identity_sha256']==sha(R/'build-identity.json')
counts={'source-tests':6,'lut6-native':33,'cli':6}
for name,count in counts.items():
 rec=load(R/(name+'.receipt.json'));log=R/(name+'.log')
 assert rec['returncode']==0 and sha(log)==rec['log_sha256']
 text=log.read_text()
 if name!='cli':assert re.search(r'\[\s+PASSED\s+\]\s+'+str(count)+r' tests?\.',text),(name,text[-1000:])
 else:assert re.search(r'Ran '+str(count)+r' tests? in',text) and re.search(r'\nOK\s*$',text),text[-1000:]
control=load(R/'control-proof.json');assert control['default_zero_raw_bytes_equal']
for c in control['controls']:
 assert c['complete_modules_equal'] and c['all_bytes_except_creator_equal'] and c['predicted_timing_bytes_equal']
 rec=load(R/('prepare-'+c['case'])/'receipt.json');assert rec['returncode']==0
 for p,h in rec['artifacts'].items():assert sha(R/('prepare-'+c['case'])/p)==h
 assert rec['binary_sha256']==build['production_sha256']
probe=load(R/'board-eligibility/result.json');pr=load(R/'board-eligibility/receipt.json')
assert pr['returncode']==0 and pr['objects_unchanged'] and pr['source_unchanged']
for p,h in pr['files'].items():assert sha(R/'board-eligibility'/p)==h
assert probe['all_selected_native_coverage_and_legality'] and probe['all_ff_cache_mismatches']==0
assert sorted(a['with_clock_skew'] for a in probe['analyses'])==[False,True]
for a in probe['analyses']:
 assert len(a['targets'])==3 and not a['have_loops']
 for t in a['targets']:
  assert t['source_coverage'] and t['downstream_coverage'] and t['native_location_legal'] and not t['origin_inventory']['truncated']
files={}
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name in ('nextpnr-mistral','native-probe','probe.o','final-validation.json'):continue
 if any(x.startswith('route-') or x=='final-analysis' for x in p.relative_to(R).parts):continue
 if p.name in ('route.py','record-routes.py','committed-source-verification.json'):continue
 files[str(p.relative_to(R))]=sha(p)
final={'scope':'Host-only source-origin admission and disabled-behavior validation; no new routed timing or hardware acceptance',
 'binary_sha256':build['production_sha256'],'native_test_sha256':build['native_test_sha256'],
 'source_parent':source['base'],'source_files':sources,'control_proof_sha256':sha(R/'control-proof.json'),
 'enabled_lut6_route_admission':True,
 'enabled_lut6_route_admission_reason':'Mixed omitted origins now reject; complete native source/downstream guards pass all three actual CPU targets in both predicted timing frames. A future fresh route must still satisfy unchanged full setup/hold and clock guards.',
 'validation':{'passed':True,'source_coverage_count':6,'lut6_native_count':33,'lut6_cli_count':6,
 'actual_board_targets':3,'actual_board_frames':2,'actual_board_coverage_and_native_legality_pass':True},
 'prior_validation':{'path':str(OLD/'final-validation.json'),'sha256':sha(OLD/'final-validation.json'),
 'commit':'972d8ea681c66daeaa3a77749582d49dfc6d7cdc','cache_regression_count':8,'private_pair_native_count':77,
 'private_pair_cli_count':6,'rerun_on_this_binary':False,'unchanged_source_proof_sha256':sha(R/'retained-source-proof.json')},
 'files':files}
write(R/'final-validation.json',final)
print(sha(R/'final-validation.json'),flush=True)
