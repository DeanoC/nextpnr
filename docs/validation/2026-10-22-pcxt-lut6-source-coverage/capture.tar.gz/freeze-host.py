#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
H=Path(__file__).resolve().parent
r=json.loads((H/'validation.json').read_text());assert r['pass'] and r['sources_and_binaries_unchanged']
b=json.loads((H/'build-identity.json').read_text());s=json.loads((H/'source-identity.json').read_text())
text=f'''# LUT6 upstream coverage guard: host validation

The default-off live LUT6 swap now proves structural source coverage before admission and after each actual local reroute. It walks all six inputs through explicitly supported LUT/BUF/ARITH arcs to characterized FF/M10K launch clocks, compares exact structural clock/edge sets with native timing hints, and preserves all existing downstream, whole-clock, endpoint, setup and hold guards. Unknown, missing-clock, undriven, public, asynchronous, cut, malformed, cyclic or over-bound sources reject. Only explicit native PIN0/PIN1 or an exact MISTRAL_CONST identity is static; connected register clock pins must remain PIN_SIG/PIN_INV. No CLI or original private-pair source rule was widened.

The motivating immutable native probe is `../lut6-upstream-coverage-20261022/result.json`: the old downstream check accepted known-plus-missing-clock, known-plus-undriven and known-plus-public-undriven fanin with the same known timing row as the valid control. A genuine asynchronous domain already rejected. Thus the repair addresses origins omitted from propagated native tags; it does not invent a timing model for those origins.

The reviewed five-file source snapshot is based on `{s['base']}` and bound by `source-identity.json`. Production binary SHA256 is `{b['production_sha256']}`; native-test binary SHA256 is `{b['native_test_sha256']}`. The observed build HEAD was `{b['observed_head']}`. This subagent made no commits or pushes; parent owns final reviewed delivery.

Validation passed six new source-coverage cases, 33 existing LUT6/native coverage cases, and six CLI cases. New cases exercise both skew configurations, valid multi-phase FF/M10K and multilevel logic, inversions/constants, all concrete omitted origins, malformed/constant clock pins, stale skew, cuts/async sources, cycles and depth/work bounds. Existing cases independently cover all 64 emitted LUT truth rows, LAB/MLAB halves, exact rejected/exception rollback, and cohabiting FF controls/selector/mask preservation. CLI checks retain default/zero byte equality and reject unauthorized execution modes. `validation.json` records exact commands, log hashes and elapsed times and verifies that all source and binary bytes remained unchanged.

This is host-only compiler validation, not an FPGA route or timing-closure/hardware result. The tester separately owns actual-board source eligibility and default/zero controls and the consolidated `final-validation.json`; those results are not inferred from these unit tests. No FES RTL, clock constraints, module interfaces or shared schemas changed. Next integration step is parent review of the consolidated evidence, then the frozen fresh-route diagnostic recipe with all original acceptance gates intact.
'''
(H/'README.md').write_text(text)
fixed=['README.md','source-identity.json','source.patch','build.log','build-identity.json','validate.py','validation.json','validation-run.log','freeze-host.py']
for n in ['source-tests','lut6-native','cli']:fixed.extend([n+'.log',n+'.receipt.json'])
fixed.extend(str(p.relative_to(H)) for p in sorted((H/'source').rglob('*')) if p.is_file())
manifest={p:{'sha256':hashlib.sha256((H/p).read_bytes()).hexdigest(),'bytes':(H/p).stat().st_size} for p in fixed}
(H/'host-manifest.json').write_text(json.dumps({'files':manifest},indent=2,sort_keys=True)+'\n')
print(json.dumps({'host_files':len(manifest),'validation_sha256':hashlib.sha256((H/'validation.json').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((H/'host-manifest.json').read_bytes()).hexdigest()},indent=2))
