// Native domain-coverage counterexample; no placement, routing, or source edits.
#include "nextpnr.h"
#include "timing.h"
#include "analogue_repair.h"
#include "json11.hpp"
#include <fstream>
#include <iostream>
USING_NEXTPNR_NAMESPACE
using J=json11::Json;
static J one(const std::string &kind) {
    ArchArgs args;args.device="5CSEBA6U23I7";Context c(args);c.settings[c.id("target_freq")]=1e8;
    c.createNet(c.id("$PACKER_GND_NET"));c.createNet(c.id("$PACKER_VCC_NET"));
    auto *clock=c.createNet(c.id("clock"));clock->clkconstr=std::make_unique<ClockConstraint>();
    clock->clkconstr->period=DelayPair(10000);clock->clkconstr->high=clock->clkconstr->low=DelayPair(5000);
    auto ff=[&](const std::string &name,NetInfo *data,bool connected_clock=true){
        auto *f=c.createCell(c.id(name),id_MISTRAL_FF);
        for(auto p:{id_CLK,id_ENA,id_ACLR,id_SCLR,id_SLOAD,id_SDATA,id_DATAIN})f->addInput(p);
        f->addOutput(id_Q);f->connectPort(id_Q,c.createNet(c.id(name+"$q")));
        f->connectPort(id_DATAIN,data?data:f->getPort(id_Q));if(connected_clock)f->connectPort(id_CLK,clock);
        f->pin_data[id_ENA].state=f->pin_data[id_ACLR].state=PIN_1;
        f->pin_data[id_SCLR].state=f->pin_data[id_SLOAD].state=PIN_0;return f;
    };
    std::array<CellInfo*,6> sources{};for(unsigned n=0;n<6;++n)sources[n]=ff("source"+std::to_string(n),nullptr);
    NetInfo *branch=nullptr;
    if(kind=="known")branch=ff("other_known",nullptr)->getPort(id_Q);
    else if(kind=="missing_clock")branch=ff("missing_clock",nullptr,false)->getPort(id_Q);
    else if(kind=="undriven"||kind=="public_undriven") {
        branch=c.createNet(c.id("undriven"));
        if(kind=="public_undriven")c.ports[c.id("public_input")]=PortInfo{c.id("public_input"),branch,PORT_IN,{}};
    } else {
        auto *pll=c.createCell(c.id("async_pll"),id_altera_pll);pll->addOutput(id_locked);
        pll->connectPort(id_locked,c.createNet(c.id("async_status")));branch=pll->getPort(id_locked);
    }
    auto *mix=c.createCell(c.id("mixed_input"),id_MISTRAL_ALUT2);mix->params[id_LUT]=Property(8,4);
    mix->addInput(id_A);mix->addInput(id_B);mix->addOutput(id_Q);
    mix->connectPort(id_A,sources[0]->getPort(id_Q));mix->connectPort(id_B,branch);mix->connectPort(id_Q,c.createNet(c.id("mixed_input$q")));
    auto *lut=c.createCell(c.id("six_input_root"),id_MISTRAL_ALUT6);lut->params[id_LUT]=Property(int64_t(0xfffffffffffffffeULL),64);
    std::array<IdString,6> pins{id_A,id_B,id_C,id_D,id_E,id_F};
    for(unsigned n=0;n<6;++n){lut->addInput(pins[n]);lut->connectPort(pins[n],n?sources[n]->getPort(id_Q):mix->getPort(id_Q));}
    lut->addOutput(id_Q);lut->connectPort(id_Q,c.createNet(c.id("six_input_root$q")));auto *capture=ff("capture",lut->getPort(id_Q));
    c.assignArchInfo();TimingAnalyser timing(&c);timing.setup(false,false,true);std::string reason;
    bool accepted=critical_lut6_swap_output_coverage(&c,timing,lut->getPort(id_Q),&reason);
    std::vector<TimingAnalyser::SetupWindowHint> hints;bool have_hints=timing.get_setup_window_hints(CellPortKey(capture->name,id_DATAIN),hints);
    std::vector<EndpointClockPairTiming> rows;bool have_rows=timing.get_endpoint_clock_pair_timings(CellPortKey(capture->name,id_DATAIN),rows);
    J::array hh,rr;
    for(auto &h:hints)hh.push_back(J::object{{"launch",h.launch.clock.str(&c)},{"capture",h.capture.clock.str(&c)},
         {"launch_edge",int(h.launch.edge)},{"capture_edge",int(h.capture.edge)},{"cut",h.cut},{"window",h.window?J(*h.window):J()}});
    for(auto &r:rows)rr.push_back(J::object{{"launch",r.launch.clock.str(&c)},{"capture",r.capture.clock.str(&c)},
         {"setup_timed",r.setup_timed},{"hold_related",r.hold_related},{"setup_window",r.setup_window?J(*r.setup_window):J()},
         {"setup_margin",r.setup_margin?J(*r.setup_margin):J()},{"hold_margin",r.hold_margin?J(*r.hold_margin):J()}});
    int clock_count=0;auto cls=branch->driver.cell?int(c.getPortTimingClass(branch->driver.cell,branch->driver.port,clock_count)):-1;
    return J::object{{"case",kind},{"target_output_coverage_accepted",accepted},{"reason",reason},
        {"endpoint_hints_available",have_hints},{"hints",hh},{"endpoint_rows_available",have_rows},{"rows",rr},
        {"branch_driver_timing_class",cls},{"branch_clock_count",clock_count},{"source_lut_connected_inputs",2},{"target_distinct_connected_inputs",6}};
}
int main(int argc,char **argv){try{if(argc!=2)return 2;J::array cases;
    for(const char *kind:{"known","missing_clock","undriven","public_undriven","async_startpoint"})cases.push_back(one(kind));
    std::ofstream out(argv[1]);out<<J(J::object{{"scope","native timing/output-coverage API probe; no routed trial or guard change"},{"cases",cases}}).dump()<<"\n";return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<"\n";return 1;}}
