# Omitted upstream origin: native counterexample

The existing LUT6 output-coverage API accepts a cone whose source LUT mixes a valid clocked FF with a missing-clock FF, an undriven net, or a public undriven input. The native analyser omits the uncharacterized branch's origin; the downstream API then sees only the surviving known clock domain. A genuinely asynchronous startpoint remains visible and is correctly rejected.

The probe links the unchanged final `972d8ea6` native objects, with all 81 object/library hashes checked before and after build and execution. It calls full native STA and `critical_lut6_swap_output_coverage` on a LUT6 with six distinct connected input nets. One input is an ALUT2 AND of a known FF Q and the tested sibling origin; the other five come from distinct known FFs. A normal FF captures the LUT6 output.

| Sibling origin | Output coverage accepts | Native endpoint rows |
| --- | --- | --- |
| Known clocked FF | Yes | One known clock pair |
| FF with disconnected CLK | **Yes** | Identical to control |
| Undriven net | **Yes** | Identical to control |
| Public undriven input | **Yes** | Identical to control |
| Asynchronous PLL locked output | No | Strict accessor rejects |

Every accepted case reports the same rising-edge clock-to-clock row: 10,000 ps setup window, 8,175 ps setup margin and 544 ps hold margin. Thus checking retained native rows or preserving the unchanged full-report inventory alone does not prove complete upstream origins.

This is a source-coverage API counterexample on a small unplaced graph, not a routed-trial or physical-gain claim. No production sources, frozen binaries, prior receipts, acceptance guards or full routes were changed. The cache-fix host validation remains valid; enabled LUT6 repair admission remains blocked pending a bounded upstream structural check and focused regressions.

`probe.cc`, `build-plan.json`, `result.json` and `receipt.json` retain the construction, exact native calls, complete rows and frozen identities. The source/clock boundary is the point of the experiment; no assumption is made that a missing-clock register describes useful hardware.
