# Compact evidence capture recipe

Prepare only until the parent has frozen final receipts and campaign accounting.
Do not package a partial route or overwrite any earlier capture. The parent owns
`final-analysis/` and all route receipts/accounting.

1. Verify `final-validation.json`, all its `files` hashes and every source hash
   under `complete-source/`. Verify `committed-source-verification.json` against
   that exact manifest, binary hash and source-file dictionary. Keep observed
   build parent and later result commit separate.
2. Retain the complete host files bound by that manifest except executable/object
   payloads: six/33/six test logs and receipts, source/patch/complete-source,
   both CPU-only preparation receipts plus full placed JSON and predicted timing,
   default/zero comparison, board probe source/build plan/results/log/receipt,
   source reviews, and the new manifest/readback scripts. Binary/object hashes
   remain in the original receipts; this archive is not a standalone toolchain.
3. Retain the unchanged-972 counterexample source, exact build plan, native result,
   log and receipt from `../lut6-upstream-coverage-20261022/`. Its omitted-origin
   cases and the new guard are separate executions. Retain the exact board-probe
   input checkpoint from the earlier fixed-972 default control, or bind an exact
   retained path inside the existing immutable sibling capture. Do not substitute
   a new creator-normalized input.
4. Record exact original-path → retained-path → SHA256 mappings for every external
   receipt reference. No basename fallback, alias intersection or silent omission.
   The earlier cache/private suites remain at their 972 provenance; use the
   already published sibling `2026-10-22-pcxt-routethrough-cache` capture and its
   archive SHA instead of presenting those tests as rerun here.
5. If the parent combines this with the fresh paired-route capture, add both
   complete receipt/log/RBF/routed-JSON/endpoints/timing artifacts and the immutable
   accounting receipt only after completion. Include every failed/accepted trial
   and all root-owned final graph/timing proofs. Full route bytes are required;
   hashes alone are not durable evidence for new results.
6. Build a new deterministic tar.gz from an explicit member list. Read it back
   into a fresh temporary directory, reject traversal/absolute/link/duplicate
   members, verify the exact member inventory and every hash, and replay offline
   checks against the retained files. Controls must compare complete top-level and
   module inventories, raw bytes except creator, and complete report bytes. The
   board-probe result must retain three exact identities, both timing frames,
   all source/downstream/legality outcomes and full bounded origin inventories.
7. Freeze readback receipts before installation. The final README must separate
   source admission and physical-mask host tests from actual routed STA, and both
   from hardware acceptance. Earlier 972 validation explicitly declined enabled
   LUT6 routing; do not rewrite that historical decision.

The native board eligibility probe cannot be replayed from lightweight source
alone: its exact compiled objects are recorded but intentionally omitted from a
compact archive. Its immutable outputs can be independently read back; a fresh
native replay requires rebuilding that recorded toolchain identity. No loaded
checkpoint STA should be represented as the original fresh-route result.
