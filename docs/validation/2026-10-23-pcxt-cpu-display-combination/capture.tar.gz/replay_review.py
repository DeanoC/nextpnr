#!/usr/bin/env python3
"""Replay the original independent review without changing its bytes or paths."""
from pathlib import Path
import runpy,sys
R=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'final-analysis'))
runpy.run_path(str(R/'final-analysis/independent-review/review.py'),run_name='__main__')
