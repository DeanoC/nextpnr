#!/usr/bin/env python3
"""Independent replay/review of root-authored full graph and final timing proofs."""
from pathlib import Path
import contextlib,hashlib,importlib,io,json,sys
HERE=Path(__file__).resolve().parent;A=HERE.parent;sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
inputs={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*.py'))};checks=[]
def compare_write(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs';checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
log=io.StringIO()
with contextlib.redirect_stdout(log):
 g=importlib.import_module('prove_graph');g.write=compare_write;g.main()
 for name in ('test_checks',):
  c=importlib.import_module(name);c.write=compare_write;c.main()
 n=importlib.import_module('verify_topology');n.write=compare_write;n.main()
 t=importlib.import_module('compare_timing');t.R=HERE;t.main()
assert (HERE/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
assert inputs=={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*.py'))}
g=read(A/'graph-proof.json');t=read(A/'route-comparison.json');n=read(A/'topology-proof.json');d=read(A/'decision-ledger.json')
assert len(g['accepted_cells'])==2
assert [(x['pins'],len(x['all_raw_net_rows'])) for x in g['accepted_cells']]==[(['D','E'],32),(['A','C'],8)]
assert all(x['before_output']==x['after_output'] for c in g['accepted_cells'] for x in c['all_raw_net_rows'])
assert set(g['changed_canonical_net_bits'])=={54479,54480,57715,57717}
assert d['preceding_repair_lines']['cpu2']==d['preceding_repair_lines']['combined16']
assert d['budget']==16 and d['tried']==16 and d['kept']==2
assert [x['number'] for x in d['all_trials'] if x['accepted']]==[3,6]
assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal'] and len(t['every_endpoint_row'])==17199
assert t['default_vs_prior_fixed_invariance_pass']
assert t['native_margin_delta_counts']=={'setup':{'improved':5,'unchanged':17189},'hold':{'unchanged':17194}}
assert t['independent_complete_clock_guard']['pass'] and t['independent_emitted_inventory_guard']['nonregression_and_inventory_pass'] and not t['independent_emitted_inventory_guard']['all_violations']
assert all(x['setup']['failures']==8 and x['unsupported_count']==105 and not x['complete'] and x['hold']['failures']==0 for x in t['runs'].values())
assert n['selected_nets']==10 and n['stationary_users']==18 and n['changed_physical_users']==4 and n['retained_original_wire_tuples']==65
changed=[x for x in t['every_endpoint_row'] if x['margin_delta_ps']['setup']]
result={'passed':True,'reviewer':'timing_strategy','review_script_sha256':sha(__file__),'inputs':inputs,'exact_replays':checks,'complete_endpoint_rows':17199,'native_margin_delta_counts':t['native_margin_delta_counts'],'setup_failure_counts':{k:v['setup']['failures'] for k,v in t['runs'].items()},'whole_system_setup_minimum_ps':{k:v['setup']['minimum_ps'] for k,v in t['runs'].items()},'changed_setup_rows':changed,'accepted_cells':[{'cell':x['cell'],'pins':x['pins'],'complete_truth_rows':len(x['all_raw_net_rows'])} for x in g['accepted_cells']],'native_topology':{k:n[k] for k in ('selected_nets','stationary_users','changed_physical_users','retained_original_wire_tuples')},'charged_route_seconds':0,'findings':['Complete graph, alias, settings/LAB, physical ownership and final setup/hold/native clock inventories replay exactly. Only four canonical input trees and their logged D/E and A/C endpoints change.','Preceding route and two-round LUT6 repair decisions match; trial3 CGA and trial6 MDA permutations are proven directly between complete final checkpoints. Intermediate state is not independently snapshotted.','One CGA setup row improves135ps and four MDA setup rows improve62ps; no setup regresses and all17194 holds are exact. Eight setup failures remain; whole-system worst slack stays-434ps.','The complete native10-net frontier preserves18 stationary users and65 original wire/PIP/strength tuples. Source/driver metadata and all32 CGA plus8 MDA truth rows remain exact.'],'limits':['Independent review of root-authored graph/timing checkers and exact offline replay. New native selection/readback integration was authored by this same reviewer and is separately subject to source review; this is not an independent implementation of that integration.','Emitted final reports use the recorded final timing frame; no reload STA or new reference-free report is invented. Live pass guards remain separately evidenced by the frozen implementation/logs.','Still8 setup failures,105 unsupported entries and complete=false. No hardware, electrical qualification or emitted-RBF mask equivalence is claimed.']}
(HERE/'replay.log').write_text(log.getvalue());(HERE/'review.json').write_bytes(encoded(result));print(json.dumps({'passed':True,'review_sha256':sha(HERE/'review.json'),'exact_replays':len(checks)},sort_keys=True))
