#!/usr/bin/env python3
"""Complete ordinary-LUT proof after the unchanged two-round CPU repair."""
import json
from permutation_graph_core import decisions,prove,pinmap,transposed_mask,route_tree
from support import HERE,ROOT,need,read,write,sha,paired_receipts

def main():
    paired_receipts()
    cases = ('cpu2', 'combined16')
    logs = {name: (ROOT / ('route-' + name) / 'nextpnr.log').read_text() for name in cases}
    ledger = decisions(logs['combined16'],16)
    need(ledger['all_verbatim_lines'][-1] == ledger['summary'], 'candidate summary must be last')
    ledger['preceding_repair_lines'] = {name: [line for line in text.splitlines() if 'Critical route ' in line or 'Critical LUT6 ' in line] for name, text in logs.items()}
    need(ledger['preceding_repair_lines']['cpu2'] == ledger['preceding_repair_lines']['combined16'], 'preceding route/LUT6 repair decisions differ')
    need('Critical LUT permutation' not in logs['cpu2'], 'baseline unexpectedly ran permutation pass')
    left, right = [read(ROOT / ('route-' + name) / 'routed.json') for name in cases]
    result = prove(left, right, [t for t in ledger['all_trials'] if t['accepted']])
    graph_hashes = {name: sha(ROOT / ('route-' + name) / 'routed.json') for name in cases}
    result.update(native_port_resolver_sha256=sha(HERE/'native_port_identity.py'),checker_sha256=sha(__file__), support_sha256=sha(HERE / 'support.py'), graph_core_sha256=sha(HERE/'permutation_graph_core.py'), graph_sha256=graph_hashes)
    write('decision-ledger.json', ledger)
    write('graph-proof.json', result)
    write('native-selection-specs.json', {'schema': 1, 'graph_proof_sha256': sha(HERE / 'graph-proof.json'),
          'graph_sha256': graph_hashes, 'selections': result['native_topology_selections'],
          'requirements': ['Native decode every selected source, complete users and every PIP source/destination in both graphs.',
                           'Require complete trees rooted at the identical source with no foreign owners, cycles, disconnected branches or missing sinks.',
                           'For each native sink whose wire vector is unchanged, require every original root-to-sink wire/PIP/strength tuple unchanged.',
                           'Do not infer timing, reroute, assign new pins or configure bitstream during readback.']})
    print(json.dumps({key: result[key] for key in ('status', 'complete_cells', 'complete_net_alias_records', 'changed_canonical_net_bits')}, sort_keys=True))


if __name__ == '__main__':
    main()
