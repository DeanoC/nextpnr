"""Strict deterministic readers shared only by this independent evidence check."""
from pathlib import Path
import hashlib
import json
import math

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def need(value, message):
    if not value:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def finite_tree(value):
    if isinstance(value, float):
        need(math.isfinite(value), 'nonfinite JSON numeric value')
    elif isinstance(value, dict):
        for item in value.values():
            finite_tree(item)
    elif isinstance(value, list):
        for item in value:
            finite_tree(item)


def read(path):
    value = json.loads(Path(path).read_text(), object_pairs_hook=unique)
    finite_tree(value)
    return value


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def archive_mode():
    path = ROOT / 'archive-mode.json'
    return read(path) if path.exists() else None


def verify_recorded(path, expected):
    """Resolve exact recorded identities, with no original-path archive fallback."""
    mode = archive_mode()
    if mode is None:
        actual = Path(path)
    else:
        need(str(path) in mode['recorded_files'], 'unmapped archived original identity: ' + str(path))
        record = mode['recorded_files'][str(path)]
        need(record['sha256'] == expected, 'archive recorded digest disagrees with original receipt')
        relative = Path(record['retained_path'])
        need(not relative.is_absolute() and '..' not in relative.parts, 'unsafe archive path mapping')
        actual = ROOT / relative
    need(sha(actual) == expected, 'recorded file hash mismatch: ' + str(path))
    return actual


def verify_binary(expected, original_path):
    mode = archive_mode()
    if mode is None:
        need(sha(ROOT / 'nextpnr-mistral') == expected, 'frozen binary mismatch')
    else:
        need(mode['excluded_binary'] == {'original_path': original_path, 'sha256': expected},
             'omitted binary identity differs from original receipt')
        need(not (ROOT / 'nextpnr-mistral').exists(), 'archive unexpectedly contains executable')


def reference_folder(kind='route'):
    mode = archive_mode()
    if mode is None:
        return ROOT.parent / ('lut6-rounds-20261022/route-round2' if kind == 'route' else 'private-pair-20261022/prepare-default')
    relative = Path(mode['references'][kind]['retained_path'])
    need(not relative.is_absolute() and '..' not in relative.parts, 'unsafe archived reference directory')
    return ROOT / relative


def reference_original(kind='route'):
    mode = archive_mode()
    return str(reference_folder(kind)) if mode is None else mode['references'][kind]['original_directory']


def receipt(folder):
    folder = Path(folder)
    value = read(folder / 'receipt.json')
    need(value['returncode'] in (0, 1), 'incomplete/non-timing execution: ' + str(folder))
    required = {'routed.json', 'endpoints.json', 'timing.json', 'diagnostic.rbf', 'nextpnr.log'}
    need(required <= set(value['artifacts']), 'receipt lacks complete final artifacts')
    for name, expected in value['artifacts'].items():
        need(sha(folder / name) == expected, 'artifact hash mismatch: ' + str(folder / name))
    return value


def paired_receipts():
    values = {name: receipt(ROOT / ('route-' + name)) for name in ('cpu2', 'combined16')}
    left, right = values['cpu2'], values['combined16']
    need(right['nextpnr_command'] == left['nextpnr_command'] + ['--critical-lut-permute-budget', '16', '--critical-unobserved-arith-outputs'],
         'unexpected route recipe difference')
    need(left['inputs'] == right['inputs'], 'raw input identity differs')
    need(left['binary_sha256'] == right['binary_sha256'], 'binary differs')
    verify_binary(left['binary_sha256'], left['nextpnr_command'][0])
    need(left['committed_source_verification'] == right['committed_source_verification'], 'source verification differs')
    need(left['committed_source_verification'] == read(ROOT / 'committed-source-verification.json'), 'committed source verification file differs')
    need(left['final_validation'] == right['final_validation'] == read(ROOT / 'final-validation.json'), 'validation differs')
    for record in values.values():
        for path, expected in record['immutable_evidence_sha256'].items():
            verify_recorded(path, expected)
        for item in record['inputs'].values():
            verify_recorded(item['path'], item['sha256'])
    return values
