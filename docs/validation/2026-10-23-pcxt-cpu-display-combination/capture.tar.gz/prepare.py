#!/usr/bin/env python3
"""Retain completed combined routes; deduplicate immutable host/source evidence."""
from pathlib import Path
import hashlib,json,shutil,tarfile
C=Path(__file__).resolve().parent;A=C.parent;R=A.parent;P=C/'payload'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def copy(p,n=None):
 dest=P/(n or p.relative_to(R));dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==sha(p),str(dest)
 else:shutil.copy2(p,dest)
 return str(dest.relative_to(P))
assert not P.exists(),'fresh payload required';P.mkdir()
for n in ['final-validation.json','source-identity.json','committed-source-verification.json','control-proof.json','independent-source-review.json','route.py','record-runs.py']:copy(R/n)
final=read(R/'final-validation.json');assert sha(R/'final-validation.json')=='135036d3f77623b44eaecc50dc66c66e2236ee0821561fdd64907fc2da6b9814'
commit=read(R/'committed-source-verification.json');assert commit['commit']=='02ffa3aa6a74b71debbb23da24e5332b541cf742'
assert commit['source_files']==final['source_files']
for case in ['cpu2','combined16']:
 receipt=read(R/f'route-{case}/receipt.json');assert receipt['binary_sha256']==final['binary_sha256']
 for n,h in receipt['artifacts'].items():assert sha(R/f'route-{case}'/n)==h;copy(R/f'route-{case}'/n)
 copy(R/f'route-{case}/receipt.json')
for p in sorted(A.rglob('*')):
 if p.is_file() and not {'capture','__pycache__'}&set(p.relative_to(A).parts):copy(p)
for p in sorted((R/'native-topology').rglob('*')):
 if p.is_file() and p.name!='tree-reader' and '__pycache__' not in p.parts:copy(p)
for p in sorted((R/'accounting-44').iterdir()):
 if p.is_file():copy(p)
summary=read(P/'accounting-44/summary.json');assert summary['fes_commit']=='c02fede0378e36d61073bd77c89bfbcced94c084'
assert summary['journal_sha256']==sha(P/'accounting-44/continued-runs.jsonl')
omitted=[]
for p in [R/'nextpnr-mistral',R/'native-topology/tree-reader']:
 omitted.append({'original_path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'reason':'Executable omitted; offline replay uses exact recorded artifacts and decoded native trees.'})
write(P/'omitted-payloads.json',{'files':omitted,'native_snapshot_manifest':'native-topology/frozen-manifest.json','native_snapshot_payload':'All401 frozen native source/header/object snapshot members omitted; no native execution/rebuild is claimed by offline replay.'})
paths={'budget':R.parent/'lut-permutation-budget16-20261022/final-analysis/capture/capture.tar.gz','rounds':R.parent/'lut6-rounds-20261022/final-analysis/capture/capture.tar.gz'}
expected={'budget':'ab43d849cef04528dad1353c33e4a6bf440feffe39500d3a0509085c065a0b9e','rounds':'86105f2089992e257032b32b10c818b14e59c74a72bca14ba871c5cad890f5a8'}
bindings=[];dependencies={}
for kind,dep in paths.items():
 assert sha(dep)==expected[kind]
 with tarfile.open(dep) as t:
  data=t.extractfile('manifest.json').read();m=json.loads(data)
  spec={'archive_sha256':sha(dep),'bytes':dep.stat().st_size,'members':len(t.getmembers()),'manifest_sha256':hashlib.sha256(data).hexdigest(),'manifest_path':f'dependencies/{kind}-manifest.json'}
  assert spec['members']==len(m)+1;dependencies[kind]=spec
  d=P/spec['manifest_path'];d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
  for member in sorted(m):
   target=None
   if kind=='budget':
    if member.startswith('external-inputs/'):target=member
    if member in ['final-validation.json','committed-source-verification.json','replay-proof.json','archive-mode.json','CAPTURE-README.md']:target='references/budget-evidence/'+member
   elif member.startswith('route-round2/'):target='references/prior-cpu/'+member[len('route-round2/'):]
   if target is not None:
    d=P/target;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(t.extractfile(member).read());assert sha(d)==m[member]['sha256']
    bindings.append({'dependency':kind,'member':member,'retained_path':target,'sha256':sha(d)})
  if kind=='budget':
   for n,h in final['files'].items():assert m[n]['sha256']==h
   for n,h in final['source_files'].items():assert m['complete-source/'+n]['sha256']==h
   for p in [P/'final-validation.json',P/'source-identity.json',P/'committed-source-verification.json',P/'control-proof.json',P/'independent-source-review.json']:
    member=p.name;assert sha(p)==m[member]['sha256'];bindings.append({'dependency':kind,'member':member,'retained_path':member,'sha256':sha(p)})
   for name,h in read(P/'native-topology/reuse-identity.json')['reader_files'].items():
    if name=='tree-reader':continue
    member='native-topology/'+name;assert sha(P/member)==h==m[member]['sha256'];bindings.append({'dependency':kind,'member':member,'retained_path':member,'sha256':h})
recorded={};receipt=read(R/'route-cpu2/receipt.json')
for path,h in receipt['immutable_evidence_sha256'].items():
 original=Path(path);target=str(original.relative_to(R)) if original.is_relative_to(R) else 'references/prior-cpu/receipt.json'
 assert sha(P/target)==h;recorded[path]={'retained_path':target,'sha256':h}
for v in receipt['inputs'].values():
 target='external-inputs/'+v['sha256']+'-'+Path(v['path']).name
 assert sha(P/target)==v['sha256'];recorded[v['path']]={'retained_path':target,'sha256':v['sha256']}
bindings.sort(key=lambda v:(v['dependency'],v['member'],v['retained_path']))
mode={'recorded_files':recorded,'excluded_binary':{'original_path':receipt['nextpnr_command'][0],'sha256':final['binary_sha256']},'references':{'route':{'original_directory':str(R.parent/'lut6-rounds-20261022/route-round2'),'retained_path':'references/prior-cpu'}},'dependencies':dependencies,'selected_dependency_members':bindings,'scope':'No live-path fallback. Complete budget16/rounds archive member hashes are verified. The85 host bindings and29 committed sources are retained once in the budget16 dependency. Historical transitive identities are context, not new replay.'}
write(P/'archive-mode.json',mode)
for n in ['prepare.py','replay.py','replay_review.py','verify_capture.py','build_archive.py','README.md']:copy(C/n,'CAPTURE-README.md' if n=='README.md' else n)
print(json.dumps({'files':len([p for p in P.rglob('*') if p.is_file()]),'host_bindings_in_budget_dependency':len(final['files']),'source_files_in_budget_dependency':len(final['source_files']),'dependencies':dependencies},indent=2,sort_keys=True))
