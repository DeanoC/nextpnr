#!/usr/bin/env python3
"""Complete saved graph/timing/tree replay; immutable host payload stays in dependency."""
from pathlib import Path
from decimal import Decimal
import contextlib,hashlib,importlib,io,json,sys,tempfile
R=Path(__file__).resolve().parent;A=R/'final-analysis';sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
assert support.archive_mode() is not None and support.ROOT==R
final=read(R/'final-validation.json');commit=read(R/'committed-source-verification.json')
assert commit['commit']=='02ffa3aa6a74b71debbb23da24e5332b541cf742' and commit['source_files']==final['source_files'] and commit['final_validation_sha256']==sha(R/'final-validation.json')
budget=read(R/'dependencies/budget-manifest.json')
for n,h in final['files'].items():assert budget[n]['sha256']==h,n
for n,h in final['source_files'].items():assert budget['complete-source/'+n]['sha256']==h,n
assert len(final['files'])==85 and len(final['source_files'])==29
assert (R/'references/budget-evidence/final-validation.json').read_bytes()==(R/'final-validation.json').read_bytes()
prior=read(R/'references/budget-evidence/replay-proof.json');assert prior['passed'] and prior['source_files']==29 and prior['host_admission_files']==85
assert sha(R/'references/budget-evidence/replay-proof.json')==budget['replay-proof.json']['sha256']
native=R/'native-topology';build=read(native/'build-receipt.json');compat=read(native/'architecture-compatibility.json');reuse=read(native/'reuse-identity.json')
assert build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
for name,key in [('tree-reader.cc','helper_source_sha256'),('frozen-manifest.json','frozen_manifest_sha256'),('build-commands.json','build_commands_sha256'),('build.log','build_log_sha256')]:assert sha(native/name)==build[key]
assert len(read(native/'frozen-manifest.json')['files'])==401
assert reuse['passed'] and reuse['source_commit']==compat['route_compiler_commit']==commit['commit']
assert reuse['binary_sha256']==final['binary_sha256'] and compat['reader_binary_sha256']==build['helper_binary_sha256']
for n,h in reuse['identical_compiler_and_checker_bindings'].items():assert sha(R/n)==h==budget[n]['sha256']
for n,h in reuse['reader_files'].items():
 if n=='tree-reader':assert h==build['helper_binary_sha256'];continue
 assert sha(native/n)==h==budget['native-topology/'+n]['sha256']
assert sha(native/'architecture-compatibility.json')==budget['native-topology/architecture-compatibility.json']['sha256']
origin=read(A/'indexed-port-resolution-origin.json');assert origin['frontend_commit']==commit['commit'] and origin['frontend_sha256']==sha(A/'pinned-frontend_base.h') and origin['module_sha256']==sha(A/'native_port_identity.py')
resolver_review=read(A/'indexed-resolver-review.json');assert resolver_review['passed'] and resolver_review['frontend_sha256']==sha(A/'pinned-frontend_base.h')
assert resolver_review['cores']['combined']['new_core_sha256']==sha(A/'permutation_graph_core.py') and resolver_review['cores']['combined']['resolver_sha256']==sha(A/'native_port_identity.py')
root=read(native/'root-readback/receipt.json');assert root['passed'] and root['helper_binary_sha256']==build['helper_binary_sha256'] and root['architecture_compatibility_sha256']==sha(native/'architecture-compatibility.json')
assert len(root['rows'])==2 and {v['case'] for v in root['rows']}=={'cpu2','combined16'}
for row in root['rows']:
 case=row['case'];assert row['returncode']==0 and row['independent_native_output_byte_exact']
 assert sha(native/'root-readback'/(case+'-topology.json'))==row['output_sha256']==sha(native/'paired-readback'/(case+'-topology.json'))
 assert sha(native/'paired-readback'/(case+'-selection.json'))==row['selection_sha256']
accounting=read(R/'accounting-44/summary.json');journal=R/'accounting-44/continued-runs.jsonl';records=[json.loads(v) for v in journal.read_text().splitlines()]
assert sha(journal)==accounting['journal_sha256'] and len(records)==accounting['completed_subsequent_receipts']==44
assert len({v['case'] for v in records})==44
assert Decimal(accounting['pre_journal_charge_seconds'])+sum(Decimal(v['charged_seconds_decimal']) for v in records)==Decimal(accounting['cumulative_charge_seconds'])
for case in ['cpu2','combined16']:
 rows=[v for v in records if v['case']=='out/cpu2-permutation16-20261022/route-'+case];assert len(rows)==1 and rows[0]['receipt_sha256']==sha(R/f'route-{case}/receipt.json')
checks=[]
def compare_write(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs';checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
with contextlib.redirect_stdout(io.StringIO()):
 for name in ['prove_graph','test_checks','verify_topology']:
  m=importlib.import_module(name);m.write=compare_write;m.main()
 c=importlib.import_module('compare_timing')
 with tempfile.TemporaryDirectory(prefix='pcxt-combined-proof-') as scratch:
  c.R=Path(scratch);c.main();assert (c.R/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
 checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
graph=read(A/'graph-proof.json');timing=read(A/'route-comparison.json');topology=read(A/'topology-proof.json')
assert len(timing['every_endpoint_row'])==17199 and timing['native_margin_delta_counts']=={'setup':{'improved':5,'unchanged':17189},'hold':{'unchanged':17194}}
assert timing['endpoint_identity_inventory_equal'] and timing['all_row_domain_windows_and_flags_equal'] and timing['all_metadata_categories_equal'] and timing['default_vs_prior_fixed_invariance_pass']
assert [(x['pins'],len(x['all_raw_net_rows'])) for x in graph['accepted_cells']]==[(['D','E'],32),(['A','C'],8)]
assert all(v['before_output']==v['after_output'] for c in graph['accepted_cells'] for v in c['all_raw_net_rows'])
assert set(graph['changed_canonical_net_bits'])=={54479,54480,57715,57717}
assert topology['selected_nets']==10 and topology['stationary_users']==18 and topology['changed_physical_users']==4 and topology['retained_original_wire_tuples']==65
assert all(x['setup']['failures']==8 and x['hold']['failures']==0 and x['unsupported_count']==105 and not x['complete'] for x in timing['runs'].values())
result={'passed':True,'source_commit':commit['commit'],'source_files_in_verified_budget_dependency':29,'host_admission_files_in_verified_budget_dependency':85,'native_snapshot_manifest_members':401,'exact_replays':checks,'complete_endpoint_rows':17199,'native_margin_delta_counts':timing['native_margin_delta_counts'],'all32_CGA_and8_MDA_truth_rows_equal':True,'native_topology':{k:topology[k] for k in ('selected_nets','stationary_users','changed_physical_users','retained_original_wire_tuples')},'pair_route_charge_seconds_recorded_not_recharged':timing['pair_charge_seconds'],'charged_route_seconds':0,'historical_accounting_context':{'journal_records':44,'cumulative_charge_seconds':accounting['cumulative_charge_seconds'],'scope':'Journal arithmetic and these two receipt hashes checked; other historical routes are context only.'},'scope':'Offline replay of saved full graphs, final timing inventories and recorded native decoded trees. Complete dependency member hashes bind prior host/source evidence without duplicating it; prior host commands are not rerun. No native execution, GPU route, emitted-RBF mask proof, reload STA or hardware acceptance.'}
print(encoded(result).decode(),end='')
