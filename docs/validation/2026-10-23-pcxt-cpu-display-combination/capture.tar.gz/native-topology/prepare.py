#!/usr/bin/env python3
"""Reuse an already qualified structural reader for the exact same compiler source."""
from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent;R=H.parent;B=R.parent/'lut-permutation-budget16-20261022';N=B/'native-topology'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
bound={}
for n in ['source-identity.json','final-validation.json','committed-source-verification.json','control-proof.json']:
 assert sha(R/n)==sha(B/n);bound[n]=sha(R/n)
source=read(R/'committed-source-verification.json');assert source['commit']=='02ffa3aa6a74b71debbb23da24e5332b541cf742'
assert sha(R/'nextpnr-mistral')==source['binary_sha256']=='ff2174157ae425d4b8c106bb22120be740230ac02b28e8a198010124f3b433e3'
files={}
for n in ['tree-reader','tree-reader.cc','build-receipt.json','build-commands.json','build.log','frozen-manifest.json','committed-source-verification.json','architecture-compatibility.json','independent-reader-review.json','lut6-prefix-proof.json']:
 if (H/n).exists():assert sha(H/n)==sha(N/n)
 else:shutil.copy2(N/n,H/n)
 files[n]=sha(H/n)
compat=read(H/'architecture-compatibility.json');review=read(H/'independent-reader-review.json');build=read(H/'build-receipt.json')
assert compat['passed'] and review['passed'] and review['architecture_compatibility_sha256']==sha(H/'architecture-compatibility.json')
assert compat['route_compiler_commit']==source['commit'] and compat['route_source_identity_sha256']==sha(R/'source-identity.json')
assert sha(H/'tree-reader')==build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
assert sha(H/'tree-reader.cc')==build['helper_source_sha256'] and sha(H/'frozen-manifest.json')==build['frozen_manifest_sha256']
for n in ['permutation_graph_core.py','native_port_identity.py']:
 assert sha(R/'final-analysis'/n)==sha(B/'final-analysis'/n);bound['final-analysis/'+n]=sha(R/'final-analysis'/n)
value={'passed':True,'source_commit':source['commit'],'binary_sha256':source['binary_sha256'],'identical_compiler_and_checker_bindings':bound,'reader_files':files,'source_validation_parent':str(B),'scope':'Exact same committed compiler/model, core graph checker and indexed-port resolver as the qualified budget4/16 pair. Reused internally consistent old native reader only decodes saved JSON/PIP/source/sink identities. No new route, configuration, pin assignment, reload timing or hardware acceptance.'}
(H/'reuse-identity.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');print(sha(H/'reuse-identity.json'))
