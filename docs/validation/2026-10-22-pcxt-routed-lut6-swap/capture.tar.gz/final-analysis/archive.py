#!/usr/bin/env python3
"""Immutable compact capture; verifies every member and exact offline replay."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import sys
import tarfile
import tempfile
from support import HERE, ROOT, need, read, sha, paired_receipts, reference_folder

CAPTURE = HERE / 'capture'
SOURCE = CAPTURE / 'source'


def main():
    need(not CAPTURE.exists(), 'capture already exists; never overwrite immutable evidence')
    receipts = paired_receipts()
    need(read(HERE / 'summary.json')['status'] == 'complete_no_improvement', 'complete summary missing')
    need(read(HERE / 'graph-proof.json')['status'] == 'pass', 'complete graph proof missing')
    need(read(HERE / 'source-control-proof.json')['status'] == 'pass', 'source/control proof missing')
    need(read(HERE / 'checker-tests.json')['status'] == 'pass', 'checker self-tests missing')
    SOURCE.mkdir(parents=True)
    recorded = {}

    def retain(original, relative):
        original, relative = Path(original), Path(relative)
        need(original.is_file() and not original.is_symlink(), 'not a regular source file: ' + str(original))
        need(not relative.is_absolute() and '..' not in relative.parts, 'unsafe retained path')
        target = SOURCE / relative
        expected = sha(original)
        if target.exists():
            need(sha(target) == expected, 'different retained-path collision')
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, target)
        item = {'retained_path': str(relative), 'sha256': expected}
        if str(original) in recorded:
            need(recorded[str(original)]['sha256'] == expected, 'original source changed during capture')
        else:
            recorded[str(original)] = item

    def folder(original, relative):
        for path in sorted(Path(original).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                retain(path, Path(relative) / path.relative_to(original))

    for name in ('source-identity.json', 'source.diff', 'final-validation.json', 'committed-source-verification.json',
                 'control-proof.json', 'prepare-controls.py', 'prepare-controls.log', 'freeze-validation.py',
                 'route.py', 'route.log', 'route-accounting.json'):
        retain(ROOT / name, name)
    for name in ('source', 'final-validation', 'prepare-default', 'prepare-zero', 'route-default', 'route-swap16'):
        folder(ROOT / name, name)
    for path in sorted(HERE.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.log', '.md'):
            retain(path, Path('final-analysis') / path.name)
    retain(HERE / 'README.md', 'README.md')
    references = {}
    all_receipts = list(receipts.values())
    for kind in ('route', 'preparation'):
        original = reference_folder(kind)
        relative = 'references/prior13' if kind == 'route' else 'references/prior-preparation'
        folder(original, relative)
        references[kind] = {'original_directory': str(original), 'retained_path': relative}
        all_receipts.append(read(original / 'receipt.json'))
    all_receipts += [read(ROOT / name / 'receipt.json') for name in ('prepare-default', 'prepare-zero')]
    for receipt in all_receipts:
        for info in receipt['inputs'].values():
            original = Path(info['path'])
            need(sha(original) == info['sha256'], 'external input digest differs')
            retain(original, Path('external-inputs') / (info['sha256'] + '-' + original.name))
    for receipt in receipts.values():
        for path, expected in receipt['immutable_evidence_sha256'].items():
            need(path in recorded and recorded[path]['sha256'] == expected, 'missing immutable recorded identity: ' + path)
    mode = {'scope': 'Exact offline replay of captured sources, graph and native reports. No original-path fallback or compiler execution.',
            'excluded_binary': {'original_path': receipts['default']['nextpnr_command'][0], 'sha256': receipts['default']['binary_sha256']},
            'excluded_binary_reason': 'Executable/object trees omitted; original binary hash and all13 frozen source identities remain bound.',
            'references': references, 'recorded_files': recorded}
    (SOURCE / 'archive-mode.json').write_text(json.dumps(mode, indent=2, sort_keys=True) + '\n')
    files = [path for path in sorted(SOURCE.rglob('*')) if path.is_file()]
    manifest = {str(path.relative_to(SOURCE)): {'sha256': sha(path), 'size': path.stat().st_size} for path in files}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    (SOURCE / 'manifest.json').write_bytes(manifest_bytes)
    archive = CAPTURE / 'capture.tar.gz'
    with archive.open('wb') as stream, gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0, compresslevel=6) as compressed, tarfile.open(fileobj=compressed, mode='w|') as tar:
        for path in files:
            payload = path.read_bytes()
            info = tarfile.TarInfo(str(path.relative_to(SOURCE)))
            info.size = len(payload); info.mode = 0o644; info.mtime = 0
            tar.addfile(info, io.BytesIO(payload))
        info = tarfile.TarInfo('manifest.json'); info.size = len(manifest_bytes); info.mode = 0o644; info.mtime = 0
        tar.addfile(info, io.BytesIO(manifest_bytes))
    with tarfile.open(archive, 'r:gz') as tar:
        need(set(tar.getnames()) == set(manifest) | {'manifest.json'} and len(tar.getnames()) == len(manifest) + 1, 'archive member inventory differs')
        for name, item in manifest.items():
            payload = tar.extractfile(name).read()
            need(len(payload) == item['size'] and hashlib.sha256(payload).hexdigest() == item['sha256'], 'archive readback differs: ' + name)
        need(tar.extractfile('manifest.json').read() == manifest_bytes, 'embedded manifest differs')
    readback = {'status': 'pass', 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
                'verified_members_including_manifest': len(manifest) + 1, 'manifest_sha256': sha(SOURCE / 'manifest.json')}
    (CAPTURE / 'archive-readback.json').write_text(json.dumps(readback, indent=2, sort_keys=True) + '\n')
    extraction = Path(tempfile.mkdtemp(prefix='pcxt-lut6-swap-offline-', dir='/tmp'))
    with tarfile.open(archive, 'r:gz') as tar:
        tar.extractall(extraction, filter='data')
    checks = []
    for script, outputs in (
        ('verify_sources.py', ['source-control-proof.json']),
        ('test_checks.py', ['checker-tests.json']),
        ('prove_graph.py', ['graph-proof.json', 'decision-ledger.json']),
        ('compare_timing.py', ['route-comparison.json']),
        ('summarize.py', ['summary.json']),
    ):
        expected = {name: (extraction / 'final-analysis' / name).read_bytes() for name in outputs}
        completed = subprocess.run([sys.executable, str(extraction / 'final-analysis' / script)], cwd='/tmp',
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (CAPTURE / ('offline-' + script + '.log')).write_text(completed.stdout)
        need(completed.returncode == 0, 'offline check failed: ' + script + '; retained ' + str(extraction))
        for name, payload in expected.items():
            need((extraction / 'final-analysis' / name).read_bytes() == payload, 'offline proof bytes differ: ' + name)
        checks.append({'script': script, 'returncode': 0, 'outputs': outputs, 'all_proof_bytes_identical': True})
    for path, item in recorded.items():
        need(sha(path) == item['sha256'], 'original evidence changed during capture')
    need(sha(ROOT / 'nextpnr-mistral') == mode['excluded_binary']['sha256'], 'original binary changed during capture')
    result = {**readback, 'offline_extraction': str(extraction), 'all_offline_checks': checks,
              'scope': 'Complete retained source/control/graph/timing proof replay without the compiler executable; no reroute or hardware acceptance.'}
    (CAPTURE / 'offline-readback.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
