#!/usr/bin/env python3
"""Deterministic outcome and accounting summary of the complete checks."""
from collections import Counter, defaultdict
from decimal import Decimal
import json
from support import HERE, ROOT, read, sha, write, need


def main():
    comparison, graph, ledger, accounting = [read(path) for path in
        (HERE / 'route-comparison.json', HERE / 'graph-proof.json', HERE / 'decision-ledger.json', ROOT / 'route-accounting.json')]
    artifacts = {name: {'default_sha256': sha(ROOT / 'route-default' / name), 'swap16_sha256': sha(ROOT / 'route-swap16' / name),
                        'byte_identical': (ROOT / 'route-default' / name).read_bytes() == (ROOT / 'route-swap16' / name).read_bytes()}
                 for name in ('diagnostic.rbf', 'routed.json', 'endpoints.json', 'timing.json')}
    families = defaultdict(list)
    for failure in comparison['every_setup_failure_each_run']['default']:
        source = failure['actual_saved_source_and_path']
        family = source['family_inferred_from_actual_launch_cell'] if source else 'saved witness unavailable'
        families[family].append(failure['native_row']['setup'])
    charge = sum(Decimal(str(read(ROOT / ('route-' + name) / 'receipt.json')['charged_seconds'])) for name in ('default', 'swap16'))
    need(str(charge) == comparison['pair_charge_seconds'], 'current pair charge differs')
    need(accounting['completed_subsequent_runs'] == 32 and set(accounting['new_cases']) == {
        'out/routed-lut6-swap-20261022/route-default', 'out/routed-lut6-swap-20261022/route-swap16'}, 'root accounting capture differs')
    summary = {
        'status': 'complete_no_improvement',
        'scope': 'Paired fresh full-route host diagnostic; no trial ran because native preflight eligibility rejected every pair.',
        'binary_sha256': read(ROOT / 'source-identity.json')['binary_sha256'],
        'source_commit': read(ROOT / 'committed-source-verification.json'),
        'case_metrics': {name: {key: comparison['runs'][name][key] for key in
            ('rows', 'setup', 'hold', 'unsupported_count', 'complete', 'all_clock_summaries', 'all_fmax')} for name in ('default', 'swap16')},
        'actual_saved_source_failure_cohorts': {key: {'failures': len(values), 'worst_setup_ps': min(values)} for key, values in sorted(families.items())},
        'discovery': {key: ledger[key] for key in ('discovery_counts', 'tried', 'kept', 'budget', 'path_discovery_bound_reached')},
        'filter_reason_counts': dict(sorted(Counter(line.rsplit(': ', 1)[1] for line in ledger['all_filters']).items())),
        'all_final_artifacts_default_vs_swap16': artifacts,
        'default_vs_prior13': comparison['default_vs_prior_fixed_route_artifact_bytes'],
        'default_creator_only_complete_graph': comparison['default_vs_prior_fixed_complete_graph'],
        'all_native_rows_metadata_clocks_equal': comparison['endpoint_identity_inventory_equal'] and comparison['all_row_domain_windows_and_flags_equal'] and comparison['all_metadata_categories_equal'],
        'all_setup_and_hold_delta_counts': comparison['native_margin_delta_counts'],
        'complete_graph_counts': {key: graph[key] for key in ('complete_cells', 'complete_net_alias_records', 'complete_net_alias_classes', 'complete_public_ports')},
        'changed_LUT6_cells': len(graph['accepted_cells']), 'changed_canonical_net_bits': graph['changed_canonical_net_bits'],
        'pair_charge_seconds_from_receipts': str(charge), 'root_cumulative_charge': accounting,
        'accounting_scope': 'Independently recomputes this pair only; the 32-run cumulative total is root-supplied campaign accounting.',
        'artifact_hashes': {name: sha(HERE / name) for name in
            ('graph-proof.json', 'route-comparison.json', 'decision-ledger.json', 'checker-tests.json', 'source-control-proof.json')},
        'root_accounting_sha256': sha(ROOT / 'route-accounting.json'), 'checker_sha256': sha(__file__),
        'limits': ['The native inventory remains complete=false with105 unsupported identities; equality does not qualify coverage.',
                   'No LUT6 swap was tried or accepted. There is no measured timing benefit from this capture.',
                   'Final reports expose the skewed native inventory; internal reference-free acceptance is separately enforced in source/tests, not independently emitted here.',
                   'No hardware ran; serialized route identity and byte comparisons are not electrical/board acceptance.']}
    need(ledger['tried'] == ledger['kept'] == 0 and all(item['byte_identical'] for item in artifacts.values()), 'capture differs from recorded no-op outcome')
    write('summary.json', summary)
    print(json.dumps({'status': summary['status'], 'pair_charge_seconds': str(charge),
                      'campaign_seconds': accounting['campaign_seconds'], 'all_four_artifacts_identical': True}, sort_keys=True))


if __name__ == '__main__':
    main()
