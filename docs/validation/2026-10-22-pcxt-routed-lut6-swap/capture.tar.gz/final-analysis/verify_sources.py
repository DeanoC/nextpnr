#!/usr/bin/env python3
"""Verify frozen source, retained test logs, and complete CPU controls offline."""
import json
import re
from support import HERE, ROOT, need, read, sha, write, verify_binary, verify_recorded, reference_folder


def main():
    original, final, committed = [read(ROOT / name) for name in
        ('source-identity.json', 'final-validation.json', 'committed-source-verification.json')]
    need(len(original['source_files']) == 13 and original['source_files'].keys() == final['source_files'].keys(), 'source inventory differs')
    need(final['source_files'] == committed['source_files'] and committed['all_recorded_source_bytes_match_commit'] is True, 'commit/source binding differs')
    need(sha(ROOT / 'final-validation.json') == committed['final_validation_sha256'], 'final validation binding differs')
    need(sha(ROOT / 'source-identity.json') == final['initial_preparation_identity_sha256'], 'initial identity was overwritten')
    need(sha(ROOT / 'source.diff') == original['source_diff_sha256'], 'initial tracked source diff changed')
    need(original['binary_sha256'] == final['binary_sha256'] == committed['binary_sha256'], 'production binary identities differ')
    changed = []
    for name, expected in original['source_files'].items():
        need(sha(ROOT / 'source' / name) == expected, 'initial frozen source differs: ' + name)
        need(sha(ROOT / 'final-validation/source' / name) == final['source_files'][name], 'final frozen source differs: ' + name)
        if expected != final['source_files'][name]:
            changed.append(name)
    need(sorted(changed) == sorted(final['test_only_changes_after_cpu_preparation']) == ['mistral/tests/routed_lut6_swap_backend.cc'], 'unrecorded production/test changes')
    logs = final['validation']['logs']
    need(set(logs) == {path.name for path in (ROOT / 'final-validation').glob('*.log')}, 'retained test/build log inventory differs')
    for name, expected in logs.items():
        need(sha(ROOT / 'final-validation' / name) == expected, 'retained validation log differs')
    native_names = set()
    for name in sorted(logs):
        if name.startswith('native-stage'):
            text = (ROOT / 'final-validation' / name).read_text()
            native_names.update(re.findall(r'^\[       OK \] (\S+) \(', text, re.M))
    need(sorted(native_names) == final['validation']['native_tests_passed'] and len(native_names) == 33, 'native case coverage differs')
    first = (ROOT / 'final-validation/native-stage1.log').read_text()
    last = (ROOT / 'final-validation/native-stage2.log').read_text()
    need('[  PASSED  ] 13 tests.' in first and '[  FAILED  ]' in first, 'initial fixture failure not retained')
    need('[  PASSED  ] 20 tests.' in last and '[  FAILED  ]' not in last, 'corrected remainder did not pass')
    need('[  PASSED  ] 3 tests.' in (ROOT / 'final-validation/pure-test.log').read_text(), 'pure tests did not pass')
    cli = (ROOT / 'final-validation/cli.log').read_text()
    need('Ran 6 tests' in cli and cli.rstrip().endswith('OK'), 'CLI tests did not pass')
    need([committed[k] for k in ('native_tests_passed', 'pure_tests_passed', 'cli_tests_passed')] == [33, 3, 6], 'committed test counts differ')
    controls = read(ROOT / 'control-proof.json')
    need(sha(ROOT / 'control-proof.json') == final['control_proof_sha256'], 'control proof binding differs')
    need(controls['script_sha256'] == sha(ROOT / 'prepare-controls.py'), 'control producer source differs')
    reference = reference_folder('preparation')
    prior = read(reference / 'receipt.json')
    for name, expected in prior['artifacts'].items():
        need(sha(reference / name) == expected, 'reference preparation artifact differs')
    expected_controls = []
    for case in ('default', 'zero'):
        folder = ROOT / ('prepare-' + case)
        receipt = read(folder / 'receipt.json')
        need(sha(folder / 'receipt.json') == final['preparation_receipts_sha256'][case], 'preparation receipt binding differs')
        need(receipt['source_identity'] == original and receipt['returncode'] == 0 and receipt['charged_seconds'] == 0, 'preparation runtime identity differs')
        need(receipt['reference_receipt_sha256'] == sha(reference / 'receipt.json'), 'reference preparation receipt differs')
        verify_binary(receipt['binary_sha256'], receipt['nextpnr_command'][0])
        for info in receipt['inputs'].values():
            verify_recorded(info['path'], info['sha256'])
        for name, expected in receipt['artifacts'].items():
            need(sha(folder / name) == expected, 'CPU preparation artifact differs')
        command = prior['nextpnr_command'][:]
        command[0] = receipt['nextpnr_command'][0]
        if case == 'zero':
            command += ['--critical-lut6-swap-budget', '0']
        need(receipt['nextpnr_command'] == command, 'CPU preparation recipe differs')
        old_bytes, new_bytes = (reference / 'placed.json').read_bytes(), (folder / 'placed.json').read_bytes()
        old, new = json.loads(old_bytes), json.loads(new_bytes)
        need(old['modules'] == new['modules'], 'complete CPU placed graph differs')
        old_creator, new_creator = json.dumps(old.pop('creator')).encode(), json.dumps(new.pop('creator')).encode()
        need(old == new and old_bytes.count(old_creator) == 1 and old_bytes.replace(old_creator, new_creator, 1) == new_bytes,
             'CPU preparation differs beyond creator bytes')
        need((reference / 'predicted-timing.json').read_bytes() == (folder / 'predicted-timing.json').read_bytes(), 'predicted timing bytes differ')
        expected_controls.append({'case': case, 'complete_modules_equal': True, 'all_bytes_except_creator_equal': True,
                                  'predicted_timing_bytes_equal': True, 'placed_sha256': sha(folder / 'placed.json')})
    need(expected_controls == controls['controls'] and controls['default_zero_raw_bytes_equal'], 'stored CPU control assertion differs')
    need((ROOT / 'prepare-default/placed.json').read_bytes() == (ROOT / 'prepare-zero/placed.json').read_bytes(), 'default/zero bytes differ')
    write('source-control-proof.json', {
        'status': 'pass', 'committed_source': committed['commit'], 'committed_tree': committed['tree'],
        'binary_sha256': original['binary_sha256'], 'complete_frozen_source_file_count': 13,
        'all_initial_and_final_source_hashes_verified': True, 'test_only_changes_after_initial_preparation': changed,
        'initial_fixture_failure_retained': True, 'native_passed': 33, 'pure_passed': 3, 'cli_passed': 6,
        'complete_default_and_zero_control_proof': expected_controls,
        'initial_and_final_validation_identities': {name: sha(ROOT / name) for name in
            ('source-identity.json', 'final-validation.json', 'committed-source-verification.json', 'control-proof.json')},
        'checker_sha256': sha(__file__),
        'limits': ['Verifies captured source/test-log provenance and complete CPU outputs; does not rerun the omitted native executable.',
                   'Build-start parent and final commit can differ by recorded evidence commits; exact source hashes bind the tested bytes.']})
    print(json.dumps({'status': 'pass', 'native': 33, 'pure': 3, 'cli': 6, 'source_files': 13}, sort_keys=True))


if __name__ == '__main__':
    main()
