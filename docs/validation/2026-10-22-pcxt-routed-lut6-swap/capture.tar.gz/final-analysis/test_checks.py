#!/usr/bin/env python3
"""Positive and deliberately corrupted checks; never mutates route artifacts."""
from copy import deepcopy
from pathlib import Path
import json
import support
from support import HERE, ROOT, need, read, sha, write, reference_folder
from prove_graph import prove, decisions, route_tree
from compare_timing import endpoint_guard, clock_guard, index


def fixture():
    pins = 'ABCDEF'
    maps = {'count': 7, 'pins': {p: [0, p if p in 'ABCD' else p + '0'] for p in pins}}
    maps['pins']['Q'] = [0, 'COMBOUT']
    cells = {'lut': {'hide_name': 0, 'type': 'MISTRAL_ALUT6', 'parameters': {'LUT': '1' * 63 + '0'},
                     'attributes': {'NEXTPNR_BEL': 'MISTRAL_MCOMB.15.35.54', 'FES_PINMAP_V1': json.dumps(maps).encode().hex()},
                     'connections': {**{p: [i + 1] for i, p in enumerate(pins)}, 'Q': [7]},
                     'port_directions': {**{p: 'input' for p in pins}, 'Q': 'output'}}}
    for i in range(6):
        cells['source' + str(i)] = {'hide_name': 0, 'type': 'MISTRAL_FF', 'parameters': {}, 'attributes': {},
                                    'connections': {'Q': [i + 1]}, 'port_directions': {'Q': 'output'}}
    cells['sink'] = {'hide_name': 0, 'type': 'MISTRAL_FF', 'parameters': {}, 'attributes': {},
                     'connections': {'DATAIN': [7]}, 'port_directions': {'DATAIN': 'input'}}
    nets = {f'net{i + 1}': {'hide_name': 0, 'bits': [i + 1], 'attributes': {
                'ROUTING': f'S{p};R{p}.S{p};1;R{p};;1'}} for i, p in enumerate(pins)}
    nets['output'] = {'hide_name': 0, 'bits': [7], 'attributes': {'ROUTING': 'Q;;1'}}
    nets['unused_alias'] = {'hide_name': 1, 'bits': [8], 'attributes': {'ROUTING': ' '}}
    left = {'creator': 'independent synthetic checker fixture', 'modules': {'top': {
        'settings': {'unchanged': '1'}, 'attributes': {'FES_LABSTATE_V1': 'synthetic exact-state sentinel'},
        'ports': {}, 'cells': cells, 'netnames': nets}}}
    right = deepcopy(left)
    module = right['modules']['top']
    module['cells']['lut']['connections']['B'], module['cells']['lut']['connections']['F'] = [6], [2]
    module['netnames']['net2']['attributes']['ROUTING'] = 'SF;RB.SF;1;RB;;1'
    module['netnames']['net6']['attributes']['ROUTING'] = 'SB;RF.SB;1;RF;;1'
    return left, right, [{'cell': 'lut', 'first': 'B', 'second': 'F', 'accepted': True}]


def main():
    outcomes = []
    def negative(name, action):
        try:
            action()
        except (ValueError, KeyError, TypeError) as exc:
            outcomes.append({'mutation': name, 'rejected': True, 'reason': str(exc)})
        else:
            raise ValueError('corruption was accepted: ' + name)

    left, right, accepted = fixture()
    result = prove(left, right, accepted)
    need(len(result['accepted_cells'][0]['all64_rows']) == 64, 'fixture omitted truth rows')
    def graph_bad(name, edit, both=False):
        a, b, c = deepcopy(left), deepcopy(right), deepcopy(accepted)
        edit(a, b, c)
        negative(name, lambda: prove(a, b, c))
    def module(g): return g['modules']['top']
    graph_bad('removed unused alias', lambda a,b,c: module(b)['netnames'].pop('unused_alias'))
    graph_bad('new hidden alias', lambda a,b,c: module(b)['netnames'].update(hidden=deepcopy(module(b)['netnames']['net1'])))
    graph_bad('alias retargeting', lambda a,b,c: module(b)['netnames']['unused_alias'].update(bits=[9]))
    graph_bad('outside cell input changed', lambda a,b,c: module(b)['cells']['sink']['connections'].update(DATAIN=[1]))
    graph_bad('cell removed', lambda a,b,c: module(b)['cells'].pop('sink'))
    graph_bad('LUT mask changed', lambda a,b,c: module(b)['cells']['lut']['parameters'].update(LUT='0'*64))
    def asym(a,b,c):
        for g in (a,b):module(g)['cells']['lut']['parameters']['LUT']=format(1<<2,'064b')
    graph_bad('same but nonsymmetric mask on both sides', asym)
    graph_bad('changed physical LUT pin map', lambda a,b,c: module(b)['cells']['lut']['attributes'].update(FES_PINMAP_V1='00'))
    def inverted(a,b,c):
        for g in (a,b):
            cell=module(g)['cells']['lut'];p=json.loads(bytes.fromhex(cell['attributes']['FES_PINMAP_V1']));p['pins']['B'][0]=1;cell['attributes']['FES_PINMAP_V1']=json.dumps(p).encode().hex()
    graph_bad('same inverted input maps on both sides', inverted)
    graph_bad('changed BEL', lambda a,b,c: module(b)['cells']['lut']['attributes'].update(NEXTPNR_BEL='MISTRAL_MCOMB.1.1.1'))
    graph_bad('changed LAB state', lambda a,b,c: module(b)['attributes'].update(FES_LABSTATE_V1='different'))
    graph_bad('changed settings', lambda a,b,c: module(b)['settings'].update(unchanged='0'))
    graph_bad('unlogged actual swap', lambda a,b,c: c.clear())
    graph_bad('wrong accepted pin pair', lambda a,b,c: c[0].update(first='A'))
    graph_bad('selected output changed', lambda a,b,c: module(b)['cells']['lut']['connections'].update(Q=[1]))
    graph_bad('outside canonical route changed', lambda a,b,c: module(b)['netnames']['net1']['attributes'].update(ROUTING='SA;RA.SA;2;RA;;1'))
    graph_bad('selected route serialization stale', lambda a,b,c: module(b)['netnames']['net2']['attributes'].update(ROUTING=module(a)['netnames']['net2']['attributes']['ROUTING']))
    graph_bad('selected root changed', lambda a,b,c: module(b)['netnames']['net2']['attributes'].update(ROUTING='SF;XX.SF;1;XX;;1'))
    graph_bad('selected protected route strength', lambda a,b,c: module(b)['netnames']['net2']['attributes'].update(ROUTING='SF;RB.SF;5;RB;;1'))
    graph_bad('selected net steals outside wire', lambda a,b,c: module(b)['netnames']['net2']['attributes'].update(ROUTING='SA;RB.SA;1;RB;;1'))
    graph_bad('new top-level field', lambda a,b,c: b.update(unexpected=True))
    negative('partial route tuple', lambda: route_tree('root;;1;extra'))
    negative('duplicate route wire', lambda: route_tree('root;;1;root;;1'))
    valid_log='Info: Critical LUT6 discovery: negative endpoint rows=1 native failing path witnesses=1 LUT6 arcs=1 filtered pairs=0 eligible pairs=1 cells=1.\nInfo: Critical LUT6 trial 1: cell=lut pins=B/F prior-path-slack=-100ps native-pin-rank=50ps accepted=1; native margins preserved.\nInfo: Critical LUT6 swap: tried=1/16 kept=1 eligible=1; unchanged unsupported coverage is not qualification.\n'
    need(decisions(valid_log)['kept']==1,'valid log rejected')
    negative('missing decision trial',lambda:decisions('\n'.join(line for line in valid_log.splitlines() if 'trial 1:' not in line)))
    negative('unknown new decision line',lambda:decisions(valid_log+'Info: Critical LUT6 unknown line.\n'))
    negative('trial on positive path',lambda:decisions(valid_log.replace('slack=-100ps','slack=100ps')))

    reference=reference_folder()
    complete=read(reference/'routed.json');unchanged=prove(complete,complete,[])
    s=read(reference/'endpoints.json');t=read(reference/'timing.json')
    need(endpoint_guard(s,s)['nonregression_and_inventory_pass'],'same native inventory rejected')
    need(clock_guard(t,t)['pass'],'same native clocks rejected')
    def timing_bad(name,edit):
        changed=deepcopy(s);edit(changed)
        need(not endpoint_guard(s,changed)['nonregression_and_inventory_pass'],'native corruption accepted: '+name)
        outcomes.append({'mutation':name,'rejected':True})
    first=next(iter(s['endpoints']))
    positive=next(k for k,v in s['endpoints'].items() if v[0]['setup_timed'] and v[0]['setup']>0 and v[0]['hold_related'])
    timing_bad('removed native endpoint',lambda b:b['endpoints'].pop(first))
    timing_bad('native launch domain changed',lambda b:b['endpoints'][first][0]['launch'].__setitem__(0,'different'))
    timing_bad('positive setup margin regressed one ps',lambda b:b['endpoints'][positive][0].update(setup=b['endpoints'][positive][0]['setup']-1))
    timing_bad('positive hold margin regressed one ps',lambda b:b['endpoints'][positive][0].update(hold=b['endpoints'][positive][0]['hold']-1))
    timing_bad('native window changed',lambda b:b['endpoints'][first][0].update(setup_window=12345))
    timing_bad('unsupported obligation removed',lambda b:b['unsupported'].pop())
    timing_bad('physical obligation removed',lambda b:b['physical_obligations'].pop())
    timing_bad('native coverage falsely complete',lambda b:b.update(complete=True))
    for field in ('setup_wns_ns','hold_wns_ns'):
        changed=deepcopy(t);clock=next(iter(changed['timing_summary']['clocks']));changed['timing_summary']['clocks'][clock][field]-=0.001
        need(not clock_guard(t,changed)['pass'],'clock margin corruption accepted');outcomes.append({'mutation':'clock '+field+' regression','rejected':True})
    changed=deepcopy(t);clock=next(iter(changed['fmax']));changed['fmax'][clock]['constraint']+=1
    need(not clock_guard(t,changed)['pass'],'fmax constraint corruption accepted');outcomes.append({'mutation':'fmax constraint changed','rejected':True})
    empty=deepcopy(t);empty['timing_summary']['clocks']={};empty['fmax']={}
    need(not clock_guard(empty,empty)['pass'],'empty paired clock inventories accepted');outcomes.append({'mutation':'both clock/fmax inventories empty','rejected':True})
    original_mode=support.archive_mode
    actual=ROOT/'source-identity.json';expected=sha(actual)
    recorded=str(Path(read(ROOT/'prepare-default/receipt.json')['nextpnr_command'][0]).parent/'source-identity.json')
    try:
        support.archive_mode=lambda:{'recorded_files':{}}
        negative('archive cannot fall back to existing original path',lambda:support.verify_recorded(recorded,expected))
        support.archive_mode=lambda:{'recorded_files':{recorded:{'sha256':'0'*64,'retained_path':'source-identity.json'}}}
        negative('archive mapping digest disagrees with original receipt',lambda:support.verify_recorded(recorded,expected))
        support.archive_mode=lambda:{'recorded_files':{recorded:{'sha256':expected,'retained_path':'../source-identity.json'}}}
        negative('archive mapping escapes retained root',lambda:support.verify_recorded(recorded,expected))
        support.archive_mode=lambda:{'recorded_files':{recorded:{'sha256':expected,'retained_path':'source-identity.json'}}}
        need(support.verify_recorded(recorded,expected)==actual,'valid exact archive mapping rejected')
    finally:
        support.archive_mode=original_mode
    write('checker-tests.json',{'status':'pass','scope':'Checker self-tests against synthetic valid swap and full prior13 evidence; no new route analysis or hardware claim.',
        'positive_synthetic_all64_rows':result['accepted_cells'][0]['all64_rows'],
        'unchanged_full_graph_counts':{k:unchanged[k] for k in ('complete_cells','complete_net_alias_records','complete_net_alias_classes')},
        'complete_native_row_count':len(index(s)),'all_negative_mutations':outcomes,
        'reference_hashes':{name:sha(reference/name) for name in ('routed.json','endpoints.json','timing.json')},
        'checker_hashes':{name:sha(HERE/name) for name in ('support.py','prove_graph.py','compare_timing.py','test_checks.py')}})
    print(json.dumps({'status':'pass','negative_mutations':len(outcomes),'native_rows':len(index(s))},sort_keys=True))


if __name__=='__main__':main()
