#!/usr/bin/env python3
"""Bind focused native/CLI proofs to the frozen production/default controls."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
SOURCE=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
BUILD=SOURCE.parent/'build-candidate'
LOGS=Path('/tmp/pcxt-lut6-swap')

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def main():
    identity_path=ROOT/'source-identity.json';identity_hash=sha(identity_path)
    identity=json.loads(identity_path.read_text())
    native_logs=sorted(LOGS.glob('native-stage*.log'))
    assert native_logs and '[  FAILED  ]' not in native_logs[-1].read_text()
    passed=set()
    for log in native_logs:passed.update(re.findall(r'^\[       OK \] (\S+) \(',log.read_text(),re.M))
    assert len(passed)==33,len(passed)
    assert '[  PASSED  ] 3 tests.' in (LOGS/'pure-test.log').read_text()
    cli=(LOGS/'cli.log').read_text();assert 'Ran 6 tests' in cli and cli.rstrip().endswith('OK')
    assert sha(ROOT/'nextpnr-mistral')==sha(BUILD/'nextpnr-mistral')==identity['binary_sha256']
    hashes={name:sha(SOURCE/name) for name in identity['source_files']}
    changes=[name for name,digest in hashes.items() if digest!=identity['source_files'][name]]
    assert set(changes)<={'mistral/tests/routed_lut6_swap_backend.cc','mistral/tests/private_pair_decomposition_backend.cc'},changes
    subprocess.run(['git','diff','--check'],cwd=SOURCE,check=True)
    controls=json.loads((ROOT/'control-proof.json').read_text())
    assert controls['default_zero_raw_bytes_equal']
    for case in controls['controls']:
        assert case['complete_modules_equal'] and case['all_bytes_except_creator_equal'] and case['predicted_timing_bytes_equal']
    target=ROOT/'final-validation';target.mkdir(exist_ok=False)
    for name in hashes:
        dest=target/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/name,dest)
    logs=sorted(LOGS.glob('*.log'))
    for path in logs:shutil.copyfile(path,target/path.name)
    receipts={}
    for case in ('default','zero'):
        path=ROOT/('prepare-'+case)/'receipt.json';receipt=json.loads(path.read_text())
        assert receipt['returncode']==0 and receipt['source_identity']==identity
        receipts[case]=sha(path)
    validation_parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
    record={
        'scope':'Host-only bounded post-route symmetric LUT6 swap validation; full fresh routes and hardware acceptance remain pending',
        'source_parent_at_validation':validation_parent,
        'parent_tree_at_validation':subprocess.check_output(['git','rev-parse',validation_parent+'^{tree}'],cwd=SOURCE,text=True).strip(),
        'build_start_parent':identity['build_start_parent'],
        'initial_preparation_identity_sha256':identity_hash,
        'source_files':hashes,'test_only_changes_after_cpu_preparation':changes,
        'binary_sha256':identity['binary_sha256'],'native_test_binary_sha256':sha(BUILD/'nextpnr-mistral-test'),
        'validation':{'native_tests_passed':sorted(passed),'native_count':33,'pure_count':3,'cli_count':6,
                      'git_diff_check_passed':True,'logs':{path.name:sha(target/path.name) for path in logs},
                      'retained_initial_failure':'Stage1 passed 13 cases; the forced-second-route fixture expected an empty second tree despite both original roots being preserved. Corrected only that assertion to require exactly the original root/no pip, then reran the failed case and all 19 skipped cases. No production bytes changed.'},
        'control_proof_sha256':sha(ROOT/'control-proof.json'),'preparation_receipts_sha256':receipts,
        'candidate_additional_flags':['--critical-lut6-swap-budget','16'],
        'full_route_recipe':'Original default raw recipe with --critical-route-budget 32; no private-pair options; root owns fresh full routes',
        'frozen_source_and_binary':True,'source_commit_pending_parent_review':True,
        'charged_route_seconds':0,'freeze_script_sha256':sha(__file__),
    }
    (ROOT/'final-validation.json').write_text(json.dumps(record,indent=2)+'\n')
    assert sha(identity_path)==identity_hash
    print(json.dumps({'native':33,'pure':3,'cli':6,'binary_sha256':record['binary_sha256'],
                      'final_validation_sha256':sha(ROOT/'final-validation.json')},indent=2))

if __name__=='__main__':main()
