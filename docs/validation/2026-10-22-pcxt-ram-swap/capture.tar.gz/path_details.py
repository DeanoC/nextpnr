#!/usr/bin/env python3
"""Retain native path witnesses without inventing missing source-specific paths."""
import json
from pathlib import Path
from prepare import ROOT, PAIRS, load, dump

def clock_label(value):
    return ('posedge ' if value[1] == 0 else 'negedge ') + value[0]

def main():
    baseline = load((ROOT.parent/'reassociate-20261022/baseline/timing.json').read_bytes())
    for label, _, _ in PAIRS:
        directory = ROOT/label
        analysis = load((directory/'analysis.json').read_bytes())
        candidate = load((directory/'route/timing.json').read_bytes())
        selected = {}
        for group in ('all_endpoints', 'microcode_outputs', 'framebuffer_inputs', 'framebuffer_outputs'):
            for row in analysis['groups'][group]['worst_after'][:2]:
                key = json.dumps([row['identity'],row['metadata']['launch'],row['metadata']['capture']])
                selected.setdefault(key, {'endpoint_row':row,'groups':[]})['groups'].append(group)
        for row in analysis['selected_rom_address_rows']:
            key=json.dumps([row['identity'],row['metadata']['launch'],row['metadata']['capture']])
            selected.setdefault(key, {'endpoint_row':row,'groups':[]})['groups'].append('microcode_inputs')
        for item in selected.values():
            row = item['endpoint_row']
            for side, timing in [('before', baseline), ('after', candidate)]:
                witnesses = []
                for path in timing['critical_paths']:
                    routes = [s for s in path['path'] if s['type']=='routing']
                    if not routes:
                        continue
                    end = routes[-1]['to']
                    if [end['cell'],end['port']] != row['identity']:
                        continue
                    if path['from'] != clock_label(row['metadata']['launch']) or path['to'] != clock_label(row['metadata']['capture']):
                        continue
                    witnesses.append(path)
                item[side+'_native_paths'] = witnesses
        dump(directory/'path-details.json', {'kind':'Exact selected native witnesses from bounded 1024-path reports; missing witnesses are empty',
                                             'endpoints':list(selected.values())})

if __name__=='__main__':
    main()
