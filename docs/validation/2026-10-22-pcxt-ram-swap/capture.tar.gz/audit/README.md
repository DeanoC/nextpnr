# PC/XT reciprocal M10K placement audit, 22 October 2026

This is a read-only host diagnostic using the original frozen placed graph and
the compiler 692 baseline route. It inventories every RAM boundary before
screening reciprocal placement exchanges. No swap, placement or route ran as
part of this audit. Geometry estimates below justify experiments; they do not
prove routed gain or timing acceptance.

The frozen placed input is
`/tmp/pcxt-replicate-leased-20261022/inputs/placed.json`, SHA256
`9241b02074cfee262c985c9ddde7e2c71f05bc654d35b989857a9a93ccc58878`.
Baseline timing comes from `../reassociate-20261022/baseline/`. Exact file
identities and the native source excerpts used are recorded in
`source-manifest.json`. Compiler source is
`692a1c372b2b55620ba1fd5e43e0c14ae8ffa4d9`, tree
`9b953cd947a89cbf7da9d203b3e07000783a45c2`.

## Complete clock and data boundary inventory

| RAM group | Blocks | CLK1 | CLK2 | Active input window | Output capture window |
| --- | ---: | --- | --- | --- | --- |
| Framebuffers | 192 | clocks[0], rising | clk_pixel, rising | 19 write-side pins at 10,000 ps; 10 read-side pins at 13,468 ps per RAM | 13,468 ps |
| Microcode ROMs | 16 | clocks[2], rising | clocks[2], rising | 12 CPU address pins at 2,500 ps per RAM | 7,500 ps |
| Other RAMs | 110 | clocks[0], rising | clocks[0], rising | 10,000 ps | 10,000 ps |

`clocks[2]` has a 10,000 ps period and a +2,500 ps phase relative to
`clocks[0]`, in the same `memory_clock` phase group. The window is taken from
each native endpoint row, rather than inferred solely from a clock frequency.
Native `getPortClockingInfo()` assigns A1 inputs to CLK1 and B1 inputs/outputs
to CLK2 for these synchronous dual-clock, non-TDP configurations. All clock
pins are PIN_SIG; all ACLR0/1 pins are folded PIN_0.

All 318 blocks have complete data classifications: 7,902 timed input pins,
1,866 static input pins, 1,934 distinct per-RAM output capture pairs, and zero
missing/ambiguous/unsupported data relationships. The 1,934 pairs comprise
1,536 framebuffer, 150 microcode and 248 other-RAM pairs. Some capture pairs
are reached by multiple output bits; the per-output records preserve those
branches. Every active input also has an immediate-driver entry in the native
detailed net timing report. All 2,438 incident nets retain their complete
drivers, users and aliases in `all-incident-fanouts.json`.

`all-ram-inventory.json` contains exact cell/pin identities, physical saved pin
maps, clocks, setup/hold rows, static-record hashes and full output walks.
Local ALUT support is exhaustively evaluated after folded constants, input
inversion and tied net identities. The transitive walk is conservative after
that local support calculation; it does not claim SAT proof of cancellation
across reconvergent cones. There were no unknown traversed primitives or
combinational cycles. A reachable capture lacking exactly one timed, related
native launch/capture row is a coverage gap and disqualifies the experiment.

Native output margins are aggregate endpoint margins for the launch domain;
they do not identify the selected RAM as the worst launch path. A subset of
detailed critical paths does identify selected launches, and that evidence is
recorded separately. This audit never treats a selected source's improved
geometry as a proven improvement to an aggregate output margin.

## Placement eligibility and why swaps are useful

Every RAM has recorded placement strength WEAK=1. None has `keep`,
`dont_touch`, `BEL`, `LOC` or `FES_SLOT` attributes. Their attributes are
exactly BEL_STRENGTH, NEXTPNR_BEL, FES_PINMAP_V1, src and module_not_derived.
All 69 occupied M10K sites in column 26 are framebuffers. The original CPU
address FFs are mostly near columns 15–26 and row 38; the microcode ROMs are
in columns 38/41. Current bindings prove that both destinations in a reciprocal
pair exist and are occupied by the other selected M10K.

The JSON checkpoint does not serialize cluster/relative-placement metadata.
The frozen packer creates carry, MLAB, DSP and slot LUT/FF groups; it does
not create M10K clusters. That source observation does not permit a future generic pass to
skip live guards: inspect live strength, keep/location attributes, cluster,
constraint children/offsets, region, pseudo-cell status, frozen-slot/fence and
destination eligibility. A protected or incomplete case must remain unchanged.
This audit did not execute native swap legality. The separate diagnostics in
`../ram-swap-20261022/` perform native reload and guard qualification.

The independent spreader audit showed that increasing density allowance to
beta 0.9 leaves only 35 RAMs occupying column 26 while all 16 microcode ROMs remain
in columns 38/41. Framebuffer solved targets rank west of the ROMs. Thus the
timing problem is not explained by vacancy count alone; coordinate-rank
spreading does not express the different native setup windows.

## Bounded candidate screening

The cross-LAB estimator matches the frozen Mistral model:
`650 + 250*(dy != 0) + 35*dx + 100*dy` ps. Each input uses the change in
its last net edge from the fixed immediate driver. Its estimated setup margin
is old setup minus that delta; estimated hold is old hold plus that delta.

For a RAM output capture, every affected first RAM-to-user edge is retained.
The output setup screen subtracts only the largest adverse first-edge change
from the native aggregate endpoint margin; the hold screen adds only the
largest adverse shortening. Unselected same-domain launch paths remain in the
baseline aggregate. These are conservative *uses of the geometry model*, not
physical lower bounds on routed slack. Routing, congestion, clock skew and
shared net branches can invalidate any numerical prediction.

The score sums input deltas divided by their native setup windows and each
output capture's worst first-edge delta divided by its native setup window.
All 1,104 pairs (16 ROMs times 69 column-26 framebuffers) are retained in
`ranked-candidate-pairs.json`; 34 pass the screen. Passing requires improved
microcode worst input slack and failure count, lower total weighted cost,
nonnegative estimated return and displaced-framebuffer margins, and
nonnegative estimated hold on both sides. The pass set is concentrated in a
few framebuffer partners; the selected list contains three cell-disjoint
pairs. It is not evidence that every microcode ROM can be moved to column 26.

| Candidate | Reciprocal BELs | Microcode address WNS, measured → model (ps) | Address failures, measured → model | Microcode return margin under model (ps) | Displaced framebuffer input / output margin under model (ps) |
| --- | --- | ---: | ---: | ---: | ---: |
| Byte 3 ROM1 ↔ framebuffer bank 0 ram.0.54 | (41,42) ↔ (26,40) | -841 → +134 | 10 → 0 | +2901 | +2247 / +496 |
| Byte 2 ROM3 ↔ framebuffer bank 0 ram.0.52 | (41,34) ↔ (26,41) | -1461 → -182 | 9 → 3 | +274 | +2708 / +446 |
| Byte 2 ROM2 ↔ framebuffer bank 1 ram.0.14 | (38,34) ↔ (26,35) | -1181 → -661 | 10 → 4 | +699 | +2980 / +1775 |

The first row is the clearest isolated diagnostic: all 12 address endpoints
are predicted to pass, with only two distinct microcode output capture pairs.
Its worst B1ADDR[8] launches at (15,40); the measured last route is 2444 ps,
and the existing full path leaves a 1603 ps last-route budget. The model delta
for the swap is -975 ps, producing the +134 ps estimate. The framebuffer's
output margin is the limiting screened displaced-side margin at +496 ps.

The second row has the largest estimated worst-address improvement and tests
a different CPU byte lane. It has 29 output capture pairs and a tighter
predicted return margin of +274 ps. It also introduces a predicted B1ADDR[6]
failure: that bit changes from +126 to -49 ps. Its predicted remaining worst
bit is B1ADDR[8], -182 ps. Its improvement must therefore be judged across the
whole pair, not only the original worst bit.

The third row has 30 output pairs and improves the smaller modeled distance,
but it leaves -661 ps on B1ADDR[9]. It is a lower-priority alternative, not a
claim of closure. Complete rows, measured last-route arcs and full source and
destination coordinates are stored in the selected-pair records.

## General compiler implication and remaining gates

A bounded default-off assignment experiment is justified. Its cost must
include the input and return edges of every eligible RAM and the displacement
cost of every other RAM, using exact native launch/capture setup windows.
The architecture owns port timing classification; the timing analyzer owns
phase, edge, cut and multicycle semantics. Zero/missing/untimed windows cannot
silently become a nominal full period. Static endpoints can be omitted only
through their native static classification. The policy must use these data,
not PC/XT instance names or a single scalar priority per RAM.

Keep capacity/region/type constraints and all protected-cell guards, use
deterministic bounded assignment and transactional rollback, and compare
complete fresh routes. Do not route a checkpoint reconstructed by intersecting
aliases or by serializing a normalized native load: the exact-byte diagnostic
preparation preserves the source's orphan aliases, graph order and every
non-placement bit.

The baseline still has 105 unsupported endpoint rows, and
`primitive_clocks` has no native period/pulse-width margins. This data-pair
inventory does not close those gates. Native fresh-route setup/hold,
unchanged complete endpoint/clock inventory, full graph equivalence, RBF
evidence, required seeds and physical board/hardware qualification remain
separate. No timing limit or keep guard was relaxed.

Reproduce the read-only inventory and screen with:

```sh
python3 audit.py
python3 rank_swaps.py
```

The files under this directory are uncommitted host-only diagnostic evidence.
They change no RTL, source compiler policy or module/shared contracts.
