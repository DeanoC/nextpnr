## mistral/delay.cc:580-645

```cpp
580:     } else if (cell->type == id_MISTRAL_M10K) {
581:         const auto &name = port.str(this);
582:         const bool async_read = bool_or_default(cell->params, id_CFG_ASYNC_READ, false) ||
583:                                 cell->getPort(id_B1EN) == nullptr;
584:         if (bool_or_default(cell->params, id_CFG_TDP, false)) {
585:             if (port.in(id_CLK1, id_CLK2))
586:                 return TMG_CLOCK_INPUT;
587:             if (port.in(id_ACLR0, id_ACLR1))
588:                 return TMG_ENDPOINT;
589:             if (port.in(id_ADDRSTALLA, id_ADDRSTALLB)) {
590:                 clockInfoCount = 1;
591:                 return TMG_REGISTER_INPUT;
592:             }
593:             if (name.find("A1Q") == 0 || name.find("B1Q") == 0) {
594:                 if (async_read)
595:                     return TMG_COMB_OUTPUT;
596:                 clockInfoCount = 1;
597:                 return TMG_REGISTER_OUTPUT;
598:             }
599:             if (name.find("A1") == 0 || name.find("B1") == 0) {
600:                 clockInfoCount = 1;
601:                 return TMG_REGISTER_INPUT;
602:             }
603:             return TMG_IGNORE;
604:         }
605:         if (async_read) {
606:             if (port.in(id_CLK1, id_CLK2))
607:                 return TMG_CLOCK_INPUT;
608:             if (port.in(id_ACLR0, id_ACLR1))
609:                 return TMG_ENDPOINT;
610:             if (port.in(id_ADDRSTALLA, id_ADDRSTALLB)) {
611:                 clockInfoCount = 1;
612:                 return TMG_REGISTER_INPUT;
613:             }
614:             if (port.in(id_A1DATA, id_A1EN, id_A1BE) || name.find("A1DATA[") == 0 ||
615:                 name.find("A1BE[") == 0 || name.find("A1ADDR") == 0) {
616:                 clockInfoCount = 1;
617:                 return TMG_REGISTER_INPUT;
618:             }
619:             if (name.find("B1ADDR") == 0)
620:                 return TMG_COMB_INPUT;
621:             if (port == id_B1DATA || name.find("B1DATA[") == 0)
622:                 return TMG_COMB_OUTPUT;
623:             return TMG_IGNORE;
624:         }
625:         if (port.in(id_CLK1, id_CLK2)) {
626:             return TMG_CLOCK_INPUT;
627:         } else if (port.in(id_ACLR0, id_ACLR1)) {
628:             return TMG_ENDPOINT;
629:         } else if (port.in(id_ADDRSTALLA, id_ADDRSTALLB)) {
630:             clockInfoCount = 1;
631:             return TMG_REGISTER_INPUT;
632:         } else if (port.in(id_A1DATA, id_A1EN, id_A1BE, id_B1EN) || name.find("A1DATA[") == 0 ||
633:                    name.find("A1BE[") == 0 ||
634:                    name.find("A1ADDR") == 0 || name.find("B1ADDR") == 0) {
635:             clockInfoCount = 1;
636:             return TMG_REGISTER_INPUT;
637:         } else if (port == id_B1DATA || name.find("B1DATA[") == 0) {
638:             clockInfoCount = 1;
639:             return TMG_REGISTER_OUTPUT;
640:         }
641:     }
642:     return TMG_IGNORE;
643: }
644: 
645: std::vector<RegisteredIoTiming> Arch::getRegisteredIoTiming(const CellInfo *cell, IdString pad, bool input) const
```

## mistral/delay.cc:790-854

```cpp
790:     } else if (cell->type == id_MISTRAL_M10K) {
791:         const auto &name = port.str(this);
792:         const bool async_read = bool_or_default(cell->params, id_CFG_ASYNC_READ, false) ||
793:                                 cell->getPort(id_B1EN) == nullptr;
794:         auto clock_edge = [&](IdString clock_port) {
795:             auto clock_pin = cell->pin_data.find(clock_port);
796:             return clock_pin != cell->pin_data.end() && clock_pin->second.state == PIN_INV ? FALLING_EDGE : RISING_EDGE;
797:         };
798:         if (bool_or_default(cell->params, id_CFG_TDP, false)) {
799:             timing.clock_port = name.find("B1") == 0 ? id_CLK2 : id_CLK1;
800:             if (port == id_ADDRSTALLB)
801:                 timing.clock_port = id_CLK2;
802:             timing.edge = clock_edge(timing.clock_port);
803:             if ((name.find("A1Q") == 0 || name.find("B1Q") == 0) && !async_read) {
804:                 timing.clockToQ = m10k_clock_to_out(getCtx(), cell, name);
805:             } else {
806:                 timing.hold = DelayPair{42, 42};
807:                 if (name.find("ADDR") != std::string::npos)
808:                     timing.setup = DelayPair{125, 125};
809:                 else if (name.find("DATA") != std::string::npos)
810:                     timing.setup = DelayPair{97, 97};
811:                 else if (port.in(id_A1WE, id_B1WE) || name.find("A1BE[") == 0 || name.find("B1BE[") == 0)
812:                     timing.setup = DelayPair{140, 140};
813:                 else if (port.in(id_A1EN, id_B1EN))
814:                     timing.setup = DelayPair{161, 161};
815:             }
816:             return timing;
817:         }
818:         if (async_read && (name.find("B1ADDR") == 0 || port == id_B1DATA || name.find("B1DATA[") == 0))
819:             return timing;
820:         bool read_port = port.in(id_B1DATA, id_B1EN) || name.find("B1DATA[") == 0 || name.find("B1ADDR") == 0;
821:         timing.clock_port = read_port && bool_or_default(cell->params, id_CFG_DUAL_CLOCK, false) ? id_CLK2 : id_CLK1;
822:         if (port == id_ADDRSTALLB && bool_or_default(cell->params, id_CFG_DUAL_CLOCK, false))
823:             timing.clock_port = id_CLK2;
824:         timing.edge = clock_edge(timing.clock_port);
825:         if (port.in(id_ADDRSTALLA, id_ADDRSTALLB)) {
826:             timing.setup = DelayPair{125, 125};
827:             timing.hold = DelayPair{42, 42};
828:             timing.clockToQ = DelayQuad{};
829:         } else if (port.str(this).find("A1ADDR") == 0 || port.str(this).find("B1ADDR") == 0) {
830:             timing.setup = DelayPair{125, 125};
831:             timing.hold = DelayPair{42, 42};
832:             timing.clockToQ = DelayQuad{};
833:         } else if (port == id_A1DATA || name.find("A1DATA[") == 0) {
834:             timing.setup = DelayPair{97, 97};
835:             timing.hold = DelayPair{42, 42};
836:             timing.clockToQ = DelayQuad{};
837:         } else if (port == id_A1EN || port == id_A1BE || name.find("A1BE[") == 0) {
838:             timing.setup = DelayPair{140, 140};
839:             timing.hold = DelayPair{42, 42};
840:             timing.clockToQ = DelayQuad{};
841:         } else if (port == id_B1EN) {
842:             timing.setup = DelayPair{161, 161};
843:             timing.hold = DelayPair{42, 42};
844:             timing.clockToQ = DelayQuad{};
845:         } else if (port == id_B1DATA || name.find("B1DATA[") == 0) {
846:             timing.setup = DelayPair{};
847:             timing.hold = DelayPair{};
848:             timing.clockToQ = m10k_clock_to_out(getCtx(), cell, name);
849:         }
850:         return timing;
851:     }
852:     NPNR_ASSERT_FALSE("unreachable");
853: }
854: 
```

## mistral/arch.cc:583-660

```cpp
583: bool Arch::isBelLocationValid(BelId bel, bool explain_invalid) const
584: {
585:     auto &data = bel_data(bel);
586:     if (data.bound && !fes_placement_allowed(bel, data.bound, explain_invalid))
587:         return false;
588:     if (data.type.in(id_MISTRAL_COMB, id_MISTRAL_MCOMB, id_MISTRAL_FF)) {
589:         bool any_locked = false;
590:         auto occupant_ok = [&](BelId other) {
591:             CellInfo *cell = getBoundBelCell(other);
592:             if (cell == nullptr)
593:                 return true;
594:             if (cell->belStrength < STRENGTH_LOCKED)
595:                 return false;
596:             any_locked = true;
597:             return true;
598:         };
599:         const auto &alm_data = labs.at(data.lab_data.lab).alms.at(data.lab_data.alm);
600:         if (occupant_ok(alm_data.lut_bels[0]) && occupant_ok(alm_data.lut_bels[1]) && occupant_ok(alm_data.ff_bels[0]) &&
601:             occupant_ok(alm_data.ff_bels[1]) && occupant_ok(alm_data.ff_bels[2]) && occupant_ok(alm_data.ff_bels[3]) &&
602:             any_locked)
603:             return true;
604:         if (data.bound == nullptr) {
605:             const auto &lab_data = labs.at(data.lab_data.lab);
606:             for (const auto &alm : lab_data.alms) {
607:                 for (BelId other : {alm.lut_bels[0], alm.lut_bels[1], alm.ff_bels[0], alm.ff_bels[1], alm.ff_bels[2],
608:                                     alm.ff_bels[3]}) {
609:                     CellInfo *cell = getBoundBelCell(other);
610:                     if (cell != nullptr && cell->belStrength >= STRENGTH_LOCKED)
611:                         return true;
612:                 }
613:             }
614:         }
615:     }
616:     if (data.type.in(id_MISTRAL_MUL9X9, id_MISTRAL_MUL18X18, id_MISTRAL_MUL27X27,
617:                      id_MISTRAL_MUL18X19, id_MISTRAL_MUL18X19_COMBINED) &&
618:         data.bound) {
619:         // The mode-specific BELs are alternate views of one physical DSP
620:         // tile. Three M9 lanes may share a tile, while a wide multiplier owns
621:         // the tile and cannot coexist with another mode. A sign-extended M9
622:         // cell uses the lane-0 upper slices, so it needs lane 0 and owns the
623:         // tile.
624:         auto m9_extended = [&](const CellInfo *cell) {
625:             return cell->ports.count(id("A[9]")) || cell->ports.count(id("B[9]"));
626:         };
627:         const bool extended = data.type == id_MISTRAL_MUL9X9 && m9_extended(data.bound);
628:         if (extended && bel.z != 0) {
629:             if (explain_invalid)
630:                 log_info("Sign-extended MISTRAL_MUL9X9 %s needs DSP lane 0.\n", nameOf(data.bound));
631:             return false;
632:         }
633:         for (BelId other : getBelsByTile(bel.pos.x(), bel.pos.y())) {
634:             if (other == bel)
635:                 continue;
636:             const auto &other_data = bel_data(other);
637:             if (!other_data.bound ||
638:                 !other_data.type.in(id_MISTRAL_MUL9X9, id_MISTRAL_MUL18X18, id_MISTRAL_MUL27X27,
639:                                     id_MISTRAL_MUL18X19, id_MISTRAL_MUL18X19_COMBINED))
640:                 continue;
641:             if (other_data.type != data.type) {
642:                 if (explain_invalid)
643:                     log_info("DSP tile already contains multiplier mode %s; cannot place %s here.\n",
644:                              nameOf(other_data.type), nameOf(data.type));
645:                 return false;
646:             }
647:             if (data.type == id_MISTRAL_MUL9X9 && (extended || m9_extended(other_data.bound))) {
648:                 if (explain_invalid)
649:                     log_info("DSP tile already contains a sign-extended M9 lane; it cannot share the tile.\n");
650:                 return false;
651:             }
652:             if (data.type == id_MISTRAL_MUL9X9 && !dsp_shared_config_equal(data.bound, other_data.bound)) {
653:                 if (explain_invalid)
654:                     log_info("DSP tile already contains an M9 lane with different shared controls.\n");
655:                 return false;
656:             }
657:         }
658:     }
659:     if (data.type.in(id_MISTRAL_CLKENA, id_MISTRAL_CLKENA_PLL) && data.block_index != 2 && data.bound) {
660:         auto input = data.bound->getPort(id_A);
```

## mistral/pack.cc:1721-1820

```cpp
1721:     void constrain_carries(bool unbound_only = false)
1722:     {
1723:         for (auto &cell : ctx->cells) {
1724:             CellInfo *ci = cell.second.get();
1725:             if (!chain_cell_selected(ci, unbound_only))
1726:                 continue;
1727:             const NetInfo *cin = ci->getPort(id_CI);
1728:             if (cin != nullptr && cin->driver.cell != nullptr)
1729:                 continue; // not the start of a chain
1730:             std::vector<CellInfo *> chain;
1731:             CellInfo *cursor = ci;
1732:             while (true) {
1733:                 chain.push_back(cursor);
1734:                 const NetInfo *co = cursor->getPort(id_CO);
1735:                 if (co == nullptr || co->users.empty())
1736:                     break;
1737:                 if (co->users.entries() > 1)
1738:                     log_error("Carry net %s has more than one sink!\n", ctx->nameOf(co));
1739:                 auto &usr = *co->users.begin();
1740:                 if (usr.port != id_CI)
1741:                     log_error("Carry net %s drives port %s, expected CI\n", ctx->nameOf(co), ctx->nameOf(usr.port));
1742:                 cursor = usr.cell;
1743:             }
1744: 
1745:             chain.at(0)->constr_abs_z = true;
1746:             chain.at(0)->constr_z = 0;
1747:             chain.at(0)->cluster = chain.at(0)->name;
1748: 
1749:             for (int i = 1; i < int(chain.size()); i++) {
1750:                 chain.at(i)->constr_x = 0;
1751:                 chain.at(i)->constr_y = -(i / 20);
1752:                 // 2 COMB, 4 FF per ALM
1753:                 chain.at(i)->constr_z = ((i / 2) % 10) * 6 + (i % 2);
1754:                 chain.at(i)->constr_abs_z = true;
1755:                 chain.at(i)->cluster = chain.at(0)->name;
1756:                 chain.at(0)->constr_children.push_back(chain.at(i));
1757:             }
1758: 
1759:             if (ctx->debug) {
1760:                 log_info("Chain: \n");
1761:                 for (int i = 0; i < int(chain.size()); i++) {
1762:                     auto &c = chain.at(i);
1763:                     log_info("    i=%d cell=%s dy=%d z=%d ci=%s co=%s\n", i, ctx->nameOf(c), c->constr_y, c->constr_z,
1764:                              ctx->nameOf(c->getPort(id_CI)), ctx->nameOf(c->getPort(id_CO)));
1765:                 }
1766:             }
1767:         }
1768:         // Check we reached all the cells in the above pass
1769:         for (auto &cell : ctx->cells) {
1770:             CellInfo *ci = cell.second.get();
1771:             if (!chain_cell_selected(ci, unbound_only))
1772:                 continue;
1773:             if (ci->cluster == ClusterId())
1774:                 log_error("Failed to include arith cell '%s' in any chain (CI=%s)\n", ctx->nameOf(ci),
1775:                           ctx->nameOf(ci->getPort(id_CI)));
1776:         }
1777:     }
1778: 
1779:     void constrain_lutram()
1780:     {
1781:         // We form clusters based on both read and write address; as both being the same makes it more likely these
1782:         // cells should be packed together, too.
1783:         // This makes things easier for the placement legaliser to deal with RAM in LAB-compatible blocks without
1784:         // over-constraining things
1785:         idict<dict<IdString, IdString>> mlab_keys;
1786:         std::vector<std::vector<CellInfo *>> mlab_groups;
1787:         for (auto &cell : ctx->cells) {
1788:             CellInfo *ci = cell.second.get();
1789:             if (ci->type != id_MISTRAL_MLAB)
1790:                 continue;
1791:             auto init = ci->params.find(id_INIT);
1792:             if (init != ci->params.end() && (init->second.is_string || init->second.str.size() > 32))
1793:                 log_error("MLAB '%s': INIT must be a numeric value of at most 32 bits.\n", ctx->nameOf(ci));
1794:             auto key = ctx->get_mlab_key(ci, true);
1795:             int key_idx = mlab_keys(key);
1796:             if (key_idx >= int(mlab_groups.size()))
1797:                 mlab_groups.resize(key_idx + 1);
1798:             mlab_groups.at(key_idx).push_back(ci);
1799:         }
1800:         // Combine into clusters
1801:         size_t cluster_size = 20;
1802:         for (auto &group : mlab_groups) {
1803:             for (size_t i = 0; i < group.size(); i++) {
1804:                 CellInfo *ci = group.at(i);
1805:                 CellInfo *base = group.at((i / cluster_size) * cluster_size);
1806:                 int cell_index = int(i) % cluster_size;
1807:                 int alm = cell_index / 2;
1808:                 int alm_cell = cell_index % 2;
1809:                 ci->cluster = base->name;
1810:                 ci->constr_abs_z = true;
1811:                 ci->constr_z = alm * 6 + alm_cell;
1812:                 if (cell_index != 0) {
1813:                     // Not the root of a cluster
1814:                     base->constr_children.push_back(ci);
1815:                     ci->constr_x = 0;
1816:                     ci->constr_y = 0;
1817:                 }
1818:             }
1819:         }
1820:     }
```

## mistral/pack.cc:2127-2197

```cpp
2127:     void setup_m10ks(bool unbound_only = false)
2128:     {
2129:         // Normalize TDP cells before the per-cell setup below.
2130:         for (auto &cell : ctx->cells) {
2131:             CellInfo *ci = cell.second.get();
2132:             if (unbound_only && ci->bel != BelId())
2133:                 continue;
2134:             if (ci->type == id_MISTRAL_M10K_TDP) {
2135:                 ci->type = id_MISTRAL_M10K;
2136:                 ci->params[id_CFG_TDP] = 1;
2137:             }
2138:         }
2139: 
2140:         // A read-only flow-through M10K has no logical write clock, but the
2141:         // physical read mux still needs a live clock tree. Select that clock
2142:         // from the read data's downstream timing domain rather than from the
2143:         // first unrelated M10K in cell iteration order. A cell-level override
2144:         // is available for an output with no registered consumer or with an
2145:         // intentionally shared/mixed clock domain.
2146:         const IdString async_read_clock_attr = ctx->id("MISTRAL_ASYNC_READ_CLOCK");
2147:         auto normalize_async_read_clock = [&](NetInfo *net) -> NetInfo * {
2148:             // Resolve a top-level input alias through its MISTRAL_IB PAD pin.
2149:             // The loop also protects against malformed alias/buffer cycles.
2150:             for (int depth = 0; net != nullptr && depth < 4; depth++) {
2151:                 if (net->driver.cell == nullptr) {
2152:                     NetInfo *next = nullptr;
2153:                     for (const auto &user : net->users) {
2154:                         if (user.cell != nullptr && user.cell->type == id_MISTRAL_IB && user.port == id_PAD) {
2155:                             next = user.cell->getPort(id_O);
2156:                             break;
2157:                         }
2158:                     }
2159:                     if (next == nullptr)
2160:                         return nullptr;
2161:                     net = next;
2162:                     continue;
2163:                 }
2164:                 if (net->driver.cell->type.in(id_GND, id_VCC, id_MISTRAL_CONST))
2165:                     return nullptr;
2166:                 if (net->driver.cell->type == id_MISTRAL_IB && net->driver.port == id_O) {
2167:                     for (const auto &user : net->users) {
2168:                         if (user.cell->type != id_MISTRAL_CLKBUF || user.port != id_A)
2169:                             continue;
2170:                         NetInfo *buffered = user.cell->getPort(id_Q);
2171:                         if (buffered != nullptr && buffered->driver.cell == user.cell)
2172:                             return buffered;
2173:                     }
2174:                 }
2175:                 return net;
2176:             }
2177:             return nullptr;
2178:         };
2179: 
2180:         auto find_async_read_clock = [&](CellInfo *ci, std::string &source) -> NetInfo * {
2181:             std::string requested = str_or_default(ci->attrs, async_read_clock_attr, "");
2182:             if (!requested.empty()) {
2183:                 NetInfo *net = normalize_async_read_clock(ctx->getNetByAlias(ctx->id(requested)));
2184:                 if (net == nullptr)
2185:                     log_error("M10K '%s': %s names no live clock net '%s'.\n", ctx->nameOf(ci),
2186:                               ctx->nameOf(async_read_clock_attr), requested.c_str());
2187:                 source = "MISTRAL_ASYNC_READ_CLOCK attribute";
2188:                 return net;
2189:             }
2190: 
2191:             std::deque<NetInfo *> pending;
2192:             std::set<NetInfo *> visited;
2193:             for (const auto &port : ci->ports) {
2194:                 const std::string name = port.first.str(ctx);
2195:                 if ((port.first == id_B1DATA || name.find("B1DATA[") == 0) && port.second.net != nullptr)
2196:                     pending.push_back(port.second.net);
2197:             }
```

## mistral/pack.cc:2638-2680

```cpp
2638:         for (size_t i = 0; i < multipliers.size();) {
2639:             CellInfo *root = multipliers.at(i);
2640:             if (root->type != id_MISTRAL_MUL9X9) {
2641:                 ++i;
2642:                 continue;
2643:             }
2644:             root->cluster = root->name;
2645:             root->constr_abs_z = true;
2646:             root->constr_z = 0;
2647: 
2648:             bool a_signed = dsp_bool_param(root->params, id_A_SIGNED, true);
2649:             bool b_signed = dsp_bool_param(root->params, id_B_SIGNED, true);
2650:             // A sign-extended lane-0 cell owns its block (see
2651:             // extend_dsp_signed_operands and Arch::isBelLocationValid).
2652:             const bool exclusive = (a_signed || b_signed) && !dsp_bool_param(root->params, id_PREADDER_EN) &&
2653:                                    !ctx->args.dsp_signed_lanes;
2654:             size_t end = i + 1;
2655:             while (!exclusive && end < multipliers.size() && end - i < mistral_dsp_lanes.size() &&
2656:                    multipliers.at(end)->type == id_MISTRAL_MUL9X9 &&
2657:                    dsp_bool_param(multipliers.at(end)->params, id_A_SIGNED, true) == a_signed &&
2658:                    dsp_bool_param(multipliers.at(end)->params, id_B_SIGNED, true) == b_signed &&
2659:                    dsp_shared_config_equal(root, multipliers.at(end)))
2660:                 ++end;
2661:             for (size_t lane = i; lane < end; ++lane) {
2662:                 CellInfo *ci = multipliers.at(lane);
2663:                 if (dsp_bool_param(ci->params, id_A_SIGNED, true) != a_signed ||
2664:                     dsp_bool_param(ci->params, id_B_SIGNED, true) != b_signed) {
2665:                     log_error("MISTRAL_MUL9X9 cells '%s' and '%s' disagree on shared DSP signedness; "
2666:                               "three-lane packing requires matching A_SIGNED and B_SIGNED.\n",
2667:                               ctx->nameOf(root), ctx->nameOf(ci));
2668:                 }
2669:                 if (lane == i)
2670:                     continue;
2671:                 ci->cluster = root->name;
2672:                 ci->constr_x = 0;
2673:                 ci->constr_y = 0;
2674:                 ci->constr_abs_z = true;
2675:                 ci->constr_z = int(lane - i);
2676:                 root->constr_children.push_back(ci);
2677:             }
2678:             i = end;
2679:         }
2680:     }
```

## mistral/pack.cc:3271-3304

```cpp
3271:     // resource inside a small reserved rectangle. The FF sits two BELs
3272:     // above its LUT (z+2): legal only when the LUT takes the first half of
3273:     // an ALM, so the legaliser skips the odd-z half automatically.
3274:     void pair_unbound_lut_ffs()
3275:     {
3276:         int paired = 0;
3277:         std::vector<CellInfo *> ffs;
3278:         for (auto &cell : ctx->cells) {
3279:             CellInfo *ci = cell.second.get();
3280:             if (ci->type == id_MISTRAL_FF && ci->bel == BelId() && ci->cluster == ClusterId() &&
3281:                 ctx->fes_cell_is_slot(ci))
3282:                 ffs.push_back(ci);
3283:         }
3284:         std::sort(ffs.begin(), ffs.end(), [](const CellInfo *a, const CellInfo *b) { return a->name < b->name; });
3285:         for (CellInfo *ff : ffs) {
3286:             const NetInfo *datain = ff->getPort(id_DATAIN);
3287:             if (datain == nullptr || datain->driver.cell == nullptr || datain->driver.port != id_Q)
3288:                 continue;
3289:             CellInfo *lut = datain->driver.cell;
3290:             if (!ctx->is_comb_cell(lut->type) || lut->type.in(id_MISTRAL_ALUT_ARITH, id_MISTRAL_CONST))
3291:                 continue;
3292:             if (lut->bel != BelId() || lut->cluster != ClusterId() || !ctx->fes_cell_is_slot(lut))
3293:                 continue;
3294:             lut->cluster = lut->name;
3295:             ff->cluster = lut->name;
3296:             ff->constr_x = 0;
3297:             ff->constr_y = 0;
3298:             ff->constr_z = 2;
3299:             ff->constr_abs_z = false;
3300:             lut->constr_children.push_back(ff);
3301:             ++paired;
3302:         }
3303:         if (paired > 0)
3304:             log_info("FES paired %d cart flip-flops with their driving LUTs.\n", paired);
```
