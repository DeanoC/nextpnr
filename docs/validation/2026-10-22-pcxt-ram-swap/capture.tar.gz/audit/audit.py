#!/usr/bin/env python3
"""Read-only complete RAM boundary inventory and conservative swap geometry screen."""
import collections,functools,hashlib,itertools,json,math,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SOURCE=Path('/tmp/pcxt-replicate-leased-20261022/inputs/placed.json')
BASE=ROOT.parent/'reassociate-20261022/baseline'
SHA='9241b02074cfee262c985c9ddde7e2c71f05bc654d35b989857a9a93ccc58878'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(name,obj):(ROOT/name).write_text(json.dumps(obj,indent=2)+'\n')
def xy(bel):return tuple(map(int,bel.split('.')[1:3]))
def delay(a,b):
 dx,dy=abs(a[0]-b[0]),abs(a[1]-b[1]);return 650+250*bool(dy)+35*dx+100*dy
def flat(cell):
 pins=json.loads(bytes.fromhex(cell['attributes']['FES_PINMAP_V1']))['pins'];result={}
 for port,bits in cell['connections'].items():
  names=[port] if port in pins else [f'{port}[{i}]' for i in range(len(bits))]
  assert len(names)==len(bits) or not bits
  for name,bit in zip(names,bits):result[name]=(cell['port_directions'][port],bit,pins[name][0])
 return result,pins

def main():
 assert sha(SOURCE)==SHA
 module=read(SOURCE)['modules']['top'];cells=module['cells'];ep=read(BASE/'endpoints.json');timing=read(BASE/'timing.json')
 ports={};pinmaps={};users=collections.defaultdict(list);drivers={};aliases=collections.defaultdict(list)
 for name,net in module['netnames'].items():
  for i,bit in enumerate(net['bits']):aliases[bit].append([name,i])
 for name,cell in cells.items():
  ports[name],pinmaps[name]=flat(cell)
  for pin,(direction,bit,state) in ports[name].items():
   item={'cell':name,'pin':pin,'state':state,'bel':cell['attributes']['NEXTPNR_BEL'],'type':cell['type']}
   if direction=='output':assert bit not in drivers;drivers[bit]=item
   else:users[bit].append(item)
 rams={n:c for n,c in cells.items() if c['type']=='MISTRAL_M10K'};assert len(rams)==318
 const={}
 for bit,d in drivers.items():
  c=cells[d['cell']]
  if c['type']=='MISTRAL_CONST':const[bit]=int(c['parameters']['LUT'],2)&1
 # Exact local support after constants, inversion and tied-input aliases. This
 # conservative transitive walk does not claim global reconvergence SAT proof.
 support={};comb_outputs={};comb_inputs={}
 for name,cell in cells.items():
  match=re.fullmatch(r'MISTRAL_ALUT([1-6])',cell['type'])
  if not match:continue
  width=int(match[1]);params=cell['parameters'];mask=int(params['LUT'],2)
  inputs=[];variables=set()
  for pin in 'ABCDEF'[:width]:
   state=pinmaps[name][pin][0];conn=ports[name].get(pin)
   if state in (1,2):value=state-1;inputs.append(('const',value));continue
   assert state in (0,3) and conn
   bit=conn[1]
   if bit in const:inputs.append(('const',const[bit]^(state==3)))
   elif isinstance(bit,str):assert bit in '01';inputs.append(('const',int(bit)^(state==3)))
   else:variables.add(bit);inputs.append(('var',bit,state==3))
  variables=sorted(variables);index={b:i for i,b in enumerate(variables)};truth=[]
  for vector in range(1<<len(variables)):
   raw=0
   for i,p in enumerate(inputs):raw|=((p[1] if p[0]=='const' else ((vector>>index[p[1]])&1)^p[2]))<<i
   truth.append((mask>>raw)&1)
  used={b for b,i in index.items() if any(truth[v]!=truth[v^(1<<i)] for v in range(len(truth)))}
  q=ports[name]['Q'][1];support[q]=used;comb_outputs[name]=[q];comb_inputs[name]=used
 unresolved_walk=set()
 @functools.lru_cache(None)
 def downstream(bit,ancestors=()):
  assert bit not in ancestors,'Combinational cycle'
  terminals=set();nodes=set();gaps=set()
  for u in users[bit]:
   name,pin=u['cell'],u['pin'];cell=cells[name]
   if name in comb_outputs:
    if bit not in comb_inputs[name]:continue
    nodes.add(name)
    for output in comb_outputs[name]:
     t,n,g=downstream(output,ancestors+(bit,));terminals.update(t);nodes.update(n);gaps.update(g)
   elif cell['type'] in ('MISTRAL_FF','MISTRAL_M10K'):
    terminals.add((name,pin))
   else:gaps.add((name,pin,cell['type']))
  return frozenset(terminals),frozenset(nodes),frozenset(gaps)
 def clk(name,pin):
  direction,bit,state=ports[name][pin];assert direction=='input' and state in (0,3)
  candidates=[label if i==0 else f'{label}[{i}]' for label,i in aliases[bit]]
  matches=[n for n in candidates if n in ep['clocks']];assert len(matches)==1,(name,pin,matches)
  return {'pin':pin,'bit':bit,'aliases':aliases[bit],'net':matches[0],'edge':int(state==3),
          'state':state,'waveform':ep['clocks'][matches[0]],'driver':drivers.get(bit),
          'fanout':len(users[bit])}
 detailed={}
 for net in timing['detailed_net_timings']:
  for endpoint in net['endpoints']:
   key=(endpoint['cell'],endpoint['port']);detailed.setdefault(key,[]).append({'driver':net['driver'],'driver_port':net['port'],
      'net':net['net'],'launch_event':net['event'],**endpoint})
 inventory=[];incident=set();all_gaps=[]
 for name,cell in sorted(rams.items()):
  params={k:int(v,2) for k,v in cell['parameters'].items() if k!='INIT'}
  assert params.get('CFG_DUAL_CLOCK')==1 and not params.get('CFG_ASYNC_READ',0) and not params.get('CFG_TDP',0)
  assert 'B1EN' in ports[name] and len(cell['connections']['CLK1'])==len(cell['connections']['CLK2'])==1
  clocks={pin:clk(name,pin) for pin in ('CLK1','CLK2')};inputs=[];outputs=[];gaps=[]
  attrs=cell['attributes'];guard_keys={'keep','dont_touch','BEL','LOC','FES_SLOT'}
  protected={k:v for k,v in attrs.items() if k in guard_keys};strength=int(attrs['BEL_STRENGTH'],2)
  record={'cell':name,'type':cell['type'],'bel':attrs['NEXTPNR_BEL'],'bel_strength':strength,
    'protection_attributes':protected,'all_attributes':attrs,'parameters_without_init':params,
    'init_sha256':hashlib.sha256(cell['parameters']['INIT'].encode()).hexdigest(),
    'clocks':clocks,'reset_pins':{p:pinmaps[name][p] for p in ('ACLR0','ACLR1')},
    'inputs':inputs,'outputs':outputs,'coverage_gaps':gaps}
  for pin,(direction,bit,state) in sorted(ports[name].items()):
   incident.add(bit)
   if pin in clocks or pin.startswith('ACLR'):continue
   key=json.dumps([name,pin])
   if direction=='input':
    clock=clocks['CLK2' if pin.startswith('B1') else 'CLK1'];classes=[k for k in ('endpoints','static_endpoints','unsupported_details') if key in ep[k]]
    if len(classes)!=1:gaps.append({'kind':'input-classification','pin':pin,'matches':classes});continue
    kind=classes[0];rows=ep[kind][key]
    item={'pin':pin,'bit':bit,'state':state,'capture':[clock['net'],clock['edge']],
          'driver':drivers.get(bit),'classification':kind,'endpoint_identity':[name,pin]}
    if kind=='endpoints':
     assert all(row['capture']==item['capture'] for row in rows),(name,pin,'clock mismatch')
     item['rows']=rows;item['direct_net_timing']=detailed.get((name,pin),[])
     if not item['direct_net_timing']:gaps.append({'kind':'input-native-net-record-missing','pin':pin})
     if not all(r['setup_timed'] and r['hold_related'] for r in rows):gaps.append({'kind':'input-untimed-clock-pair','pin':pin})
    elif kind=='static_endpoints':
     item['static_reason']=rows['reason'];item['static_value']=rows['value'];item['native_record_sha256']=hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()
    else:gaps.append({'kind':'input-unsupported','pin':pin});item['reason']=rows['reason']
    inputs.append(item)
   else:
    assert pin=='B1DATA' or pin.startswith('B1DATA[');clock=clocks['CLK2'];first=[];endpoint_edges=collections.defaultdict(list)
    for user in users[bit]:
     un,up=user['cell'],user['pin'];ct=cells[un]['type']
     if un in comb_outputs:
      if bit not in comb_inputs[un]:first.append({'user':user,'inactive_exact_local_support':True});continue
      terminals=set();nodes={un};ugaps=set()
      for output in comb_outputs[un]:
       t,n,g=downstream(output);terminals.update(t);nodes.update(n);ugaps.update(g)
     elif ct in ('MISTRAL_FF','MISTRAL_M10K'):terminals={(un,up)};nodes=set();ugaps=set()
     else:terminals=set();nodes=set();ugaps={(un,up,ct)}
     edge={'bit':bit,'driver_pin':pin,'first_user':user}
     first.append({'user':user,'terminals':sorted(terminals),'combinational_cells':sorted(nodes),'walk_gaps':sorted(ugaps)})
     for terminal in terminals:endpoint_edges[terminal].append(edge)
     if ugaps:gaps.append({'kind':'output-walk-unsupported','pin':pin,'edges':sorted(ugaps)})
    ends=[]
    for terminal,edges in sorted(endpoint_edges.items()):
     identity=json.dumps(list(terminal));rows=ep['endpoints'].get(identity,[])
     matches=[r for r in rows if r['launch']==[clock['net'],clock['edge']]]
     item={'identity':list(terminal),'launch':[clock['net'],clock['edge']],'first_edges':edges,'rows':matches}
     if len(matches)!=1:gaps.append({'kind':'output-native-clock-pair-missing-or-ambiguous','pin':pin,'terminal':terminal,'matches':len(matches)})
     elif not matches[0]['setup_timed'] or not matches[0]['hold_related']:gaps.append({'kind':'output-untimed-clock-pair','pin':pin,'terminal':terminal})
     ends.append(item)
    outputs.append({'pin':pin,'bit':bit,'state':state,'launch':[clock['net'],clock['edge']],
                    'immediate_fanout':len(users[bit]),'first_branches':first,'endpoints':ends})
  record['fully_inventoried_data_pairs']=not gaps
  record['input_timed_count']=sum(i['classification']=='endpoints' for i in inputs)
  record['input_static_count']=sum(i['classification']=='static_endpoints' for i in inputs)
  record['output_endpoint_pairs']=len({tuple(e['identity']) for o in outputs for e in o['endpoints']})
  inventory.append(record);all_gaps += [{'cell':name,**g} for g in gaps]
 fanouts={str(b):{'bit':b,'aliases':aliases[b],'driver':drivers.get(b),'all_users':users[b]} for b in sorted(incident,key=str)}
 write('all-ram-inventory.json',{'source_sha256':SHA,'clock_waveforms':ep['clocks'],'rams':inventory,'coverage_gaps':all_gaps})
 write('all-incident-fanouts.json',{'net_count':len(fanouts),'nets':fanouts})
 summary={'ram_count':len(inventory),'clocks':dict(collections.Counter(str(tuple(r['clocks'][p]['net'] for p in ('CLK1','CLK2'))) for r in inventory)),
  'protected_ram_count':sum(bool(r['protection_attributes']) for r in inventory),'strengths':dict(collections.Counter(r['bel_strength'] for r in inventory)),
  'timed_input_pins':sum(r['input_timed_count'] for r in inventory),'static_input_pins':sum(r['input_static_count'] for r in inventory),
  'output_endpoint_pairs':sum(r['output_endpoint_pairs'] for r in inventory),'fully_inventoried_rams':sum(r['fully_inventoried_data_pairs'] for r in inventory),
  'coverage_gap_count':len(all_gaps),'coverage_gap_kinds':dict(collections.Counter(g['kind'] for g in all_gaps)),
  'source_sha256':SHA,'baseline_endpoint_sha256':sha(BASE/'endpoints.json'),'baseline_timing_sha256':sha(BASE/'timing.json'),
  'script_sha256':sha(Path(__file__)),'incident_net_count':len(fanouts),'native_primitive_clock_margins_available':bool(ep['primitive_clocks']),
  'scope':'Complete logical data-pair inventory plus conservative geometry; not STA or native swap legality proof'}
 write('inventory-summary.json',summary);print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
