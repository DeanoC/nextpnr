#!/usr/bin/env python3
"""Rank reciprocal M10K placement diagnostics; all timing gains are model estimates."""
import collections,hashlib,json
from pathlib import Path
from audit import ROOT,BASE,SOURCE,sha,read,write,xy,delay

def main():
 inv=read(ROOT/'all-ram-inventory.json');rams=inv['rams'];byname={r['cell']:r for r in rams}
 micro=[r for r in rams if r['clocks']['CLK2']['net']=='clocks[2]']
 fb=[r for r in rams if xy(r['bel'])[0]==26]
 assert len(micro)==16 and len(fb)==69 and all(r['clocks']['CLK2']['net']=='clk_pixel' for r in fb)
 detailed=read(BASE/'timing.json');last_arcs={};source_paths=collections.defaultdict(list)
 for path in detailed['critical_paths']:
  routes=[p for p in path['path'] if p['type']=='routing']
  if not routes:continue
  last=routes[-1];end=(last['to']['cell'],last['to']['port'])
  if end[0] in byname:
   # These complete direct microcode address paths have one routing edge.
   item={'from':last['from'],'to':last['to'],'routing_ps':round(last['delay']*1000),'path_from_clock':path['from'],
         'path_to_clock':path['to'],'window_ns':path['max_delay']}
   old=last_arcs.get(end)
   if old is None or item['routing_ps']>old['routing_ps']:last_arcs[end]=item
  first=routes[0]
  if first['from']['cell'] in byname:source_paths[first['from']['cell']].append({'first_routing':first,'endpoint':last['to']})
 def evaluate(ram,site):
  old=xy(ram['bel']);inputs=[];outputs=[];weighted=0.;all_deltas=[]
  for pin in ram['inputs']:
   if pin['classification']!='endpoints':continue
   driver=pin['driver'];assert driver is not None
   origin=xy(driver['bel']);delta=delay(origin,site)-delay(origin,old)
   for row in pin['rows']:
    assert row['setup_timed'] and row['hold_related']
    weighted+=delta/row['setup_window'];all_deltas.append(delta)
    item={'identity':pin['endpoint_identity'],'launch':row['launch'],'capture':row['capture'],
      'window_ps':row['setup_window'],'driver':driver,'old_setup_ps':row['setup'],'old_hold_ps':row['hold'],
      'old_edge_estimate_ps':delay(origin,old),'new_edge_estimate_ps':delay(origin,site),'delta_estimate_ps':delta,
      'estimated_setup_ps':row['setup']-delta,'estimated_hold_ps':row['hold']+delta,
      'native_direct_net_timing':pin['direct_net_timing']}
    if tuple(pin['endpoint_identity']) in last_arcs:
     measured=last_arcs[tuple(pin['endpoint_identity'])];item['measured_last_routing_arc']=measured
     item['last_routing_budget_for_zero_setup_ps']=measured['routing_ps']+row['setup']
    inputs.append(item)
  grouped={}
  for out in ram['outputs']:
   for endpoint in out['endpoints']:
    assert len(endpoint['rows'])==1
    key=tuple(endpoint['identity']);row=endpoint['rows'][0]
    group=grouped.setdefault(key,{'identity':endpoint['identity'],'launch':row['launch'],'capture':row['capture'],
       'window_ps':row['setup_window'],'old_setup_ps':row['setup'],'old_hold_ps':row['hold'],'first_edges':[]})
    for edge in endpoint['first_edges']:
     target=xy(edge['first_user']['bel']);delta=delay(site,target)-delay(old,target)
     group['first_edges'].append({**edge,'old_estimate_ps':delay(old,target),'new_estimate_ps':delay(site,target),'delta_estimate_ps':delta})
  for group in grouped.values():
   changes=[e['delta_estimate_ps'] for e in group['first_edges']];dmax,dmin=max(changes),min(changes)
   weighted+=dmax/group['window_ps'];all_deltas.extend(changes)
   group.update(worst_first_edge_delta_ps=dmax,best_first_edge_delta_ps=dmin,
      estimated_setup_lower_bound_ps=group['old_setup_ps']-max(0,dmax),
      estimated_hold_lower_bound_ps=group['old_hold_ps']+min(0,dmin),
      bound_note='Uses complete endpoint native worst margin; unselected same-clock launch paths remain. Geometry delta is not a physical delay bound.')
   outputs.append(group)
  assert inputs and outputs
  summary={'input_rows':len(inputs),'output_pairs':len(outputs),'weighted_delay_delta_over_window':weighted,
    'old_input_setup_worst_ps':min(i['old_setup_ps'] for i in inputs),
    'estimated_input_setup_worst_ps':min(i['estimated_setup_ps'] for i in inputs),
    'old_input_setup_failures':sum(i['old_setup_ps']<0 for i in inputs),
    'estimated_input_setup_failures':sum(i['estimated_setup_ps']<0 for i in inputs),
    'old_output_setup_worst_ps':min(i['old_setup_ps'] for i in outputs),
    'estimated_output_setup_lower_bound_ps':min(i['estimated_setup_lower_bound_ps'] for i in outputs),
    'estimated_all_hold_lower_bound_ps':min([i['estimated_hold_ps'] for i in inputs]+[i['estimated_hold_lower_bound_ps'] for i in outputs]),
    'output_pairs_with_native_selected_source_worst_path':len({(p['endpoint']['cell'],p['endpoint']['port']) for p in source_paths[ram['cell']]}),
    'input_measured_last_route_arc_count':sum('measured_last_routing_arc' in i for i in inputs)}
  return {'cell':ram['cell'],'old_bel':ram['bel'],'new_bel':f'MISTRAL_M10K.{site[0]}.{site[1]}.0',
          'clocks':ram['clocks'],'summary':summary,'inputs':inputs,'outputs':outputs}
 candidates=[];screen_counts=collections.Counter()
 for cpu in micro:
  for frame in fb:
   assert cpu['fully_inventoried_data_pairs'] and frame['fully_inventoried_data_pairs']
   assert cpu['bel_strength']==frame['bel_strength']==1 and not cpu['protection_attributes'] and not frame['protection_attributes']
   a=evaluate(cpu,xy(frame['bel']));b=evaluate(frame,xy(cpu['bel']));sa,sb=a['summary'],b['summary'];reasons=[]
   if sb['estimated_input_setup_worst_ps']<0:reasons.append('framebuffer-input-budget')
   if sb['estimated_output_setup_lower_bound_ps']<0:reasons.append('framebuffer-output-budget')
   if sa['estimated_output_setup_lower_bound_ps']<0:reasons.append('microcode-return-budget')
   if min(sa['estimated_all_hold_lower_bound_ps'],sb['estimated_all_hold_lower_bound_ps'])<0:reasons.append('hold-budget')
   if sa['estimated_input_setup_worst_ps']<=sa['old_input_setup_worst_ps']:reasons.append('no-microcode-worst-improvement')
   if sa['estimated_input_setup_failures']>=sa['old_input_setup_failures']:reasons.append('no-microcode-failure-count-improvement')
   weighted=sa['weighted_delay_delta_over_window']+sb['weighted_delay_delta_over_window']
   if weighted>=0:reasons.append('nonimproving-phase-weighted-cost')
   screen_counts.update(reasons)
   candidates.append({'microcode':cpu['cell'],'framebuffer':frame['cell'],'old_microcode_bel':cpu['bel'],'old_framebuffer_bel':frame['bel'],
       'passes_geometry_budget_screen':not reasons,'rejection_reasons':reasons,
       'weighted_delta_over_window':weighted,'microcode_summary':sa,'framebuffer_summary':sb})
 accepted=[c for c in candidates if c['passes_geometry_budget_screen']]
 accepted.sort(key=lambda c:(c['microcode_summary']['estimated_input_setup_worst_ps'],c['weighted_delta_over_window'],c['microcode'],c['framebuffer']),reverse=False)
 # Rank by worst-slack improvement, then weighted total cost and identities.
 accepted.sort(key=lambda c:(-(c['microcode_summary']['estimated_input_setup_worst_ps']-c['microcode_summary']['old_input_setup_worst_ps']),
     c['weighted_delta_over_window'],c['microcode'],c['framebuffer']))
 chosen=[];used=set()
 for c in accepted:
  if c['microcode'] in used or c['framebuffer'] in used:continue
  chosen.append(c);used.update((c['microcode'],c['framebuffer']))
  if len(chosen)==4:break
 full=[]
 for i,c in enumerate(chosen,1):
  a,b=byname[c['microcode']],byname[c['framebuffer']]
  full.append({'rank':i,**c,'microcode_evaluation':evaluate(a,xy(b['bel'])),'framebuffer_evaluation':evaluate(b,xy(a['bel'])),
    'recorded_placement_guards':{'both_weak':True,'no_keep_dont_touch_bel_loc_fes_slot':True,
      'destinations_are_actual_occupied_m10k_bels':True,'same_primitive_type':True,'all_data_pairs_inventoried':True},
    'native_transactional_swap_checked':False,'physical_gain_proven':False})
 write('ranked-candidate-pairs.json',{'kind':'Read-only model-ranked reciprocal swap diagnostics; no native swap or route',
   'total_pairs':len(candidates),'screen_pass_count':len(accepted),'rejection_reason_counts':dict(screen_counts),
   'ranking':'largest estimated microcode worst-margin improvement, then phase-window-normalized total delta; selected pairs are cell-disjoint',
   'output_bound_rule':'Use native endpoint margin and only adverse max/min first-edge changes; no output improvement claimed from a non-source-specific endpoint row',
   'selected_pairs':full,'all_candidate_summaries':candidates,
   'mandatory_next_checks':['Native explicit two-M10K unbind/bind, protection/cluster/region checks and exact rollback',
     'Complete fresh route with both sides and all outside endpoints; clock nets/skew can change',
     'Native primitive-clock period/pulse-width margins unavailable; data inventory does not close this gap',
     'RBF/electrical/board/hardware and existing multi-seed/retention gates remain open']})
 summary={'pair_count':len(candidates),'geometry_screen_pass_count':len(accepted),'rejections':dict(screen_counts),
          'selected_pairs':[{k:v for k,v in c.items() if k not in ['microcode_evaluation','framebuffer_evaluation']} for c in full]}
 write('ranking-summary.json',summary);print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
