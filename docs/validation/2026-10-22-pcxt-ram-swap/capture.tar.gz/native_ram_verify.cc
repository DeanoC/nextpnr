// Read-only placed-checkpoint diagnostic, linked against frozen 692 objects.
// No packing, placement, route preparation, routing, or checkpoint serialization.
#include "nextpnr.h"
#include "json_frontend.h"
#include "json11.hpp"
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>

USING_NEXTPNR_NAMESPACE
using J = json11::Json;
static void need(bool value, const std::string &reason) { if (!value) throw std::runtime_error(reason); }
static J read(const std::string &path)
{
    std::ifstream f(path); need(bool(f), "Cannot read plan");
    std::string raw((std::istreambuf_iterator<char>(f)), {}), error;
    auto result = J::parse(raw, error); need(error.empty(), error); return result;
}
static std::string belname(Context &ctx, BelId b) { return b == BelId() ? "" : ctx.getBelName(b).str(&ctx); }
static bool protected_cell(Context &ctx, CellInfo *cell)
{
    if (cell->belStrength > STRENGTH_WEAK || cell->cluster != ClusterId() || !cell->constr_children.empty() ||
        cell->constr_x || cell->constr_y || cell->constr_z || cell->constr_abs_z || cell->region || cell->isPseudo()) return true;
    for (const auto &entry : cell->attrs) {
        auto key = entry.first.str(&ctx);
        if (key == "keep" || key == "dont_touch" || key == "BEL" || key == "LOC" || key == "FES_SLOT") return true;
    }
    return false;
}
static J decoded_map(const std::string &encoded)
{
    need(encoded.size() % 2 == 0, "Malformed saved-map hex"); std::string decoded, error;
    auto digit=[](char ch)->int { if(ch >= '0' && ch <= '9')return ch-'0'; if(ch >= 'a' && ch <= 'f')return ch-'a'+10;
        if(ch >= 'A' && ch <= 'F')return ch-'A'+10;throw std::runtime_error("Invalid hex digit"); };
    for (size_t i=0; i<encoded.size(); i+=2) decoded.push_back(char(16*digit(encoded[i])+digit(encoded[i+1])));
    auto value=J::parse(decoded,error); need(error.empty(),"Malformed saved pin map"); return value;
}
int main(int argc, char **argv)
{
    try {
        need(argc == 5, "Usage: native-ram-verify input.json plan.json source|candidate proof.json");
        std::string phase=argv[3]; need(phase=="source" || phase=="candidate", "Unknown checkpoint phase");
        auto plan=read(argv[2]); auto moves=plan["moves"].array_items(); need(moves.size()==2,"Requires two selected RAMs");
        need(moves[0]["old_bel"]==moves[1]["new_bel"] && moves[1]["old_bel"]==moves[0]["new_bel"],"Not a reciprocal swap");
        ArchArgs args;args.device="5CSEBA6U23I7";Context ctx(args);
        std::ifstream file(argv[1]);need(parse_json(file,argv[1],&ctx),"Cannot parse checkpoint");
        need(ctx.attrs.count(id_step) && ctx.attrs.at(id_step).as_string()=="place","Not a placed checkpoint");
        need(!ctx.fes_any_slot_region_active && !ctx.fes_fence_active && !ctx.fes_has_reserved_rect &&
             ctx.fes_frozen_cells.empty() && ctx.fes_frozen_pips.empty(),"Frozen region/scaffold present");
        for (const auto &a:ctx.attrs)need(a.first.str(&ctx).find("FES_LABSTATE")!=0,"Routed LAB state present");
        for (const auto &net:ctx.nets)need(net.second->wires.empty(),"Routing is present");
        ctx.restore_placed_pin_maps();
        std::set<CellInfo*> selected;
        for (const auto &move:moves) {
            auto key=ctx.id(move["cell"].string_value());need(ctx.cells.count(key),"Missing selected cell");
            auto *cell=ctx.cells.at(key).get();need(selected.insert(cell).second,"Duplicate selected cell");
            need(cell->type==id_MISTRAL_M10K,"Selected cell is not M10K");
            need(!protected_cell(ctx,cell),"Selected cell is protected/clustered/constrained");
            auto expected=move[phase=="source"?"old_bel":"new_bel"].string_value();
            need(belname(ctx,cell->bel)==expected,"Selected binding differs from plan");
        }
        J::object ram_records;int sites=0,legal_cells=0;
        for (auto bel:ctx.getBels())if(ctx.getBelType(bel)==id_MISTRAL_M10K)++sites;
        need(sites==553,"Unexpected M10K site inventory");
        for (const auto &entry:ctx.cells) {
            auto *cell=entry.second.get();
            if (cell->bel!=BelId()) {
                need(ctx.getBoundBelCell(cell->bel)==cell,"Inconsistent BEL binding");
                need(ctx.isValidBelForCellType(cell->type,cell->bel),"Wrong bound BEL type");
                need(ctx.isBelLocationValid(cell->bel,false),"Illegal bound BEL location");++legal_cells;
            }
            if (cell->type!=id_MISTRAL_M10K)continue;
            need(cell->bel!=BelId() && ctx.fes_placement_allowed(cell->bel,cell),"RAM has no allowed placement");
            J::object pins,port_records;
            for (const auto &pin:cell->pin_data) {
                J::array values{int(pin.second.state)};for (auto physical:pin.second.bel_pins)values.emplace_back(physical.str(&ctx));
                pins[pin.first.str(&ctx)]=values;
            }
            need(decoded_map(cell->attrs.at(ctx.id("FES_PINMAP_V1")).as_string())==
                 J(J::object{{"count",int(pins.size())},{"pins",pins}}),"Native RAM pin map differs from saved map");
            for (const auto &port:cell->ports) {
                int count=0;auto cls=ctx.getPortTimingClass(cell,port.first,count);J::array clocking;
                for (int i=0;i<count;i++) {
                    auto info=ctx.getPortClockingInfo(cell,port.first,i);auto *clock=cell->getPort(info.clock_port);
                    need(clock!=nullptr,"Timed RAM port has no clock");
                    clocking.emplace_back(J::object{{"clock_port",info.clock_port.str(&ctx)},{"clock_net",clock->name.str(&ctx)},
                        {"edge",int(info.edge)},{"setup_min",info.setup.minDelay()},{"setup_max",info.setup.maxDelay()},
                        {"hold_min",info.hold.minDelay()},{"hold_max",info.hold.maxDelay()},
                        {"clock_to_q_min",info.clockToQ.minDelay()},{"clock_to_q_max",info.clockToQ.maxDelay()}});
                }
                port_records[port.first.str(&ctx)]=J::object{{"class",int(cls)},{"clock_info",clocking},
                    {"net",port.second.net?port.second.net->name.str(&ctx):""}};
            }
            ram_records[cell->name.str(&ctx)]=J::object{{"bel",belname(ctx,cell->bel)},
                {"strength",int(cell->belStrength)},{"protected_clustered_constrained",protected_cell(ctx,cell)},
                {"pins",pins},{"native_ports",port_records},{"placement_legal",true}};
        }
        need(ram_records.size()==318,"RAM inventory changed");ctx.check();
        std::ofstream output(argv[4]);need(bool(output),"Cannot write proof");
        output<<J(J::object{{"kind","Native placed checkpoint binding, guards, full cell legality and RAM timing class check"},
            {"phase",phase},{"selected_ram_count",2},{"m10k_sites",sites},{"checked_bound_cells",legal_cells},
            {"rams",ram_records},{"packing_placement_routing_performed",false}}).dump()<<"\n";
        return 0;
    } catch(const std::exception &error) { std::cerr<<"REJECTED: "<<error.what()<<"\n";return 1; }
}
