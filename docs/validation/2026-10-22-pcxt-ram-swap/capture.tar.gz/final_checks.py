#!/usr/bin/env python3
"""Complete final graph, recipe and endpoint comparison for both reciprocal routes."""
import json
import subprocess
from pathlib import Path
from prepare import ROOT, SOURCE, PAIRS, digest, dump, load, require

BASE = ROOT.parent / 'reassociate-20261022/baseline'
NUMERIC = {'setup', 'hold', 'min_path', 'max_path'}

def rows(document):
    result = {}
    for identity, entries in document['endpoints'].items():
        for row in entries:
            metadata = {k: v for k, v in row.items() if k not in NUMERIC}
            key = (identity, json.dumps(metadata, sort_keys=True))
            require(key not in result, 'Duplicate native endpoint/clock tuple')
            result[key] = row
    return result

def summarize(records):
    result = {'rows': len(records)}
    for side in ('before', 'after'):
        setup = [r[side]['setup'] for r in records if r['metadata']['setup_timed']]
        hold = [r[side]['hold'] for r in records if r['metadata']['hold_related']]
        result[side] = {'setup_failures': sum(x < 0 for x in setup), 'setup_worst_ps': min(setup) if setup else None,
                        'hold_failures': sum(x < 0 for x in hold), 'hold_worst_ps': min(hold) if hold else None}
    result['setup_regressions'] = sum(r['metadata']['setup_timed'] and r['after']['setup'] < r['before']['setup'] for r in records)
    result['hold_decreases'] = sum(r['metadata']['hold_related'] and r['after']['hold'] < r['before']['hold'] for r in records)
    result['new_setup_failures'] = sum(r['metadata']['setup_timed'] and r['before']['setup'] >= 0 > r['after']['setup'] for r in records)
    result['fixed_setup_failures'] = sum(r['metadata']['setup_timed'] and r['before']['setup'] < 0 <= r['after']['setup'] for r in records)
    result['worst_after'] = sorted((r for r in records if r['metadata']['setup_timed']), key=lambda r: (r['after']['setup'],r['identity']))[:5]
    return result

def main():
    audit = load((ROOT.parent / 'ram-swap-audit-20261022/all-ram-inventory.json').read_bytes())
    ram_by_name = {r['cell']: r for r in audit['rams']}
    microcode = {r['cell'] for r in audit['rams'] if r['clocks']['CLK2']['net'] == 'clocks[2]'}
    baseline = load((BASE / 'endpoints.json').read_bytes())
    old_rows = rows(baseline)
    frozen_inputs = load((ROOT.parent / 'reassociate-20261022/inputs.json').read_bytes())
    for value in frozen_inputs.values():
        require(digest(Path(value['original']).read_bytes()) == value['sha256'], 'Frozen constraint/input bytes changed')
    summaries = []
    for label, micro, frame in PAIRS:
        directory = ROOT / label
        plan = load((directory / 'plan.json').read_bytes())
        prep = load((directory / 'preparation-proof.json').read_bytes())
        complete_plan = {**prep, 'candidate_path': str(directory / 'candidate-placed.json'), 'moves': plan['moves']}
        dump(directory / 'final-comparison-plan.json', complete_plan)
        command = ['python3', str(ROOT / 'prove-routed.py'), '--baseline', str(BASE / 'routed.json'),
                   '--candidate', str(directory / 'route/routed.json'), '--plan', str(directory / 'final-comparison-plan.json'),
                   '--output-prefix', str(directory / 'proof-routed'), '--self-test']
        with (directory / 'proof-routed.log').open('wb') as log:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
        for route in (BASE, directory / 'route'):
            receipt = load((route / 'receipt.json').read_bytes())
            for name, expected in receipt['artifacts'].items():
                require(digest((route / name).read_bytes()) == expected, 'Route artifact checksum mismatch')
        candidate = load((directory / 'route/endpoints.json').read_bytes())
        new_rows = rows(candidate)
        require(old_rows.keys() == new_rows.keys(), 'Full native clock/endpoint inventory changed')
        records = []
        for key in sorted(old_rows):
            old, new = old_rows[key], new_rows[key]
            records.append({'identity': json.loads(key[0]), 'metadata': json.loads(key[1]),
                            'before': {m: old[m] for m in sorted(NUMERIC)},
                            'after': {m: new[m] for m in sorted(NUMERIC)},
                            'setup_delta_ps': new['setup']-old['setup'] if old['setup_timed'] else None,
                            'hold_delta_ps': new['hold']-old['hold'] if old['hold_related'] else None})
        groups = {
            'all_endpoints': records,
            'cpu_same_clock': [r for r in records if r['metadata']['launch'] == r['metadata']['capture'] == ['clocks[0]',0]],
            'pixel_same_clock': [r for r in records if r['metadata']['launch'] == r['metadata']['capture'] == ['clk_pixel',0]],
            'all_microcode_addresses': [r for r in records if r['identity'][0] in microcode and r['identity'][1].startswith('B1ADDR')],
            'all_microcode_returns': [r for r in records if r['metadata']['launch'] == ['clocks[2]',0] and r['metadata']['capture'] == ['clocks[0]',0]],
        }
        selected_keys = set()
        for prefix, name in [('microcode', micro), ('framebuffer', frame)]:
            ram = ram_by_name[name]
            inputs = {tuple(i['endpoint_identity']) for i in ram['inputs'] if i['classification'] == 'endpoints'}
            outputs = {tuple(e['identity']) for o in ram['outputs'] for e in o['endpoints']}
            clock = [ram['clocks']['CLK2']['net'], ram['clocks']['CLK2']['edge']]
            groups[prefix + '_inputs'] = [r for r in records if tuple(r['identity']) in inputs]
            groups[prefix + '_outputs'] = [r for r in records if tuple(r['identity']) in outputs and r['metadata']['launch'] == clock]
            require(len(groups[prefix + '_inputs']) == ram['input_timed_count'], 'Selected input coverage mismatch')
            require(len(groups[prefix + '_outputs']) == ram['output_endpoint_pairs'], 'Selected output coverage mismatch')
            for suffix in ('_inputs', '_outputs'):
                for record in groups[prefix + suffix]:
                    selected_keys.add((tuple(record['identity']), json.dumps(record['metadata'],sort_keys=True)))
        groups['outside_selected_pairs'] = [r for r in records if
            (tuple(r['identity']),json.dumps(r['metadata'],sort_keys=True)) not in selected_keys]
        result = {'case': label, 'setup_accepted': False, 'hardware_evidence': False,
                  'all_endpoint_identities': len(candidate['endpoints']), 'all_native_clock_tuples': len(records),
                  'unsupported_rows': len(candidate['unsupported_details']), 'native_primitive_clock_rows': len(candidate['primitive_clocks']),
                  'complete': candidate['complete'], 'groups': {name: summarize(group) for name,group in groups.items()},
                  'selected_rom_address_rows': groups['microcode_inputs'],
                  'framebuffer_rows': groups['framebuffer_inputs'] + groups['framebuffer_outputs'],
                  'charged_seconds_including_queue': load((directory/'route/receipt.json').read_bytes())['charged_seconds'],
                  'proof': {'all_graph_physical_pin_alias_classes_exact_except_two_bels': True,
                            'all_endpoint_metadata_and_clock_tuples_exact': True,
                            'all_artifact_receipt_hashes_verified': True,
                            'same_frozen_recipe_except_verified_placed_input': True,
                            'all_3_original_frozen_inputs_preserved': True},
                  'limits': ['Geometry predictions were not timing bounds.',
                             'No native primitive clock period/pulse-width margins are available.',
                             'Complete logical/physical-pin equality is not emitted RBF or electrical routing proof.',
                             'Every outside-pair regression is retained; no endpoint intersection or timing waiver is used.']}
        dump(directory / 'all-endpoint-deltas.json', {'rows': records})
        dump(directory / 'analysis.json', result)
        compact = {'case': label, 'groups': {k:{x:v for x,v in s.items() if x!='worst_after'} for k,s in result['groups'].items()},
                   'charged_seconds_including_queue': result['charged_seconds_including_queue']}
        summaries.append(compact)
    dump(ROOT / 'analysis-summary.json', summaries)
    print(json.dumps(summaries, indent=2))

if __name__ == '__main__':
    main()
