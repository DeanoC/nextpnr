from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time

root = Path(__file__).resolve().parent
task = root.parents[1]
baseline_path = root.parent / 'reassociate-20261022/baseline/receipt.json'
baseline = json.loads(baseline_path.read_text())
qualifications = json.loads((root / 'qualification-summary.json').read_text())

def run(case):
    assert case['qualified'] is True
    source = root / case['label'] / 'candidate-placed.json'
    assert hashlib.file_digest(source.open('rb'), 'sha256').hexdigest() == case['input_sha256']
    command = baseline['nextpnr_command'][:]
    assert hashlib.file_digest(open(command[0], 'rb'), 'sha256').hexdigest() == baseline['binary_sha256']
    command[command.index('--json') + 1] = str(source)
    assert '--no-pack' in command and '--no-place' in command
    wrapped = [str(task / 'scripts/gpu-run'), '--phase-lease', '--owner', 'pcxt-timing',
               '--label', 'pcxt-ram-swap-' + case['label'], '--', *command]
    directory = source.parent / 'route'
    directory.mkdir(exist_ok=False)
    receipt = {'command': wrapped, 'nextpnr_command': command,
               'input_sha256': case['input_sha256'], 'binary_sha256': baseline['binary_sha256'],
               'baseline_receipt': str(baseline_path),
               'qualification_summary_sha256': hashlib.file_digest((root/'qualification-summary.json').open('rb'), 'sha256').hexdigest(),
               'evidence': 'leased GPU host diagnostic; exactly two reciprocal RAM BEL moves; not acceptance',
               'limit': 'native bounded router iterations; no external GPU-job termination'}
    env = dict(os.environ, NEXTPNR_REQUIRE_GPU='1')
    start = time.monotonic()
    with (directory/'nextpnr.log').open('w') as log:
        receipt['returncode'] = subprocess.run(wrapped, cwd=directory, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    receipt['charged_seconds'] = time.monotonic() - start
    receipt['artifacts'] = {p.name: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
                            for p in directory.iterdir() if p.suffix in ['.json', '.rbf']}
    (directory/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(case['label'], receipt['returncode'], receipt['charged_seconds'], flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(run, qualifications):
        pass
