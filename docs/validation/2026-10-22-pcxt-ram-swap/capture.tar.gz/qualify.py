#!/usr/bin/env python3
"""Native loader/placement legality qualification only. Never invokes a route."""
import copy
import hashlib
import json
import subprocess
import time
from pathlib import Path
from prepare import ROOT, SOURCE, SOURCE_SHA, BINARY, BINARY_SHA, PAIRS, digest, dump, load, differences, require

def execute(command, log):
    start = time.monotonic()
    with log.open('wb') as output:
        result = subprocess.run([str(a) for a in command], stdout=output, stderr=subprocess.STDOUT, cwd=ROOT)
    receipt = {'command': [str(a) for a in command], 'returncode': result.returncode,
               'wall_seconds': time.monotonic()-start, 'log_sha256': digest(log.read_bytes())}
    return receipt

def verify_exact_changes(original, candidate, moves):
    actual = differences(original, candidate)
    expected = [{'path': ['modules', 'top', 'cells', m['cell'], 'attributes', 'NEXTPNR_BEL'],
                 'before': m['old_bel'], 'after': m['new_bel']} for m in moves]
    require(sorted(actual, key=lambda d: d['path']) == sorted(expected, key=lambda d: d['path']),
            'Unexpected complete checkpoint difference')

def main():
    require(digest(SOURCE.read_bytes()) == SOURCE_SHA, 'Frozen source changed')
    require(digest(BINARY.read_bytes()) == BINARY_SHA, 'Frozen compiler changed')
    helper = ROOT / 'native-ram-verify'
    records = []
    for label, micro, frame in PAIRS:
        target = ROOT / label
        plan = load((target / 'plan.json').read_bytes())
        prep = load((target / 'preparation-proof.json').read_bytes())
        candidate = target / 'candidate-placed.json'
        require(digest(candidate.read_bytes()) == prep['candidate_sha256'], 'Prepared bytes changed')
        native = []
        for phase, checkpoint in [('source', SOURCE), ('candidate', candidate)]:
            proof = target / f'native-{phase}-proof.json'
            command = [helper, checkpoint, target / 'plan.json', phase, proof]
            receipt = execute(command, target / f'native-{phase}.log')
            receipt['helper_sha256'] = digest(helper.read_bytes())
            dump(target / f'native-{phase}-receipt.json', receipt)
            require(receipt['returncode'] == 0, f'Native {phase} qualification failed: {label}')
            native.append(load(proof.read_bytes()))
        before, after = native
        require(before['checked_bound_cells'] == after['checked_bound_cells'], 'Native bound cell count changed')
        require(list(before['rams']) == list(after['rams']) and len(before['rams']) == 318, 'Native RAM identities changed')
        native_changes = differences(before['rams'], after['rams'])
        expected = [{'path': [m['cell'], 'bel'], 'before': m['old_bel'], 'after': m['new_bel']} for m in plan['moves']]
        require(sorted(native_changes, key=lambda d: d['path']) == sorted(expected, key=lambda d: d['path']),
                'Native pin/clock/timing class/strength/guard or unexpected BEL changed')
        require(all(not r['protected_clustered_constrained'] and r['strength'] == 1 for r in before['rams'].values()),
                'Original RAM has native protection/cluster/constraint')
        command = [BINARY, '--device', '5CSEBA6U23I7', '--json', candidate, '--no-pack', '--no-place', '--no-route']
        receipt = execute(command, target / 'native-cli-load.log')
        receipt.update(binary_sha256=BINARY_SHA, compiler_commit='692a1c372b2b55620ba1fd5e43e0c14ae8ffa4d9')
        dump(target / 'native-cli-load-receipt.json', receipt)
        require(receipt['returncode'] == 0, 'Frozen compiler checkpoint load failed')
        require(digest(candidate.read_bytes()) == prep['candidate_sha256'], 'Loader changed actual route input')
        require(digest(SOURCE.read_bytes()) == SOURCE_SHA and digest(BINARY.read_bytes()) == BINARY_SHA,
                'Frozen source/compiler changed during qualification')
        original = load(SOURCE.read_bytes())
        value = load(candidate.read_bytes())
        verify_exact_changes(original, value, plan['moves'])
        failures = []
        # Deliberately corrupt independent graph boundaries; each must reject.
        clock_param = 'CFG_DUAL_CLOCK'
        changes = [('ram-clock-parameter', lambda v: v['modules']['top']['cells'][micro]['parameters'].__setitem__(clock_param, '0')),
                   ('ram-saved-pin-map', lambda v: v['modules']['top']['cells'][micro]['attributes'].__setitem__('FES_PINMAP_V1', '00')),
                   ('removed-net-alias', lambda v: v['modules']['top']['netnames'].pop(next(iter(v['modules']['top']['netnames'])))),
                   ('unselected-bel', lambda v: v['modules']['top']['cells'][next(n for n in v['modules']['top']['cells'] if n not in (micro, frame))]['attributes'].__setitem__('NEXTPNR_BEL', 'bad'))]
        for name, corrupt in changes:
            trial = copy.deepcopy(value)
            corrupt(trial)
            try:
                verify_exact_changes(original, trial, plan['moves'])
            except ValueError:
                failures.append({'corruption': name, 'rejected': True})
            else:
                raise ValueError('Graph checker accepted corruption ' + name)
        dump(target / 'graph-negative-tests.json', failures)
        proof = {'kind': 'Qualified host-only reciprocal RAM placement diagnostic; ready for a separate fresh route',
                 'input_sha256': prep['candidate_sha256'], 'source_sha256': SOURCE_SHA,
                 'binary_sha256': BINARY_SHA, 'helper_sha256': digest(helper.read_bytes()),
                 'exact_complete_checkpoint_two_bel_changes': True, 'orphan_aliases_and_order_preserved': True,
                 'native_all_bound_cells_legal': after['checked_bound_cells'], 'native_ram_count': 318,
                 'native_all_ram_clock_arcs_pin_maps_unchanged': True,
                 'native_selected_weak_unprotected_unclustered_unconstrained': True,
                 'native_no_frozen_slot_or_fence': True, 'candidate_not_native_reserialized': True,
                 'packing_placement_routing_performed': False, 'negative_graph_cases_rejected': len(failures),
                 'changed_native_properties': native_changes,
                 'limits': ['No physical setup/hold gain proven', 'No routed clock/skew or primitive clock margin proof',
                            'No RBF or hardware evidence', 'Future production policy must apply live guards independently']}
        dump(target / 'qualification-proof.json', proof)
        records.append({'label': label, 'qualified': True, 'input_sha256': prep['candidate_sha256'],
                        'native_bound_cells': after['checked_bound_cells']})
    dump(ROOT / 'qualification-summary.json', records)
    print(json.dumps(records, indent=2))

if __name__ == '__main__':
    main()
