#!/usr/bin/env python3
"""Archive complete diagnostic evidence, then read back every member and hash."""
import hashlib
import io
import json
import tarfile
from pathlib import Path
from prepare import ROOT, PAIRS, digest, dump, require

def main():
    selected = {}
    excluded = {'native-ram-verify', 'native_ram_verify.o', 'capture.tar.gz', 'capture-readback.json',
                'capture-manifest.json', 'manifest.json', 'package-capture.log'}
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.name in excluded or '__pycache__' in path.parts:
            continue
        selected[str(path.relative_to(ROOT))] = path
    audit = ROOT.parent/'ram-swap-audit-20261022'
    for path in sorted(audit.iterdir()):
        if path.is_file():
            selected['audit/'+path.name] = path
    inputs = ROOT.parent/'reassociate-20261022/inputs'
    for path in sorted(inputs.iterdir()):
        if path.is_file():
            selected['original-inputs/'+path.name] = path
    baseline = ROOT.parent/'reassociate-20261022/baseline'
    for name in ('routed.json','endpoints.json','timing.json','diagnostic.rbf','receipt.json','nextpnr.log'):
        selected['baseline/'+name] = baseline/name
    for name in ('source-identity.json','inputs.json'):
        selected['baseline/'+name] = ROOT.parent/'reassociate-20261022'/name
    frozen = ROOT.parent/'ram-decode-20261022'
    for name in ('frozen-object-manifest.json','original-link-command.txt'):
        selected['helper-dependencies/'+name] = frozen/name
    require(all(p.is_file() for p in selected.values()), 'Missing retained evidence source')
    require(all(not name.startswith('/') and '..' not in Path(name).parts for name in selected), 'Unsafe archive member name')
    manifest = {name:{'source':str(path),'size':path.stat().st_size,'sha256':digest(path.read_bytes())}
                for name,path in sorted(selected.items())}
    identity = {'kind':'Complete compact reciprocal RAM swap evidence; host-only diagnostics, timing not accepted',
                'compiler_binary_sha256':digest((ROOT.parent/'reassociate-20261022/nextpnr-mistral').read_bytes()),
                'helper_binary_sha256':digest((ROOT/'native-ram-verify').read_bytes()),
                'excluded':['compiler/helper executables','compiled objects/libraries','frozen source/header trees','Python caches'],
                'includes':['original placed input and constraints','complete baseline route artifacts',
                            'both complete candidate placements and final route RBF/JSON/endpoint/timing artifacts',
                            'all 318 RAM inventory and full fanouts','complete preparation/native/final proofs and sources'],
                'run_charges_including_queue_seconds':{label:json.loads((ROOT/label/'route/receipt.json').read_text())['charged_seconds'] for label,_,_ in PAIRS},
                'files':manifest}
    dump(ROOT/'capture-manifest.json',identity)
    archive=ROOT/'capture.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
        for name,path in sorted(selected.items()):
            raw=path.read_bytes();require(digest(raw)==manifest[name]['sha256'],'Evidence changed while archiving')
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
        raw=(ROOT/'capture-manifest.json').read_bytes()
        info=tarfile.TarInfo('capture-manifest.json');info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
    checked={}
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers();require(len(members)==len(manifest)+1,'Archive member count mismatch')
        require(len({m.name for m in members})==len(members),'Duplicate archive members')
        for member in members:
            require(member.isfile(),'Nonregular archive member')
            raw=tar.extractfile(member).read()
            expected=(ROOT/'capture-manifest.json').read_bytes() if member.name=='capture-manifest.json' else selected[member.name].read_bytes()
            require(raw==expected,'Archive readback differs from evidence source')
            checked[member.name]={'size':len(raw),'sha256':digest(raw)}
    dump(ROOT/'capture-readback.json',{'archive_sha256':digest(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
         'member_count':len(checked),'all_source_bytes_read_back_exactly':True,'members':checked})
    print(json.dumps({'archive_bytes':archive.stat().st_size,'archive_sha256':digest(archive.read_bytes()),'member_count':len(checked)},indent=2))

if __name__=='__main__':
    main()
