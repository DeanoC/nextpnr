#!/usr/bin/env python3
"""Two independent, exact-byte reciprocal RAM BEL patches. Never routes."""
import collections
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/tmp/pcxt-replicate-leased-20261022/inputs/placed.json')
SOURCE_SHA = '9241b02074cfee262c985c9ddde7e2c71f05bc654d35b989857a9a93ccc58878'
BINARY = ROOT.parent / 'reassociate-20261022/nextpnr-mistral'
BINARY_SHA = '05dca6ea935a614e4948f5cf9e0fb2b92b3934e9b6891568d13f492d3dbc1162'
AUDIT = ROOT.parent / 'ram-swap-audit-20261022'
PAIRS = [
    ('byte3-rom1', 'system.machine.cpu.cpu.u_eu_core.u_ucode_rom.bytes[3].rom.1.0.0',
     'system.video.adapter.framebuffer_banks[0].framebuffer.ram.0.54'),
    ('byte2-rom3', 'system.machine.cpu.cpu.u_eu_core.u_ucode_rom.bytes[2].rom.3.0.0',
     'system.video.adapter.framebuffer_banks[0].framebuffer.ram.0.52'),
]

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def require(ok, reason):
    if not ok:
        raise ValueError(reason)

def unique_keys(items):
    result = {}
    for key, value in items:
        require(key not in result, 'Duplicate JSON key ' + key)
        result[key] = value
    return result

def load(raw):
    return json.loads(raw, object_pairs_hook=unique_keys)

def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def differences(a, b, path=()):
    require(type(a) is type(b), 'Changed value type at ' + repr(path))
    if isinstance(a, dict):
        require(list(a) == list(b), 'Changed keys/order at ' + repr(path))
        return [d for k in a for d in differences(a[k], b[k], path + (k,))]
    if isinstance(a, list):
        require(len(a) == len(b), 'Changed list length at ' + repr(path))
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in differences(x, y, path + (i,))]
    return [] if a == b else [{'path': list(path), 'before': a, 'after': b}]

def main():
    raw = SOURCE.read_bytes()
    require(digest(raw) == SOURCE_SHA, 'Unexpected frozen source')
    require(digest(BINARY.read_bytes()) == BINARY_SHA, 'Unexpected frozen 692 binary')
    source = load(raw)
    require(list(source['modules']) == ['top'], 'Expected module top')
    module = source['modules']['top']
    require(module['attributes']['step'] == 'place', 'Expected placed checkpoint')
    require(not any(k.startswith('FES_LABSTATE') for k in module['attributes']), 'Routed LAB state present')
    routes = [n['attributes']['ROUTING'] for n in module['netnames'].values()
              if 'ROUTING' in n.get('attributes', {})]
    require(all(isinstance(r, str) and not r.strip() for r in routes), 'Physical routing present')
    sites_raw = (ROOT.parent / 'ram-locality-20261022/native-m10k-sites.txt').read_bytes()
    sites = {f'MISTRAL_M10K.{x}.{y}.0' for x, y in
             [tuple(map(int, line.split())) for line in sites_raw.decode().splitlines()]}
    require(len(sites) == 553, 'Native site inventory is incomplete')
    (ROOT / 'native-m10k-sites.txt').write_bytes(sites_raw)
    inventory = load((AUDIT / 'all-ram-inventory.json').read_bytes())
    require(inventory['source_sha256'] == SOURCE_SHA and not inventory['coverage_gaps'], 'Incomplete RAM inventory')
    by_name = {r['cell']: r for r in inventory['rams']}
    ranked = load((AUDIT / 'ranked-candidate-pairs.json').read_bytes())
    fanouts = load((AUDIT / 'all-incident-fanouts.json').read_bytes())['nets']
    occupied = collections.defaultdict(list)
    for name, cell in module['cells'].items():
        occupied[cell['attributes']['NEXTPNR_BEL']].append(name)
    receipts = []
    for label, micro, framebuffer in PAIRS:
        target = ROOT / label
        target.mkdir(exist_ok=True)
        selected = [r for r in ranked['selected_pairs'] if r['microcode'] == micro and r['framebuffer'] == framebuffer]
        require(len(selected) == 1 and selected[0]['passes_geometry_budget_screen'], 'Pair has no passing complete screen')
        old_bels = [module['cells'][n]['attributes']['NEXTPNR_BEL'] for n in (micro, framebuffer)]
        require(len(set(old_bels)) == 2, 'Duplicate source BELs')
        moves = []
        for name, old, new in zip((micro, framebuffer), old_bels, reversed(old_bels)):
            cell = module['cells'][name]
            attrs = cell['attributes']
            require(cell['type'] == 'MISTRAL_M10K', 'Selected cell is not M10K')
            require(list(attrs) == ['BEL_STRENGTH', 'NEXTPNR_BEL', 'FES_PINMAP_V1', 'src', 'module_not_derived'],
                    'Unexpected selected protection/placement attribute')
            require(int(attrs['BEL_STRENGTH'], 2) == 1, 'Selected cell is not weakly placed')
            require(occupied[old] == [name] and len(occupied[new]) == 1, 'Missing/ambiguous reciprocal occupant')
            require(old in sites and new in sites, 'Native M10K site is absent')
            pinmap = load(bytes.fromhex(attrs['FES_PINMAP_V1']))
            require(pinmap['count'] == len(pinmap['pins']), 'Pin count mismatch')
            require(all('.' not in p for entry in pinmap['pins'].values() for p in entry[1:]),
                    'Coordinate-dependent RAM physical pin mapping')
            require(by_name[name]['fully_inventoried_data_pairs'], 'Uninventoried selected RAM')
            moves.append({'cell': name, 'type': cell['type'], 'old_bel': old, 'new_bel': new,
                          'strength': 1, 'destination_original_occupant': occupied[new][0],
                          'pinmap_sha256': digest(bytes.fromhex(attrs['FES_PINMAP_V1'])),
                          'parameters_sha256': digest(json.dumps(cell['parameters'], sort_keys=True).encode()),
                          'clocks': by_name[name]['clocks']})
        substitutions = {f'"NEXTPNR_BEL": "{m["old_bel"]}"'.encode():
                         f'"NEXTPNR_BEL": "{m["new_bel"]}"'.encode() for m in moves}
        require(all(raw.count(t) == 1 for t in substitutions), 'Ambiguous original BEL token')
        pattern = re.compile(b'|'.join(re.escape(t) for t in substitutions))
        candidate, count = pattern.subn(lambda m: substitutions[m[0]], raw)
        require(count == 2, 'Expected exactly two replacements')
        require(pattern.sub(lambda m: substitutions[m[0]], candidate) == raw,
                'Reciprocal inverse does not restore exact source bytes')
        actual = differences(source, load(candidate))
        expected = [{'path': ['modules', 'top', 'cells', m['cell'], 'attributes', 'NEXTPNR_BEL'],
                     'before': m['old_bel'], 'after': m['new_bel']} for m in moves]
        require(sorted(actual, key=lambda d: d['path']) == sorted(expected, key=lambda d: d['path']),
                'Unexpected graph/clock/pinmap/alias/metadata change')
        path = target / 'candidate-placed.json'
        path.write_bytes(candidate)
        incident = {str(bit) for name in (micro, framebuffer) for bits in module['cells'][name]['connections'].values() for bit in bits}
        require(incident <= fanouts.keys(), 'Incomplete selected incident nets')
        dump(target / 'affected-net-fanouts.json', {'nets': {b: fanouts[b] for b in sorted(incident)}, 'net_count': len(incident)})
        dump(target / 'timing-screen.json', selected[0])
        dump(target / 'plan.json', {'kind': 'Independent diagnostic reciprocal two-M10K placement', 'moves': moves})
        proof = {'source_path': str(SOURCE), 'source_sha256': SOURCE_SHA,
                 'candidate_sha256': digest(candidate), 'source_bytes': len(raw), 'candidate_bytes': len(candidate),
                 'changed_bytes': sum(a != b for a, b in zip(raw, candidate)), 'all_differences': actual,
                 'native_device_sites_sha256': digest(sites_raw), 'native_site_count': len(sites),
                 'frozen_compiler_commit': '692a1c372b2b55620ba1fd5e43e0c14ae8ffa4d9',
                 'frozen_compiler_tree': '9b953cd947a89cbf7da9d203b3e07000783a45c2',
                 'frozen_binary_path': str(BINARY), 'frozen_binary_sha256': BINARY_SHA,
                 'proof': {'exact_two_bel_differences': True, 'inverse_restores_exact_original_bytes': True,
                           'all_other_bytes_unchanged': True, 'all_cell_net_alias_order_unchanged': True,
                           'all_logical_graph_pins_parameters_clocks_unchanged': True,
                           'no_occupied_unselected_site_replaced': True, 'no_routed_snapshot': True,
                           'no_native_legality_or_timing_claim_yet': True},
                 'route_attributes_whitespace_only': len(routes), 'incident_net_count': len(incident),
                 'selected_timing_screen_sha256': digest((target / 'timing-screen.json').read_bytes())}
        dump(target / 'preparation-proof.json', proof)
        receipts.append({'label': label, 'input': str(path), 'input_sha256': digest(candidate)})
    dump(ROOT / 'prepared-inputs.json', receipts)
    print(json.dumps(receipts, indent=2))

if __name__ == '__main__':
    main()
