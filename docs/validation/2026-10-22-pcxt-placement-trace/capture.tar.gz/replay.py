from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time

root = Path(__file__).resolve().parent
task = root.parents[2]
repo = Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
old = task/'out/reduction-balanced-20261022'
receipt = json.loads((old/'route-baseline/receipt.json').read_text())
diff = subprocess.check_output(['git','diff','--','common/place/placer_heap.cc'], cwd=repo)
(root/'source.diff').write_bytes(diff)
identity = {'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
            'diff_sha256': hashlib.sha256(diff).hexdigest(),
            'binary_sha256': hashlib.file_digest((root/'nextpnr-mistral').open('rb'),'sha256').hexdigest()}
(root/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')

def run(label, binary, debug):
    command = receipt['nextpnr_command'][:]
    command[0] = str(binary)
    for flag in ['--rbf','--report','--routed-endpoints','--timing-report-paths']:
        at=command.index(flag); del command[at:at+2]
    for flag in ['--compress-rbf','--detailed-timing-report']:
        command.remove(flag)
    command[command.index('--write')+1] = 'placed.json'
    command += ['--no-route']
    if debug: command += ['--debug-placer']
    # --no-route performs CPU placement only. The phase wrapper correctly
    # rejected the initial attempts because they never requested a GPU phase.
    wrapped=command
    directory=root/(label+'-cpu'); directory.mkdir(exist_ok=False)
    start=time.monotonic()
    with (directory/'nextpnr.log').open('w') as log:
        code=subprocess.run(wrapped,cwd=directory,stdout=log,stderr=subprocess.STDOUT).returncode
    result={'command':wrapped,'nextpnr_command':command,'returncode':code,
            'elapsed_seconds':time.monotonic()-start,'route_charge_seconds':0,
            'evidence':'host-only placement diagnostic; no routing or hardware',
            'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()}
    if (directory/'placed.json').exists():
        result['placed_sha256']=hashlib.file_digest((directory/'placed.json').open('rb'),'sha256').hexdigest()
    (directory/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(label,code,result['elapsed_seconds'],flush=True)
    return result

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures=[pool.submit(run,label,binary,debug) for label,binary,debug in [
        ('parent-off',old/'nextpnr-mistral',False), ('parent-debug',old/'nextpnr-mistral',True),
        ('trace-off',root/'nextpnr-mistral',False), ('trace-debug',root/'nextpnr-mistral',True)]]
    results=[f.result() for f in futures]
(root/'cpu-results.json').write_text(json.dumps(results,indent=2)+'\n')
