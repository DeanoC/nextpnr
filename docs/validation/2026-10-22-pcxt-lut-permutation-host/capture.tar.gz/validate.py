#!/usr/bin/env python3
"""Immutable host validation only; no full FPGA route."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,subprocess,sys,time,shutil
HERE=Path(__file__).resolve().parent
ROOT=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');BUILD=ROOT.parent/'build-candidate'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
source=json.loads((HERE/'source-identity.json').read_text())
assert all(sha(ROOT/f)==r['sha256'] for f,r in source['files'].items())
exe=BUILD/'nextpnr-mistral';test=BUILD/'nextpnr-mistral-test'
identity={'source_identity_sha256':sha(HERE/'source-identity.json'),'production_sha256':sha(exe),'native_test_sha256':sha(test),'observed_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()}
(HERE/'build-identity.json').write_text(json.dumps(identity,indent=2,sort_keys=True)+'\n');shutil.copy2(exe,HERE/'nextpnr-mistral')
def run(name,cmd):
 log=HERE/(name+'.log');assert not log.exists();t=time.monotonic()
 with log.open('w') as f:rc=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT).returncode
 r={'name':name,'command':cmd,'cwd':str(ROOT),'returncode':rc,'elapsed_seconds':time.monotonic()-t,'log_sha256':sha(log)}
 (HERE/(name+'.receipt.json')).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r),flush=True);return r
results=[run('permutation-native',[str(test),'--gtest_filter=*RoutedLutPermutation*'])]
if results[0]['returncode']==0:
 with ThreadPoolExecutor(max_workers=2) as pool:
  a=pool.submit(run,'lut6-regression',[str(test),'--gtest_filter=RoutedLut6SourceCoverage.*:RoutedLut6SwapCoverage.*:*RoutedLut6SwapBackend.*:*PrivatePairBackend.CompleteMultiCaptureCoverageRejectsHiddenUnsupportedAndPublicBranches*'])
  b=pool.submit(run,'permutation-cli',[sys.executable,str(ROOT/'mistral/tests/routed_lut_permutation_cli.py'),str(exe),'-v'])
  results.extend([a.result(),b.result()])
 results.append(run('lut6-cli',[sys.executable,str(ROOT/'mistral/tests/routed_lut6_swap_cli.py'),str(exe),'-v']))
unchanged=all(sha(ROOT/f)==r['sha256'] for f,r in source['files'].items()) and sha(exe)==identity['production_sha256'] and sha(test)==identity['native_test_sha256']
r={'build_identity_sha256':sha(HERE/'build-identity.json'),'results':results,'sources_and_binaries_unchanged':unchanged,'pass':unchanged and len(results)==4 and all(x['returncode']==0 for x in results)}
(HERE/'validation.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r),flush=True)
sys.exit(0 if r['pass'] else 1)
