/*
 *  nextpnr -- Next Generation Place and Route
 *
 *  Copyright (C) 2021  Lofty <dan.ravensloft@gmail.com>
 *
 *  Permission to use, copy, modify, and/or distribute this software for any
 *  purpose with or without fee is hereby granted, provided that the above
 *  copyright notice and this permission notice appear in all copies.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */

#ifndef MISTRAL_ARCH_H
#define MISTRAL_ARCH_H

#include <array>
#include <mutex>
#include <set>
#include <unordered_map>
#include <sstream>

#include "base_arch.h"
#include "nextpnr_types.h"
#include "relptr.h"

#include "cyclonev.h"

NEXTPNR_NAMESPACE_BEGIN

struct TimingAnalyser;
struct GpuRouterCfg;

struct ArchArgs
{
    std::string device;
    // --mistral-clkb: model each LAB's second clock (CLKB) and per-pair clock
    // polarity. This adds CLKIN[1]/DATAIN[1] pips into the LAB clock wires, so
    // it must be known when the routing graph is built.
    bool lab_clkb = false;
    // --mistral-dsp-signed-lanes: pack signed MISTRAL_MUL9X9 cells three per
    // DSP block and rely on the block's sign bits alone, instead of the
    // Quartus-equivalent lane-0 sign extension. Hardware-unverified.
    bool dsp_signed_lanes = false;
};

// These structures are used for fast ALM validity checking
struct ALMInfo
{
    // Wires, so bitstream gen can determine connectivity
    std::array<WireId, 2> comb_out;
    std::array<WireId, 2> sel_clk, sel_ena, sel_aclr, sel_ef;
    std::array<WireId, 4> ff_in, ff_out;
    // Pointers to bels
    std::array<BelId, 2> lut_bels;
    std::array<BelId, 4> ff_bels;

    bool l6_mode = false;
    bool carry_mode = false;

    // Which CLK/ENA and ACLR is chosen for each control group. The clock+enable
    // (TCLK_SEL/BCLK_SEL) and async clear (TCLR_SEL/BCLR_SEL) selectors do not
    // follow the ALM halves: group 0 (T*) drives FF0 and FF3, group 1 (B*)
    // drives FF1 and FF2 (Quartus 17.0.2 oracles, mistral/tests/lab_ff4).
    // Data, EF_SEL, PKREG, SCLR_DIS and SLOAD_EN do follow the halves.
    std::array<int, 2> clk_ena_idx{}, aclr_idx{};
    static int ctrl_group(int ff) { return (ff == 0 || ff == 3) ? 0 : 1; }

    // For keeping track of how many inputs are currently being used, for the LAB routeability check
    int unique_input_count = 0;
};

struct LABInfo
{
    // LAB or MLAB?
    bool is_mlab;
    std::array<ALMInfo, 10> alms;
    //  Control set wires
    std::array<WireId, 3> clk_wires, ena_wires;
    std::array<WireId, 2> aclr_wires;
    WireId sclr_wire, sload_wire;
    // TODO: LAB configuration (control set etc)
    std::array<bool, 2> aclr_used{};
};

struct PinInfo
{
    WireId wire;
    PortType dir;
};

struct BelInfo
{
    IdString name;
    IdString type;
    IdString bucket;

    CellInfo *bound = nullptr;

    // For cases where we need to determine an original block index, due to multiple bels at the same tile this
    // might not be the same as the nextpnr z-coordinate
    int block_index;
    dict<IdString, PinInfo> pins;
    // Info for different kinds of bels
    union
    {
        // This enables fast lookup of the associated ALM, etc
        struct
        {
            uint32_t lab; // index into the list of LABs
            uint8_t alm;  // ALM index inside LAB
            uint8_t idx;  // LUT or FF index inside ALM
        } lab_data;
    };
};

// We maintain our own wire data based on mistral's. This gets us the bidirectional linking that nextpnr needs,
// and also makes it easy to add wires and pips for our own purposes like LAB internal routing, global clock
// sources, etc.
struct WireInfo
{
    // name_override is only used for nextpnr-created wires
    // otherwise; this is empty and a name is created according to mistral rules
    IdString name_override;

    // these are transformed on-the-fly to PipId by the iterator, to save space (WireId is half the size of PipId)
    std::vector<WireId> wires_downhill;
    std::vector<WireId> wires_uphill;

    std::vector<BelPin> bel_pins;

    // flags for special wires (currently unused)
    uint64_t flags;

    // if the RESERVED_ROUTE mask is set in flags, then only wires_uphill[flags&0xFF] may drive this wire - used for
    // control set preallocations
    static const uint64_t RESERVED_ROUTE = 0x100;
};

// This transforms a WireIds, and adds the mising half of the pair to create a PipId
using WireVecIterator = std::vector<WireId>::const_iterator;
struct UpDownhillPipIterator
{
    WireVecIterator base;
    WireId other_wire;
    bool is_uphill;

    UpDownhillPipIterator(WireVecIterator base, WireId other_wire, bool is_uphill)
            : base(base), other_wire(other_wire), is_uphill(is_uphill) {};

    bool operator!=(const UpDownhillPipIterator &other) { return base != other.base; }
    UpDownhillPipIterator operator++()
    {
        ++base;
        return *this;
    }
    UpDownhillPipIterator operator++(int)
    {
        UpDownhillPipIterator prior(*this);
        ++(*this);
        return prior;
    }
    PipId operator*() { return is_uphill ? PipId(base->node, other_wire.node) : PipId(other_wire.node, base->node); }
};

struct UpDownhillPipRange
{
    UpDownhillPipIterator b, e;

    UpDownhillPipRange(const std::vector<WireId> &v, WireId other_wire, bool is_uphill)
            : b(v.begin(), other_wire, is_uphill), e(v.end(), other_wire, is_uphill) {};

    UpDownhillPipIterator begin() const { return b; }
    UpDownhillPipIterator end() const { return e; }
};

// This iterates over the list of wires, and for each wire yields its uphill pips, as an efficient way of going over
// all the pips in the device
using WireMapIterator = dict<WireId, WireInfo>::const_iterator;
struct AllPipIterator
{
    WireMapIterator base, end;
    int uphill_idx;

    AllPipIterator(WireMapIterator base, WireMapIterator end, int uphill_idx)
            : base(base), end(end), uphill_idx(uphill_idx) {};

    bool operator!=(const AllPipIterator &other) { return base != other.base || uphill_idx != other.uphill_idx; }
    AllPipIterator operator++()
    {
        // Increment uphill list index by one
        ++uphill_idx;
        // We've reached the end of the current wire. Keep incrementing the wire of interest until we find one with
        // uphill pips, or we reach the end of the list of wires
        while (base != end && uphill_idx >= int(base->second.wires_uphill.size())) {
            uphill_idx = 0;
            ++base;
        }
        return *this;
    }
    AllPipIterator operator++(int)
    {
        AllPipIterator prior(*this);
        ++(*this);
        return prior;
    }
    PipId operator*() { return PipId(base->second.wires_uphill.at(uphill_idx).node, base->first.node); }
};

struct AllPipRange
{
    AllPipIterator b, e;

    AllPipRange(const dict<WireId, WireInfo> &wires) : b(wires.begin(), wires.end(), -1), e(wires.end(), wires.end(), 0)
    {
        // Starting the begin iterator at index -1 and incrementing it ensures we skip over the first wire if it has no
        // uphill pips
        ++b;
    };

    AllPipIterator begin() const { return b; }
    AllPipIterator end() const { return e; }
};

// This transforms a map to a range of keys, used as the wire iterator
template <typename T> struct key_range
{
    key_range(const T &t) : b(t.begin()), e(t.end()) {};
    typename T::const_iterator b, e;

    struct xformed_iterator : public T::const_iterator
    {
        explicit xformed_iterator(typename T::const_iterator base) : T::const_iterator(base) {};
        typename T::key_type operator*() { return this->T::const_iterator::operator*().first; }
    };

    xformed_iterator begin() const { return xformed_iterator(b); }
    xformed_iterator end() const { return xformed_iterator(e); }
};

using AllWireRange = key_range<dict<WireId, WireInfo>>;

struct ArchRanges : BaseArchRanges
{
    using ArchArgsT = ArchArgs;
    // Bels
    using AllBelsRangeT = const std::vector<BelId> &;
    using TileBelsRangeT = std::vector<BelId>;
    using BelPinsRangeT = std::vector<IdString>;
    using CellBelPinRangeT = const std::vector<IdString> &;
    // Wires
    using AllWiresRangeT = AllWireRange;
    using DownhillPipRangeT = UpDownhillPipRange;
    using UphillPipRangeT = UpDownhillPipRange;
    using WireBelPinRangeT = const std::vector<BelPin> &;
    // Pips
    using AllPipsRangeT = AllPipRange;
};

// This enum captures different 'styles' of cell pins
// This is a combination of the modes available for a pin (tied high, low or inverted)
// and the default value to set it to not connected
enum CellPinStyle
{
    PINOPT_NONE = 0x0, // no options, just signal as-is
    PINOPT_LO = 0x1,   // can be tied low
    PINOPT_HI = 0x2,   // can be tied high
    PINOPT_INV = 0x4,  // can be inverted

    PINOPT_LOHI = 0x3,    // can be tied low or high
    PINOPT_LOHIINV = 0x7, // can be tied low or high; or inverted

    PINOPT_MASK = 0x7,

    PINDEF_NONE = 0x00, // leave disconnected
    PINDEF_0 = 0x10,    // connect to 0 if not used
    PINDEF_1 = 0x20,    // connect to 1 if not used

    PINDEF_MASK = 0x30,

    PINGLB_CLK = 0x100, // pin is a 'clock' for global purposes

    PINGLB_MASK = 0x100,

    PINSTYLE_NONE = 0x000, // default

    PINSTYLE_COMB = 0x017, // combinational signal, defaults low, can be inverted and tied
    PINSTYLE_CLK = 0x107,  // CLK type signal, invertible and defaults to disconnected

    PINSTYLE_CE = 0x027,   // CE type signal, invertible and defaults to enabled
    PINSTYLE_RST = 0x017,  // RST type signal, invertible and defaults to not reset
    PINSTYLE_DEDI = 0x000, // dedicated signals, leave alone
    PINSTYLE_INP = 0x010,  // general inputs, no inversion/tieing but defaults low
    PINSTYLE_PU = 0x022,   // signals that float high and default high

    PINSTYLE_CARRY = 0x001, // carry chains can be floating or 0?

};

struct Arch : BaseArch<ArchRanges>
{
    ArchArgs args;
    mistral::CycloneV *cyclonev;

    // Mistral needs the bitstream configuring before it can use the simulator.
    bool bitstream_configured = false;

    Arch(ArchArgs args);
    ArchArgs archArgs() const override { return args; }

    std::string getChipName() const override { return args.device; }
    // -------------------------------------------------

    int getGridDimX() const override { return cyclonev->get_tile_sx(); }
    int getGridDimY() const override { return cyclonev->get_tile_sy(); }
    int getTileBelDimZ(int x, int y) const override; // arch.cc
    char getNameDelimiter() const override { return '.'; }

    // -------------------------------------------------

    BelId getBelByName(IdStringList name) const override; // arch.cc
    IdStringList getBelName(BelId bel) const override;    // arch.cc
    const std::vector<BelId> &getBels() const override { return all_bels; }
    std::vector<BelId> getBelsByTile(int x, int y) const override;
    Loc getBelLocation(BelId bel) const override
    {
        return Loc(bel.pos.x(), bel.pos.y(), bel.z);
    }
    BelId getBelByLocation(Loc loc) const override
    {
        if (loc.x < 0 || loc.x >= cyclonev->get_tile_sx())
            return BelId();
        if (loc.y < 0 || loc.y >= cyclonev->get_tile_sy())
            return BelId();
        auto &bels = bels_by_tile.at(pos2idx(loc.x, loc.y));
        if (loc.z < 0 || loc.z >= int(bels.size()))
            return BelId();
        return BelId(CycloneV::xycoords(loc.x, loc.y), loc.z);
    }
    IdString getBelType(BelId bel) const override; // arch.cc
    WireId getBelPinWire(BelId bel, IdString pin) const override
    {
        auto &pins = bel_data(bel).pins;
        auto found = pins.find(pin);
        if (found == pins.end())
            return WireId();
        else
            return found->second.wire;
    }
    PortType getBelPinType(BelId bel, IdString pin) const override { return bel_data(bel).pins.at(pin).dir; }
    std::vector<IdString> getBelPins(BelId bel) const override;

    bool isBelLocationValid(BelId bel, bool explain_invalid = false) const override;
    void restore_fes_reservations();
    void begin_fes_qsf_reservation_check();
    void finish_fes_qsf_reservation_check();
    bool capture_fes_qsf_reservation(const std::string &kind, const std::string &spec);
    void record_fes_reservation(const std::string &kind, const std::string &spec);
    void note_reserved_bel(const std::string &name);
    void note_reserved_rect(const std::string &spec);
    void note_reserved_rect_group(const std::string &spec);
    bool fes_placement_allowed(BelId bel, const CellInfo *cell, bool explain_invalid = false) const;
    bool fes_cell_is_slot(const CellInfo *cell) const;
    IdString fes_cell_slot_region(const CellInfo *cell) const;
    bool fes_net_touches_slot(const NetInfo *net) const;
    bool fes_pip_in_socket(PipId pip) const;
    bool pipInReservedRegion(PipId pip) const override
    {
        return fes_fence_active && fes_pip_in_socket(pip);
    }
    bool netMayUseReservedRegion(const NetInfo *net) const override
    {
        return !fes_fence_active || !fes_has_reserved_rect || fes_net_touches_slot(net);
    }
    void note_fes_cram_region(const std::string &spec);
    bool fes_pip_preserves_cram(PipId pip) const;
    void fes_trim_net_orphans(NetInfo *net);
    void fes_lock_protected_routing();
    void fes_validate_cram_routing() const;
    void fes_check_boundary_connectivity() const;
    void fes_constrain_slot_region();
    void fes_report_slot_capacity(IdString region_name, const std::vector<CellInfo *> &slot_cells) const;
    bool fes_pip_in_plug_halo(PipId pip) const;
    bool fes_pip_hits_bound_shell_pin(PipId pip) const;
    bool fes_pip_reaches_net_shell_tile(PipId pip, const NetInfo *net) const;
    bool fes_search_pin_narrow(WireId wire, const NetInfo *net, bool forward) const;
    bool fes_slot_pin_narrow(WireId wire, const NetInfo *net, bool forward) const;
    void fes_precompute_narrow_pins();
    bool fes_slot_pins_escape(BelId bel, const CellInfo *cell, bool explain_invalid) const;
    void fes_rip_reserved_shell_pips();
    void lock_fes_scaffold();
    void save_fes_pin_maps(bool save_lab_state = true);
    bool restore_cell_pin_map(CellInfo *cell);
    void restore_placed_pin_maps();
    void merge_fes_cart(const std::string &filename, const std::string &region);
    bool pack_unbound_cells();

    void bindBel(BelId bel, CellInfo *cell, PlaceStrength strength) override
    {
        auto &data = bel_data(bel);
        NPNR_ASSERT(data.bound == nullptr);
        data.bound = cell;
        cell->bel = bel;
        cell->belStrength = strength;
        update_bel(bel);
    }
    void unbindBel(BelId bel) override
    {
        auto &data = bel_data(bel);
        NPNR_ASSERT(data.bound != nullptr);
        data.bound->bel = BelId();
        data.bound->belStrength = STRENGTH_NONE;
        data.bound = nullptr;
        update_bel(bel);
    }
    bool checkBelAvail(BelId bel) const override { return bel_data(bel).bound == nullptr; }
    CellInfo *getBoundBelCell(BelId bel) const override { return bel_data(bel).bound; }
    CellInfo *getConflictingBelCell(BelId bel) const override { return bel_data(bel).bound; }

    void update_bel(BelId bel);
    BelId bel_by_block_idx(int x, int y, IdString type, int block_index) const;

    // -------------------------------------------------

    WireId getWireByName(IdStringList name) const override;
    IdStringList getWireName(WireId wire) const override;
    DelayQuad getWireDelay(WireId wire) const override { return DelayQuad(0); }
    const std::vector<BelPin> &getWireBelPins(WireId wire) const override { return wires.at(wire).bel_pins; }
    AllWireRange getWires() const override { return AllWireRange(wires); }

    bool wires_connected(WireId src, WireId dst) const;
    // Only allow src, and not any other wire, to drive dst
    void reserve_route(WireId src, WireId dst);

    // -------------------------------------------------

    PipId getPipByName(IdStringList name) const override;
    AllPipRange getPips() const override { return AllPipRange(wires); }
    Loc getPipLocation(PipId pip) const override { return Loc(pip.dst.x(), pip.dst.y(), 0); }
    IdStringList getPipName(PipId pip) const override;
    WireId getPipSrcWire(PipId pip) const override { return WireId(pip.src); };
    WireId getPipDstWire(PipId pip) const override { return WireId(pip.dst); };
    UpDownhillPipRange getPipsDownhill(WireId wire) const override
    {
        return UpDownhillPipRange(wires.at(wire).wires_downhill, wire, false);
    }
    UpDownhillPipRange getPipsUphill(WireId wire) const override
    {
        return UpDownhillPipRange(wires.at(wire).wires_uphill, wire, true);
    }

    bool is_pip_blocked(PipId pip) const
    {
        WireId dst(pip.dst);
        const auto &dst_data = wires.at(dst);
        if ((dst_data.flags & WireInfo::RESERVED_ROUTE) != 0) {
            if (WireId(pip.src) != dst_data.wires_uphill.at(dst_data.flags & 0xFF))
                return true;
        }
        return false;
    }

    bool checkPipAvail(PipId pip) const override
    {
        // Check reserved routes
        if (is_pip_blocked(pip))
            return false;
        if (!fes_pip_preserves_cram(pip))
            return false;
        return BaseArch::checkPipAvail(pip);
    }

    // Architecture constraints before the per-pip ownership check.
    const char *pip_rejection_reason(PipId pip, const NetInfo *net) const
    {
        if (is_pip_blocked(pip))
            return "reserved_route_requires_other_source";
        if (WireId(pip.src).is_nextpnr_created() && pll_private_pips.count(pip) &&
            !(net && net->driver.cell && net->driver.cell->type == id_altera_pll))
            return "pll_private_output_requires_pll_driver";
        if (WireId(pip.dst).is_nextpnr_created() && pll_private_ref_pips.count(pip) && !net_feeds_pll(net))
            return "pll_private_reference_requires_pll_sink";
        if (!fes_pip_preserves_cram(pip))
            return "fes_scaffold_cram_preservation";
        if (fes_fence_active && fes_has_reserved_rect && net != nullptr) {
            const bool slot_driven = fes_cell_is_slot(net->driver.cell);
            const bool slot_user = fes_net_touches_slot(net);
            const bool in_socket = fes_pip_in_socket(pip);
            // Same pip bit as pipOutsideNetHalo. The shell-tile exception is
            // fes_pip_reaches_net_shell_tile minus the bound-shell-pin case,
            // which the search receives as netHaloShellTiles.
            if (slot_driven && !fes_pip_in_plug_halo(pip) && !fes_pip_reaches_net_shell_tile(pip, net))
                return "fes_slot_route_outside_plug_halo_and_shell";
            if (!slot_user && in_socket && BaseArch::checkPipAvail(pip))
                return "fes_non_slot_route_enters_socket";
        }
        return nullptr;
    }

    bool pip_allowed_for_net(PipId pip, const NetInfo *net) const
    {
        return pip_rejection_reason(pip, net) == nullptr;
    }

    // Search fence for fes_slot_route_outside_plug_halo_and_shell. The pip
    // bit excludes the per-net shell tile; netHaloShellTiles carries that.
    bool pipOutsideNetHalo(PipId pip) const override
    {
        if (!fes_fence_active || !fes_has_reserved_rect)
            return false;
        return !fes_pip_in_plug_halo(pip) && !fes_pip_hits_bound_shell_pin(pip);
    }
    bool netConstrainedToHalo(const NetInfo *net) const override
    {
        return fes_fence_active && fes_has_reserved_rect && net != nullptr &&
               fes_cell_is_slot(net->driver.cell);
    }

    bool checkPipAvailForNet(PipId pip, const NetInfo *net) const override
    {
        return pip_allowed_for_net(pip, net) && BaseArch::checkPipAvailForNet(pip, net);
    }

    void netHaloShellTiles(const NetInfo *net, std::vector<std::pair<int, int>> &tiles) const override;

    // -------------------------------------------------

    delay_t estimateDelay(WireId src, WireId dst) const override;
    delay_t predictDelay(BelId src_bel, IdString src_pin, BelId dst_bel, IdString dst_pin) const override;
    delay_t getDelayEpsilon() const override { return 10; };
    delay_t getRipupDelayPenalty() const override { return 100; };
    float getDelayNS(delay_t v) const override { return float(v) / 1000.0f; };
    delay_t getDelayFromNS(float ns) const override { return delay_t(ns * 1000.0f); };
    uint32_t getDelayChecksum(delay_t v) const override { return v; };

    BoundingBox getRouteBoundingBox(WireId src, WireId dst) const override;

    TimingPortClass getPortTimingClass(const CellInfo *cell, IdString port,
                                       int &clockInfoCount) const override;                                // delay.cc
    TimingClockingInfo getPortClockingInfo(const CellInfo *cell, IdString port, int index) const override; // delay.cc
    std::vector<RegisteredIoTiming> getRegisteredIoTiming(const CellInfo *cell, IdString pad, bool input) const override;
    std::vector<PrimitiveClockRequirement> getPrimitiveClockRequirements(const CellInfo *cell) const override;
    std::optional<UnregisteredIoTiming> getUnregisteredIoTiming(const CellInfo *cell, IdString port) const override;
    std::optional<DelayQuad> getForwardedClockPadTiming(const CellInfo *cell) const;
    std::optional<std::pair<delay_t, delay_t>> getInvertedClockPulseLoss(const CellInfo *cell, double load_pf) const;
    bool getCellDelay(const CellInfo *cell, IdString fromPort, IdString toPort,
                      DelayQuad &delay) const override;                                                      // delay.cc
    bool get_lut_pin_delay(IdString physical, bool l6, DelayQuad &delay) const; // delay.cc
    // Native LUT input wires end before the block-input mux. Charge that
    // final stage on the cell side of the existing timing boundary.
    DelayQuad get_lut_input_delay(const CellInfo *cell, IdString port) const;
    DelayQuad getPipDelay(PipId pip) const override;                                                         // delay.cc
    // The per-type table the routers use until analogue_repair() calibrates it.
    DelayQuad getPipDelayTable(PipId pip) const;
    DelayQuad getPipDelayCalibrated(PipId pip, const DelayQuad &table) const; // analogue.cc
    bool getArcDelayOverride(const NetInfo *net_info, const PortRef &sink, DelayQuad &delay) const override; // delay.cc
    // Observation records contain completed hops only, including valid zero delays.
    struct AnalogueHop
    {
        PipId pip;
        delay_t table, rise, fall;
    };
    // Full analogue arc, including a native LUT's terminal input stage.
    // The optional stage result lets STA retain the graph's GOUT boundary;
    // hop observations contain real routing pips only.
    bool analogue_arc_delay(const NetInfo *net_info, const PortRef &sink, DelayQuad &delay,
                            std::vector<AnalogueHop> *hops, DelayQuad *lut_input_delay = nullptr) const;
    void dump_analogue_arcs(const std::string &path) const;

    // Analogue signoff repair after the GPU router (analogue.cc)
    struct TypeCalibration
    {
        double table_ps = 0, analogue_ps = 0;
        int64_t hops = 0;
    };
    bool pip_delay_calibrated = false;
    // Set when a bitstream is requested, so build_bitstream() will run the
    // analogue signoff after routing and that is the timing gate. Without
    // it the router's own table-model check has to stay the gate.
    bool signoff_after_route = false;
    float pip_delay_prior = 1.0f;
    dict<PipId, delay_t> pip_delay_observed;
    std::array<TypeCalibration, 256> pip_type_calibration;
    // Analogue delay of every routed arc, computed in parallel once the
    // bitstream is configured; observe also records per-pip delays.
    struct AnalogueArc
    {
        DelayQuad delay;
        bool ok;
        // Already included in delay. getCellDelay charges it on the cell
        // side, so getArcDelayOverride subtracts it from the routing term.
        DelayQuad lut_input_delay;
    };
    std::unordered_map<const PortRef *, AnalogueArc> analogue_arc_cache;
    bool analogue_cache_valid = false;
    void compute_analogue_arcs(bool observe);
    bool analogue_repair();
    int critical_route_budget = 0; // CLI-only, full native timing trials after ordinary routing.
    void repair_critical_routes();
    int critical_lut6_swap_budget = 0; // Explicit CLI only; symmetric post-route input swaps.
    void repair_critical_lut6_swaps();
    int critical_private_pair_budget = 0; // Explicit CLI only; bounded live two-LUT decomposition.
    void repair_critical_private_pairs();
    int critical_lut_permute_budget = 0; // Explicit CLI only; fixed-BEL ALUT2..5 transpositions.
    void repair_critical_lut_permutations();
    int critical_move_route_budget = 0; // CLI-only, bounded post-route LUT moves.
    void repair_critical_moves();
    void refresh_post_route_repair_checkpoint();
    // Analogue-scored route selection: several GPU candidate routes per sink
    // with less than `limit` slack, evaluated with the analogue model, best
    // one kept. To repair, a net scores by its worst sink slack; to improve
    // a passing design, by its worst sink margin over that sink's clock
    // pairs (TimingAnalyser::get_setup_slack_margin).
    bool analogue_candidate_pass(TimingAnalyser &tmg, float limit, bool improve, const GpuRouterCfg &repair_cfg);
    // Keep the analogue simulator's routing-mux state in step with a net
    // whose routing changed: removed pips are parked on an unused input,
    // added pips linked.
    void analogue_relink(const std::vector<PipId> &removed, const std::vector<PipId> &added);
    void configure_bitstream(bool observe = false); // bitstream.cc

    // -------------------------------------------------

    const std::vector<IdString> &getBelPinsForCellPin(const CellInfo *cell_info, IdString pin) const override
    {
        return cell_info->pin_data.at(pin).bel_pins;
    }

    bool isValidBelForCellType(IdString cell_type, BelId bel) const override;
    BelBucketId getBelBucketForCellType(IdString cell_type) const override;
    BelBucketId getBelBucketForBel(BelId bel) const override;

    void assignArchInfo() override;
    bool pack() override;
    bool place() override;
    int enable_replication_budget = 0; // Explicit opt-in; never inherited from JSON settings.
    int critical_cohort_budget = 0; // CLI only; number of complete placement STA trials.
    std::string critical_cohort_report; // CLI only; optional prior routed timing guidance.
    void replicate_enables(int budget);
    std::string local_remap_report; // CLI only, never read from serialized settings.
    int local_remap_selection = -1;
    int local_remap_groups = 1;
    bool local_remap_optimize_pins = false;
    bool local_remap_preserve_ff_placement = false;
    bool remap_critical(const std::string &report, int selection, int group_budget = 1);
    static constexpr size_t local_remap_max_steps = 16;
    struct LocalRemapStep {
        std::string report;
        int candidate = -1;
        int groups = 1;
        bool optimize_pins = false;
        bool preserve_ff_placement = false;
    };
    std::vector<LocalRemapStep> local_remap_plan; // Explicit CLI state, never serialized settings.
    bool local_remap_plan_list_only = false;
    std::vector<LocalRemapStep> local_remap_post_plan; // After reductions/decomposition, before driver copies.
    bool local_remap_post_plan_list_only = false;
    void prevalidate_local_remap_plans();
    bool execute_local_remap_plan(bool post = false);
    std::string comb_remap_report; // Explicit CLI experiment, never a serialized setting.
    int comb_remap_selection = -1;
    bool remap_comb_critical(const std::string &report, int selection);
    struct CombRemapStep {
        std::string report;
        int candidate = -1;
    };
    std::vector<CombRemapStep> comb_remap_plan; // CLI only, never serialized settings.
    bool comb_remap_plan_list_only = false;
    bool execute_comb_remap_plan();
    std::string decomposition_remap_report; // Explicit CLI only; never a serialized setting.
    int decomposition_remap_selection = -1;
    bool remap_decomposed_critical(const std::string &report, int selection);
    std::string private_pair_report; // Explicit CLI only; never a serialized setting.
    int private_pair_selection = -1;
    bool remap_private_pair_critical(const std::string &report, int selection);
    std::string lut_pair_report; // Explicit CLI only; never a serialized setting.
    int lut_pair_selection = -1;
    bool lut_pair_compose_copy = false; // Explicit CLI only; default relocation remains unchanged.
    bool remap_lut_pair_critical(const std::string &report, int selection);
    bool remap_lut_pair_copy_critical(const std::string &report, int selection);
    std::string lut_driver_copy_report; // Explicit CLI only; never a serialized setting.
    int lut_driver_copy_selection = -1;
    bool remap_lut_driver_critical(const std::string &report, int selection);
    std::string capture_pipeline_report; // Experimental request bytes, never serialized settings.
    int capture_pipeline_budget = 0;
    int capture_pipeline_radius = 24;
    bool balance_reduction(const std::string &root_name);
    bool route() override;

    // -------------------------------------------------
    // Functions for device setup

    BelId add_bel(int x, int y, IdString name, IdString type);
    WireId add_wire(int x, int y, IdString name, uint64_t flags = 0);
    PipId add_pip(WireId src, WireId dst);

    void add_bel_pin(BelId bel, IdString pin, PortType dir, WireId wire);

    CycloneV::rnode_coords find_rnode(CycloneV::block_type_t bt, int x, int y, CycloneV::port_type_t port, int bi = -1,
                                 int pi = -1) const;
    WireId get_port(CycloneV::block_type_t bt, int x, int y, int bi, CycloneV::port_type_t port, int pi = -1) const;
    bool has_port(CycloneV::block_type_t bt, int x, int y, int bi, CycloneV::port_type_t port, int pi = -1) const;

    void create_lab(int x, int y, bool is_mlab);       // lab.cc
    void create_m10k(int x, int y);                    // m10k.cc
    // Whether an M10K's A or B output half (DATAAOUT / DATABOUT) reads through
    // its output register, as the bitstream programs A/B_OUTPUT_SEL.
    bool m10k_output_registered(const CellInfo *cell, bool a_half) const; // m10k.cc
    void create_dsp(int x, int y);                     // dsp.cc
    void create_plls();                               // globals.cc
    dict<PipId, int> pll_ref_select, pll_clock_select;
    dict<BelId, std::array<std::vector<BelId>, 9>> pll_clock_bels; // per FPLL counter C0..C8
    WireId pll_output_wire(const CellInfo *pll, IdString port) const; // mapped counter wire
    // Edges added after the original ones are hidden from nets that cannot
    // use them: counter edges from nets not driven by a PLL, reference edges
    // from nets without a PLL sink.
    pool<PipId> pll_private_pips, pll_private_ref_pips;
    static bool net_feeds_pll(const NetInfo *net)
    {
        if (net == nullptr)
            return false;
        for (auto &user : net->users)
            if (user.cell && user.cell->type == id_altera_pll)
                return true;
        return false;
    }
    void create_gpio(int x, int y);                    // io.cc
    void create_clkbuf(int x, int y);                  // globals.cc
    void create_control(int x, int y);                 // globals.cc
    void create_hps_mpu_general_purpose(int x, int y); // globals.cc
    void create_hps_peripheral_i2c(int x, int y);      // globals.cc
    void create_hps_fpga2sdram(int x, int y);          // globals.cc

    // -------------------------------------------------

    // --mistral-ff4: also place flip-flops on the secondary registers (FF1/FF3)
    // of each ALM. Off by default; set from the command line only.
    bool lab_ff4 = false;
    bool isolated_lut_placement = false; // Opt-in: score earlier L5 inputs on the isolated legal LUT pins.
    bool arrival_pin_assignment = false; // Opt-in: permute private LUT pins by arrival after legalisation.

    bool is_comb_cell(IdString cell_type) const;        // lab.cc
    bool is_alm_legal(uint32_t lab, uint8_t alm) const; // lab.cc
    bool ff4_has_sync_load(const FFControlSet &ctrlset) const;                                          // lab.cc
    bool ff4_lut_feeds_only(const CellInfo *lut, const CellInfo *ff_a, const CellInfo *ff_b) const; // lab.cc
    bool is_lab_ctrlset_legal(uint32_t lab) const;      // lab.cc
    bool lab_pair_model(uint32_t lab) const;            // lab.cc
    bool check_lab_input_count(uint32_t lab) const;     // lab.cc
    bool check_mlab_groups(uint32_t lab) const;         // lab.cc

    void assign_comb_info(CellInfo *cell) const; // lab.cc
    void assign_ff_info(CellInfo *cell) const;   // lab.cc

    void lab_pre_route();                                   // lab.cc
    void assign_control_sets(uint32_t lab);                 // lab.cc
    int park_open_aclr(uint32_t lab);                          // lab.cc
    void reassign_alm_inputs(uint32_t lab, uint8_t alm);    // lab.cc
    int optimise_private_lut_pins(uint32_t lab, uint8_t alm, int half, const dict<IdString, delay_t> &arrival);
    CellInfo *get_alm_route_through_ff(uint32_t lab, uint8_t alm, uint8_t half) const; // lab.cc
    // F, or E when the other half's direct-data flip-flop needs this F.
    IdString alm_route_through_pin(uint32_t lab, uint8_t alm, uint8_t half) const; // lab.cc
    void assign_alm_lut_inputs(uint32_t lab, uint8_t alm); // LUT pins only; no netlist mutation.
    void update_alm_input_count(uint32_t lab, uint8_t alm); // lab.cc

    uint64_t compute_lut_mask(uint32_t lab, uint8_t alm);  // lab.cc
    uint64_t compute_mlab_mask(uint32_t lab, uint8_t alm); // lab.cc

    // Keeping track of unique MLAB write ports to assign them indices
    dict<IdString, IdString> get_mlab_key(const CellInfo *cell, bool include_raddr = false) const; // lab.cc
    mutable idict<dict<IdString, IdString>> mlab_groups;

    // -------------------------------------------------

    bool is_io_cell(IdString cell_type) const;                   // io.cc
    BelId get_io_pin_bel(const CycloneV::pin_info_t *pin) const; // io.cc

    // Per-pin electrical options from Quartus instance assignments (IO_STANDARD,
    // CURRENT_STRENGTH_NEW, SLEW_RATE, WEAK_PULL_UP_RESISTOR, bus hold, clamp
    // diode and the D1/D3/D5/D5_OE delay chains), checked against Quartus
    // 17.0.2 decodes for the 3.3 V banks. Unset delays are -1.
    struct IoElectrical
    {
        bool lvcmos = false;
        CycloneV::bmux_type_t drive_strength = CycloneV::V3P3_LVTTL_16MA_LVCMOS_2MA;
        bool slow_slew = false;
        bool weak_pullup = false;
        bool bus_hold = false;
        bool clamp_diode = false;
        int d1_delay = -1, d3_delay = -1, d5_delay = -1, d5_oe_delay = -1;
    };
    IoElectrical get_io_electrical(const CellInfo *cell) const; // io.cc
    void check_io_electrical() const;                           // io.cc

    // -------------------------------------------------

    bool is_clkbuf_cell(IdString cell_type) const; // globals.cc
    void route_globals();                          // globals.cc

    // -------------------------------------------------

    static const std::string defaultPlacer;
    static const std::vector<std::string> availablePlacers;
    static const std::string defaultRouter;
    static const std::vector<std::string> availableRouters;

    dict<WireId, WireInfo> wires;

    // List of LABs
    std::vector<LABInfo> labs;

    // WIP to link without failure
    std::vector<BelPin> empty_belpin_list;

    // Conversion between numbers and rnode types and IdString, for fast wire name implementation
    std::vector<IdString> int2id;
    dict<IdString, int> id2int;

    std::vector<IdString> rn_t2id;
    dict<IdString, CycloneV::rnode_type_t> id2rn_t;

    // This structure is only used for nextpnr-created wires
    dict<IdStringList, WireId> npnr_wirebyname;

    std::vector<std::vector<BelInfo>> bels_by_tile;
    std::vector<BelId> all_bels;

    size_t pos2idx(int x, int y) const
    {
        NPNR_ASSERT(x >= 0 && x < int(cyclonev->get_tile_sx()));
        NPNR_ASSERT(y >= 0 && y < int(cyclonev->get_tile_sy()));
        return y * cyclonev->get_tile_sx() + x;
    }

    size_t pos2idx(CycloneV::xycoords pos) const { return pos2idx(pos.x(), pos.y()); }

    BelInfo &bel_data(BelId bel) { return bels_by_tile.at(pos2idx(bel.pos)).at(bel.z); }
    const BelInfo &bel_data(BelId bel) const { return bels_by_tile.at(pos2idx(bel.pos)).at(bel.z); }

    // -------------------------------------------------

    void assign_default_pinmap(CellInfo *cell);
    static const dict<IdString, IdString> comb_pinmap;
    IdString lut_placement_pin(const CellInfo *cell, IdString port) const;

    // -------------------------------------------------

    typedef dict<IdString, CellPinStyle> CellPinsData;                          // pins.cc
    static const dict<IdString, CellPinsData> cell_pins_db;                     // pins.cc
    CellPinStyle get_cell_pin_style(const CellInfo *cell, IdString port) const; // pins.cc

    // -------------------------------------------------

    // List of IO constraints, used by QSF parser
    dict<IdString, dict<IdString, Property>> io_attr;
    // Instance assignments whose -to target uses Quartus '*' or '?'
    // wildcards, in file order. Applied to matching top-level ports before
    // bus-wide and exact assignments, so the most specific one wins.
    struct IoAttrPattern
    {
        std::string target;
        IdString name;
        Property value;
    };
    std::vector<IoAttrPattern> io_attr_patterns;
    void read_qsf(std::istream &in);                       // qsf.cc
    void apply_io_attrs(IdString port, CellInfo *cell);    // qsf.cc

    // PLACE_REGION instance assignments ("X<x0> Y<y0> X<x1> Y<y1>", grid
    // coordinates, inclusive), in file order. place() constrains each
    // matching cell to its most specific assignment's rectangle before
    // placement and checks every such cell is still inside it afterwards.
    struct PlaceRegionAssignment
    {
        std::string target;
        int x0, y0, x1, y1;
    };
    std::vector<PlaceRegionAssignment> place_region_assignments;
    pool<IdString> place_region_names;
    void note_place_region(const std::string &target, const std::string &value); // qsf.cc
    void restore_place_regions(bool qsf_supplied);                               // qsf.cc
    void apply_place_regions();                                                  // qsf.cc
    void check_place_regions() const;                                            // qsf.cc

    // Static expansion slot(s): HeAP may not place unconstrained cells on
    // these BELs. Explicit BEL cells, FES_SLOT cells tagged for the owning
    // region and cells locked by the scaffold reload at their original BEL
    // may use them. A slot cell may not leave its own reserved region, and
    // reserved regions may not overlap each other (note_reserved_rect fails
    // closed on overlap). Each declared FES_RESERVED_RECT carries a name
    // (default "cart" when the QSF spec omits one, for single-socket cores);
    // a cart merged with merge_fes_cart() is tagged with the region its
    // cells must legalise into.
    struct FesReservedRect
    {
        std::string name;
        int x0, y0, x1, y1;
    };
    std::vector<std::pair<std::string, std::string>> fes_reservation_declarations;
    std::vector<std::pair<std::string, std::string>> fes_qsf_reservation_declarations;
    bool fes_restoring_reservations = false;
    bool fes_restored_reservations = false;
    bool fes_checking_qsf_reservations = false;
    std::vector<FesReservedRect> fes_reserved_rects;
    dict<BelId, IdString> fes_bel_region;
    dict<IdString, std::set<BelId>> fes_region_bels;
    // Every region name ever declared (plain FES_RESERVED_RECT or
    // FES_RESERVED_RECT_GROUP), kept even after a region is absorbed into a
    // group so a stale reference gets a precise error instead of "unknown".
    std::set<IdString> fes_declared_region_names;
    // Sub-region name -> the group region name it was folded into. A big
    // card can claim several small declared regions at once via
    // FES_RESERVED_RECT_GROUP; the absorbed names stay blocked (fail closed
    // if targeted directly), mirroring a large expansion card physically
    // covering its smaller neighbours' backplane slots.
    dict<IdString, IdString> fes_region_absorbed_by;
    // Region merge_fes_cart() most recently tagged cells with; pack_unbound_cells()
    // reads this so synthetic per-cart cells (local constant drivers) join the
    // same region as the cart that needs them.
    std::string fes_active_cart_region = "cart";
    std::unordered_map<const CellInfo *, BelId> fes_frozen_cells;
    // fes_slot_pin_narrow by ((wire, net or net class), forward | class << 1).
    // Frozen scaffold routing and the fences do not change once the scaffold
    // is locked.
    mutable std::mutex fes_narrow_mutex;
    mutable dict<std::pair<std::pair<WireId, IdString>, int>, bool> fes_narrow_cache;
    bool fes_has_reserved_rect = false;
    bool fes_any_slot_region_active = false;
    bool fes_fence_active = false;
    bool fes_has_cram_region = false;
    std::array<int, 4> fes_cram_region = {};
    pool<PipId> fes_frozen_pips;
    pool<CycloneV::rnode_coords> fes_cram_allowed_muxes;
    // Outside-region frozen muxes and the connected upstream paths needed
    // to keep them driven. Each entry records the original pip and net owner.
    dict<WireId, std::pair<PipId, IdString>> fes_protected_routing;

    // -------------------------------------------------

    // Control block atoms (chip ID, CRC, user JTAG, ...) and the device-wide
    // options of QSF global assignments (ctrl.cc).
    void create_control_atoms(int x, int y);
    bool apply_control_option(const std::string &name, const std::string &value);
    std::string control_option(const std::string &name) const;
    void pack_control_atoms();
    void check_control_options() const;
    void write_control_bitstream();
    dict<std::string, std::string> control_options;

    // -------------------------------------------------

    void build_bitstream(); // bitstream.cc
};

// Experimental request preload; the live placement is validated by the worker.
void preload_capture_pipeline_locality(Context *, const char *);

NEXTPNR_NAMESPACE_END

#endif
