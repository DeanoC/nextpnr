from pathlib import Path
import hashlib,json,shutil,subprocess
HERE=Path(__file__).resolve().parent;ROOT=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
files=['mistral/'+p for p in ('routed_lut_permutation.cc','routed_lut_permutation_policy.h','routed_lut6_swap.cc','analogue_repair.h','arch.h','main.cc','routed_move.cc','CMakeLists.txt','tests/routed_lut_permutation_backend.cc','tests/routed_lut_permutation_cli.py')]+['docs/mistral-routed-lut-permutation.md']
result={'base':'243c829c','observed_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'files':{}}
for name in files:
 p=ROOT/name;data=p.read_bytes();dest=HERE/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 result['files'][name]={'sha256':hashlib.sha256(data).hexdigest(),'size':len(data)}
(HERE/'source-identity.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(HERE/'source.patch').write_bytes(subprocess.check_output(['git','diff','--',*files],cwd=ROOT))
print(hashlib.sha256((HERE/'source-identity.json').read_bytes()).hexdigest())
