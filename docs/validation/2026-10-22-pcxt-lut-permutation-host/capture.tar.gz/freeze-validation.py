#!/usr/bin/env python3
"""Consolidate completed host gates; never launch or qualify an FPGA route."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
R=Path(__file__).resolve().parent;F=R/'final-host';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');OLD=R.parent/'lut6-source-coverage-20261022'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
initial=read(R/'source-identity.json');source=read(F/'source-identity.json');build=read(F/'build-identity.json');old=read(OLD/'final-validation.json')
assert sha(OLD/'final-validation.json')=='8d58d9bbae8c3c4026c2a3ca92c7021e1ef45dbac3b394bf91f2d8bcbb67663d'
assert sha(F/'source-identity.json')==build['source_identity_sha256']
assert sha(R/'nextpnr-mistral')==build['production_sha256']==read(R/'build-identity.json')['production_sha256']
assert set(source['files'])==set(initial['files'])
changed=[p for p in source['files'] if source['files'][p]['sha256']!=initial['files'][p]['sha256']]
assert changed==['mistral/tests/routed_lut_permutation_backend.cc'],changed
assert source['files'][changed[0]]['sha256']=='600a187a7adb5b8e643e941a03c13c4e36ac85cdd7881ab68480666ea3965603'
sources=dict(old['source_files']);sources.update({p:v['sha256'] for p,v in source['files'].items()})
unchanged={p:h for p,h in old['source_files'].items() if p not in source['files']}
for p,h in sources.items():
 assert sha(S/p)==h,(p,'live source differs')
 dest=R/'complete-source'/p;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==h
 else:shutil.copy2(S/p,dest)
for p,h in unchanged.items():
 assert hashlib.sha256(subprocess.check_output(['git','show','243c829c07de92a610ddb9811cf69abff1987a0a:'+p],cwd=S)).hexdigest()==h
write(R/'retained-source-proof.json',{'earlier_commit':'243c829c07de92a610ddb9811cf69abff1987a0a','earlier_final_validation_sha256':sha(OLD/'final-validation.json'),
 'unchanged_source_files':unchanged,'scope':'Earlier cache8/private77 and board source admission remain at their earlier provenance; only expressly logged suites reran on this binary.'})
summary=read(F/'validation.json');assert summary['pass'] and summary['sources_and_binaries_unchanged']
assert summary['build_identity_sha256']==sha(F/'build-identity.json')
counts={'permutation-native':45,'lut6-regression':39,'permutation-cli':6,'lut6-cli':6}
assert set(x['name'] for x in summary['results'])==set(counts)
for name,count in counts.items():
 rec=read(F/(name+'.receipt.json'));log=F/(name+'.log');assert rec['returncode']==0 and sha(log)==rec['log_sha256']
 text=log.read_text()
 if name.endswith('-cli'):assert re.search(r'Ran '+str(count)+r' tests? in',text) and re.search(r'\nOK\s*$',text)
 else:assert re.search(r'\[\s+PASSED\s+\]\s+'+str(count)+r' tests?\.',text)
initial_summary=read(R/'validation.json');assert initial_summary['pass'] is False and initial_summary['sources_and_binaries_unchanged']
irec=read(R/'permutation-native.receipt.json');itext=(R/'permutation-native.log').read_text();assert irec['returncode']!=0 and sha(R/'permutation-native.log')==irec['log_sha256']
assert '[  PASSED  ] 37 tests.' in itext and '[  FAILED  ] 8 tests' in itext
control=read(R/'control-proof.json');assert control['default_zero_raw_bytes_equal']
assert sorted(x['case'] for x in control['controls'])==['default','zero']
for x in control['controls']:
 assert all(x[k] for k in ('complete_modules_equal','all_bytes_except_creator_equal','predicted_timing_bytes_equal'))
 folder=R/('prepare-'+x['case']);receipt=read(folder/'receipt.json');assert receipt['returncode']==0 and receipt['binary_sha256']==build['production_sha256']
 for p,h in receipt['artifacts'].items():assert sha(folder/p)==h
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
# The unchanged guard conservatively excludes the intended CGA target; retain
# that actual-board scope boundary separately from the passing generic host gates.
audit=read(R.parent/'cga-frontier-audit-20261022/analysis.json')
assert len(audit['empty_output_bits'])==6 and audit['native_structural_probe']['complete_capture_identity_match']
files={}
for prefix in ('source','final-host','complete-source','prepare-default','prepare-zero'):
 for p in sorted((R/prefix).rglob('*')):
  if p.is_file() and p.name not in ('nextpnr-mistral','nextpnr-mistral-test'):
   files[str(p.relative_to(R))]=sha(p)
for name in ('freeze-source.py','source-identity.json','source.patch','build-identity.json','build.receipt.json','build.log','validate.py','validation.json','validation-run.log','permutation-native.receipt.json','permutation-native.log','prepare-controls.py','prepare-controls.log','control-proof.json','retained-source-proof.json','freeze-validation.py','independent-source-review.json','independent-oracle-correction-review.json'):
 p=R/name
 if p.exists():files[name]=sha(p)
final={'scope':'Host-only native transaction, complete source/capture coverage and disabled-behavior validation; no new routed timing or hardware acceptance',
 'binary_sha256':build['production_sha256'],'native_test_sha256':build['native_test_sha256'],'source_parent':source['base'],'source_files':sources,
 'control_proof_sha256':sha(R/'control-proof.json'),'enabled_lut_permutation_route_admission':False,
 'enabled_lut_permutation_route_admission_reason':'Generic host gates passed, but unchanged complete-output guard excludes intended CGA target because its stationary inputC fanout reaches six explicitly unused local arithmetic outputs. No guard changed or actual-board eligibility asserted.',
 'validation':{'passed':True,'lut_permutation_native_count':45,'lut6_native_count':33,'source_coverage_count':6,'lut_permutation_cli_count':6,'lut6_cli_count':6},
 'retained_prior_validation':{'path':str(OLD/'final-validation.json'),'sha256':sha(OLD/'final-validation.json'),'unchanged_source_proof_sha256':sha(R/'retained-source-proof.json'),'rerun_claim':'Only final-host logged45+39+6+6 suites rerun; older private77/cache8 retain original972 provenance.'},
 'independent_correction_review_sha256':sha(R/'independent-oracle-correction-review.json'),
 'initial_failure':{'validation_sha256':sha(R/'validation.json'),'test_sha256':read(R/'build-identity.json')['native_test_sha256'],'passed':37,'failed':8,'reason':'Two raw-net-to-physical oracle equations double-applied PIN_INV; test-only correction uses native physical=!raw. Production unchanged.'},
 'actual_board_scope':{'intended_target_eligible':False,'audit_path':str(R.parent/'cga-frontier-audit-20261022/analysis.json'),'audit_sha256':sha(R.parent/'cga-frontier-audit-20261022/analysis.json')},'files':files}
assert not (R/'final-validation.json').exists()
write(R/'final-validation.json',final);print(sha(R/'final-validation.json'))
