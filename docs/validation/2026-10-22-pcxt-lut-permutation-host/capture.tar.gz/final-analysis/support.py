from pathlib import Path
import hashlib,json,math
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
def need(value,message):
    if not value:raise ValueError(message)
def unique(pairs):
    out={}
    for key,value in pairs:need(key not in out,'duplicate JSON key '+key);out[key]=value
    return out
def read(path):
    def invalid(value):raise ValueError('nonfinite number '+value)
    return json.loads(Path(path).read_text(),object_pairs_hook=unique,parse_constant=invalid)
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(name,value):(HERE/name).write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
def mode():return read(ROOT/'archive-mode.json') if (ROOT/'archive-mode.json').exists() else None
def recorded(path,digest):
    m=mode()
    if m:
        need(str(path) in m['recorded_files'],'unmapped original identity '+str(path));v=m['recorded_files'][str(path)]
        need(v['sha256']==digest,'recorded expected hash differs');r=Path(v['retained_path']);need(not r.is_absolute() and '..' not in r.parts,'unsafe mapping');path=ROOT/r
    need(sha(path)==digest,'recorded bytes differ '+str(path));return Path(path)
def cpu_root():return ROOT/'dependency/frontier/dependency/cpu' if mode() else ROOT.parent/'lut6-source-coverage-20261022'
