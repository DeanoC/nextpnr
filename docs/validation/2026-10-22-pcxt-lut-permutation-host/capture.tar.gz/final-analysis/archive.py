#!/usr/bin/env python3
"""Immutable host-only permutation baseline with exact dependency captures."""
import gzip,hashlib,io,json,os,shutil,subprocess,sys,tarfile,tempfile
from pathlib import Path
from support import ROOT,HERE,need,read,sha
CAPTURE=HERE/'capture';SOURCE=CAPTURE/'source'
DEP_DIRS={'frontier':ROOT.parent/'routed-private-pair-board-20261022/final-analysis/capture','cpu':ROOT.parent/'lut6-source-coverage-20261022/final-analysis/capture'}
EXPECTED={'frontier':'4c82c3d307ad1148abc7dfffdd1d1c0efac58dcb93b419cfac3f9fb02cafba91','cpu':'2b2240ddd347411dc22a695cb5db0e53544b873e75183acf299ebc230101c8f1'}
def main():
    need(not CAPTURE.exists(),'capture exists; never overwrite immutable evidence');need(read(HERE/'host-proof.json')['status']=='pass','host proof missing')
    final=read(ROOT/'final-validation.json');need(final['enabled_lut_permutation_route_admission'] is False,'host baseline admission differs')
    dependencies={}
    for name,folder in DEP_DIRS.items():
        report=read(folder/'offline-readback.json');need(report['status']=='pass' and sha(folder/'capture.tar.gz')==EXPECTED[name]==report['archive_sha256'],'dependency differs')
        dependencies[name]={'archive_sha256':EXPECTED[name],'archive_bytes':report['archive_bytes'],'manifest_sha256':report['manifest_sha256'],'members':report['verified_members_including_manifest'],'retained_directory':'dependency/frontier'+('/dependency/cpu' if name=='cpu' else '')}
    prior=read(DEP_DIRS['frontier']/'source/archive-mode.json')
    recorded={p:{'retained_path':'dependency/frontier/'+v['retained_path'],'sha256':v['sha256']} for p,v in prior['recorded_files'].items()}
    SOURCE.mkdir(parents=True);originals={}
    def retain(original,relative):
        original=Path(original);relative=Path(relative);need(original.is_file() and not original.is_symlink(),'nonregular input');need(not relative.is_absolute() and '..' not in relative.parts,'unsafe capture path')
        digest=sha(original);target=SOURCE/relative;target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():need(sha(target)==digest,'capture path collision')
        else:shutil.copyfile(original,target)
        if str(original) in recorded:need(recorded[str(original)]['sha256']==digest,'recorded original changed')
        else:recorded[str(original)]={'retained_path':str(relative),'sha256':digest}
        originals[str(original)]=digest
    for name,digest in final['files'].items():need(sha(ROOT/name)==digest,'frozen host file changed');retain(ROOT/name,name)
    for name in ('final-validation.json','committed-source-verification.json','root-precommit-verification.json'):retain(ROOT/name,name)
    for p in sorted(HERE.iterdir()):
        if p.is_file() and p.suffix in ('.py','.json','.log','.md'):retain(p,Path('final-analysis')/p.name)
    retain(HERE/'README.md','README.md')
    old,new=read(ROOT/'build-identity.json'),read(ROOT/'final-host/build-identity.json')
    need(sha(ROOT/'nextpnr-mistral')==old['production_sha256']==new['production_sha256'],'frozen binary changed')
    for case in ('default','zero'):
        receipt=read(ROOT/('prepare-'+case)/'receipt.json')
        for item in receipt['inputs'].values():need(item['path'] in recorded and recorded[item['path']]['sha256']==item['sha256'],'missing raw control input')
    audit=final['actual_board_scope'];need(audit['audit_path'] in recorded and recorded[audit['audit_path']]['sha256']==audit['audit_sha256'],'missing excluded-target structural evidence')
    mode={'scope':'Frozen host-only baseline; exact dependency archives supplied explicitly, with no original-path fallback or native execution','dependencies':dependencies,'recorded_files':recorded,'excluded_native_identities':{'production_sha256':old['production_sha256'],'production_original_path':str(ROOT/'nextpnr-mistral'),'production_bytes':(ROOT/'nextpnr-mistral').stat().st_size,'initial_test_sha256':old['native_test_sha256'],'final_test_sha256':new['native_test_sha256']},'omissions':'Native production/test executables and build object payloads are not included. Initial and corrected test identities remain in frozen build receipts; native checks cannot run from this capture alone. CPU/MDA captures are explicit dependencies, not duplicated.'}
    (SOURCE/'archive-mode.json').write_text(json.dumps(mode,indent=2,sort_keys=True)+'\n')
    files=[p for p in sorted(SOURCE.rglob('*')) if p.is_file()];manifest={str(p.relative_to(SOURCE)):{'sha256':sha(p),'size':p.stat().st_size} for p in files}
    payload=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();(SOURCE/'manifest.json').write_bytes(payload);archive=CAPTURE/'capture.tar.gz'
    with archive.open('wb') as stream,gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0,compresslevel=6) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tar:
        for p in files+[SOURCE/'manifest.json']:
            b=p.read_bytes();entry=tarfile.TarInfo(str(p.relative_to(SOURCE)));entry.size=len(b);entry.mode=0o644;entry.mtime=0;tar.addfile(entry,io.BytesIO(b))
    need(archive.stat().st_size<100_000_000,'capture too large');extraction=Path(tempfile.mkdtemp(prefix='pcxt-permutation-host-offline-',dir='/tmp'))
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers();names=[m.name for m in members];need(len(names)==len(set(names)) and set(names)==set(manifest)|{'manifest.json'},'member inventory differs')
        for m in members:need(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts,'unsafe archive member')
        need(tar.extractfile('manifest.json').read()==payload,'embedded manifest differs')
        for name,item in manifest.items():
            b=tar.extractfile(name).read();need(len(b)==item['size'] and hashlib.sha256(b).hexdigest()==item['sha256'],'member bytes differ')
        tar.extractall(extraction,filter='data')
    need({str(p.relative_to(extraction)) for p in extraction.rglob('*') if p.is_file()}==set(manifest)|{'manifest.json'},'extracted inventory differs')
    for name,item in manifest.items():need(sha(extraction/name)==item['sha256'],'extracted bytes differ')
    commands=[('final-analysis/hydrate.py',[str(DEP_DIRS[n]/'capture.tar.gz') for n in ('frontier','cpu')],[]),('final-analysis/verify_host.py',[],['final-analysis/host-proof.json']),('dependency/frontier/final-analysis/verify_frontiers.py',[],['dependency/frontier/final-analysis/frontier-proof.json'])];checks=[]
    for script,args,outputs in commands:
        expected={n:(extraction/n).read_bytes() for n in outputs}
        result=subprocess.run([sys.executable,str(extraction/script),*args],cwd='/tmp',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        (CAPTURE/('offline-'+Path(script).name+'.log')).write_text(result.stdout);need(result.returncode==0,'offline failure '+script+'; retained '+str(extraction))
        for n,b in expected.items():need((extraction/n).read_bytes()==b,'proof bytes differ '+n)
        checks.append({'script':script,'returncode':0,'all_proof_bytes_identical':True,'outputs':outputs})
    for original,digest in originals.items():need(sha(original)==digest,'original evidence changed')
    for name,folder in DEP_DIRS.items():need(sha(folder/'capture.tar.gz')==EXPECTED[name],'dependency changed')
    need(sha(ROOT/'nextpnr-mistral')==final['binary_sha256'],'production binary changed')
    result={'status':'pass','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'verified_members_including_manifest':len(manifest)+1,'manifest_sha256':sha(SOURCE/'manifest.json'),'dependencies':dependencies,'offline_extraction':str(extraction),'checks':checks,'scope':'Frozen host-only source/test receipt and full placement-control verification; actual target excluded, no route admitted, no native execution or hardware acceptance.'}
    (CAPTURE/'offline-readback.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
