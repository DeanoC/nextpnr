#!/usr/bin/env python3
"""Verify frozen host executions and controls without running native binaries."""
import json,re
from pathlib import Path
from support import ROOT,HERE,need,read,sha,write,mode,recorded,cpu_root

def native_log(path,expected_total,expected_failed):
    text=path.read_text();runs=re.findall(r'^\[ RUN\s+\]\s+(.+)$',text,re.M)
    ok=re.findall(r'^\[\s+OK\s+\]\s+(.+) \(\d+ ms\)$',text,re.M)
    bad=[name.split(', where GetParam() = ',1)[0] for name in re.findall(r'^\[\s+FAILED\s+\]\s+(.+) \(\d+ ms\)$',text,re.M)]
    need(len(runs)==len(set(runs))==expected_total,'native run identity inventory differs')
    need(len(ok)==len(set(ok)) and len(bad)==len(set(bad)) and not set(ok)&set(bad),'duplicate native result')
    need(set(ok)|set(bad)==set(runs) and len(bad)==expected_failed,'native result coverage differs')
    need(re.search(r'\[==========\] '+str(expected_total)+r' tests? from .* ran\.',text),'native final footer missing')
    return {'total':expected_total,'passed':len(ok),'failed':len(bad),'complete_names':sorted(runs),'failed_names':sorted(bad)}
def main():
    final=read(ROOT/'final-validation.json');binding=read(ROOT/'committed-source-verification.json')
    need(sha(ROOT/'final-validation.json')==binding['final_validation_sha256'],'final validation binding differs')
    need(binding['commit']=='a17e0ce3762b78a30cbfd41c8615be9a9b4fc727' and binding['source_files']==final['source_files'],'commit source inventory differs')
    need(len(final['files'])==93 and len(final['source_files'])==26,'host/source count differs')
    for name,digest in final['files'].items():need(sha(ROOT/name)==digest,'host file changed '+name)
    for name,digest in final['source_files'].items():need(sha(ROOT/'complete-source'/name)==digest,'complete source changed '+name)
    oldbuild,newbuild=read(ROOT/'build-identity.json'),read(ROOT/'final-host/build-identity.json')
    need(oldbuild['production_sha256']==newbuild['production_sha256']==binding['binary_sha256']==final['binary_sha256'],'production binary identity differs')
    for folder,build in [(ROOT,oldbuild),(ROOT/'final-host',newbuild)]:
        need(sha(folder/'source-identity.json')==build['source_identity_sha256'],'source identity binding differs')
        identity=read(folder/'source-identity.json')
        for name,item in identity['files'].items():need(sha(folder/'source'/name)==item['sha256'] and (folder/'source'/name).stat().st_size==item['size'],'snapshot file differs')
    oldsource=read(ROOT/'source-identity.json')['files'];newsource=read(ROOT/'final-host/source-identity.json')['files']
    need(oldsource.keys()==newsource.keys(),'corrected source inventory differs')
    changed=[n for n in oldsource if oldsource[n]!=newsource[n]];need(changed==['mistral/tests/routed_lut_permutation_backend.cc'],'non-test correction')
    correction=read(ROOT/'final-host/test-oracle-correction.json')
    need(correction['changed_files']==changed and correction['production_source_unchanged'],'correction receipt differs')
    need(correction['initial_source_identity_sha256']==sha(ROOT/'source-identity.json') and correction['final_source_identity_sha256']==sha(ROOT/'final-host/source-identity.json'),'correction identities differ')
    need(correction['initial_validation_sha256']==sha(ROOT/'validation.json'),'initial failure binding differs')
    independent=read(ROOT/'independent-oracle-correction-review.json')
    need(independent['final_test_sha256']==newsource[changed[0]]['sha256'] and independent['final_source_identity_sha256']==sha(ROOT/'final-host/source-identity.json'),'independent correction identity differs')
    need(independent['correction_receipt_sha256']==sha(ROOT/'final-host/test-oracle-correction.json') and independent['correction_patch_sha256']==sha(ROOT/'final-host/test-oracle-correction.patch'),'correction review binding differs')
    initial=native_log(ROOT/'permutation-native.log',45,8);corrected=native_log(ROOT/'final-host/permutation-native.log',45,0)
    need(initial['complete_names']==corrected['complete_names'],'corrected suite changed identities')
    regression=native_log(ROOT/'final-host/lut6-regression.log',39,0)
    initial_receipt=read(ROOT/'permutation-native.receipt.json');need(initial_receipt['returncode']!=0 and initial_receipt['log_sha256']==sha(ROOT/'permutation-native.log'),'initial failed execution differs')
    validation=read(ROOT/'final-host/validation.json');need(validation['pass'] and validation['sources_and_binaries_unchanged'],'final execution failed')
    need(validation['build_identity_sha256']==sha(ROOT/'final-host/build-identity.json'),'final test binary binding differs')
    need([r['name'] for r in validation['results']]==['permutation-native','lut6-regression','permutation-cli','lut6-cli'],'final suite inventory differs')
    for row in validation['results']:
        need(row==read(ROOT/'final-host'/(row['name']+'.receipt.json')) and row['returncode']==0,'final suite receipt differs')
        log=ROOT/'final-host'/(row['name']+'.log');need(sha(log)==row['log_sha256'],'suite log differs')
        if row['name'].endswith('cli'):
            text=log.read_text();need(re.search(r'^Ran 6 tests in ',text,re.M) and re.search(r'^OK$',text,re.M),'CLI6 result missing')
    prior=cpu_root();oldfinal=read(prior/'final-validation.json');retained=read(ROOT/'retained-source-proof.json')
    need(sha(prior/'final-validation.json')==retained['earlier_final_validation_sha256'],'retained prior identity differs')
    for name,digest in retained['unchanged_source_files'].items():need(sha(prior/'complete-source'/name)==digest==final['source_files'][name],'retained source bytes differ')
    reference=prior/'prepare-default';refreceipt=read(reference/'receipt.json');refbytes=(reference/'placed.json').read_bytes();refgraph=read(reference/'placed.json')
    cases={}
    for case in ('default','zero'):
        folder=ROOT/('prepare-'+case);r=read(folder/'receipt.json');need(r['returncode']==0 and r['charged_seconds']==0 and r['binary_sha256']==final['binary_sha256'],'CPU control receipt differs')
        for name,digest in r['artifacts'].items():need(sha(folder/name)==digest,'control artifact differs')
        need(r['reference_receipt_sha256']==sha(reference/'receipt.json') and r['inputs']==refreceipt['inputs'],'control reference/input differs')
        for item in r['inputs'].values():recorded(item['path'],item['sha256'])
        need(r['source_identity']['source_identity_sha256']==sha(ROOT/'source-identity.json') and r['source_identity']['source_files']==oldsource,'CPU source identity differs')
        command=list(refreceipt['nextpnr_command']);command[0]=r['nextpnr_command'][0]
        if case=='zero':command+=['--critical-lut6-swap-budget','0','--critical-private-pair-budget','0','--critical-lut-permute-budget','0']
        need(command==r['nextpnr_command'] and '--no-route' in command and '--rbf' not in command,'control recipe differs')
        graph=read(folder/'placed.json');need(graph.keys()==refgraph.keys() and {k:v for k,v in graph.items() if k!='creator'}=={k:v for k,v in refgraph.items() if k!='creator'},'complete control graph differs')
        a,b=json.dumps(refgraph['creator']).encode(),json.dumps(graph['creator']).encode();need(refbytes.count(a)==1 and refbytes.replace(a,b,1)==(folder/'placed.json').read_bytes(),'creator-only raw graph differs')
        need((folder/'predicted-timing.json').read_bytes()==(reference/'predicted-timing.json').read_bytes(),'predicted timing differs')
        cases[case]={'complete_graph_equal_except_creator':True,'raw_bytes_equal_except_creator':True,'predicted_timing_bytes_equal':True,'placed_sha256':sha(folder/'placed.json')}
    need((ROOT/'prepare-default/placed.json').read_bytes()==(ROOT/'prepare-zero/placed.json').read_bytes(),'default/zero bytes differ')
    need(final['enabled_lut_permutation_route_admission'] is False and final['actual_board_scope']['intended_target_eligible'] is False,'route admission scope changed')
    audit=read(recorded(final['actual_board_scope']['audit_path'],final['actual_board_scope']['audit_sha256']))
    need(audit['actual_permutation_pass_was_not_run'] and len(audit['empty_output_bits'])==6 and len(audit['all_capture_identities'])==66,'CGA excluded frontier differs')
    if mode():need(mode()['excluded_native_identities']['production_sha256']==final['binary_sha256'] and mode()['excluded_native_identities']['initial_test_sha256']==oldbuild['native_test_sha256'] and mode()['excluded_native_identities']['final_test_sha256']==newbuild['native_test_sha256'],'omitted binary identities differ')
    else:need(sha(ROOT/'nextpnr-mistral')==final['binary_sha256'],'frozen production binary differs')
    result={'status':'pass','scope':'Offline verification of recorded host executions, frozen source, complete placement controls and explicit target exclusion; no native execution, board eligibility, routing or hardware acceptance','committed_source':binding['commit'],'source_tree':binding['tree'],'binary_sha256':final['binary_sha256'],'final_test_sha256':newbuild['native_test_sha256'],'host_files':len(final['files']),'complete_source_files':len(final['source_files']),'initial_native_failure':initial,'corrected_native_success':corrected,'retained_native_regression':regression,'cli_counts':{'permutation':6,'lut6':6},'production_unchanged_by_test_correction':True,'control_cases':cases,'default_zero_raw_bytes_identical':True,'intended_CGA_route_admitted':False,'CGA_unused_arithmetic_outputs':6,'CGA_capture_identities':66,'charged_route_seconds':0,'checker_sha256':sha(Path(__file__))}
    write('host-proof.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ('initial_native_failure','corrected_native_success','retained_native_regression')},sort_keys=True))
if __name__=='__main__':main()
