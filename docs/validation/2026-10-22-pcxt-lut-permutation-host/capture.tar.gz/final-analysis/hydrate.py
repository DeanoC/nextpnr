#!/usr/bin/env python3
"""Safely install two exact explicit capture dependencies, without native execution."""
from pathlib import Path
import hashlib,json,sys,tarfile
ROOT=Path(__file__).resolve().parent.parent
def need(value,message):
    if not value:raise ValueError(message)
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def main():
    need(len(sys.argv)==3,'usage: hydrate.py /path/to/MDA-capture.tar.gz /path/to/CPU-capture.tar.gz')
    deps=json.loads((ROOT/'archive-mode.json').read_text())['dependencies'];results=[]
    for name,argument in zip(('frontier','cpu'),sys.argv[1:]):
        dep=deps[name];archive=Path(argument);need(sha(archive)==dep['archive_sha256'],'wrong dependency '+name)
        rel=Path(dep['retained_directory']);need(not rel.is_absolute() and '..' not in rel.parts,'unsafe dependency path');dest=ROOT/rel
        nested=[Path(v['retained_directory']).relative_to(rel) for n,v in deps.items() if n!=name and Path(v['retained_directory']).is_relative_to(rel)]
        with tarfile.open(archive,'r:gz') as tar:
            members=tar.getmembers();names=[m.name for m in members];need(len(names)==len(set(names))==dep['members'],'duplicate/wrong dependency member count')
            for m in members:need(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts,'unsafe member')
            payload=tar.extractfile('manifest.json').read();need(hashlib.sha256(payload).hexdigest()==dep['manifest_sha256'],'dependency manifest differs');manifest=json.loads(payload)
            need(set(names)==set(manifest)|{'manifest.json'},'dependency exact inventory differs')
            for n,v in manifest.items():
                b=tar.extractfile(n).read();need(len(b)==v['size'] and hashlib.sha256(b).hexdigest()==v['sha256'],'dependency member differs '+n)
            if not dest.exists():dest.mkdir(parents=True);tar.extractall(dest,filter='data')
        actual={str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file() and not any(p.relative_to(dest).is_relative_to(n) for n in nested)}
        need(actual==set(manifest)|{'manifest.json'},'installed dependency inventory differs')
        need(sha(dest/'manifest.json')==dep['manifest_sha256'],'installed manifest differs')
        for n,v in manifest.items():need(sha(dest/n)==v['sha256'] and (dest/n).stat().st_size==v['size'],'installed dependency bytes differ')
        results.append({'dependency':name,'sha256':dep['archive_sha256'],'verified_members':len(manifest)+1})
    print(json.dumps({'status':'pass','dependencies':results},sort_keys=True))
if __name__=='__main__':main()
