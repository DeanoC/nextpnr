from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time

root=Path(__file__).resolve().parent
task=root.parents[1]
previous=root.parent/'reduction-balanced-20261022'

def run(label,seed):
    source=json.loads((previous/('route-'+label)/'receipt.json').read_text())
    command=source['nextpnr_command'][:]
    command[command.index('--seed')+1]=str(seed)
    wrapped=[str(task/'scripts/gpu-run'),'--phase-lease','--owner','pcxt-timing',
             '--label',f'pcxt-reduction-{label}-seed{seed}','--',*command]
    directory=root/f'{label}-seed{seed}'; directory.mkdir(exist_ok=False)
    receipt={'command':wrapped,'nextpnr_command':command,'selected_roots':source['selected_roots'],
             'binary_sha256':source['binary_sha256'],
             'evidence':'leased GPU fresh pack/place/route host diagnostic; not acceptance',
             'limit':'native bounded router iterations; no external GPU-job termination'}
    assert hashlib.file_digest(open(command[0],'rb'),'sha256').hexdigest()==receipt['binary_sha256']
    env=dict(os.environ);env['NEXTPNR_REQUIRE_GPU']='1'
    start=time.monotonic()
    with (directory/'nextpnr.log').open('w') as log:
        receipt['returncode']=subprocess.run(wrapped,cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    receipt['charged_seconds']=time.monotonic()-start
    receipt['artifacts']={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in directory.iterdir() if p.suffix in ['.json','.rbf']}
    (directory/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(label,seed,receipt['returncode'],receipt['charged_seconds'],flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
    futures=[pool.submit(run,label,seed) for seed in [2,3] for label in ['overflow17']]
    for future in futures: future.result()
