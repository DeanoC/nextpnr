from pathlib import Path
from collections import defaultdict
from decimal import Decimal
import hashlib,json

root=Path(__file__).resolve().parent
def sha(path):
    return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
def rows(snapshot):
    result={}
    for endpoint,values in snapshot['endpoints'].items():
        for row in values:
            key=(endpoint,tuple(row['launch']),tuple(row['capture']))
            assert key not in result;result[key]=row
    return result
all_rows={};snapshots={};result={'runs':{},'comparisons':{}}
charge=Decimal(0)
for seed in [2,3]:
    for mode in ['baseline','both','overflow17']:
        name=f'{mode}-seed{seed}';directory=root/name
        receipt=json.loads((directory/'receipt.json').read_text())
        for filename,expected in receipt['artifacts'].items():assert sha(directory/filename)==expected
        timing=json.loads((directory/'timing.json').read_text())
        snapshot=json.loads((directory/'endpoints.json').read_text());snapshots[name]=snapshot
        assert timing['timing_summary']['final_analogue_model'] and snapshot['final_analogue']
        r=rows(snapshot);all_rows[name]=r;groups=defaultdict(list)
        for key,row in r.items():groups[(key[1],key[2])].append(row)
        pairs=[]
        for (launch,capture),values in sorted(groups.items()):
            pairs.append({'launch':launch,'capture':capture,'rows':len(values),
                'setup_wns_ps':min((v['setup'] for v in values if v['setup_timed']),default=None),
                'related_hold_wns_ps':min((v['hold'] for v in values if v['hold_related']),default=None),
                'setup_failures':sum(v['setup_timed'] and v['setup']<0 for v in values),
                'related_hold_failures':sum(v['hold_related'] and v['hold']<0 for v in values)})
        charge+=Decimal(str(receipt['charged_seconds']))
        result['runs'][name]={'returncode':receipt['returncode'],'charged_seconds':receipt['charged_seconds'],
            'artifact_hashes':receipt['artifacts'],'binary_sha256':receipt['binary_sha256'],
            'clock_summary':timing['timing_summary']['clocks'],'clock_pairs':pairs,
            'endpoint_rows':len(r),'endpoint_identities':len(snapshot['endpoints']),
            'setup_failures':sum(v['setup_timed'] and v['setup']<0 for v in r.values()),
            'related_hold_failures':sum(v['hold_related'] and v['hold']<0 for v in r.values()),
            'schema':snapshot['schema'],'complete':snapshot['complete'],
            'unsupported_count':len(snapshot['unsupported']),'primitive_clocks':snapshot['primitive_clocks'],
            'physical_obligations':snapshot['physical_obligations']}
    base=f'baseline-seed{seed}'
    for mode in ['both','overflow17']:
        name=f'{mode}-seed{seed}';a,b=all_rows[base],all_rows[name]
        assert set(a)==set(b)
        for key in a:
            for field in ['setup_timed','hold_related','setup_window']:assert a[key][field]==b[key][field]
        for field in ['clocks','forwarded_clocks','io_constraints','output_contracts','physical_obligations',
                      'primitive_clocks','registered_contracts','reset_contracts','unregistered_contracts','unsupported']:
            assert snapshots[base][field]==snapshots[name][field],(name,field)
        metadata={}
        for field in ['constant_outputs','static_endpoints','unsupported_details']:
            before,after=snapshots[base][field],snapshots[name][field]
            assert set(before)==set(after)
            metadata[field]={'identities_equal':True,'changed_records':sum(before[k]!=after[k] for k in before),
                             'complete_records_equal':before==after}
        margins={}
        for field,flag in [('setup','setup_timed'),('hold','hold_related')]:
            delta=[b[k][field]-a[k][field] for k in a if a[k][flag]]
            margins[field]={'improved':sum(v>0 for v in delta),'regressed':sum(v<0 for v in delta),
                            'unchanged':sum(v==0 for v in delta),'worst_regression_ps':min(delta),
                            'best_improvement_ps':max(delta)}
        result['comparisons'][name]={'timed_endpoint_identities_and_clock_constraints_equal':True,
                                    'margins':margins,'physical_metadata':metadata,
                                    'qualification':'fails setup and has incomplete physical coverage'}
prior=Decimal('10575.23023688094620')
result['accounting']={'prior_cumulative_seconds':str(prior),'six_seed_route_seconds':str(charge),
                      'subtotal_with_these_six_runs_only_seconds':str(prior+charge),'total_cap':None,
                      'excluded_parallel_routes':'RAM-decoder and spreader correction are recorded separately'}
result['evidence']='host-only final-route diagnostics, no hardware or production acceptance; final routed equivalence not independently established'
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['accounting'],indent=2))
