#!/usr/bin/env python3
"""Offline evidence replay: no native binary, compiler, GPU, device or original absolute path access."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
P=Path(__file__).resolve().parent;mode=json.loads((P/'archive-mode.json').read_text());R=P/mode['host_directory'];OLD=P/'evidence/routed-lut-permutation-20261022'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
f=read(R/'final-validation.json');assert sha(R/'final-validation.json')==mode['original_host_final_sha256']
assert len(f['files'])==131 and len(f['source_files'])==29
for p,h in f['files'].items():assert sha(R/p)==h,p
commit=read(R/'committed-source-verification.json');assert commit['commit']==mode['committed_source'] and commit['all_recorded_source_bytes_match_commit']
assert commit['final_validation_sha256']==sha(R/'final-validation.json') and commit['source_files']==f['source_files'] and commit['binary_sha256']==f['binary_sha256']
for p,h in f['source_files'].items():assert sha(R/'complete-source'/p)==h
F=R/'source-validation/final-host';source=read(F/'source-identity.json');initial=read(R/'source-identity.json');build=read(F/'build-identity.json')
assert build['source_identity_sha256']==sha(F/'source-identity.json')==f['corrected_source_identity_sha256']
assert build['production_sha256']==f['binary_sha256'] and build['native_test_sha256']==f['native_test_sha256']
assert set(source['files'])==set(initial['files']) and len(source['files'])==10
for p,x in source['files'].items():assert sha(F/'source'/p)==x['sha256']==f['source_files'][p]
for p,x in initial['files'].items():assert sha(R/'source'/p)==x['sha256']
changed=[p for p in source['files'] if source['files'][p]['sha256']!=initial['files'][p]['sha256']];assert changed==['mistral/tests/unobserved_arithmetic_coverage.cc']
p=changed[0];assert (R/'source'/p).read_text().replace('unused->users.add({hidden,id_DATAIN})','unused->users.add(PortRef{hidden,id_DATAIN})')==(F/'source'/p).read_text()
old_build=read(R/'source-validation/build.receipt.json');assert old_build['returncode']!=0 and old_build['log_sha256']==sha(R/'source-validation/build.log')
summary=read(F/'validation.json');assert summary['pass'] and summary['sources_and_binaries_unchanged'] and summary['build_identity_sha256']==sha(F/'build-identity.json')
counts={'unobserved-arithmetic':12,'source-coverage':6,'lut6-native':33,'permutation-native':45,'private-pair-native':77,'unobserved-cli':6,'lut6-cli':6,'permutation-cli':6,'private-pair-cli':6}
assert len(summary['results'])==len(counts) and {x['name'] for x in summary['results']}==set(counts)
native_ids={}
for name,n in counts.items():
 receipt=read(F/(name+'.receipt.json'));text=(F/(name+'.log')).read_text();assert receipt['pass'] and receipt['returncode']==0 and receipt['expected_count']==receipt['observed_count']==n
 assert receipt['log_sha256']==sha(F/(name+'.log'))
 if name.endswith('-cli'):assert re.search(r'Ran '+str(n)+r' tests in',text) and re.search(r'\nOK\s*$',text)
 else:
  run=re.findall(r'^\[ RUN      \] (.+)$',text,re.M);ok=re.findall(r'^\[       OK \] (.+) \(\d+ ms\)$',text,re.M)
  assert len(run)==len(ok)==len(set(run))==n and run==ok and re.search(r'\[  PASSED  \] '+str(n)+r' tests\.',text)
  native_ids[name]=run
control=read(R/'control-proof.json');assert control['default_zero_raw_bytes_equal'] and len(control['controls'])==2
prior=read(OLD/'prepare-default/receipt.json');old_bytes=(OLD/'prepare-default/placed.json').read_bytes()
for case in ('default','zero'):
 folder=R/('prepare-'+case);rec=read(folder/'receipt.json');assert rec['returncode']==0 and rec['binary_sha256']==f['binary_sha256'] and rec['inputs']==prior['inputs']
 expected=prior['nextpnr_command'][:];expected[0]=rec['nextpnr_command'][0]
 if case=='zero':expected+=['--critical-lut6-swap-budget','0','--critical-private-pair-budget','0','--critical-lut-permute-budget','0']
 assert rec['nextpnr_command']==expected and '--no-route' in expected and '--rbf' not in expected
 for p,h in rec['artifacts'].items():assert sha(folder/p)==h
 new_bytes=(folder/'placed.json').read_bytes();a=json.loads(old_bytes);b=json.loads(new_bytes);old_creator=json.dumps(a.pop('creator')).encode();new_creator=json.dumps(b.pop('creator')).encode()
 assert a==b and old_bytes.count(old_creator)==1 and old_bytes.replace(old_creator,new_creator,1)==new_bytes
 assert (folder/'predicted-timing.json').read_bytes()==(OLD/'prepare-default/predicted-timing.json').read_bytes()
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
ret=read(R/'retained-source-proof.json');assert ret['earlier_final_validation_sha256']==sha(OLD/'final-validation.json') and f['retained_prior_validation']['sha256']==sha(OLD/'final-validation.json')
for p,h in ret['unchanged_source_files'].items():assert h==f['source_files'][p]==read(OLD/'final-validation.json')['source_files'][p]
B=R/'board-eligibility';revision=read(B/'checker-evolution/revision.json');native=read(B/'receipt.json')
assert revision['original_receipt_sha256']==sha(B/'receipt.json') and revision['current_checker_sha256']==sha(B/'check.py') and revision['current_proof_sha256']==sha(B/'proof.json')
for p,h in native['files'].items():
 if p=='native-probe':assert h==mode['omitted_native_payloads']['probe_sha256']
 else:assert sha(B/('checker-evolution/original-check.py' if p=='check.py' else p))==h,p
assert native['returncode']==0 and native['objects_unchanged'] and native['source_unchanged']
for p in ('root-native-replay/result.json',):assert (B/p).read_bytes()==(B/'result.json').read_bytes()
assert (R/'independent-host-review/board-replay.json').read_bytes()==(B/'result.json').read_bytes()
proof=(B/'proof.json').read_bytes();subprocess.run([sys.executable,str(B/'check.py')],check=True,stdout=subprocess.DEVNULL);assert (B/'proof.json').read_bytes()==proof
old=(R/'strict-lut6-retention/prior-routed_lut6_swap.cc').read_bytes();new=(R/'complete-source/mistral/routed_lut6_swap.cc').read_bytes();old_start=old.index(b'bool critical_lut6_swap_output_coverage(');new_start=new.index(b'namespace {\nbool output_coverage(')
assert old[:old_start]==new[:new_start];marker=b'bool critical_routed_lut6_swap_trial(';suffix=old[old.index(marker):];assert suffix==new[new.index(marker):] and b'critical_output_coverage_with_unobserved_arithmetic' not in suffix
assert b'return output_coverage(ctx,timing,output,false,reason);' in new
sproof=read(R/'strict-lut6-retention/proof.json');assert sproof['prior_file_sha256']==hashlib.sha256(old).hexdigest() and sproof['current_file_sha256']==hashlib.sha256(new).hexdigest() and sproof['prefix_sha256']==hashlib.sha256(old[:old_start]).hexdigest() and sproof['suffix_sha256']==hashlib.sha256(suffix).hexdigest()
review=read(R/'independent-host-review.json');assert review['passed'] and review['board_proof_sha256']==sha(B/'proof.json') and review['control_proof_sha256']==sha(R/'control-proof.json')
assert all(f[k] is True for k in ['enabled_lut6_route_admission','enabled_lut_permutation_route_admission','enabled_private_pair_route_admission','enabled_unobserved_arithmetic_route_admission'])
result={'passed':True,'scope':'Offline immutable host receipts/source/control/coverage proof replay only; no native execution or route/physical acceptance','final_validation_sha256':sha(R/'final-validation.json'),'retained_host_files':len(f['files']),'source_union_files':len(f['source_files']),'native_count':173,'cli_count':24,'named_native_tests':native_ids,'board_proof_bytes_reproduced':True,'strict_source_retention_recomputed':True,'complete_control_bytes_reproduced':True}
print(json.dumps(result,indent=2,sort_keys=True))
