# CGA permutation target: unused-output boundary

The proposed ordinary-LUT permutation pass's unchanged complete-output coverage guard will exclude the intended CGA ALUT3 on the captured graph. Its input C, `dot[0]`, has six reachable arithmetic output nets with no users. This is discovered before launching the proposed GPU pair; no permutation pass or timing trial ran for this audit. Passing native transaction tests cannot establish eligibility for this board target.

The exact target is `system.machine.isa.slots[1].cga.card.card.pixel_MISTRAL_ALUT6_Q_F_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_Q_1`, at `MISTRAL_COMB.18.9.13`. Inputs A/B and output Q have complete structural capture branches without an empty output. Input C reaches 66 distinct FF captures plus these six empty arithmetic outputs:

| Saved bit | Driver output |
| --- | --- |
|53149|dot3 initial carry helper SO|
|53114|dot2 final carry CO|
|53097|dot1 initial carry helper SO|
|53085|dot1 next carry helper SO|
|53074|dot1 next carry helper SO|
|53059|dot1 final carry CO|

The full driver identities, every alias and observer, physical maps, complete source-to-boundary paths, and all 66 original saved endpoint rows are retained in `analysis.json`. Three of those rows fail setup, worst −434 ps; the minimum related hold is +1315 ps. These numbers are the original live route's exported timing rows, not a new analysis.

The separate native probe uses retained 972 headers/objects only to inspect structural metadata after parsing the unchanged final 243/e94f route. It confirms all six empty outputs have a single valid arithmetic driver, zero users, no top-level observer, no global-net flag and no clock constraint. The native capture identity union matches the graph inventory exactly. It never runs STA, changes a route, invokes a trial, or substitutes reloaded timing for live evidence.

The production source at the current frozen 7107 build calls `critical_lut6_swap_output_coverage` on every target input net and its output, in both timing frames. That helper rejects zero-user nets. The graph and native metadata therefore establish the specific conservative scope exclusion, without predicting which filter is printed first or asserting a live timing result. No guard is changed here; a narrowly verified local unused-output terminal rule would require its own reviewed source/tests and new provenance.
