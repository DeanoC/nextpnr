from pathlib import Path
import hashlib,json,subprocess,re,time
R=Path('out/dev/pcxt-board/out/unobserved-arith-coverage-20261022').resolve(); B=R/'board-eligibility'; OUT=R/'independent-host-review'; OUT.mkdir(exist_ok=True)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,x):Path(p).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
plan=read(B/'build-plan.json');receipt=read(B/'receipt.json');build=read(R/'source-validation/final-host/build-identity.json');src=read(R/'source-validation/final-host/source-identity.json')
assert sha(R/'source-validation/final-host/build-identity.json')==plan['build_identity_sha256']
assert sha(R/'source-validation/final-host/source-identity.json')==plan['source_identity_sha256']==build['source_identity_sha256']
assert sha(B/'probe.cc')==plan['source_sha256'] and sha(B/'build-plan.json')==receipt['plan_sha256']
assert receipt['returncode']==0 and receipt['objects_unchanged'] and receipt['source_unchanged']
assert all(row['returncode']==0 for row in receipt['commands'])
assert plan['source_files']==src['files']
for p,expected in plan['object_hashes'].items():assert sha(p)==expected,p
receipt_changes={p:{'recorded_sha256':expected,'current_sha256':sha(B/p)} for p,expected in receipt['files'].items() if sha(B/p)!=expected}
assert set(receipt_changes)=={'check.py'}
assert sha(plan['input'])==plan['input_sha256']
for p,x in src['files'].items():assert sha(R/'source-validation/final-host/source'/p)==x['sha256'],p
assert sha(R/'nextpnr-mistral')==build['production_sha256']==plan['binary_sha256']
evolution=read(B/'checker-evolution/revision.json')
assert evolution['original_receipt_sha256']==sha(B/'receipt.json')
assert evolution['original_checker_sha256']==sha(B/'checker-evolution/original-check.py')==receipt_changes['check.py']['recorded_sha256']
assert evolution['current_checker_sha256']==sha(B/'check.py') and evolution['current_proof_sha256']==sha(B/'proof.json')
original=read(B/'result.json')
cmd=receipt['commands'][-1]['argv'][:];assert cmd[0]==str(B/'native-probe') and cmd[1]==plan['input'];cmd[2]=str(OUT/'board-replay.json')
start=time.monotonic()
with (OUT/'board-replay.log').open('w') as log:rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
assert rc==0 and read(OUT/'board-replay.json')==original and sha(OUT/'board-replay.json')==sha(B/'result.json')
for p,expected in plan['object_hashes'].items():assert sha(p)==expected,p
# Checker is deterministic, but rerun from an isolated exact copy to preserve the original.
checker=(B/'check.py').read_text();checker=checker.replace('R=Path(__file__).resolve().parent;T=R.parent.parent',f'R=Path({str(B)!r});T=R.parent.parent').replace("(R/'proof.json').write_text",f"(Path({str(OUT)!r})/'board-proof-replay.json').write_text").replace("'checker_sha256':sha(__file__)",f"'checker_sha256':sha(Path({str(B/'check.py')!r}))").replace("print(sha(R/'proof.json'))",f"print(sha(Path({str(OUT/'board-proof-replay.json')!r})))")
(OUT/'board-check-replay.py').write_text(checker)
subprocess.run(['python3',str(OUT/'board-check-replay.py')],check=True,stdout=subprocess.PIPE)
assert sha(OUT/'board-proof-replay.json')==sha(B/'proof.json')
control=read(R/'control-proof.json');previous=R.parent/'routed-lut-permutation-20261022/prepare-default'
control_details=[]
for case in ('default','zero'):
 folder=R/('prepare-'+case);rec=read(folder/'receipt.json');assert rec['returncode']==0
 # The receipts use named artifact records; verify every complete emitted file.
 for name,expected in rec['artifacts'].items():assert sha(folder/name)==expected,name
 current=read(folder/'placed.json');prior=read(previous/'placed.json')
 assert current['modules']==prior['modules']
 text=(folder/'placed.json').read_text();old=(previous/'placed.json').read_text()
 norm=lambda t:re.sub(r'"creator":\s*"[^"\\]*(?:\\.[^"\\]*)*"','"creator": "<creator>"',t,count=1)
 assert norm(text)==norm(old)
 assert (folder/'predicted-timing.json').read_bytes()==(previous/'predicted-timing.json').read_bytes()
 control_details.append({'case':case,'receipt_sha256':sha(folder/'receipt.json'),'placed_sha256':sha(folder/'placed.json'),'complete_modules_equal':True,'raw_except_creator_equal':True,'timing_bytes_equal':True})
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
result={'passed':True,'board_proof_sha256':sha(B/'proof.json'),'control_proof_sha256':sha(R/'control-proof.json'),'production_binary_sha256':build['production_sha256'],'source_identity_sha256':plan['source_identity_sha256'],'source_review_sha256':sha(R.parent/'unused-arith-leaf-review-20261022/installed-source-review.json'),'independent_native_replay':{'command':cmd,'returncode':rc,'wall_seconds':time.monotonic()-start,'output_sha256':sha(OUT/'board-replay.json'),'raw_bytes_equal':True,'object_files_checked':len(plan['object_hashes']),'source_files_checked':len(src['files']),'objects_unchanged':True},'controls':control_details,'post_execution_checker_update':receipt_changes,'checker_evolution_receipt_sha256':sha(B/'checker-evolution/revision.json'),'findings':['Both native skew frames admit all selected input/output frontiers, preserve exact 64/66 capture identities and complete clock-window contracts, and retain 2/6 strictly unobserved arithmetic leaves.','The existing strict coverage wrapper rejects these frontiers; the explicit optional wrapper admits them.','Every observed leaf has zero active users, zero routed wires, exactly one live canonical driver reference, and no public/global/clock/region observer.','No FF cache mismatch, timing loop, or selected native BEL legality failure is recorded.','Whole CPU placement/default-zero bytes and predicted timing are unchanged; prior7107 differs only creator.'],'limits':['This is host admission evidence only. The native probe restores a placed checkpoint and runs route preparation plus predicted full STA; it does not route or run a local transaction.','Native origin inventory is diagnostic; the production source-coverage predicates determine admission.','No predicted-to-routed margin comparison, full-route timing acceptance, native RBF equality or hardware qualification is inferred.','Final route admission also requires root validation of completed native and CLI suites and exact committed source/binary binding.']}
save(R/'independent-host-review.json',result);print('PASS',sha(R/'independent-host-review.json'))
