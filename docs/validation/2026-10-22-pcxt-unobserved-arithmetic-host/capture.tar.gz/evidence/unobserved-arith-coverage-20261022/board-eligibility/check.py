#!/usr/bin/env python3
"""Exact host capture/leaf identity comparison; never compare predicted margins to routed margins."""
from pathlib import Path
import hashlib,json,math
R=Path(__file__).resolve().parent;T=R.parent.parent

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
report=read(R/'result.json');receipt=read(R/'receipt.json')
assert receipt['returncode']==0 and receipt['objects_unchanged'] and receipt['source_unchanged']
assert report['all_selected_native_coverage_and_legality'] and report['all_ff_cache_mismatches']==0
assert len(report['analyses'])==2 and {r['with_clock_skew'] for r in report['analyses']}=={False,True}
proof=[]
for analysis in report['analyses']:
 assert not analysis['have_loops'] and len(analysis['targets'])==2
 for target in analysis['targets']:
  name='mda' if target['kind']=='mda_private_pair' else 'cga';expected_count=64 if name=='mda' else 66;leaf_count=2 if name=='mda' else 6
  old_dir=T/(name+'-frontier-audit-20261022');old=read(old_dir/'analysis.json');native=read(old_dir/'native-result.json')
  assert target['source_coverage'] and target['all_opt_in_output_coverage'] and target['native_location_legal']
  assert not target['all_strict_output_coverage'] and not target['source_inventory']['truncated']
  assert len(target['frontiers'])==(8 if name=='mda' else 4)
  assert {x['net'] for x in target['frontiers']}=={x['root'] for x in native['frontiers']}
  for f in target['frontiers']:assert f['opt_in_coverage']
  inventory=target['downstream_inventory'];actual={(x['cell'],x['port']) for x in inventory['captures']};expected={tuple(x) for x in old['all_capture_identities']}
  assert actual==expected and len(actual)==inventory['capture_count']==expected_count
  assert len(inventory['captures'])==expected_count
  saved_rows={}
  for frontier in old['frontiers']:
   for capture in frontier['captures']:
    key=tuple(capture['endpoint']);rows=capture['complete_native_saved_rows']
    if key in saved_rows:assert saved_rows[key]==rows
    saved_rows[key]=rows
  assert set(saved_rows)==actual
  for cap in inventory['captures']:
   assert cap['available'] and cap['rows']
   keys=[]
   for row in cap['rows']:
    assert row['setup_timed'] and row['hold_related']
    assert row['setup_window']>0 and all(isinstance(row[k],(int,float)) and math.isfinite(row[k]) for k in ('setup_window','setup_margin','hold_margin','min_path','max_path'))
    keys.append((row['launch'],row['launch_edge'],row['capture'],row['capture_edge']))
   assert len(keys)==len(set(keys))
   native_contract=sorted((r['launch'],r['launch_edge'],r['capture'],r['capture_edge'],r['setup_timed'],r['hold_related'],r['setup_window']) for r in cap['rows'])
   saved_contract=sorted((r['launch'][0],r['launch'][1],r['capture'][0],r['capture'][1],r['setup_timed'],r['hold_related'],r['setup_window']) for r in saved_rows[(cap['cell'],cap['port'])])
   assert native_contract==saved_contract
  old_leaves={(x['driver'],x['driver_port'],x['net']) for f in native['frontiers'] for x in f['rejecting_boundaries']}
  actual_leaves={(x['driver'],x['port'],x['net']) for x in inventory['unused_arithmetic_outputs']}
  assert actual_leaves==old_leaves and len(actual_leaves)==len(inventory['unused_arithmetic_outputs'])==leaf_count
  for leaf in inventory['unused_arithmetic_outputs']:
   assert leaf['users']==leaf['route_wires']==leaf['native_clocks']==0 and leaf['cell_port_references']==1
   assert not any(leaf[k] for k in ('public_ports','global','clock_constraint','net_region','cell_region'))
   assert leaf['canonical_driver'] and leaf['pin_state']==0 and leaf['timing_class']==5
  proof.append({'kind':target['kind'],'with_clock_skew':analysis['with_clock_skew'],'source_coverage':True,'native_location_legal':True,
    'strict_coverage_rejects_original_frontier':True,'explicit_optional_coverage_passes_all_frontiers':True,
    'all_capture_clock_pairs_windows_and_timed_flags_match_saved_route':True,'exact_capture_inventory_count':expected_count,'exact_unused_arithmetic_leaf_count':leaf_count,
    'saved_route_audit_sha256':sha(old_dir/'analysis.json'),'saved_route_native_structural_report_sha256':sha(old_dir/'native-result.json')})
result={'passed':True,'scope':'Host-only fresh placed checkpoint plus native route preparation and predicted full STA coverage. Capture/unused-leaf identities exactly match saved-route audits; no predicted-to-routed margin comparison, local route transaction, routed timing acceptance or physical signoff.',
 'result_sha256':sha(R/'result.json'),'receipt_sha256':sha(R/'receipt.json'),'checker_sha256':sha(__file__),'proofs':proof}
(R/'proof.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(sha(R/'proof.json'))
