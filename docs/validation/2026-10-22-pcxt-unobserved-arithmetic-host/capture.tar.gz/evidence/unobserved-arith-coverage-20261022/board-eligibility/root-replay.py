from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;d=r/'root-native-replay';d.mkdir(exist_ok=False)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
receipt=json.loads((r/'receipt.json').read_text());plan=json.loads((r/'build-plan.json').read_text());revision=json.loads((r/'checker-evolution/revision.json').read_text())
assert sha(r/'receipt.json')==revision['original_receipt_sha256']
assert sha(r/'check.py')==revision['current_checker_sha256'] and sha(r/'proof.json')==revision['current_proof_sha256']
for p,h in receipt['files'].items():
 actual=r/revision['original_checker_retained_path'] if p=='check.py' else r/p
 assert sha(actual)==h,p
assert sha(plan['input'])==plan['input_sha256']
command=receipt['commands'][-1]['argv'][:];assert sha(command[0])==receipt['files']['native-probe'];command[-1]=str(d/'result.json')
start=time.monotonic()
with (d/'probe.log').open('w') as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
assert code==0,code
assert (d/'result.json').read_bytes()==(r/'result.json').read_bytes()
assert sha(plan['input'])==plan['input_sha256'] and sha(command[0])==receipt['files']['native-probe']
before=(r/'proof.json').read_bytes()
with (d/'checker.log').open('w') as log:check=subprocess.run(['python3',str(r/'check.py')],stdout=log,stderr=subprocess.STDOUT).returncode
assert check==0 and (r/'proof.json').read_bytes()==before
result={'status':'pass','command':command,'returncode':code,'elapsed_seconds':time.monotonic()-start,'original_receipt_sha256':sha(r/'receipt.json'),'checker_revision_sha256':sha(r/'checker-evolution/revision.json'),'binary_sha256':sha(command[0]),'input_sha256':plan['input_sha256'],'result_sha256':sha(d/'result.json'),'complete_result_bytes_equal':True,'strengthened_proof_bytes_equal':True,'route_charge':0,'scope':'Native host admission replay only; no route or hardware acceptance'}
(d/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
