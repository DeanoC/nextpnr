// Host-only structural/source admission probe after native route preparation.
// Predicted full STA is used only for the coverage API; no route or acceptance trial.
#include "nextpnr.h"
#include "json_frontend.h"
#include "timing.h"
#include "analogue_repair.h"
#include "private_pair_decomposition_native.h"
#include "json11.hpp"
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
USING_NEXTPNR_NAMESPACE
using J=json11::Json;
static const std::array<IdString,6> inputs{id_A,id_B,id_C,id_D,id_E,id_F};
static J hints(Context &c,TimingAnalyser &timing,CellPortKey key) {
    std::vector<TimingAnalyser::SetupWindowHint> rows;bool available=timing.get_setup_window_hints(key,rows);J::array result;
    for(const auto &r:rows) result.push_back(J::object{{"launch",r.launch.clock.str(&c)},{"launch_edge",int(r.launch.edge)},
        {"capture",r.capture.clock.str(&c)},{"capture_edge",int(r.capture.edge)},{"cut",r.cut},{"window",r.window?J(*r.window):J()}});
    return J::object{{"available",available},{"rows",result}};
}
// Separate diagnostic inventory, not an alternative acceptance predicate.
static J inventory(Context &c, TimingAnalyser &timing,NetInfo *root) {
    std::set<NetInfo*> done,visiting;J::array nets,terminals;unsigned work=0,maxdepth=0;bool truncated=false;
    auto walk=[&](auto &&self,NetInfo *net,unsigned depth)->void {
        if(!net||depth>64||++work>4096){truncated=true;return;}
        maxdepth=std::max(maxdepth,depth);if(done.count(net))return;
        if(visiting.count(net)){terminals.push_back(J::object{{"net",net->name.str(&c)},{"kind","cycle"}});return;}
        visiting.insert(net);auto *cell=net->driver.cell;int clocks=0;
        J::object row{{"net",net->name.str(&c)},{"fanout",int(net->users.entries())},{"depth",int(depth)},
            {"driver",cell?cell->name.str(&c):""},{"port",net->driver.port.str(&c)},
            {"type",cell?cell->type.str(&c):""}};
        bool public_net=false;for(const auto &p:c.ports)public_net|=p.second.net==net;row["public"]=public_net;
        if(cell) {
            auto cls=c.getPortTimingClass(cell,net->driver.port,clocks);row["timing_class"]=int(cls);
            row["native_hints"]=hints(c,timing,CellPortKey(net->driver));J::array ports,clock_rows;
            if(cls==TMG_REGISTER_OUTPUT) for(int i=0;i<clocks;++i){auto ci=c.getPortClockingInfo(cell,net->driver.port,i);auto *clk=cell->getPort(ci.clock_port);
                clock_rows.push_back(J::object{{"port",ci.clock_port.str(&c)},{"net",clk?clk->name.str(&c):""},
                    {"state",int(cell->get_pin_state(ci.clock_port))},{"edge",int(ci.edge)},
                    {"period",clk&&clk->clkconstr?J(clk->clkconstr->period.maxDelay()):J()}});}
            row["clocks"]=clock_rows;
            int width=cell->type==id_MISTRAL_ALUT6?6:cell->type==id_MISTRAL_ALUT5?5:cell->type==id_MISTRAL_ALUT4?4:
                cell->type==id_MISTRAL_ALUT3?3:cell->type==id_MISTRAL_ALUT2?2:cell->type==id_MISTRAL_BUF?1:0;
            bool arithmetic=cell->type==id_MISTRAL_ALUT_ARITH;
            if((width||arithmetic)&&cls==TMG_COMB_OUTPUT){
                auto pins=arithmetic?std::vector<IdString>{id_A,id_B,id_C,id_D0,id_D1,id_CI}:std::vector<IdString>(inputs.begin(),inputs.begin()+width);
                for(auto pin:pins){DelayQuad delay;bool arc=c.getCellDelay(cell,pin,net->driver.port,delay);auto *up=cell->getPort(pin);
                    ports.push_back(J::object{{"pin",pin.str(&c)},{"state",int(cell->get_pin_state(pin))},
                        {"net",up?up->name.str(&c):""},{"native_arc",arc}});if(up&&arc)self(self,up,depth+1);}
            } else terminals.push_back(row);
            row["inputs"]=ports;
        }else terminals.push_back(row);
        nets.push_back(row);visiting.erase(net);done.insert(net);
    };
    walk(walk,root,0);return J::object{{"nets",nets},{"terminal_origins",terminals},{"unique_nets",int(done.size())},
        {"truncated",truncated},{"diagnostic_visits",int(work)},{"maximum_depth",int(maxdepth)}};
}

static J downstream_inventory(Context &c,TimingAnalyser &timing,const std::vector<NetInfo*> &roots) {
    std::set<NetInfo*> done,visiting;std::set<CellPortKey> captures;J::array leaves;unsigned work=0;
    auto walk=[&](auto &&self,NetInfo *net,unsigned depth)->void {
        if(!net||depth>64||++work>4096)throw std::runtime_error("inventory bound");
        if(visiting.count(net))throw std::runtime_error("inventory cycle");
        if(!done.insert(net).second)return;visiting.insert(net);
        if(net->users.entries()==0) {
            auto *cell=net->driver.cell;if(!cell||cell->type!=id_MISTRAL_ALUT_ARITH)throw std::runtime_error("unexpected unused output");
            unsigned refs=0;J::array ports;for(const auto &kv:c.cells)for(const auto &p:kv.second->ports)if(p.second.net==net)++refs;
            for(const auto &p:c.ports)if(p.second.net==net)ports.push_back(p.first.str(&c));
            int clocks=0;auto cls=c.getPortTimingClass(cell,net->driver.port,clocks);
            leaves.push_back(J::object{{"net",net->name.str(&c)},{"driver",cell->name.str(&c)},
                {"port",net->driver.port.str(&c)},{"users",int(net->users.entries())},{"cell_port_references",int(refs)},
                {"public_ports",ports},{"route_wires",int(net->wires.size())},{"global",net->is_global},
                {"clock_constraint",bool(net->clkconstr)},{"net_region",bool(net->region)},{"cell_region",bool(cell->region)},
                {"pin_state",int(cell->get_pin_state(net->driver.port))},{"timing_class",int(cls)},{"native_clocks",clocks},
                {"canonical_driver",cell->getPort(net->driver.port)==net}});
        } else for(const auto &user:net->users) {
            auto *cell=user.cell;int count=0;auto cls=c.getPortTimingClass(cell,user.port,count);
            if(cell->type.in(id_MISTRAL_FF,id_MISTRAL_M10K)&&cls==TMG_REGISTER_INPUT&&count>0)captures.insert(CellPortKey(user));
            else if(cell->type.in(id_MISTRAL_ALUT2,id_MISTRAL_ALUT3,id_MISTRAL_ALUT4,id_MISTRAL_ALUT5,id_MISTRAL_ALUT6,id_MISTRAL_ALUT_ARITH,id_MISTRAL_BUF)&&cls==TMG_COMB_INPUT) {
                for(const auto &p:cell->ports)if(p.second.type==PORT_OUT&&p.second.net) {DelayQuad d;
                    if(c.getCellDelay(cell,user.port,p.first,d))self(self,p.second.net,depth+1);
                }
            }else throw std::runtime_error("unexpected observer "+cell->name.str(&c)+"/"+user.port.str(&c));
        }
        visiting.erase(net);
    };
    for(auto *root:roots)walk(walk,root,0);
    J::array endpoints;for(auto key:captures){std::vector<EndpointClockPairTiming> rs;bool available=timing.get_endpoint_clock_pair_timings(key,rs);J::array rows;
        for(const auto &r:rs)rows.push_back(J::object{{"launch",r.launch.clock.str(&c)},{"launch_edge",int(r.launch.edge)},
            {"capture",r.capture.clock.str(&c)},{"capture_edge",int(r.capture.edge)},
            {"setup_timed",r.setup_timed},{"hold_related",r.hold_related},
            {"setup_window",r.setup_window?J(*r.setup_window):J()},{"setup_margin",r.setup_margin?J(*r.setup_margin):J()},
            {"hold_margin",r.hold_margin?J(*r.hold_margin):J()},{"min_path",double(r.min_path_delay)},{"max_path",double(r.max_path_delay)}});
        endpoints.push_back(J::object{{"cell",key.cell.str(&c)},{"port",key.port.str(&c)},{"available",available},{"rows",rows}});
    }
    return J::object{{"capture_count",int(captures.size())},{"captures",endpoints},{"unused_arithmetic_outputs",leaves},
        {"unique_nets",int(done.size())},{"visits",int(work)}};
}
int main(int argc,char **argv){try{
    if(argc!=3)throw std::runtime_error("probe placed.json report.json");
    ArchArgs args;args.device="5CSEBA6U23I7";Context c(args);std::ifstream in(argv[1]);
    if(!parse_json(in,argv[1],&c))throw std::runtime_error("parse failed");
    if(c.attrs.at(id_step).as_string()!="place")throw std::runtime_error("requires placed checkpoint");
    c.restore_placed_pin_maps();c.lab_pre_route();
    const std::string mda="system.machine.isa.slots[2].genblk1.mda.card.card.mode_MISTRAL_ALUT5_A_E_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_Q";
    const std::string consumer="system.machine.isa.slots[2].genblk1.mda.card.card.mode_MISTRAL_ALUT5_A_E_MISTRAL_ALUT5_Q";
    const std::string cga="system.machine.isa.slots[1].cga.card.card.pixel_MISTRAL_ALUT6_Q_F_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_Q_1";
    auto *p=c.cells.at(c.id(mda)).get(),*q=c.cells.at(c.id(consumer)).get(),*g=c.cells.at(c.id(cga)).get();
    if(p->type!=id_MISTRAL_ALUT3||q->type!=id_MISTRAL_ALUT5||g->type!=id_MISTRAL_ALUT3)throw std::runtime_error("target type changed");
    if(c.getBelName(p->bel).str(&c)!="MISTRAL_COMB.27.18.6"||c.getBelName(q->bel).str(&c)!="MISTRAL_COMB.17.18.24"||c.getBelName(g->bel).str(&c)!="MISTRAL_COMB.18.9.13")throw std::runtime_error("target BEL changed");
    std::map<std::string,NetInfo*> source_signals;
    for(auto *cell:{p,q})for(const auto &port:cell->ports)if(port.second.type==PORT_IN&&port.second.net&&port.second.net!=p->getPort(id_Q))source_signals[port.second.net->name.str(&c)]=port.second.net;
    std::vector<NetInfo*> mda_sources;for(const auto &s:source_signals)mda_sources.push_back(s.second);
    if(mda_sources.size()!=7||p->getPort(id_Q)->users.entries()!=1)throw std::runtime_error("pair inputs changed");
    J::array analyses;bool all=true;
    for(bool skew:{false,true}) {TimingAnalyser timing(&c);timing.with_clock_skew=skew;timing.setup(false,false,true);J::array targets;
        for(bool is_mda:{true,false}) {
            auto *cell=is_mda?p:g;std::string sr;bool source=is_mda?critical_routed_private_pair_common_launch(&c,timing,mda_sources,&sr):critical_lut_permutation_source_coverage(&c,timing,g,&sr);
            std::vector<NetInfo*> roots=is_mda?mda_sources:std::vector<NetInfo*>{g->getPort(id_A),g->getPort(id_B),g->getPort(id_C)};
            roots.push_back((is_mda?q:g)->getPort(id_Q));J::array coverage;bool covered=true,strict=true;
            for(auto *net:roots){std::string a,b;bool old=critical_lut6_swap_output_coverage(&c,timing,net,&a),opt=critical_output_coverage_with_unobserved_arithmetic(&c,timing,net,&b);
                covered&=opt;strict&=old;coverage.push_back(J::object{{"net",net->name.str(&c)},{"strict_coverage",old},{"strict_reason",a},{"opt_in_coverage",opt},{"opt_in_reason",b}});}
            bool legal=c.isBelLocationValid(cell->bel,true)&&(!is_mda||c.isBelLocationValid(q->bel,true));
            all&=source&&covered&&legal&&!strict&&!timing.have_loops;
            targets.push_back(J::object{{"kind",is_mda?"mda_private_pair":"cga_permutation"},{"cell",cell->name.str(&c)},
                {"bel",c.getBelName(cell->bel).str(&c)},{"source_coverage",source},{"source_reason",sr},{"all_opt_in_output_coverage",covered},
                {"all_strict_output_coverage",strict},{"native_location_legal",legal},{"frontiers",coverage},
                {"source_inventory",inventory(c,timing,(is_mda?q:g)->getPort(id_Q))},{"downstream_inventory",downstream_inventory(c,timing,roots)}});
        }
        analyses.push_back(J::object{{"with_clock_skew",skew},{"have_loops",timing.have_loops},{"targets",targets}});
    }
    int mismatches=0;for(const auto &kv:c.cells){auto *cell=kv.second.get();if(cell->type==id_MISTRAL_FF&&
        (cell->ffInfo.datain!=cell->getPort(id_DATAIN)||cell->ffInfo.sdata!=cell->getPort(id_SDATA)))++mismatches;}
    std::ofstream out(argv[2]);out<<J(J::object{{"scope","host-only native route preparation and predicted full-STA coverage; no actual route, transaction, gain or timing signoff"},
        {"analyses",analyses},{"all_selected_native_coverage_and_legality",all},{"all_ff_cache_mismatches",mismatches}}).dump()<<"\n";return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<"\n";return 1;}}
