#!/usr/bin/env python3
import hashlib,json,subprocess,time,shlex
from pathlib import Path
R=Path(__file__).resolve().parent; P=R.parent; TASK=P.parent
BUILD=Path('/home/deano/harnesses/pcxt-compiler-repair/build-candidate')
SRC=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
identity=json.loads((P/'source-validation/final-host/build-identity.json').read_text())
source=json.loads((P/'source-validation/final-host/source-identity.json').read_text())
binary=BUILD/'nextpnr-mistral'; assert sha(binary)==identity['production_sha256']
for p,x in source['files'].items():assert sha(SRC/p)==x['sha256']
old=json.loads((TASK/'lut6-upstream-coverage-20261022/build-plan.json').read_text())
oldroot=str(TASK/'lut6-upstream-coverage-20261022')
compile=[x.replace(oldroot,str(R)) for x in old['compile']]
command_lines=subprocess.check_output(['ninja','-t','commands','nextpnr-mistral'],cwd=BUILD,text=True).splitlines()
raw=shlex.split(command_lines[-1]);assert raw[:2]==[':','&&'] and raw[-2:]==['&&',':']
link=raw[2:-2];main=[x for x in link if x.endswith('/main.cc.o')];assert len(main)==1
link.remove(main[0]);link.insert(link.index('-o'),str(R/'probe.o'));link[link.index('-o')+1]=str(R/'native-probe')
link=[str((BUILD/x).resolve()) if x.endswith(('.o','.a')) and not Path(x).is_absolute() else x for x in link]
link=[x for x in link if not x.startswith('-flto') and not x.startswith('-Wl,--dependency-file=')]+['-flto=2']
objects={x:sha(x) for x in link if x.endswith(('.o','.a')) and Path(x).exists() and Path(x).parent!=R}
input=P/'prepare-default/placed.json'
assert sha(input)=='432bf63c4bfdf193d2c67dde23e3269b9d362efb719d735527759dc3b058d03c'
plan={'compile':compile,'link':link,'object_hashes':objects,'source_files':source['files'],
 'build_identity_sha256':sha(P/'source-validation/final-host/build-identity.json'),'source_identity_sha256':sha(P/'source-validation/final-host/source-identity.json'),
 'source_sha256':sha(R/'probe.cc'),'input':str(input),'input_sha256':sha(input),'binary_sha256':sha(binary)}
(R/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
start=time.monotonic(); receipt={'scope':'host-only admission probe; no placement or routing','commands':[],'charged_seconds':0}
with (R/'build.log').open('w') as log:
 for cmd in (compile,link):
  rc=subprocess.run(cmd,cwd=BUILD,stdout=log,stderr=subprocess.STDOUT).returncode;receipt['commands'].append({'argv':cmd,'returncode':rc})
  if rc:break
if not rc:
 cmd=[str(R/'native-probe'),str(input),str(R/'result.json')]
 with (R/'probe.log').open('w') as log:rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 receipt['commands'].append({'argv':cmd,'returncode':rc})
receipt['elapsed_seconds']=time.monotonic()-start
for p,h in objects.items():assert sha(p)==h
for p,x in source['files'].items():assert sha(SRC/p)==x['sha256']
assert sha(binary)==identity['production_sha256'] and sha(input)==plan['input_sha256']
receipt.update({'returncode':rc,'plan_sha256':sha(R/'build-plan.json'),'objects_unchanged':True,'source_unchanged':True,
 'files':{p.name:sha(p) for p in R.iterdir() if p.is_file() and p.name not in ('receipt.json','probe.o')}})
(R/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(rc,receipt['elapsed_seconds'],flush=True)
if rc:raise SystemExit(rc)
r=json.loads((R/'result.json').read_text())
for a in r['analyses']:
 for t in a['targets']:print(a['with_clock_skew'],t['kind'],t['source_coverage'],t['source_reason'],t['all_opt_in_output_coverage'],t['native_location_legal'],flush=True)
