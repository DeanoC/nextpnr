#!/usr/bin/env python3
"""Freeze and build reviewed host-only coverage extension; no FPGA route."""
from pathlib import Path
import hashlib,json,shutil,subprocess,time
HERE=Path(__file__).resolve().parent;EVIDENCE=HERE.parents[1]
ROOT=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');BUILD=ROOT.parent/'build-candidate'
FILES=['mistral/routed_lut6_swap.cc','mistral/analogue_repair.h','mistral/arch.h','mistral/main.cc',
'mistral/private_pair_decomposition.cc','mistral/routed_lut_permutation.cc','mistral/CMakeLists.txt',
'mistral/tests/unobserved_arithmetic_coverage.cc','mistral/tests/unobserved_arithmetic_cli.py',
'docs/mistral-unobserved-arithmetic-coverage.md']
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert not (HERE/'source-identity.json').exists()
records={}
for name in FILES:
 p=ROOT/name;q=HERE/'source'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 records[name]={'sha256':sha(p),'size':p.stat().st_size}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
source={'base':head,'observed_head':head,'files':records}
(HERE/'source-identity.json').write_text(json.dumps(source,indent=2,sort_keys=True)+'\n')
cmd=['cmake','--build',str(BUILD),'--target','nextpnr-mistral','nextpnr-mistral-test','-j8']
t=time.monotonic()
with (HERE/'build.log').open('w') as f:rc=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT).returncode
receipt={'command':cmd,'returncode':rc,'elapsed_seconds':time.monotonic()-t,'log_sha256':sha(HERE/'build.log')}
(HERE/'build.receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
assert rc==0,receipt
assert all(sha(ROOT/f)==r['sha256'] for f,r in records.items())
identity={'source_identity_sha256':sha(HERE/'source-identity.json'),'production_sha256':sha(BUILD/'nextpnr-mistral'),
'native_test_sha256':sha(BUILD/'nextpnr-mistral-test'),'observed_head':head}
(HERE/'build-identity.json').write_text(json.dumps(identity,indent=2,sort_keys=True)+'\n')
shutil.copyfile(BUILD/'nextpnr-mistral',EVIDENCE/'nextpnr-mistral');(EVIDENCE/'nextpnr-mistral').chmod(0o755)
print(json.dumps(identity),flush=True)
