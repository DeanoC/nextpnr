#!/usr/bin/env python3
"""Bounded native/CLI validation against one immutable production/test object set."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,re,subprocess,sys,time
HERE=Path(__file__).resolve().parent;EVIDENCE=HERE.parents[1]
ROOT=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');BUILD=ROOT.parent/'build-candidate'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
source=json.loads((HERE/'source-identity.json').read_text());identity=json.loads((HERE/'build-identity.json').read_text())
exe=BUILD/'nextpnr-mistral';test=BUILD/'nextpnr-mistral-test'
def unchanged():
 return (all(sha(ROOT/f)==r['sha256'] for f,r in source['files'].items()) and
 sha(exe)==identity['production_sha256'] and sha(test)==identity['native_test_sha256'] and
 sha(EVIDENCE/'nextpnr-mistral')==identity['production_sha256'])
assert unchanged()
def run(name,cmd,count,native):
 log=HERE/(name+'.log');assert not log.exists();t=time.monotonic()
 with log.open('w') as f:rc=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT).returncode
 data=log.read_text();pattern=r'\[  PASSED  \] (\d+) tests?\.' if native else r'Ran (\d+) tests? in'
 matches=re.findall(pattern,data);observed=int(matches[-1]) if matches else 0
 r={'name':name,'command':cmd,'cwd':str(ROOT),'returncode':rc,'elapsed_seconds':time.monotonic()-t,
 'log_sha256':sha(log),'expected_count':count,'observed_count':observed,'pass':rc==0 and observed==count}
 (HERE/(name+'.receipt.json')).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r),flush=True);return r
native=[('unobserved-arithmetic','*UnobservedArithmeticCoverage*',12),('source-coverage','RoutedLut6SourceCoverage.*',6),
('lut6-native','RoutedLut6SwapCoverage.*:*RoutedLut6SwapBackend.*:*PrivatePairBackend.CompleteMultiCaptureCoverageRejectsHiddenUnsupportedAndPublicBranches*',33),
('permutation-native','*RoutedLutPermutation*',45),('private-pair-native','*PrivatePair*',77)]
results=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,name,[str(test),'--gtest_filter='+filter],count,True) for name,filter,count in native]
 results.extend(f.result() for f in futures)
if all(x['pass'] for x in results):
 cli=[('unobserved-cli','unobserved_arithmetic_cli.py',6),('lut6-cli','routed_lut6_swap_cli.py',6),
      ('permutation-cli','routed_lut_permutation_cli.py',6),('private-pair-cli','routed_private_pair_cli.py',6)]
 with ThreadPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(run,name,[sys.executable,str(ROOT/'mistral/tests'/file),str(exe),'-v'],count,False) for name,file,count in cli]
  results.extend(f.result() for f in futures)
valid=unchanged()
r={'build_identity_sha256':sha(HERE/'build-identity.json'),'results':results,'sources_and_binaries_unchanged':valid,
'pass':valid and len(results)==9 and all(x['pass'] for x in results)}
(HERE/'validation.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r),flush=True)
sys.exit(0 if r['pass'] else 1)
