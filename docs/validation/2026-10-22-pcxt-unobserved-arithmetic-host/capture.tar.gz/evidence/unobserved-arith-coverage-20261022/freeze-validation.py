#!/usr/bin/env python3
"""Consolidate immutable host evidence for three independent diagnostic full routes."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
R=Path(__file__).resolve().parent;F=R/'source-validation/final-host';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');OLD=R.parent/'routed-lut-permutation-20261022'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
initial=read(R/'source-identity.json');source=read(F/'source-identity.json');build=read(F/'build-identity.json');old=read(OLD/'final-validation.json')
assert sha(OLD/'final-validation.json')=='f57472babbd03cbaf141cc3f7aed9403bc8ecee8a6908b71e528682a1de74de6'
assert sha(F/'source-identity.json')==build['source_identity_sha256']
assert sha(R/'nextpnr-mistral')==build['production_sha256']=='7faa854df524d0dd3a69cf90622b589692d2db078c031a36ac2c7a5d0deadf12'
assert set(source['files'])==set(initial['files'])
changed=[p for p in source['files'] if source['files'][p]['sha256']!=initial['files'][p]['sha256']]
assert changed==['mistral/tests/unobserved_arithmetic_coverage.cc'],changed
assert source['files'][changed[0]]['sha256']=='fbb4e22f4c0676e9b6f868069f2264a057e59e06ea63c25a01f781b5005022d3'
correction=read(F/'compile-correction.json');assert correction['production_unchanged'] and correction['changed_files']==changed
assert correction['initial_source_identity_sha256']==sha(R/'source-identity.json')
assert correction['initial_build_receipt_sha256']==sha(R/'source-validation/build.receipt.json')
initial_build=read(R/'source-validation/build.receipt.json');assert initial_build['returncode']!=0 and initial_build['log_sha256']==sha(R/'source-validation/build.log')
sources=dict(old['source_files']);sources.update({p:v['sha256'] for p,v in source['files'].items()})
unchanged={p:h for p,h in old['source_files'].items() if p not in source['files']}
for p,h in sources.items():
 assert sha(S/p)==h,(p,'live source differs')
 dest=R/'complete-source'/p;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==h
 else:shutil.copy2(S/p,dest)
for p,h in unchanged.items():assert hashlib.sha256(subprocess.check_output(['git','show','a17e0ce3762b78a30cbfd41c8615be9a9b4fc727:'+p],cwd=S)).hexdigest()==h
write(R/'retained-source-proof.json',{'earlier_commit':'a17e0ce3762b78a30cbfd41c8615be9a9b4fc727','earlier_final_validation_sha256':sha(OLD/'final-validation.json'),
 'unchanged_source_files':unchanged,'scope':'Only the expressly logged suites rerun on this binary; previous cache8 retains its original972 provenance.'})
summary=read(F/'validation.json');assert summary['pass'] and summary['sources_and_binaries_unchanged']
assert summary['build_identity_sha256']==sha(F/'build-identity.json')
counts={'unobserved-arithmetic':12,'source-coverage':6,'lut6-native':33,'permutation-native':45,'private-pair-native':77,
 'unobserved-cli':6,'lut6-cli':6,'permutation-cli':6,'private-pair-cli':6}
assert set(x['name'] for x in summary['results'])==set(counts)
for name,count in counts.items():
 rec=read(F/(name+'.receipt.json'));log=F/(name+'.log');assert rec['returncode']==0 and rec['pass'] and rec['observed_count']==rec['expected_count']==count and sha(log)==rec['log_sha256']
 text=log.read_text()
 if name.endswith('-cli'):assert re.search(r'Ran '+str(count)+r' tests? in',text) and re.search(r'\nOK\s*$',text)
 else:assert re.search(r'\[\s+PASSED\s+\]\s+'+str(count)+r' tests?\.',text)
control=read(R/'control-proof.json');assert control['default_zero_raw_bytes_equal']
assert sorted(x['case'] for x in control['controls'])==['default','zero']
for x in control['controls']:
 assert all(x[k] for k in ('complete_modules_equal','all_bytes_except_creator_equal','predicted_timing_bytes_equal'))
 folder=R/('prepare-'+x['case']);receipt=read(folder/'receipt.json');assert receipt['returncode']==0 and receipt['binary_sha256']==build['production_sha256']
 for p,h in receipt['artifacts'].items():assert sha(folder/p)==h
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
board=read(R/'board-eligibility/proof.json');assert board['passed'] and len(board['proofs'])==4
assert board['result_sha256']==sha(R/'board-eligibility/result.json') and board['receipt_sha256']==sha(R/'board-eligibility/receipt.json')
assert board['checker_sha256']==sha(R/'board-eligibility/check.py')
revision=read(R/'board-eligibility/checker-evolution/revision.json')
assert revision['original_receipt_sha256']==sha(R/'board-eligibility/receipt.json') and revision['current_checker_sha256']==board['checker_sha256'] and revision['current_proof_sha256']==sha(R/'board-eligibility/proof.json')
for name,h in read(R/'board-eligibility/receipt.json')['files'].items():
 artifact=R/'board-eligibility'/('checker-evolution/original-check.py' if name=='check.py' else name)
 assert sha(artifact)==h,(name,'native receipt artifact changed')
subprocess.run(['python3',str(R/'board-eligibility/check.py')],check=True,stdout=subprocess.DEVNULL)
assert board==read(R/'board-eligibility/proof.json')
review_source=R.parent/'unused-arith-leaf-review-20261022/installed-source-review.json'
assert sha(review_source)==sha(R/'installed-source-review.json')=='00315b2991956a8ff5644b4aa543d78643e43b99acbd7665583a696bea7ed82d'
# Board/control review is independent of the source reviewer receipt above.
root_replay=read(R/'board-eligibility/root-native-replay/receipt.json')
assert root_replay['status']=='pass' and root_replay['returncode']==0 and root_replay['complete_result_bytes_equal'] and root_replay['strengthened_proof_bytes_equal']
assert root_replay['result_sha256']==sha(R/'board-eligibility/result.json')==sha(R/'board-eligibility/root-native-replay/result.json')
assert root_replay['original_receipt_sha256']==sha(R/'board-eligibility/receipt.json') and root_replay['checker_revision_sha256']==sha(R/'board-eligibility/checker-evolution/revision.json')
board_review=R/'independent-host-review.json';review=read(board_review)
assert review['passed'] and review['board_proof_sha256']==sha(R/'board-eligibility/proof.json') and review['control_proof_sha256']==sha(R/'control-proof.json')
retention=read(R/'strict-lut6-retention/proof.json')
assert retention['passed'] and retention['current_file_sha256']==sources['mistral/routed_lut6_swap.cc'] and retention['script_sha256']==sha(R/'prove-strict-lut6-retention.py')
files={}
for prefix in ('source','source-validation','complete-source','prepare-default','prepare-zero','board-eligibility','strict-lut6-retention'):
 for p in sorted((R/prefix).rglob('*')):
  if p.is_file() and p.name not in ('nextpnr-mistral','nextpnr-mistral-test','native-probe','probe.o'):
   files[str(p.relative_to(R))]=sha(p)
for name in ('README.md','freeze-source.py','source-identity.json','source.patch','prepare-controls.py','prepare-controls.log','control-proof.json','retained-source-proof.json','freeze-validation.py','independent-host-review.json','installed-source-review.json','prove-strict-lut6-retention.py'):
 p=R/name
 if p.exists():files[name]=sha(p)
final={'scope':'Host-only native transaction, complete source/capture coverage and disabled-behavior validation. Independent full routes are authorized diagnostic experiments, not completed routed timing or hardware acceptance.',
 'binary_sha256':build['production_sha256'],'native_test_sha256':build['native_test_sha256'],'source_parent':source['base'],'source_files':sources,
 'corrected_source_identity_path':str(F/'source-identity.json'),'corrected_source_identity_sha256':sha(F/'source-identity.json'),
 'control_proof_sha256':sha(R/'control-proof.json'),'enabled_lut6_route_admission':True,'enabled_unobserved_arithmetic_route_admission':True,
 'enabled_lut_permutation_route_admission':True,'enabled_private_pair_route_admission':True,
 'admission_boundary':'All native and CLI gates plus actual-target host source/output coverage and native legality passed. Fresh routed discovery/trials and complete dual-frame timing/nonregression guards remain mandatory; no predicted gain or physical acceptance asserted.',
 'validation':{'passed':True,'unobserved_arithmetic_count':12,'source_coverage_count':6,'lut6_native_count':33,'lut_permutation_native_count':45,'private_pair_native_count':77,
 'unobserved_arithmetic_cli_count':6,'lut6_cli_count':6,'lut_permutation_cli_count':6,'private_pair_cli_count':6},
 'retained_prior_validation':{'path':str(OLD/'final-validation.json'),'sha256':sha(OLD/'final-validation.json'),'unchanged_source_proof_sha256':sha(R/'retained-source-proof.json'),'rerun_claim':'All five native groups173 tests and four CLI groups24 tests reran on this binary; previous cache8 retains its original972 provenance.'},
 'strict_lut6_retention_sha256':sha(R/'strict-lut6-retention/proof.json'),
 'source_review':{'path':str(review_source),'sha256':sha(review_source)},'host_review_sha256':sha(board_review),
 'initial_compile_failure':{'source_identity_sha256':sha(R/'source-identity.json'),'build_receipt_sha256':sha(R/'source-validation/build.receipt.json'),'reason':'New test indexed_store::add initializer needed explicit PortRef type; production unchanged, corrected build and complete validation retained separately.'},
 'actual_board_scope':{'proof_sha256':sha(R/'board-eligibility/proof.json'),'mda_capture_count':64,'mda_unused_leaf_count':2,'cga_capture_count':66,'cga_unused_leaf_count':6,'frames':'predicted skewed and reference-free full STA; never reload-routed STA signoff'},'files':files}
assert not (R/'final-validation.json').exists()
write(R/'final-validation.json',final);print(sha(R/'final-validation.json'))
