#!/usr/bin/env python3
"""Source retention boundaries; optional-output refactor is covered by independent review and native tests."""
from pathlib import Path
import hashlib,json,subprocess
R=Path(__file__).resolve().parent;S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(b):return hashlib.sha256(b).hexdigest()
commit='a17e0ce3762b78a30cbfd41c8615be9a9b4fc727'
old=subprocess.check_output(['git','show',commit+':mistral/routed_lut6_swap.cc'],cwd=S)
new=(S/'mistral/routed_lut6_swap.cc').read_bytes()
old_start=old.index(b'bool critical_lut6_swap_output_coverage(')
new_start=new.index(b'namespace {\nbool output_coverage(')
assert old[:old_start]==new[:new_start]
marker=b'bool critical_routed_lut6_swap_trial('
a=old[old.index(marker):];b=new[new.index(marker):];assert a==b
strict=b'''bool critical_lut6_swap_output_coverage(Context *ctx,TimingAnalyser &timing,NetInfo *output,std::string *reason)
{
    return output_coverage(ctx,timing,output,false,reason);
}'''
assert new.count(strict)==1
assert b'critical_output_coverage_with_unobserved_arithmetic' not in b
out=R/'strict-lut6-retention';out.mkdir(exist_ok=True)
(out/'prior-routed_lut6_swap.cc').write_bytes(old)
identity=json.loads((R/'source-validation/final-host/source-identity.json').read_text())
assert sha(new)==identity['files']['mistral/routed_lut6_swap.cc']['sha256']
result={'passed':True,'base':commit,'prior_file_sha256':sha(old),'current_file_sha256':sha(new),
 'all_source_coverage_inspection_and_helpers_prefix_byte_exact':True,'prefix_sha256':sha(old[:old_start]),
 'all_lut6_transaction_and_orchestration_suffix_byte_exact':True,'suffix_sha256':sha(a),
 'strict_output_wrapper_literal_false':True,'optional_wrapper_absent_from_lut6_transaction_and_orchestration':True,
 'scope':'Exact source retention outside the output-coverage extraction. The shared output helper refactor is not claimed byte-identical or formally equivalent here; independent source review and current strict/source native/CLI regressions establish its bounded retained behavior.',
 'script_sha256':sha(Path(__file__).read_bytes())}
(out/'proof.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(sha((out/'proof.json').read_bytes()))
