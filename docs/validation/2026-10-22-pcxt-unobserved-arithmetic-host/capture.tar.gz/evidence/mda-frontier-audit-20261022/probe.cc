// Structural native checkpoint inspection only. No timing analysis or route changes.
#include "nextpnr.h"
#include "json_frontend.h"
#include "json11.hpp"
#include <fstream>
#include <iostream>
#include <set>
#include <map>
#include <stdexcept>
USING_NEXTPNR_NAMESPACE
using J=json11::Json;
int main(int argc,char **argv){try{
 if(argc!=3)throw std::runtime_error("expected routed.json result.json");
 ArchArgs args;args.device="5CSEBA6U23I7";Context c(args);std::ifstream in(argv[1]);
 if(!parse_json(in,argv[1],&c))throw std::runtime_error("parse failed");
 if(c.attrs.at(id_step).as_string()!="route")throw std::runtime_error("requires saved route");
 c.restore_placed_pin_maps(); // architecture metadata only; no route or timing preparation
 auto *p=c.cells.at(c.id("system.machine.isa.slots[2].genblk1.mda.card.card.mode_MISTRAL_ALUT5_A_E_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_Q")).get();
 if(p->type!=id_MISTRAL_ALUT3||p->getPort(id_Q)->users.entries()!=1)throw std::runtime_error("producer changed");
 auto *consumer=(*p->getPort(id_Q)->users.begin()).cell;
 if(consumer->type!=id_MISTRAL_ALUT5)throw std::runtime_error("consumer changed");
 std::map<std::string,NetInfo*> roots;
 for(auto *cell:{p,consumer})for(const auto &port:cell->ports)if(port.second.type==PORT_IN&&port.second.net!=p->getPort(id_Q))roots[port.second.net->name.str(&c)]=port.second.net;
 if(roots.size()!=7)throw std::runtime_error("expected seven external inputs");
 roots[consumer->getPort(id_Q)->name.str(&c)]=consumer->getPort(id_Q);
 J::array reports;
 for(const auto &root:roots){std::set<NetInfo*> done;std::set<std::pair<std::string,std::string>> captures;J::array boundaries,nets;
  auto walk=[&](auto &&self,NetInfo *net,J::array path)->void{
   if(!net||!done.insert(net).second)return;
   if(done.size()>4096)throw std::runtime_error("bound");
   J::array public_ports;for(const auto &port:c.ports)if(port.second.net==net)public_ports.push_back(port.first.str(&c));
   auto *driver=net->driver.cell;int nclocks=0;int timing_class=driver?int(c.getPortTimingClass(driver,net->driver.port,nclocks)):-1;
   J::object row{{"net",net->name.str(&c)},{"users",int(net->users.entries())},{"global",net->is_global},
    {"clock_constraint",bool(net->clkconstr)},{"public_ports",public_ports},{"driver",driver?driver->name.str(&c):""},
    {"driver_type",driver?driver->type.str(&c):""},{"driver_port",net->driver.port.str(&c)},
    {"driver_backreference",driver&&driver->getPort(net->driver.port)==net},{"driver_timing_class",timing_class},
    {"driver_clock_count",nclocks},{"route_wire_count",int(net->wires.size())},{"path",path}};
   nets.push_back(row);
   if(net->is_global||net->clkconstr||!driver||!net->users.entries()||!public_ports.empty()){boundaries.push_back(row);return;}
   for(const auto &user:net->users){auto *cell=user.cell;int nc=0;auto kind=c.getPortTimingClass(cell,user.port,nc);
    auto next=path;next.push_back(J::object{{"cell",cell->name.str(&c)},{"input",user.port.str(&c)}});
    bool comb=cell->type.in(id_MISTRAL_ALUT2,id_MISTRAL_ALUT3,id_MISTRAL_ALUT4,id_MISTRAL_ALUT5,id_MISTRAL_ALUT6,id_MISTRAL_ALUT_ARITH,id_MISTRAL_BUF);
    if(comb&&kind==TMG_COMB_INPUT){for(const auto &out:cell->ports)if(out.second.type==PORT_OUT&&out.second.net){auto opath=next;opath.push_back(J::object{{"cell",cell->name.str(&c)},{"output",out.first.str(&c)}});self(self,out.second.net,opath);}}
    else if(cell->type.in(id_MISTRAL_FF,id_MISTRAL_M10K)&&kind==TMG_REGISTER_INPUT&&nc>0)captures.emplace(cell->name.str(&c),user.port.str(&c));
    else throw std::runtime_error("unsupported structural observer: "+cell->name.str(&c)+"/"+user.port.str(&c));
   }
  };
  walk(walk,root.second,{});J::array cap;for(const auto &p:captures)cap.push_back(J::array{p.first,p.second});
  reports.push_back(J::object{{"root",root.first},{"nets",nets},{"rejecting_boundaries",boundaries},{"native_capture_identities",cap}});
 }
 std::ofstream out(argv[2]);out<<J(J::object{{"scope","native structural reload only; no STA, route, eligibility override or timing acceptance"},{"frontiers",reports}}).dump()<<"\n";return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<"\n";return 1;}}
