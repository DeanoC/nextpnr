# Why the routed MDA private pair was filtered

The frozen 243/e94f private4 full route correctly retained its zero-trial result. Complete graph tracing finds two connected, unused arithmetic outputs reachable from the MDA pair's external dot-counter sources. The generic output-coverage walk rejects zero-user outputs before timing-row checks. This evidence does not change that guard or establish eligibility for a future revision.

All seven external source nets and the consumer output were inventoried, retaining every alias, driver, user, top-port observer, and saved endpoint row. Their union still contains exactly 64 FF capture identities, with two failing rows, minimum setup −328 ps and minimum related hold +942 ps. That part of the prior host audit was correct. Its `downstream()` function silently stopped at empty `use_map[bit]`, so it omitted two additional empty output boundaries. The earlier statement that there was no unsupported structural boundary was incomplete as evidence for the stricter native walk. The original audit remains unchanged; this is its explicit correction.

Both empty nets belong to ordinary `MISTRAL_ALUT_ARITH` cells in the MDA dot counter:

| Saved bit | Driver suffix and output | Reachable external roots |
| --- | --- | --- |
|57447|`dot_MISTRAL_FF_Q_1_DATAIN_MISTRAL_ALUT2_Q_B_MISTRAL_ALUT_ARITH_SO_CI_MISTRAL_ALUT_ARITH_CO/SO`|dot[0]|
|57464|`dot_MISTRAL_FF_Q_2_DATAIN_MISTRAL_ALUT2_Q_B_MISTRAL_ALUT_ARITH_SO/CO`|dot[0], dot[1], dot[2], dot[3]|

The full common prefix is `system.machine.isa.slots[2].genblk1.mda.card.card.`. Their complete names, aliases, driver cells, physical pin maps and paths are retained in `analysis.json`. The three font-address sources and consumer Q reach four FF captures without an empty branch. The log contains only the generic rejection reason, so it does not identify which of the two empty outputs was visited first in the original live execution.

An independent structural-only native probe loads the unchanged final routed JSON using the retained 972 native object/header snapshot. It restores architecture metadata, walks actual native port timing classes, and confirms both empty nets have exactly one correct arithmetic driver, zero users, no public top-port observer, no global-net flag and no clock constraint. Its capture union exactly matches all 64 saved FF identities. It performs no STA, route preparation, configuration changes, trial or acceptance evaluation. The older native snapshot identity is explicit in `native-receipt.json`; it does not stand in for the frozen 243 live timing run.

This is a real, completely unobserved local output boundary in the captured graph, rather than a public/global/clock observer or missing source model. A future narrowly justified coverage rule could treat an explicitly verified local zero-user output as a terminal with no capture obligation, while retaining checks on its driver identity, every alias/public observer, clock/global status and all sibling outputs. Such a rule would need its own negative tests and source review. No rule is changed here, and the current route remains filtered.

`analyze.py` replays the complete graph/capture proof. `run-probe.py` verifies the full frozen native dependency manifest before linking a separate executable, records exact commands and source/input/binary/result hashes, and never touches the shared build. The first probe compile error and corrected build logs are retained. `native-result.json` is structural evidence only; `analysis.json` binds the actual emitted route timing rows and original filter log separately. No GPU route or hardware ran for this audit.
