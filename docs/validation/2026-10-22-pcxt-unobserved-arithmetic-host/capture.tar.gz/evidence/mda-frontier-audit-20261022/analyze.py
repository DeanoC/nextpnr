#!/usr/bin/env python3
"""Complete saved-graph frontier inventory, retaining empty output boundaries."""
from pathlib import Path
import hashlib,json,collections
R=Path(__file__).resolve().parent;D=R.parent/'routed-private-pair-board-20261022/route-private4';OLD=R.parent/'private-pair-post-route-audit-20261022'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
m=next(iter(json.loads((D/'routed.json').read_text())['modules'].values()));c=m['cells'];ledger=json.loads((D/'endpoints.json').read_text())
u=collections.defaultdict(list);d=collections.defaultdict(list);a=collections.defaultdict(list);public=collections.defaultdict(list)
for n,v in m['netnames'].items():
 for lane,b in enumerate(v['bits']):a[b].append({'name':n,'lane':lane,'complete_net_record':v})
for n,v in m['ports'].items():
 for lane,b in enumerate(v['bits']):public[b].append({'name':n,'lane':lane,'complete_port_record':v})
for n,v in c.items():
 for port,bits in v['connections'].items():
  for lane,b in enumerate(bits):(d if v['port_directions'][port]=='output' else u)[b].append((n,port,lane))
P='system.machine.isa.slots[2].genblk1.mda.card.card.mode_MISTRAL_ALUT5_A_E_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_Q';link=c[P]['connections']['Q'][0];assert len(u[link])==1;C=u[link][0][0]
roots=set(b for name in [P,C] for p,bs in c[name]['connections'].items() if c[name]['port_directions'][p]=='input' for b in bs)-{link}
assert len(roots)==7;roots.add(c[C]['connections']['Q'][0]);reports=[];union=set();empty=set()
for root in sorted(roots):
 seen=set();leaves=set();dead=[];unknown=[];cycles=[];visiting=set()
 def walk(b,path):
  if b in visiting:cycles.append(path);return
  if b in seen:return
  seen.add(b);visiting.add(b)
  if not u[b] or public[b] or not d[b]:
   dead.append({'bit':b,'path':path,'aliases':a[b],'drivers':d[b],'all_users':u[b],'public_ports':public[b],'driver_cells':{n:c[n] for n,p,i in d[b]}})
   if not u[b]:empty.add(b)
  else:
   for n,p,lane in u[b]:
    t=c[n]['type'];step=path+[{'cell':n,'input':p,'lane':lane}]
    if t.startswith('MISTRAL_ALUT') or t=='MISTRAL_BUF':
     for op,bs in c[n]['connections'].items():
      if c[n]['port_directions'][op]=='output':
       for ol,ob in enumerate(bs):walk(ob,step+[{'cell':n,'output':op,'lane':ol}])
    elif t in ['MISTRAL_FF','MISTRAL_M10K']:leaves.add((n,p if len(c[n]['connections'][p])==1 else p+'['+str(lane)+']'))
    else:unknown.append({'cell':n,'port':p,'lane':lane,'type':t,'path':step})
  visiting.remove(b)
 walk(root,[]);rows=[]
 for ep in sorted(leaves):
  keys=[k for k in ledger['endpoints'] if json.loads(k)==list(ep)];assert len(keys)==1,ep
  rows.append({'endpoint':ep,'complete_native_saved_rows':ledger['endpoints'][keys[0]]})
 union.update(leaves)
 reports.append({'root':root,'aliases':a[root],'visited_nets':len(seen),'capture_count':len(leaves),'captures':rows,'rejecting_structural_boundaries':dead,'unknown_observers':unknown,'cycles':cycles})
assert len(union)==64 and len(empty)==2
assert all(not r['unknown_observers'] and not r['cycles'] for r in reports)
assert all(not x['public_ports'] and len(x['drivers'])==1 and not x['all_users'] for r in reports for x in r['rejecting_structural_boundaries'])
rows=[row for ep in union for k,v in ledger['endpoints'].items() if json.loads(k)==list(ep) for row in v]
assert all(r['setup_timed'] and r['hold_related'] for r in rows)
result={'scope':'Complete saved graph and original emitted rows only; native reload probe is structural metadata, not live eligibility or STA',
 'inputs':{str(p):sha(p) for p in [D/'routed.json',D/'endpoints.json',D/'timing.json',D/'nextpnr.log',OLD/'audit.py',OLD/'inventory.json',OLD/'README.md']},
 'producer':P,'consumer':C,'frontiers':reports,'all_capture_identities':sorted(union),'empty_output_bits':sorted(empty),
 'capture_rows':{'count':len(rows),'minimum_setup_ps':min(r['setup'] for r in rows),'minimum_hold_ps':min(r['hold'] for r in rows),'negative_setup_count':sum(r['setup']<0 for r in rows)},
 'native_logged_filters':[l for l in (D/'nextpnr.log').read_text().splitlines() if 'Critical private pair' in l],
 'prior_audit_gap':'downstream() silently terminated when use_map[bit] was empty;64 captured FF boundaries remain correct, but the inventory omitted two unused arithmetic outputs and was incomplete as native eligibility evidence.',
 'script_sha256':sha(__file__)}
if (R/'native-result.json').exists():
 native=json.loads((R/'native-result.json').read_text());assert len(native['frontiers'])==8
 nb={b['net']:b for f in native['frontiers'] for b in f['rejecting_boundaries']};assert len(nb)==2
 assert all(b['users']==0 and not b['global'] and not b['clock_constraint'] and not b['public_ports'] and b['driver_backreference'] and b['driver_type']=='MISTRAL_ALUT_ARITH' for b in nb.values())
 nc={tuple(c) for f in native['frontiers'] for c in f['native_capture_identities']};assert nc==union
 result['native_structural_probe']={'result_sha256':sha(R/'native-result.json'),'receipt_sha256':sha(R/'native-receipt.json'),'boundary_count':len(nb),'complete_capture_identity_match':True,'timing_analysis_performed':False}
(R/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',result['capture_rows'],'empty outputs',len(empty),'native verified', 'native_structural_probe' in result)
