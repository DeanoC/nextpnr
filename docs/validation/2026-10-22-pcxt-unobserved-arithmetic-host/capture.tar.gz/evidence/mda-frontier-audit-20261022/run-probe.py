from pathlib import Path
import hashlib,json,subprocess,time
R=Path(__file__).resolve().parent
F=R.parent/'cga-native-pin-audit-20261022'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
identity=json.loads((F/'frozen-manifest.json').read_text())
for original,v in identity['files'].items():assert sha(F/v['copy'])==v['sha256'],original
cmd=json.loads((F/'build-commands.json').read_text())
for key in ['compile','link']:
 cmd[key]=[str(R/'probe.cc') if x==str(F/'probe.cc') else str(R/'probe.o') if x==str(F/'probe.o') else str(R/'native-probe') if x==str(F/'native-probe') else x for x in cmd[key]]
source=R.parent/'routed-private-pair-board-20261022/route-private4/routed.json'
receipt={'scope':'structural-only native probe; frozen972 native metadata model, not243 live STA','frozen_manifest_sha256':sha(F/'frozen-manifest.json'),'frozen_native_identity':{k:v for k,v in identity.items() if k!='files'},'commands':cmd,'source_sha256':sha(R/'probe.cc'),'input':str(source),'input_sha256':sha(source),'charged_seconds':0}
t=time.monotonic()
with (R/'build.log').open('w') as f:
 for key in ['compile','link']:subprocess.run(cmd[key],stdout=f,stderr=subprocess.STDOUT,check=True)
receipt['binary_sha256']=sha(R/'native-probe');receipt['run_command']=[str(R/'native-probe'),str(source),str(R/'native-result.json')]
with (R/'probe.log').open('w') as f:subprocess.run(receipt['run_command'],stdout=f,stderr=subprocess.STDOUT,check=True)
receipt['elapsed_seconds']=time.monotonic()-t;receipt['result_sha256']=sha(R/'native-result.json');receipt['script_sha256']=sha(__file__)
(R/'native-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS structural native probe',receipt['elapsed_seconds'])
