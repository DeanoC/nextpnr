from pathlib import Path
import gzip,hashlib,json,tarfile
R=Path(__file__).resolve().parent;P=R/'payload'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
(P/'build_archive.py').write_bytes(Path(__file__).read_bytes())
manifest={str(p.relative_to(P)):{'size':p.stat().st_size,'sha256':sha(p)} for p in sorted(P.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');(R/'manifest.json').write_bytes((P/'manifest.json').read_bytes())
with (R/'capture.tar.gz').open('wb') as f,gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w') as t:
 for p in sorted(P.rglob('*')):
  if not p.is_file():continue
  info=t.gettarinfo(str(p),arcname=str(p.relative_to(P)));info.uid=info.gid=info.mtime=0;info.uname=info.gname='';info.mode=0o644
  with p.open('rb') as payload:t.addfile(info,payload)
print(json.dumps({'archive_sha256':sha(R/'capture.tar.gz'),'bytes':(R/'capture.tar.gz').stat().st_size,'members':len(manifest)+1,'manifest_sha256':sha(P/'manifest.json')},sort_keys=True))
