from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
R=Path(__file__).resolve().parent;HOST=R.parent;TASK=HOST.parent;SRC=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');P=R/'payload';E=P/'evidence';H=E/HOST.name

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def copy(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
final=json.loads((HOST/'final-validation.json').read_text());assert sha(HOST/'final-validation.json')=='b9c15eaddbf4fd3c9c21e8ecf7b80d82b5a816e6140968cdcbefc3c84bfbdc32'
assert not P.exists();H.mkdir(parents=True)
for p,h in final['files'].items():assert sha(HOST/p)==h;copy(HOST/p,H/p)
for p in ['final-validation.json','committed-source-verification.json','verify-and-commit.py']:
 copy(HOST/p,H/p)
for p in (HOST/'independent-host-review').rglob('*'):
 if p.is_file():copy(p,H/p.relative_to(HOST))
for p in ['native-topology/frozen-manifest.json']:
 copy(HOST/p,H/p)
for name,h in final['source_files'].items():
 blob=subprocess.check_output(['git','show','186637013e17461a72cd1d2cd17ca5ef174ed06f:'+name],cwd=SRC)
 assert hashlib.sha256(blob).hexdigest()==h and blob==(H/'complete-source'/name).read_bytes()
archives={
 'prior':SRC/'docs/validation/2026-10-22-pcxt-lut-permutation-host/capture.tar.gz',
 'frontier':SRC/'docs/validation/2026-10-22-pcxt-private-pair-frontiers/capture.tar.gz',
 'cpu':TASK/'lut6-source-coverage-20261022/final-analysis/capture/capture.tar.gz'}
expected={'prior':'3a9da14c90439588794b1c301df1357a28c15718ea8c729723fb7130e6c8d130','frontier':'4c82c3d307ad1148abc7dfffdd1d1c0efac58dcb93b419cfac3f9fb02cafba91','cpu':'2b2240ddd347411dc22a695cb5db0e53544b873e75183acf299ebc230101c8f1'}
deps={};manifests={};modes={}
for name,path in archives.items():
 assert sha(path)==expected[name]
 with tarfile.open(path) as t:
  names=t.getnames();manifest=t.extractfile('manifest.json').read();mode=t.extractfile('archive-mode.json').read()
  manifests[name]=json.loads(manifest);modes[name]=json.loads(mode)
  d=P/'dependencies';d.mkdir(exist_ok=True);(d/(name+'-manifest.json')).write_bytes(manifest);(d/(name+'-archive-mode.json')).write_bytes(mode)
 deps[name]={'archive_sha256':sha(path),'bytes':path.stat().st_size,'members':len(names),'manifest_sha256':hashlib.sha256(manifest).hexdigest(),'original_path':str(path),'manifest_path':'dependencies/'+name+'-manifest.json'}
selected=[]
def retain(dep,member,dest):
 with tarfile.open(archives[dep]) as t:b=t.extractfile(member).read()
 v=manifests[dep][member];assert len(b)==v['size'] and hashlib.sha256(b).hexdigest()==v['sha256']
 target=P/dest;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 selected.append({'dependency':dep,'member':member,'retained_path':dest,'sha256':v['sha256']})
for name in ['final-validation.json','committed-source-verification.json','prepare-default/placed.json','prepare-default/predicted-timing.json','prepare-default/receipt.json']:
 retain('prior',name,'evidence/routed-lut-permutation-20261022/'+name)
for which in ['mda','cga']:
 for name in ['analysis.json','native-result.json','native-receipt.json','analyze.py','probe.cc','run-probe.py','README.md']:
  retain('frontier','audits/'+which+'/'+name,'evidence/'+which+'-frontier-audit-20261022/'+name)
# Exact external raw-input paths are declared in the already checked prior archive's map.
inputs=json.loads((H/'prepare-default/receipt.json').read_text())['inputs'];input_bindings=[]
for item in inputs.values():
 original=item['path'];entry=modes['prior']['recorded_files'][original];rel=entry['retained_path']
 if rel.startswith('dependency/frontier/dependency/cpu/'):dep='cpu';member=rel[len('dependency/frontier/dependency/cpu/'):]
 elif rel.startswith('dependency/frontier/'):dep='frontier';member=rel[len('dependency/frontier/'):]
 else:dep='prior';member=rel
 assert entry['sha256']==item['sha256']==manifests[dep][member]['sha256']
 input_bindings.append({'original_path':original,'sha256':item['sha256'],'dependency':dep,'member':member})
mode={'scope':'Immutable host-only capture; no new route artifacts. Every final131 file retained. Prior archives are explicit complete-inventory dependencies, not silently loaded from original paths.',
 'host_directory':'evidence/'+HOST.name,'committed_source':'186637013e17461a72cd1d2cd17ca5ef174ed06f','dependencies':deps,'selected_dependency_members':selected,'raw_input_bindings':input_bindings,
 'omitted_native_payloads':{'production_sha256':final['binary_sha256'],'native_test_sha256':final['native_test_sha256'],'probe_sha256':json.loads((H/'board-eligibility/root-native-replay/receipt.json').read_text())['binary_sha256'],
 'objects':'82 linked object hashes retained in board-eligibility/build-plan.json; payloads omitted. Separate401-file native-topology snapshot manifest retained without its payloads.'},
 'original_host_final_sha256':sha(HOST/'final-validation.json')}
write(P/'archive-mode.json',mode);copy(Path(__file__),P/'prepare.py');print('prepared',len(final['files']),len(final['source_files']),len(selected))
