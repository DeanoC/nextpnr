module top(input clk, input seed, inout [15:0] dq, output reg alive);
reg [15:0] data, oe, capture;
always @(posedge clk) begin
 data <= {data[14:0],seed}; oe <= {oe[14:0],data[15]}; capture <= dq; alive <= ^capture;
end
genvar i; generate for(i=0;i<16;i=i+1) begin: pads
 assign dq[i] = oe[i] ? data[i] : 1'bz;
end endgenerate
endmodule
