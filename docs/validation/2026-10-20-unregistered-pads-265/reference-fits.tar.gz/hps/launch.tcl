package require ::quartus::project
package require ::quartus::sta
project_open top
create_timing_netlist
foreach corner [get_available_operating_conditions] {
 set_operating_conditions $corner
 update_timing_netlist
 set f [open $corner/launch.tsv w]
 foreach_in_collection reg [get_registers {i2c~FF_4791 i2c~FF_4792 i2c~FF_4397}] {
  set sources {}
  foreach edge [get_register_info -synch_edges $reg] {lappend sources [get_node_info -name [get_edge_info -src $edge]]}
  set dest {}
  foreach edge [get_register_info -fanout_edges $reg] {lappend dest [get_node_info -name [get_edge_info -dst $edge]]}
  puts $f [join [list [get_register_info -name $reg] [get_node_info -location $reg] [get_register_info -tmin $reg] [get_register_info -tch $reg] [get_register_info -tcl $reg] $sources $dest] "\t"]
 }
 close $f
}
project_close
