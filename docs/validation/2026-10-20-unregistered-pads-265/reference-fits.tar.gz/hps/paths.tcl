package require ::quartus::project
package require ::quartus::sta
project_open top
create_timing_netlist
foreach corner [get_available_operating_conditions] {
 set_operating_conditions $corner
 update_timing_netlist
 file mkdir $corner
 report_clocks -file $corner/clocks.rpt
 report_ucp -file $corner/unconstrained.rpt
 foreach edge {rise fall} {
  report_path -${edge}_to [get_ports {scl sda}] -npaths 20 -show_routing -file $corner/$edge-late.rpt
  report_path -min_path -${edge}_to [get_ports {scl sda}] -npaths 20 -show_routing -file $corner/$edge-early.rpt
 }
 foreach_in_collection n [get_registers *] {
  puts "REGISTER [get_node_info -name $n]"
 }
}
project_close
