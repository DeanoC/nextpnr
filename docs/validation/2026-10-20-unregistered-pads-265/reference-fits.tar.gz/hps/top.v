module top(inout scl, inout sda);
wire lo_clk,lo_data;
assign scl=lo_clk ? 1'b0 : 1'bz;
assign sda=lo_data ? 1'b0 : 1'bz;
cyclonev_hps_interface_peripheral_i2c i2c(.scl(scl),.sda(sda),.out_clk(lo_clk),.out_data(lo_data));
endmodule
