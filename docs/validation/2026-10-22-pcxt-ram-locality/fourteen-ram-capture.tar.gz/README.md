# Fourteen-ROM locality extension

`candidate-placed.json` moves fourteen of the sixteen microcode ROM M10Ks. It
preserves the two measured destinations from the preceding diagnostic and leaves
the two ROMs feeding the east one-hot decoder at their original locations.
All register, carry and LUT placements remain byte-identical to the original.

Candidate SHA256:
`b3244ec877443219f95f3ff0d93492e0d6f2c066acab04a5cc17f88aa669784e`.
Source: `/tmp/pcxt-replicate-leased-20261022/inputs/placed.json`, SHA256
`9241b02074cfee262c985c9ddde7e2c71f05bc654d35b989857a9a93ccc58878`.

Every cell in the table has prefix
`system.machine.cpu.cpu.u_eu_core.u_ucode_rom.bytes[` and suffix
`].rom.<part>.0.0`. Coordinates are M10K x,y; z remains zero.

| Lane | Part | Original | Candidate |
| --- | --- | --- | --- |
| 0 | 0 | 38,39 | 14,39 |
| 0 | 1 | 38,36 | 14,31 |
| 0 | 2 | 38,38 | 14,32 |
| 0 | 3 | 38,37 | 14,33 |
| 1 | 0 | 41,39 | 41,37 |
| 1 | 1 | 41,38 | 41,36 |
| 1 | 2 | 38,40 | 14,44 |
| 1 | 3 | 41,40 | 14,40 |
| 2 | 0 | 41,43 | unchanged |
| 2 | 1 | 38,43 | unchanged |
| 2 | 2 | 38,34 | 14,37, measured prior move |
| 2 | 3 | 41,34 | 14,36, measured prior move |
| 3 | 0 | 38,42 | 14,42 |
| 3 | 1 | 41,42 | 14,41 |
| 3 | 2 | 38,41 | 14,43 |
| 3 | 3 | 41,41 | 41,35 |

## Basis and tradeoffs

The preceding two-ROM route reduced its selected 24 address failures from 19 to
6 and worst setup from -1,461 to -107 ps. It preserved all 17,199 endpoint
identities and had no related hold failures. This motivates extending address
locality; it does not establish whole-design improvement or timing acceptance.

`plan.py` considers all 553 native M10K sites and excludes all 318 occupied
sites. There are 235 free sites. Column 26 has no free site between y=2 and y=70;
placing ROMs there would require a separate unrelated-RAM relocation experiment.
The assignment includes every one of the 48 kept address registers, all 192
address sink edges and all 154 immediate output consumer pins.

The deterministic assignment minimises a geometric placement estimate weighted
3:1 between address and output edges, reflecting the 2.5 ns address and 7.5 ns
return windows. Each output consumer is counted separately. The estimate is
Mistral's cross-LAB form, `650 + 250*(dy != 0) + 35*dx + 100*dy` ps. It is an
assignment cost, not a native routed delay prediction. The Hungarian assignment
uses integer costs and a fixed row/site order. No routing search is performed.

`placement-plans.json` retains complete 3:1, 6:1, 12:1, forced-column-14 and
minimum-worst-address comparisons. Putting all sixteen ROMs in column 14 raises
the maximum address estimate from 2.600 to 2.795 ns and increases the summed
output estimate. The selected experiment instead retains lane-2 ROM0/ROM1 next
to their east decoder and retains the two measured placements. Only the twelve
additional ROM destinations are optimised.

| Full sixteen-ROM graph | Original | Selected candidate |
| --- | --- | --- |
| Address Manhattan-distance sum | 3,780 | 2,830 |
| Output Manhattan-distance sum | 2,492 | 1,035 |
| Address placement-estimate sum, ps | 332,370 | 314,740 |
| Output placement-estimate sum, ps | 194,375 | 169,670 |
| Worst address placement estimate, ps | 2,600 | 2,600 |

Of the 192 address edges, 99 become geometrically closer, 47 farther and 46
unchanged/equidistant. Of 154 output edges, 83 become closer, two farther and 69
unchanged/equidistant. The two farther outputs are lane-1 ROM1 to
`eu_opcode_immediate_MISTRAL_FF_Q_5` and `_14`, each two additional Manhattan
tiles. Individual path risks and all edge distances are recorded in the plan.
The remaining address estimate maximum belongs to an unchanged east ROM.
This candidate is designed to isolate locality, not to claim closure from a
geometric score. Full routing can change shared clock, constant and data trees.

The two-ROM route also exposed a return-path limitation on a moved ROM:
lane-2 ROM3 at (14,36) to `select_half_MISTRAL_ALUT4_Q_30` at (19,34) takes
2.033 ns, then that decoder to the route-through for
`eu_op0_select_MISTRAL_FF_Q_10` at (12,32) takes 2.517 ns. With RAM clock-to-Q,
logic, setup and skew, that 7.5 ns path misses by 677 ps. Moving RAMs alone
therefore leaves decode-to-register routing to solve.

## Structural and native checks

`prepare.py` changes exactly 34 bytes in fourteen `NEXTPNR_BEL` strings. It
validates the frozen input identity, expected RAM types and weak strength,
attribute inventories, all native destination sites and their original vacancy.
It rejects actual routing or a routed LAB snapshot. All saved pin maps, folded
states, INIT bits, `keep` attributes, clock/phase settings and remaining bytes
are unchanged. An ordered recursive comparison admits only the fourteen
location values; the inverse token replacement restores the exact source bytes.

`preparation-proof.json` records the checks. `all-ram-net-fanouts.json` includes
all 83 incident nets for all sixteen ROMs, including their complete users,
drivers, aliases and physical pin mappings. Constants and clocks are included.

The frozen compiler at commit
`66c97e4908304cd46f986a35335cb424cac23864`, binary SHA256
`97e818cc3f6f2e96e4826c0074323d18b3a85449948cb7546f8952492358c2b5`,
successfully loaded this candidate with `--no-pack --no-place --no-route` in
4.73 seconds. Native BEL binding and restored pin maps passed. The exact command
and log hashes are in `native-checkpoint-load.json`. No placement, route,
timing report or bitstream generation was invoked by preparation.

## East decoder boundary

`inspect_decode.py` inventories the sixteen ALUT4 decoders fed by lane-2
ROM0/ROM1 in `east-decode-cone.json`. All sixteen are weakly placed and have no
`keep`, `dont_touch`, BEL, LOC or FES_SLOT protection. Each reads the same four
ROM output nets and drives exactly two kept FFs: 64 RAM-to-LUT input edges and
32 LUT-to-FF output edges. Their capture FFs span x=10..31, y=33..43. Original
occupied ALMs contain only these decoder LUTs; there are no unrelated FFs or
LUTs to displace in those source ALMs.

The exact decoder names are the prefix
`system.machine.cpu.cpu.u_eu_core.u_ucode_rom.select_half_MISTRAL_ALUT4_Q`
with suffixes: none, `_1`, `_2`, `_3`, `_4`, `_5`, `_6`, `_7`, `_8`, `_9`,
`_10`, `_11`, `_12`, `_13`, `_14`, `_17`.
Thirteen are at x=37,y=43; `_13` is at x=25,y=43, `_14` at x=36,y=43 and
`_7` at x=22,y=43. Full BELs, LUT masks, pin states, output users, endpoint
rows and ALM occupants are in the JSON.

A future joint RAM/decode move should use a native Context transaction, retain
all capture FFs, check destination ALM legality and reassign physical LUT pins.
Blind LUT BEL edits would bypass shared-ALM/pin-map legality. The same technique
should examine the west one-hot group, whose moved-ROM return is now limiting.
No decoder was moved here.

## Reproduction and delivery

From this directory, run `python3 plan.py`, then `python3 prepare.py`.
`python3 inspect_decode.py` refreshes the read-only cone inventory from the
two-ROM routed evidence. The preparation helper and native site inventory in
`../ram-locality-20261022` are explicit dependencies and their hashes are recorded.

Next integration step: independently full-route this candidate with the frozen
compiler and the original seed-1 recipe through the shared-GPU lease runner;
use `--no-pack --no-place`. Retain complete native setup/hold, endpoint coverage,
contract, input, binary and artifact receipts. Keep its result separate from
LUT reassociation until the individual effects are measured. Unsupported timing
obligations remain outstanding. No timing acceptance gate has changed.

Result is an uncommitted diagnostic artifact set; no RTL, compiler or shared
contract changes. Evidence produced here is host-only. No hardware was used.
