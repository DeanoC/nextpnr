#!/usr/bin/env python3
"""Compare complete, deterministic, geometry-only ROM assignments. Never routes."""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/tmp/pcxt-replicate-leased-20261022/inputs/placed.json')
SOURCE_SHA = '9241b02074cfee262c985c9ddde7e2c71f05bc654d35b989857a9a93ccc58878'
PREFIX = 'system.machine.cpu.cpu.u_eu_core.u_ucode_rom.bytes['


def xy(bel):
    return tuple(map(int, bel.split('.')[1:3]))


def predict(a, b):
    """Mistral cross-LAB placement estimate; explicitly not native route timing."""
    dx, dy = abs(a[0] - b[0]), abs(a[1] - b[1])
    return 650 + (250 if dy else 0) + 35 * dx + 100 * dy


def manhattan(a, b):
    return sum(abs(x-y) for x, y in zip(a, b))


def assignment(costs):
    """Rectangular Hungarian assignment; integer costs, deterministic input order."""
    n, m = len(costs), len(costs[0])
    assert n <= m and all(len(row) == m for row in costs)
    u, v, p, way = [0]*(n+1), [0]*(m+1), [0]*(m+1), [0]*(m+1)
    inf = 10**30
    for i in range(1, n+1):
        p[0], j0 = i, 0
        minv, used = [inf]*(m+1), [False]*(m+1)
        while True:
            used[j0] = True
            i0, delta, j1 = p[j0], inf, 0
            for j in range(1, m+1):
                if not used[j]:
                    cur = costs[i0-1][j-1] - u[i0] - v[j]
                    if cur < minv[j]:
                        minv[j], way[j] = cur, j0
                    if minv[j] < delta:
                        delta, j1 = minv[j], j
            for j in range(m+1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0], j0 = p[j1], j1
            if j0 == 0:
                break
    result = [-1]*n
    for j in range(1, m+1):
        if p[j]:
            result[p[j]-1] = j-1
    assert len(set(result)) == n and min(result) >= 0
    return result


def main():
    raw = SOURCE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == SOURCE_SHA
    module = json.loads(raw)['modules']['top']
    cells = module['cells']
    occupied = {c['attributes']['NEXTPNR_BEL'] for c in cells.values()}
    site_file = ROOT.parent/'ram-locality-20261022/native-m10k-sites.txt'
    native_sites = sorted(tuple(map(int, line.split())) for line in site_file.read_text().splitlines())
    sites = [point for point in native_sites if f'MISTRAL_M10K.{point[0]}.{point[1]}.0' not in occupied]
    assert len(native_sites) == 553 and len(sites) == 235
    endpoints_file = ROOT.parent/'move-margins-20261022/baseline/endpoints.json'
    endpoints = json.loads(endpoints_file.read_bytes())['endpoints']
    users, drivers, aliases = collections.defaultdict(list), {}, collections.defaultdict(list)
    for name, net in module['netnames'].items():
        for i, bit in enumerate(net['bits']):
            aliases[bit].append([name, i])
    for name, cell in cells.items():
        for port, bits in cell['connections'].items():
            for i, bit in enumerate(bits):
                pin = {'cell': name, 'port': port, 'bit_index': i,
                       'bel': cell['attributes']['NEXTPNR_BEL'], 'type': cell['type']}
                if cell['port_directions'][port] == 'output':
                    assert bit not in drivers
                    drivers[bit] = pin
                else:
                    users[bit].append(pin)
    rams = []
    for lane in range(4):
        for part in range(4):
            name = PREFIX + f'{lane}].rom.{part}.0.0'
            cell = cells[name]
            assert cell['type'] == 'MISTRAL_M10K'
            record = {'cell': name, 'lane': lane, 'part': part,
                      'old_bel': cell['attributes']['NEXTPNR_BEL'], 'addresses': [], 'outputs': []}
            for i, bit in enumerate(cell['connections']['B1ADDR']):
                driver = drivers[bit]
                assert driver['type'] == 'MISTRAL_FF' and 'keep' in cells[driver['cell']]['attributes']
                assert len(users[bit]) == 4
                rows = endpoints[json.dumps([name, f'B1ADDR[{i}]'])]
                record['addresses'].append({'bit_index': i, 'bit': bit, 'aliases': aliases[bit],
                                            'driver': driver, 'all_users': users[bit], 'baseline_rows': rows})
            for i, bit in enumerate(cell['connections']['B1DATA']):
                record['outputs'].append({'bit_index': i, 'bit': bit, 'aliases': aliases[bit],
                                          'users': users[bit]})
            rams.append(record)
    assert len({a['driver']['cell'] for r in rams for a in r['addresses']}) == 48

    def components(ram, site):
        addr = [predict(xy(a['driver']['bel']), site) for a in ram['addresses']]
        output = [predict(site, xy(user['bel'])) for out in ram['outputs'] for user in out['users']]
        return sum(addr), max(addr), sum(output)

    def metrics(positions):
        addr, outs, ram_reports = [], [], []
        for ram, site in zip(rams, positions):
            old = xy(ram['old_bel'])
            arows, orows = [], []
            for a in ram['addresses']:
                origin = xy(a['driver']['bel'])
                row = {'driver': a['driver']['cell'], 'bit_index': a['bit_index'],
                       'old_manhattan': manhattan(old, origin), 'new_manhattan': manhattan(site, origin),
                       'old_placement_estimate_ps': predict(old, origin),
                       'new_placement_estimate_ps': predict(site, origin)}
                arows.append(row)
                addr.append(row)
            for output in ram['outputs']:
                for user in output['users']:
                    target = xy(user['bel'])
                    row = {'consumer': user['cell'], 'port': user['port'],
                           'output_bit_index': output['bit_index'],
                           'old_manhattan': manhattan(old, target), 'new_manhattan': manhattan(site, target),
                           'old_placement_estimate_ps': predict(old, target),
                           'new_placement_estimate_ps': predict(site, target)}
                    orows.append(row)
                    outs.append(row)
            a_sum, a_max, o_sum = components(ram, site)
            ram_reports.append({'cell': ram['cell'], 'old_bel': ram['old_bel'],
                                'new_bel': f'MISTRAL_M10K.{site[0]}.{site[1]}.0',
                                'address_estimate_sum_ps': a_sum, 'address_estimate_max_ps': a_max,
                                'output_estimate_sum_ps': o_sum, 'address_edges': arows, 'output_edges': orows})
        def summarise(rows):
            return {'edges': len(rows),
                    'closer': sum(r['new_manhattan'] < r['old_manhattan'] for r in rows),
                    'farther': sum(r['new_manhattan'] > r['old_manhattan'] for r in rows),
                    'equal': sum(r['new_manhattan'] == r['old_manhattan'] for r in rows),
                    'old_manhattan_sum': sum(r['old_manhattan'] for r in rows),
                    'new_manhattan_sum': sum(r['new_manhattan'] for r in rows),
                    'old_estimate_sum_ps': sum(r['old_placement_estimate_ps'] for r in rows),
                    'new_estimate_sum_ps': sum(r['new_placement_estimate_ps'] for r in rows),
                    'old_estimate_max_ps': max(r['old_placement_estimate_ps'] for r in rows),
                    'new_estimate_max_ps': max(r['new_placement_estimate_ps'] for r in rows)}
        return {'address_summary': summarise(addr), 'output_summary': summarise(outs), 'rams': ram_reports}

    plans = {}
    for address_weight in (3, 6, 12):
        costs = [[address_weight*components(r, s)[0] + components(r, s)[2] for s in sites] for r in rams]
        chosen = assignment(costs)
        plans[f'weighted_{address_weight}_to_1'] = {
            'objective': f'{address_weight} * address placement-estimate sum + output placement-estimate sum',
            'total_cost': sum(costs[i][j] for i, j in enumerate(chosen)),
            **metrics([sites[j] for j in chosen])}
    left_sites = [s for s in sites if s[0] == 14]
    costs = [[3*components(r, s)[0] + components(r, s)[2] for s in left_sites] for r in rams]
    chosen = assignment(costs)
    plans['forced_column14_3_to_1'] = {'objective': '3:1 weighted cost, every ROM in column 14',
                                     'total_cost': sum(costs[i][j] for i, j in enumerate(chosen)),
                                     **metrics([left_sites[j] for j in chosen])}
    # Establish the best possible worst address geometry at free sites, then
    # optimise the same 3:1 weighted objective within that exact bound.
    maxima = [[components(r, s)[1] for s in sites] for r in rams]
    values = sorted({v for row in maxima for v in row})
    def feasible(threshold):
        match = [-1]*len(sites)
        def visit(i, seen):
            for j, value in enumerate(maxima[i]):
                if value <= threshold and j not in seen:
                    seen.add(j)
                    if match[j] < 0 or visit(match[j], seen):
                        match[j] = i
                        return True
            return False
        return all(visit(i, set()) for i in range(len(rams)))
    lo, hi = 0, len(values)-1
    while lo < hi:
        mid = (lo+hi)//2
        if feasible(values[mid]): hi = mid
        else: lo = mid+1
    threshold = values[lo]
    costs = [[(3*components(r, s)[0] + components(r, s)[2]) if maxima[i][j] <= threshold else 10**15
              for j, s in enumerate(sites)] for i, r in enumerate(rams)]
    chosen = assignment(costs)
    assert all(costs[i][j] < 10**15 for i, j in enumerate(chosen))
    plans['minimax_then_3_to_1'] = {'objective': 'minimum possible worst address placement estimate, then 3:1 weighted sum',
                                  'address_estimate_bound_ps': threshold,
                                  'total_cost': sum(costs[i][j] for i, j in enumerate(chosen)),
                                  **metrics([sites[j] for j in chosen])}
    # Keep the two high-fanout east decode groups unchanged, and retain the
    # two measured successful diagnostic destinations. Extend locality only
    # to the remaining twelve ROMs, with all register/carry placement fixed.
    fixed = {8: xy(rams[8]['old_bel']), 9: xy(rams[9]['old_bel']),
             10: (14, 37), 11: (14, 36)}
    remaining = [i for i in range(len(rams)) if i not in fixed]
    remaining_sites = [s for s in sites if s not in fixed.values()]
    costs = [[3*components(rams[i], s)[0] + components(rams[i], s)[2]
              for s in remaining_sites] for i in remaining]
    chosen = assignment(costs)
    positions = [fixed.get(i) for i in range(len(rams))]
    for i, j in zip(remaining, chosen):
        positions[i] = remaining_sites[j]
    plans['fourteen_preserve_measured_and_decode_pair'] = {
        'objective': '3:1 weighted sum for twelve further ROMs; preserve two measured moves and two east decoder ROMs',
        'moved_rom_count': 14, 'preserved_rom_count': 2,
        'total_cost': sum(3*components(r, s)[0]+components(r,s)[2] for r,s in zip(rams,positions)),
        **metrics(positions)}
    result = {'kind': 'read-only complete geometric assignment; estimates are not routed STA',
              'source': str(SOURCE), 'source_sha256': SOURCE_SHA,
              'native_site_file': str(site_file), 'native_site_sha256': hashlib.sha256(site_file.read_bytes()).hexdigest(),
              'baseline_endpoints_file': str(endpoints_file),
              'baseline_endpoints_sha256': hashlib.sha256(endpoints_file.read_bytes()).hexdigest(),
              'free_site_count': len(sites), 'free_sites': sites, 'address_registers': 48,
              'model': '650 + 250*(dy != 0) + 35*dx + 100*dy ps; Mistral cross-LAB placement estimate',
              'weight_basis': 'Address setup window 2500 ps versus return window 7500 ps gives primary 3:1 ratio. '
                              'Every immediate output user is counted, including high-fanout decode nets. '
                              '6:1 and 12:1 expose the address/output tradeoff without running routes.',
              'connectivity': rams, 'plans': plans}
    (ROOT/'placement-plans.json').write_text(json.dumps(result, indent=2)+'\n')
    for label, plan in plans.items():
        print(label, json.dumps({k: plan[k] for k in ['address_summary','output_summary']}))
        print([(r['cell'].split('bytes[')[1], r['new_bel']) for r in plan['rams']])


if __name__ == '__main__':
    main()
