# Re-placing a transformed checkpoint

Do not feed the existing transformed placed checkpoint back with only
`--no-pack` and assume this performs a fresh full placement.

1. `common/kernel/basectx.cc:212` restores every `NEXTPNR_BEL` binding.
   `mistral/main.cc:654` restores placed pin states before placement begins.
2. `common/place/placer_heap.cc:752` treats every bound cell as analytically
   locked, regardless of weak strength. Only unbound cells enter `place_cells`.
3. `common/place/placer_heap.cc:390` nevertheless invokes `placer1_refine`.
   `common/place/placer1.cc:220` admits cells with strength at most STRONG,
   regardless of `keep`. Thus the operation is an analytic no-op followed by
   local refinement of weak cells, not a fresh analytic placement.
4. Placed JSON does not serialize cluster/relative placement metadata. The
   transformed checkpoint has 1,349 ALUT_ARITH cells and no serialized cluster
   metadata. Carry-chain adjacency is constructed by
   `mistral/pack.cc:1722` (`constrain_carries`) during packing. Individual
   refinement/unbinding can therefore move carry cells without their chains.

Deleting `NEXTPNR_BEL` from the raw JSON is not sufficient cleanup.
`restore_placed_pin_maps` skips unbound cells, so their folded constant/inverted
pin states are not restored. Custom M10K pin maps are especially important:
`assign_default_pinmap` intentionally does not synthesize those maps.
Deleting all `FES_PINMAP_V1` snapshots loses logical information removed during
packing. Re-running the complete packer is also not an established unpack/repack
operation: it begins by creating reserved constant drivers/nets already present
in this checkpoint and repeats packed IO, clock and RAM transformations.

A minimal native scoped re-placement operation would load and restore the
checkpoint normally, reject routes or a routed LAB snapshot, and then:

- Select only ordinary weak, unprotected, unclustered cells to move. For the
  current RAM task, selecting the M10Ks avoids carry reconstruction entirely.
- Snapshot original placements, strengths, pin states, graph and settings.
  Temporarily freeze every nonselected movable cell above STRONG, using FIXED
  rather than LOCKED so fresh LAB route preparation is not mistaken for a
  routed scaffold. Preserve cells already fixed more strongly.
- Unbind the selected cells in Context, retaining their restored logical pin
  states. Run placement with the remaining cells fixed through both analytic
  placement and refinement. Recompute architecture information/physical maps as
  required; native RAM maps remain coordinate-free.
- Restore original strengths for unchanged cells, prove logical graph and
  clocks identical, verify complete placement and physical pin legality, then
  write a new placed checkpoint. Full routed setup/hold and inventory checks
  remain separate acceptance steps.

This is a proposed scoped compiler feature, not an existing CLI path. The current
binary was built with `BUILD_PYTHON=OFF`, so a Python `--pre-place` hook is not
available. Truly full placement additionally requires reconstructing every
packer placement cluster, or applying reassociation to a normal packed design
within the same process before its first placement. Neither boundary has been
implemented or tested by this read-only assessment.

The placer has no existing instance-level M10K bank grouping. Mistral configures
only the COMB/FF bucket group and solves all types together. HeAP's
`get_cell_legalisation_weight` callback can prioritise hard blocks, but Mistral
leaves it at its default. That changes legalisation order, not a bank's address
window or shared fanout. All 318 M10Ks compete for sites, including framebuffer
blocks occupying the nearer column 26. A general hard-IP priority change is less
direct than the present fixed-register/free-site diagnostic and would affect
unrelated memory placement.

The next justified experiment is the explicit fourteen-ROM checkpoint in this
directory. It preserves every carry/FF/keep placement and has native binding and
pin-map validation. The following compiler experiment should move a RAM and its
one-hot decoder cone transactionally while keeping capture FFs fixed, rather
than silently refining the whole checkpoint. The saved exact decoder inventory
defines that scope without inferring architectural intent from cell names.
