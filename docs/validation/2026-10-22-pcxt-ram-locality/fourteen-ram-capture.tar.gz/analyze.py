from pathlib import Path
import json,collections
root=Path(__file__).resolve().parent
paths={'baseline':root.parent/'reassociate-20261022/baseline','candidate':root/'candidate'}
runs={};eps={}
for n,p in paths.items():
 e=json.loads((p/'endpoints.json').read_text());eps[n]=e;t=json.loads((p/'timing.json').read_text());groups=collections.defaultdict(list)
 for key,rs in e['endpoints'].items():
  for r in rs:
   if r['setup_timed']:groups[str((r['launch'],r['capture'],r['setup_window']))].append((r['setup'],key))
 runs[n]={'timing_summary':t['timing_summary'],'complete':e['complete'],'unsupported':len(e['unsupported']),'groups':{k:{'rows':len(v),'failures':sum(s<0 for s,n in v),'wns_ps':min(v)[0]} for k,v in groups.items()},'setup_failures':sum(r['setup_timed'] and r['setup']<0 for rs in e['endpoints'].values() for r in rs),'hold_failures':sum(r['hold_related'] and r['hold']<0 for rs in e['endpoints'].values() for r in rs)}
a,b=(eps[n] for n in ['baseline','candidate']);assert set(a['endpoints'])==set(b['endpoints'])
selected={x['cell'] for x in json.loads((root/'preparation-proof.json').read_text())['moves']};rows=[]
for k,rs in a['endpoints'].items():
 def identity(r):return tuple(r['launch']),tuple(r['capture']),r['setup_timed'],r['hold_related'],r['setup_window']
 old={identity(r):r for r in rs};new={identity(r):r for r in b['endpoints'][k]};assert len(old)==len(rs) and len(new)==len(b['endpoints'][k]) and set(old)==set(new)
 for ident,r in old.items():
  cell,pin=json.loads(k)
  if cell in selected and pin.startswith('B1ADDR['):rows.append({'endpoint':[cell,pin],'before':r,'after':new[ident]})
result={'evidence':'leased GPU host diagnostic only','runs':runs,'endpoint_identities_unchanged':True,'selected_rows':rows,'selected_failures_before':sum(r['before']['setup']<0 for r in rows),'selected_failures_after':sum(r['after']['setup']<0 for r in rows),'selected_wns_before_ps':min(r['before']['setup'] for r in rows),'selected_wns_after_ps':min(r['after']['setup'] for r in rows),'charged_seconds':json.loads((root/'candidate/receipt.json').read_text())['charged_seconds'],'route_allowance':'uncapped by user','previous_charged_seconds':9312.848847799933}
result['cumulative_charged_seconds']=result['previous_charged_seconds']+result['charged_seconds'];(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['selected_rows','runs']},indent=2))
