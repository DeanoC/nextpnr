#!/usr/bin/env python3
"""Read-only east one-hot decode cone inventory; does not alter LUT placement."""
import collections
import json
from plan import ROOT, SOURCE, PREFIX, xy


def main():
    module = json.loads(SOURCE.read_bytes())['modules']['top']
    cells = module['cells']
    endpoints = json.loads((ROOT.parent/'ram-locality-20261022/candidate/endpoints.json').read_bytes())['endpoints']
    users = collections.defaultdict(list)
    drivers = {}
    for name, cell in cells.items():
        for port, bits in cell['connections'].items():
            for i, bit in enumerate(bits):
                item = {'cell':name,'port':port,'bit_index':i,'bel':cell['attributes']['NEXTPNR_BEL'],
                        'type':cell['type']}
                if cell['port_directions'][port] == 'output':
                    drivers[bit] = item
                else:
                    users[bit].append(item)
    roms = [PREFIX+f'2].rom.{part}.0.0' for part in [0,1]]
    input_bits = [bit for name in roms for bit in cells[name]['connections']['B1DATA']]
    decoders = sorted({u['cell'] for bit in input_bits for u in users[bit]
                       if cells[u['cell']]['type'] == 'MISTRAL_ALUT4'})
    assert len(decoders) == 16
    def alm(bel):
        kind,x,y,z = bel.split('.')
        return int(x),int(y),int(z)//6
    records = []
    for name in decoders:
        cell = cells[name]
        attrs = cell['attributes']
        output_users = users[cell['connections']['Q'][0]]
        assert len(output_users) == 2 and all(u['type']=='MISTRAL_FF' for u in output_users)
        a = alm(attrs['NEXTPNR_BEL'])
        mates = []
        for other, c in cells.items():
            bel = c['attributes']['NEXTPNR_BEL']
            if bel.startswith(('MISTRAL_COMB.','MISTRAL_MCOMB.','MISTRAL_FF.')) and alm(bel)==a:
                mates.append({'cell':other,'bel':bel,'type':c['type'],'selected_decoder':other in decoders,
                              'protection_attributes':{k:v for k,v in c['attributes'].items()
                                                       if k in ['keep','dont_touch','BEL','LOC','FES_SLOT']}})
        record = {'cell':name,'type':cell['type'],'bel':attrs['NEXTPNR_BEL'],
                  'lut_mask':cell['parameters']['LUT'],'bel_strength':int(attrs['BEL_STRENGTH'],2),
                  'protection_attributes':{k:v for k,v in attrs.items()
                                           if k in ['keep','dont_touch','BEL','LOC','FES_SLOT']},
                  'saved_pinmap':json.loads(bytes.fromhex(attrs['FES_PINMAP_V1'])),
                  'inputs':[{'port':p,'bit':bits[0],'driver':drivers[bits[0]]}
                            for p,bits in cell['connections'].items() if p!='Q'],
                  'output_users':[{**u,'protection_attributes':{k:v for k,v in cells[u['cell']]['attributes'].items()
                                                               if k in ['keep','dont_touch','BEL','LOC','FES_SLOT']},
                                   'two_ram_native_endpoint_rows':endpoints[json.dumps([u['cell'],u['port']])]}
                                  for u in output_users],
                  'original_alm_occupants':mates,
                  'cluster_metadata':'Not serialized by checkpoint; Context must check before any future relocation.'}
        records.append(record)
    targets = [u for r in records for u in r['output_users']]
    result = {'kind':'read-only east decode cone, all register/LUT placements unchanged',
              'source':str(SOURCE),'roms':roms,'decoder_count':len(records),
              'rom_to_decoder_pin_edges':sum(len(r['inputs']) for r in records),
              'decoder_to_ff_edges':len(targets),
              'unique_capture_ffs':len({u['cell'] for u in targets}),
              'capture_ff_bounds_xy':[min(xy(u['bel'])[0] for u in targets),max(xy(u['bel'])[0] for u in targets),
                                      min(xy(u['bel'])[1] for u in targets),max(xy(u['bel'])[1] for u in targets)],
              'native_return_min_setup_ps':min(row['setup'] for u in targets for row in u['two_ram_native_endpoint_rows']),
              'native_return_negative_setup_rows':sum(row['setup']<0 for u in targets for row in u['two_ram_native_endpoint_rows']),
              'all_decoders_weak_and_without_keep_or_placement_protection':all(r['bel_strength']==1 and not r['protection_attributes'] for r in records),
              'all_capture_ffs_keep':all('keep' in u['protection_attributes'] for u in targets),
              'decoders':records}
    (ROOT/'east-decode-cone.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='decoders'}))
    for r in records:
        print(r['cell'].split('.')[-1],r['bel'],'mates',[(m['type'],m['bel'],m['selected_decoder']) for m in r['original_alm_occupants']])


if __name__=='__main__':
    main()
