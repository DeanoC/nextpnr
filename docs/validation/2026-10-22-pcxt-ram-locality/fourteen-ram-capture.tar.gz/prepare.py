#!/usr/bin/env python3
"""Exact-byte fourteen-ROM extension; retains the east decode pair and all other cells."""
import importlib.util
import json
from pathlib import Path
import hashlib
from plan import ROOT, SOURCE, SOURCE_SHA

HELPER = ROOT.parent/'ram-locality-20261022/prepare.py'
spec = importlib.util.spec_from_file_location('frozen_checkpoint_helper', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
require, read_json, dump, sha = helper.require, helper.read_json, helper.dump, helper.sha
LABEL = 'fourteen_preserve_measured_and_decode_pair'


def main():
    raw = SOURCE.read_bytes()
    require(sha(raw) == SOURCE_SHA, 'Unexpected source identity')
    before = read_json(raw)
    module = before['modules']['top']
    require(module['attributes']['step'] == 'place', 'Not a placed source')
    require(not any(k.startswith('FES_LABSTATE') for k in module['attributes']), 'Routed LAB state present')
    require(all(not n.get('attributes', {}).get('ROUTING', '').strip() for n in module['netnames'].values()),
            'Physical routing present')
    plans_file = ROOT/'placement-plans.json'
    plans = read_json(plans_file.read_bytes())
    require(plans['source_sha256'] == SOURCE_SHA, 'Plan source mismatch')
    selected = plans['plans'][LABEL]['rams']
    require(len(selected) == 16 and len({r['cell'] for r in selected}) == 16, 'Incomplete RAM plan')
    require(len({r['new_bel'] for r in selected}) == 16, 'Colliding plan')
    sites_file = Path(plans['native_site_file'])
    require(sha(sites_file.read_bytes()) == plans['native_site_sha256'], 'Native site evidence changed')
    sites = {f'MISTRAL_M10K.{x}.{y}.0' for x,y in (map(int,line.split()) for line in sites_file.read_text().splitlines())}
    occupied = {c['attributes']['NEXTPNR_BEL']: name for name,c in module['cells'].items()}
    expected, moves, unchanged = [], [], []
    output = raw
    for entry in selected:
        name, old, new = entry['cell'], entry['old_bel'], entry['new_bel']
        cell = module['cells'][name]
        attrs = cell['attributes']
        require(cell['type'] == 'MISTRAL_M10K', 'Wrong RAM type')
        require(attrs['NEXTPNR_BEL'] == old and occupied[old] == name, 'Wrong old location')
        require(list(attrs) == ['BEL_STRENGTH','NEXTPNR_BEL','FES_PINMAP_V1','src','module_not_derived'],
                'Unexpected protected/placement attributes')
        require(int(attrs['BEL_STRENGTH'],2) == 1, 'RAM is not weakly placed')
        pinmap = read_json(bytes.fromhex(attrs['FES_PINMAP_V1']))
        require(pinmap['count'] == len(pinmap['pins']) == 34, 'Unexpected pin-map shape')
        require(all('.' not in pin for values in pinmap['pins'].values() for pin in values[1:]),
                'Coordinate-qualified pin state')
        require(old in sites and new in sites, 'RAM site absent from native model')
        record = {'cell':name, 'old_bel':old, 'new_bel':new,
                  'pinmap_sha256':sha(bytes.fromhex(attrs['FES_PINMAP_V1']))}
        if old == new:
            unchanged.append(record)
            continue
        require(new not in occupied, 'Destination is occupied in original checkpoint')
        old_token, new_token = f'"NEXTPNR_BEL": "{old}"'.encode(), f'"NEXTPNR_BEL": "{new}"'.encode()
        require(output.count(old_token) == 1 and output.count(new_token) == 0, 'Nonunique BEL token')
        output = output.replace(old_token, new_token)
        expected.append({'path':['modules','top','cells',name,'attributes','NEXTPNR_BEL'],
                         'before':old,'after':new})
        moves.append({**record,'native_destination_exists':True,'destination_previously_free':True})
    require(len(moves) == 14 and len(unchanged) == 2, 'Wrong experiment scope')
    after = read_json(output)
    actual = helper.differences(before,after)
    key = lambda d: tuple(d['path'])
    require(sorted(actual,key=key) == sorted(expected,key=key), 'Unexpected graph/metadata mutation')
    inverse = output
    for move in moves:
        inverse = inverse.replace(f'"NEXTPNR_BEL": "{move["new_bel"]}"'.encode(),
                                  f'"NEXTPNR_BEL": "{move["old_bel"]}"'.encode())
    require(inverse == raw, 'Inverse patch does not restore original bytes')
    candidate = ROOT/'candidate-placed.json'
    candidate.write_bytes(output)
    incident = helper.inventory(module,{r['cell'] for r in selected})
    dump(ROOT/'all-ram-net-fanouts.json', {'kind':'All incident nets for all sixteen ROMs, including the two unchanged ROMs',
                                        'net_count':len(incident),'nets':incident})
    proof = {'kind':'diagnostic placement-only checkpoint; no route or timing acceptance',
             'source_path':str(SOURCE),'source_sha256':sha(raw),
             'candidate_path':str(candidate),'candidate_sha256':sha(output),
             'selected_plan':LABEL,'plan_sha256':sha(plans_file.read_bytes()),
             'native_site_sha256':sha(sites_file.read_bytes()),
             'helper_source':str(HELPER),'helper_sha256':sha(HELPER.read_bytes()),
             'changed_byte_count':sum(a!=b for a,b in zip(raw,output)),
             'source_bytes':len(raw),'candidate_bytes':len(output),
             'moves':moves,'unchanged_east_decode_roms':unchanged,'all_differences':actual,
             'proof':{'exact_byte_inverse':True,'ordered_graph_preserved':True,
                      'only_fourteen_bel_values_changed':True,'all_registers_and_keep_attributes_preserved':True,
                      'all_carry_placements_preserved':True,'all_pinmaps_and_initialisation_preserved':True,
                      'clocks_phases_and_timing_gates_preserved':True,'no_routed_state':True},
             'complete_all_rom_incident_net_count':len(incident),
             'all_ram_net_fanouts_sha256':sha((ROOT/'all-ram-net-fanouts.json').read_bytes())}
    dump(ROOT/'preparation-proof.json',proof)
    print(json.dumps({'candidate':str(candidate),'sha256':sha(output),
                      'moves':len(moves),'changed_bytes':proof['changed_byte_count'],'incident_nets':len(incident)}))


if __name__ == '__main__':
    main()
