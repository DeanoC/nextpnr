#!/usr/bin/env python3
"""Prepare one frozen diagnostic placement; does not invoke placement or routing."""
import argparse
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/tmp/pcxt-replicate-leased-20261022/inputs/placed.json')
SOURCE_SHA = '9241b02074cfee262c985c9ddde7e2c71f05bc654d35b989857a9a93ccc58878'
PREFIX = 'system.machine.cpu.cpu.u_eu_core.u_ucode_rom.bytes[2].'
MOVES = [
    (PREFIX + 'rom.3.0.0', 'MISTRAL_M10K.41.34.0', 'MISTRAL_M10K.14.36.0'),
    (PREFIX + 'rom.2.0.0', 'MISTRAL_M10K.38.34.0', 'MISTRAL_M10K.14.37.0'),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def no_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read_json(data):
    return json.loads(data, object_pairs_hook=no_duplicate_keys)


def differences(left, right, path=()):
    require(type(left) is type(right), 'Changed value type at ' + repr(path))
    if isinstance(left, dict):
        require(list(left) == list(right), 'Changed object keys/order at ' + repr(path))
        return [d for key in left for d in differences(left[key], right[key], path + (key,))]
    if isinstance(left, list):
        require(len(left) == len(right), 'Changed list length at ' + repr(path))
        return [d for i, (a, b) in enumerate(zip(left, right)) for d in differences(a, b, path + (i,))]
    return [] if left == right else [{'path': list(path), 'before': left, 'after': right}]


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def pin_info(cell, port, index):
    encoded = cell.get('attributes', {}).get('FES_PINMAP_V1')
    if not encoded:
        return None
    pins = read_json(bytes.fromhex(encoded))['pins']
    logical = f'{port}[{index}]' if f'{port}[{index}]' in pins else port
    return {'logical': logical, 'state_and_physical_pins': pins.get(logical)}


def inventory(module, moved):
    affected = set()
    for name in moved:
        for bits in module['cells'][name]['connections'].values():
            affected.update(bits)
    records = {bit: {'bit': bit, 'aliases': [], 'drivers': [], 'users': [], 'inouts': [],
                     'top_ports': [], 'moved_cell_connections': []} for bit in sorted(affected)}
    for name, net in module['netnames'].items():
        for index, bit in enumerate(net['bits']):
            if bit in records:
                records[bit]['aliases'].append({'name': name, 'bit_index': index})
    for name, cell in module['cells'].items():
        for port, bits in cell['connections'].items():
            for index, bit in enumerate(bits):
                if bit not in records:
                    continue
                direction = cell['port_directions'][port]
                role = {'input': 'users', 'output': 'drivers', 'inout': 'inouts'}[direction]
                connection = {'cell': name, 'type': cell['type'], 'port': port, 'bit_index': index,
                              'bel': cell.get('attributes', {}).get('NEXTPNR_BEL'),
                              'pin_mapping': pin_info(cell, port, index)}
                records[bit][role].append(connection)
                if name in moved:
                    records[bit]['moved_cell_connections'].append({**connection, 'direction': direction})
    for name, port in module['ports'].items():
        for index, bit in enumerate(port['bits']):
            if bit in records:
                records[bit]['top_ports'].append({'name': name, 'bit_index': index,
                                                'direction': port['direction']})
    for record in records.values():
        record['serialized_user_pin_count'] = len(record['users'])
        record['serialized_user_cell_count'] = len({p['cell'] for p in record['users']})
        record['mapped_signal_user_pin_count'] = sum(
            bool(p['pin_mapping']) and p['pin_mapping']['state_and_physical_pins'][0] in (0, 3)
            for p in record['users'])
    return list(records.values())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=SOURCE)
    args = parser.parse_args()
    raw = args.source.read_bytes()
    require(sha(raw) == SOURCE_SHA, 'Unexpected source checksum; this diagnostic is frozen')
    before = read_json(raw)
    require(list(before['modules']) == ['top'], 'Expected exactly module top')
    module = before['modules']['top']
    require(module['attributes']['step'] == 'place', 'Source is not a placed checkpoint')
    require(not any(k.startswith('FES_LABSTATE') for k in module['attributes']),
            'Routed LAB snapshot cannot be moved with this script')
    routes = [net['attributes']['ROUTING'] for net in module['netnames'].values()
              if 'ROUTING' in net.get('attributes', {})]
    require(all(isinstance(r, str) and not r.strip() for r in routes),
            'Source contains physical routing; relocation would leave stale routes')
    sites_raw = (ROOT / 'native-m10k-sites.txt').read_bytes()
    site_positions = [tuple(map(int, line.split())) for line in sites_raw.decode().splitlines()]
    require(len(site_positions) == 553 and len(set(site_positions)) == 553,
            'Unexpected native 5CSEBA6U23I7 M10K site inventory')
    sites = {f'MISTRAL_M10K.{x}.{y}.0' for x, y in site_positions}
    occupied = collections.defaultdict(list)
    for name, cell in module['cells'].items():
        bel = cell.get('attributes', {}).get('NEXTPNR_BEL')
        if bel:
            occupied[bel].append(name)
    output = raw
    move_proof = []
    for name, old, new in MOVES:
        cell = module['cells'][name]
        attrs = cell['attributes']
        require(cell['type'] == 'MISTRAL_M10K', 'Wrong selected RAM type')
        require(list(attrs) == ['BEL_STRENGTH', 'NEXTPNR_BEL', 'FES_PINMAP_V1',
                                'src', 'module_not_derived'], 'Unexpected selected RAM attributes')
        require(attrs['NEXTPNR_BEL'] == old and occupied[old] == [name], 'Wrong original RAM location')
        require(int(attrs['BEL_STRENGTH'], 2) == 1, 'Selected RAM is not weakly placed')
        require(new in sites and old in sites, 'RAM location absent from native device inventory')
        require(not occupied[new], 'Destination BEL is occupied')
        pinmap = read_json(bytes.fromhex(attrs['FES_PINMAP_V1']))
        require(pinmap['count'] == len(pinmap['pins']) == 34, 'Unexpected RAM pin snapshot')
        require(all(isinstance(pin, str) and '.' not in pin
                    for values in pinmap['pins'].values() for pin in values[1:]),
                'RAM snapshot contains coordinate-qualified physical pins')
        old_token = f'"NEXTPNR_BEL": "{old}"'.encode()
        new_token = f'"NEXTPNR_BEL": "{new}"'.encode()
        require(output.count(old_token) == 1, 'Original BEL token is not unique')
        require(output.count(new_token) == 0, 'Destination BEL token already present')
        output = output.replace(old_token, new_token)
        move_proof.append({'cell': name, 'old_bel': old, 'new_bel': new,
                           'old_xyz': list(map(int, old.split('.')[1:])),
                           'new_xyz': list(map(int, new.split('.')[1:])),
                           'native_destination_exists': True, 'destination_previously_free': True,
                           'bel_strength': 1, 'pinmap_sha256': sha(bytes.fromhex(attrs['FES_PINMAP_V1']))})
    after = read_json(output)
    actual = differences(before, after)
    expected = [{'path': ['modules', 'top', 'cells', name, 'attributes', 'NEXTPNR_BEL'],
                 'before': old, 'after': new} for name, old, new in MOVES]
    require(actual == expected, 'Unexpected graph or metadata difference: ' + repr(actual))
    reconstructed = output
    for _, old, new in MOVES:
        reconstructed = reconstructed.replace(f'"NEXTPNR_BEL": "{new}"'.encode(),
                                              f'"NEXTPNR_BEL": "{old}"'.encode())
    require(reconstructed == raw, 'Bytewise inverse patch does not restore exact source')
    candidate = ROOT / 'candidate-placed.json'
    candidate.write_bytes(output)
    incident = inventory(module, {name for name, _, _ in MOVES})
    dump(ROOT / 'affected-net-fanouts.json', {
        'description': 'All serialized incident-net drivers/users, including shared clocks and constants. '
                       'Physical folded pin states are retained; serialized fanout is not timing fanout.',
        'net_count': len(incident), 'nets': incident})
    proof = {'kind': 'diagnostic placement-only checkpoint; no routing or timing acceptance',
             'source_path': str(args.source.resolve()), 'source_sha256': sha(raw),
             'candidate_path': str(candidate), 'candidate_sha256': sha(output),
             'source_bytes': len(raw), 'candidate_bytes': len(output),
             'changed_byte_count': sum(a != b for a, b in zip(raw, output)),
             'native_site_inventory_sha256': sha(sites_raw), 'native_site_count': len(sites),
             'moves': move_proof, 'all_differences': actual,
             'proof': {'bytewise_inverse_restores_source': True, 'object_and_list_order_preserved': True,
                       'cell_and_net_order_preserved': True, 'logical_graph_unchanged': True,
                       'all_other_attributes_parameters_and_settings_unchanged': True,
                       'all_13597_route_attributes_whitespace_only': len(routes) == 13597,
                       'no_routed_lab_snapshot': True, 'no_keep_guard_overridden': True},
             'affected_net_count': len(incident),
             'affected_net_fanouts_sha256': sha((ROOT / 'affected-net-fanouts.json').read_bytes())}
    dump(ROOT / 'preparation-proof.json', proof)
    print(json.dumps({'candidate': str(candidate), 'sha256': sha(output),
                      'changed_bytes': proof['changed_byte_count'], 'affected_nets': len(incident)}))


if __name__ == '__main__':
    main()
