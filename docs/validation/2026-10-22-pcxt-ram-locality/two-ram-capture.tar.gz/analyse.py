#!/usr/bin/env python3
"""Read-only geometry and original routed-endpoint context for the two RAM moves."""
import hashlib
import json
from pathlib import Path
from prepare import MOVES, ROOT, dump, require


def xy(bel):
    return tuple(map(int, bel.split('.')[1:3]))


def distance(a, b):
    return sum(abs(x - y) for x, y in zip(a, b))


def main():
    baseline = ROOT.parent / 'move-margins-20261022/baseline/endpoints.json'
    endpoints = json.loads(baseline.read_bytes())
    incident = json.loads((ROOT / 'affected-net-fanouts.json').read_bytes())['nets']
    moves = {name: (old, new) for name, old, new in MOVES}
    addresses, outputs = [], []
    for net in incident:
        for pin in net['moved_cell_connections']:
            name = pin['cell']
            old, new = moves[name]
            if pin['port'] == 'B1ADDR':
                require(len(net['drivers']) == 1, 'Address net lacks one driver')
                driver = net['drivers'][0]
                identity = [name, f'B1ADDR[{pin["bit_index"]}]']
                rows = endpoints['endpoints'][json.dumps(identity)]
                addresses.append({'ram': name, 'address_bit': pin['bit_index'],
                                  'driver': driver['cell'], 'driver_bel': driver['bel'],
                                  'net': net['aliases'], 'fanout': net['serialized_user_pin_count'],
                                  'old_manhattan_tiles': distance(xy(old), xy(driver['bel'])),
                                  'new_manhattan_tiles': distance(xy(new), xy(driver['bel'])),
                                  'baseline_native_rows': rows})
            elif pin['port'] == 'B1DATA':
                for user in net['users']:
                    outputs.append({'ram': name, 'data_bit': pin['bit_index'],
                                    'consumer': user['cell'], 'consumer_bel': user['bel'],
                                    'consumer_port': user['port'],
                                    'old_manhattan_tiles': distance(xy(old), xy(user['bel'])),
                                    'new_manhattan_tiles': distance(xy(new), xy(user['bel']))})
    def summary(rows):
        return {'count': len(rows),
                'closer': sum(r['new_manhattan_tiles'] < r['old_manhattan_tiles'] for r in rows),
                'farther': sum(r['new_manhattan_tiles'] > r['old_manhattan_tiles'] for r in rows),
                'equal': sum(r['new_manhattan_tiles'] == r['old_manhattan_tiles'] for r in rows),
                'old_sum_manhattan_tiles': sum(r['old_manhattan_tiles'] for r in rows),
                'new_sum_manhattan_tiles': sum(r['new_manhattan_tiles'] for r in rows)}
    result = {'kind': 'placement geometry plus original routed timing; no candidate timing prediction',
              'baseline_endpoints_path': str(baseline),
              'baseline_endpoints_sha256': hashlib.sha256(baseline.read_bytes()).hexdigest(),
              'address_edges': addresses, 'output_edges': outputs,
              'address_geometry': summary(addresses), 'output_geometry': summary(outputs),
              'baseline_address_rows': sum(len(r['baseline_native_rows']) for r in addresses),
              'baseline_address_negative_setup_rows': sum(
                  row['setup'] < 0 for r in addresses for row in r['baseline_native_rows']),
              'baseline_address_min_setup_ps': min(
                  row['setup'] for r in addresses for row in r['baseline_native_rows']),
              'baseline_address_min_hold_ps': min(
                  row['hold'] for r in addresses for row in r['baseline_native_rows'])}
    dump(ROOT / 'geometry-and-baseline.json', result)
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ['address_edges', 'output_edges']}))


if __name__ == '__main__':
    main()
