#include "cyclonev.h"
#include <iostream>
#include <memory>
int main() {
    std::unique_ptr<mistral::CycloneV> model(mistral::CycloneV::get_model("5CSEBA6U23I7"));
    if (!model) return 1;
    for (auto pos : model->m10k_get_pos()) std::cout << pos.x() << ' ' << pos.y() << '\n';
}
