# Two-ROM locality diagnostic

This directory prepares one placement experiment for the PC/XT 2.5 ns
CPU-to-microcode address window. It changes two weakly placed, unprotected M10K
locations. No RTL, register placement, clock, phase, pin mapping, net connection,
parameter, timing gate or compiler source changes are included.

All cell names below have prefix
`system.machine.cpu.cpu.u_eu_core.u_ucode_rom.bytes[2].`.

| Cell suffix | Original BEL | Candidate BEL |
| --- | --- | --- |
| `rom.3.0.0` | `MISTRAL_M10K.41.34.0` | `MISTRAL_M10K.14.36.0` |
| `rom.2.0.0` | `MISTRAL_M10K.38.34.0` | `MISTRAL_M10K.14.37.0` |

`candidate-placed.json` SHA256:
`f8f7c7ec4cefe4956c5368f73b146517e49802a0d29c100c63e2ed18658a2901`.

Source: `/tmp/pcxt-replicate-leased-20261022/inputs/placed.json`, SHA256
`9241b02074cfee262c985c9ddde7e2c71f05bc654d35b989857a9a93ccc58878`.
The source creator string is historical provenance; the native checker used
compiler commit `66c97e4908304cd46f986a35335cb424cac23864`, binary SHA256
`97e818cc3f6f2e96e4826c0074323d18b3a85449948cb7546f8952492358c2b5`.

## Checks performed

`prepare.py` verifies the exact frozen input hash, cell names and types, original
BELs, weak strength, attribute inventory, distinct free destination BELs, native
device site existence and coordinate-free RAM pin snapshots. It rejects any
nonempty routing or routed LAB snapshot. All 13,597 source `ROUTING` attributes
contain a single space; the checkpoint has `step=place` and no `FES_LABSTATE`.

The candidate changes exactly six bytes in the two `NEXTPNR_BEL` values. All
other bytes, including JSON cell/net order, are preserved. An ordered recursive
comparison admits exactly those two value changes; reversing the two token
replacements restores the original bytes. `BEL_STRENGTH`, the complete
`FES_PINMAP_V1` snapshots, all INIT bits and every saved setting are unchanged.
Results are in `preparation-proof.json`.

`native-m10k-sites.cc` enumerates the Mistral model's 553 M10K positions for
`5CSEBA6U23I7`. Both selected destinations exist and were unoccupied in the source.
`native-site-probe.json` records the compile recipe and hashes of the source,
binary, library, header and exact enumeration output. This probe does not route.

The frozen compiler loaded the candidate successfully with
`--no-pack --no-place --no-route` in 4.83 seconds, including its native BEL binding
and pin-map restoration checks. `native-checkpoint-load.json` contains the exact
command and hashes; the log is beside it. This is a host-only checkpoint check,
not routed legality, STA, RBF or hardware evidence.

The supported checkpoint mechanism is defined in nextpnr
`common/kernel/basectx.cc` (`attributesToArchInfo`) and
`mistral/fes_slot.cc` (`restore_cell_pin_map` and `restore_placed_pin_maps`). Native
restore resolves each `NEXTPNR_BEL` and validates each saved physical pin against
that destination. A placed snapshot retains coordinate-free pin states and does
not lock a routed LAB scaffold. No hidden coordinate-bearing placement state was
found on these RAMs.

## Geometry and risks

The original native endpoint report has 19 negative setup rows among these
24 RAM address endpoints, with worst setup -1,461 ps and minimum hold 9,250 ps.
Each of the 12 lane-2 address registers drives four RAMs; this experiment moves
two of those four sinks and preserves all 48 duplicated address registers,
including their `keep` attributes.

The worst lane-2 bit-9 register is at `MISTRAL_FF.18.41.14`. Its Manhattan
distance to ROM3 falls from 30 to 9 tiles and to ROM2 from 27 to 8. Across all
24 moved address edges, 20 get closer and four get farther; summed distance falls
from 498 to 272 tiles. All 63 immediate RAM output edges get closer, with summed
distance falling from 1,463 to 392 tiles. `geometry-and-baseline.json` records
every edge and its original endpoint rows. Geometry is not a delay estimate.

The four worsening address edges are bits 3 and 4, whose registers remain at
x=31, y=36. Their distances rise from 12 to 17 tiles for ROM3 and 9 to 18 for
ROM2. Original setup margins for these four rows are only 159–583 ps. They are
the main local regression risk. Native timing must also check the unchanged two
lane-2 RAMs and all other sinks sharing the address nets, clock and constants.

`affected-net-fanouts.json` exhaustively lists all drivers, users, top ports,
aliases and saved physical pin mappings on the 19 incident nets: 12 address
nets (fanout four each), four output nets (fanouts 16, 16, 16 and 15), the shared
microcode clock (32 input pins), GND (1,534 input pins) and VCC (356 input pins).
These are serialized connection counts, with physical pin states provided
separately. Shared-net rerouting and local congestion can affect other paths.

Shortening a direct data path can reduce its positive hold margin while improving
setup. The existing incremental repair guard rejects every margin decrease;
this experiment does not change that guard. It needs an independently routed
placement and full paired setup/hold endpoint comparison. Its preparation does
not establish acceptance under any timing policy.

## Reproduction and next integration step

From this directory:

```sh
python3 prepare.py
python3 analyse.py
```

Both scripts are deterministic and use the frozen source and native site
inventory. `analyse.py` reads the original report at
`../move-margins-20261022/baseline/endpoints.json`; its hash is recorded in the
generated JSON.

Route `candidate-placed.json` as a fresh independent diagnostic through the
existing shared-GPU lease runner, using the frozen 66c97e49 binary, the original
QSF/SDC, seed 1 and the existing route recipe. Do not rerun packing or placement.
Collect final routed JSON, RBF, native setup/hold endpoints, detailed timing and
the usual binary/input/environment receipt. Compare the complete endpoint and
contract inventories against the matching original baseline. Keep this RAM-only
result separate from the LUT reassociation experiment before testing a combined
candidate. The original 105 unsupported endpoint obligations remain outstanding.

Scope/result: uncommitted diagnostic artifacts only, entirely within this
directory; no module/shared contract changes, no route launched, no hardware used.
