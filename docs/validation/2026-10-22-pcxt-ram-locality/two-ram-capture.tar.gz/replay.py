from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parent
reference=root.parent/'reassociate-20261022'
old=json.loads((reference/'baseline/receipt.json').read_text())
cmd=old['nextpnr_command'][:]
cmd[cmd.index('--json')+1]=str(root/'candidate-placed.json')
wrapper=str(root.parents[1]/'scripts/gpu-run')
command=[wrapper,'--phase-lease','--owner','pcxt-timing','--label','pcxt-ram-locality','--',*cmd]
p=root/'candidate';p.mkdir(exist_ok=False)
env=dict(os.environ);env['NEXTPNR_REQUIRE_GPU']='1'
receipt={'command':command,'nextpnr_command':cmd,'evidence':'leased GPU host diagnostic; placement experiment, not acceptance','baseline_receipt':str(reference/'baseline/receipt.json'),'limit':'native bounded router iterations; no external GPU-job termination','binary_sha256':hashlib.file_digest(open(cmd[0],'rb'),'sha256').hexdigest(),'input_sha256':hashlib.file_digest((root/'candidate-placed.json').open('rb'),'sha256').hexdigest()}
start=time.monotonic()
with (p/'nextpnr.log').open('w') as log:receipt['returncode']=subprocess.run(command,cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
receipt['charged_seconds']=time.monotonic()-start
receipt['artifacts']={f.name:hashlib.file_digest(f.open('rb'),'sha256').hexdigest() for f in p.iterdir() if f.suffix in ['.json','.rbf']}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
