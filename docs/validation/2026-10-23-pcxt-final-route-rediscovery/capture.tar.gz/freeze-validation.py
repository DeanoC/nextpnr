#!/usr/bin/env python3
"""Freeze complete focused host admission; no final-route outcome is inferred."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
R=Path(__file__).resolve().parent;F=R/'source-validation';H=F/'final-host';OLD=R.parent/'cga-source-exit-retention-20261023';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,value):
 assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def blob(name):return subprocess.check_output(['git','show',base+':'+name],cwd=S)
assert sha(OLD/'final-validation.json')=='a3762f00fdb6a84e54b0e2daf63a3aae9e12a3ff3d0c8efc12051e8790122c0e'
old=read(OLD/'final-validation.json');identity=read(H/'source-identity.json');proposal=read(R/'source-identity.json');build=read(F/'build-identity.json');review=read(R/'independent-source-review.json');fixture=read(H/'independent-fixture-registration-review.json');guard=read(H/'unchanged-guards-proof.json')
base=identity['base_commit'];assert base=='1ba2e289f5bf4e584a8539f185d6f15383650c26' and len(identity['files'])==10 and len(proposal['files'])==9
assert identity['proposal_identity_sha256']==sha(R/'source-identity.json')==review['source_identity_sha256']
assert review['passed_source_review'] and review['files']==identity['files'] and review['final_source_identity_sha256']==sha(H/'source-identity.json') and review['base_commit']==base
assert fixture['passed'] and fixture['source_identity_sha256']==sha(H/'source-identity.json') and fixture['source_base_commit']==base
assert fixture['fixture_sha256']==identity['files']['mistral/tests/final_route_source_coverage.cc']['sha256'] and fixture['cmake_sha256']==identity['files']['mistral/CMakeLists.txt']['sha256']
assert review['fixture_registration_review_sha256']==build['fixture_registration_review_sha256']==sha(H/'independent-fixture-registration-review.json')
assert review['supplemental_rebind_review_sha256']==build['supplemental_source_review_sha256']==sha(R/'supplemental-rebind-comment-review.json')
assert read(R/'supplemental-rebind-comment-review.json')['passed']
assert build['source_identity_sha256']==sha(H/'source-identity.json') and build['unchanged_guards_proof_sha256']==sha(H/'unchanged-guards-proof.json')
assert sha(R/'nextpnr-mistral')==build['production_sha256']=='52dda57ca0a9da4c57f9f5836764e791aced3e9efab9da9b1c64543c51a417f5'
assert guard['passed'] and guard['complete_parent_source_count']==30 and guard['final_complete_source_count']==34 and guard['parent_final_validation_sha256']==sha(OLD/'final-validation.json')
assert guard['cmake_only_one_native_registration_over_reviewed_proposal'] and guard['entire_prior_lut_source_file_recovered_after_removing_new_wrapper'] and guard['default_zero_returns_before_context_access']
sources=dict(old['source_files']);sources.update({n:v['sha256'] for n,v in identity['files'].items()});assert len(sources)==34
for name,h in sources.items():
 origin=H/'source'/name if name in identity['files'] else OLD/'complete-source'/name
 assert sha(origin)==h==sha(S/name),name
 if name in identity['files']:
  entry=identity['files'][name]
  if entry.get('new_file'):
   check=subprocess.run(['git','cat-file','-e',base+':'+name],cwd=S,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);assert check.returncode!=0
  else:assert hashlib.sha256(blob(name)).hexdigest()==entry['before_sha256']==sha(H/'before'/name)
 else:assert hashlib.sha256(blob(name)).hexdigest()==h==old['source_files'][name]
 dest=R/'complete-source'/name;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==h
 else:shutil.copy2(origin,dest)
for name,h in guard['unchanged_complete_source_files'].items():assert sources[name]==h==old['source_files'][name]
assert set(guard['unchanged_complete_source_files'])==set(old['source_files'])-set(identity['files'])
for name,h in identity['retained_validation_sources'].items():assert sha(S/name)==sha(H/'retained-validation-source'/name)==hashlib.sha256(blob(name)).hexdigest()==h==guard['retained_validation_sources'][name]
for name,record in proposal['files'].items():
 assert sha(R/'source'/name)==record['sha256']
 if name!='mistral/CMakeLists.txt':assert record['sha256']==identity['files'][name]['sha256']
a=(R/'source/mistral/CMakeLists.txt').read_bytes();b=(H/'source/mistral/CMakeLists.txt').read_bytes();token=b'tests/final_route_source_coverage.cc ';assert b.count(token)==1 and b.replace(token,b'')==a
# Independently recheck the unchanged native transaction and complete source helper.
a=(H/'before/mistral/analogue.cc').read_text();b=(H/'source/mistral/analogue.cc').read_text();start='bool critical_route_trial(';end='void Arch::repair_critical_routes('
a=a[a.index(start):a.index(end)];b=b[b.index(start):b.index(end)];assert a==b and hashlib.sha256(a.encode()).hexdigest()==guard['exact_native_route_transaction_sha256']
summary=read(F/'validation.json');assert summary['pass'] and summary['sources_and_binaries_unchanged'] and summary['build_identity_sha256']==sha(F/'build-identity.json')
counts={'final-source-native':9,'retained-native':22,'final-route-cli':7,'prior-route-cli':2}
assert len(summary['results'])==4 and {x['name'] for x in summary['results']}==set(counts)
for name,count in counts.items():
 rec=read(F/(name+'.receipt.json'));text=(F/(name+'.log')).read_text();assert rec['returncode']==0 and rec['pass'] and rec['expected_count']==rec['observed_count']==count and rec['log_sha256']==sha(F/(name+'.log'))
 assert rec==next(x for x in summary['results'] if x['name']==name)
 if name.endswith('cli'):assert re.search(r'Ran '+str(count)+r' tests in',text) and re.search(r'\nOK\s*$',text)
 else:
  runs=re.findall(r'^\[ RUN      \] (.+)$',text,re.M);passes=re.findall(r'^\[       OK \] (.+) \(\d+ ms\)$',text,re.M);assert len(runs)==len(passes)==len(set(runs))==count and runs==passes
control=read(R/'control-proof.json');assert control['default_zero_raw_bytes_equal'] and sorted(x['case'] for x in control['controls'])==['default','zero'] and control['script_sha256']==sha(R/'prepare-controls.py')
prior=read(OLD/'prepare-default/receipt.json');oldbytes=(OLD/'prepare-default/placed.json').read_bytes()
for item in control['controls']:
 assert all(item[k] for k in ('complete_modules_equal','all_bytes_except_creator_equal','predicted_timing_bytes_equal'))
 folder=R/('prepare-'+item['case']);receipt=read(folder/'receipt.json');assert receipt['returncode']==0 and receipt['binary_sha256']==build['production_sha256'] and receipt['inputs']==prior['inputs']
 command=prior['nextpnr_command'][:];command[0]=str(R/'nextpnr-mistral')
 if item['case']=='zero':command+=['--critical-final-route-budget','0']
 assert receipt['nextpnr_command']==command and '--no-route' in command and '--rbf' not in command
 for p,h in receipt['artifacts'].items():assert sha(folder/p)==h
 newbytes=(folder/'placed.json').read_bytes();a=json.loads(oldbytes);b=json.loads(newbytes);ca=json.dumps(a.pop('creator')).encode();cb=json.dumps(b.pop('creator')).encode();assert a==b and oldbytes.count(ca)==1 and oldbytes.replace(ca,cb,1)==newbytes
 assert (folder/'predicted-timing.json').read_bytes()==(OLD/'prepare-default/predicted-timing.json').read_bytes()
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
write(R/'retained-source-proof.json',{'parent_commit':base,'parent_final_validation_sha256':sha(OLD/'final-validation.json'),'unchanged_source_files':guard['unchanged_complete_source_files'],'current_native_transaction_sha256':guard['exact_native_route_transaction_sha256'],'scope':'Current new9 plus retained22 native and CLI7+2 reran. Other native/CLI suites retain prior exact-source/build provenance; no rerun is inferred.'})
files={}
for prefix in ('source','before','source-validation','complete-source','prepare-default','prepare-zero'):
 for p in sorted((R/prefix).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:files[str(p.relative_to(R))]=sha(p)
for name in ('source-identity.json','independent-source-review.json','supplemental-rebind-comment-review.json','installation.json','production.patch','prepare-controls.py','control-run.log','control-proof.json','retained-source-proof.json','freeze-validation.py','route.py'):
 assert (R/name).is_file();files[name]=sha(R/name)
final={'scope':'Host-only admission for default-off final critical-route rediscovery after identical earlier LUT repairs. Fresh skewed/reference-free source/downstream/clock/endpoint guards and exact native route rollback remain required. No final route, timing gain, closure or hardware acceptance.',
 'binary_sha256':build['production_sha256'],'native_test_sha256':build['native_test_sha256'],'source_parent':base,'source_files':sources,'files':files,
 'final_source_identity_path':'source-validation/final-host/source-identity.json','final_source_identity_sha256':sha(H/'source-identity.json'),
 'independent_source_review_passed':True,'source_review_path':'independent-source-review.json','source_review_sha256':sha(R/'independent-source-review.json'),
 'independent_fixture_registration_review_path':'source-validation/final-host/independent-fixture-registration-review.json','independent_fixture_registration_review_sha256':sha(H/'independent-fixture-registration-review.json'),
 'control_proof_sha256':sha(R/'control-proof.json'),'enabled_final_route_rediscovery_route_admission':True,'validation_passed':True,
 'validation':{'passed':True,'final_route_source_native_count':9,'retained_native_count':22,'total_native_count':31,'final_route_cli_count':7,'prior_route_cli_count':2},
 'retained_prior_validation':{'path':str(OLD/'final-validation.json'),'sha256':sha(OLD/'final-validation.json'),'unchanged_source_proof_sha256':sha(R/'retained-source-proof.json'),'scope':'Prior source-exit/permutation/LUT6/private/unused/cache evidence remains at original source/build provenance. Current reruns are exactly9+22+7+2.'}}
write(R/'final-validation.json',final);print(json.dumps({'sha256':sha(R/'final-validation.json'),'files':len(files),'source_files':len(sources)},sort_keys=True))
