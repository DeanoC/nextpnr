#!/usr/bin/env python3
"""Retain complete FINAL evidence plus exact selected members of the EXIT archive."""
from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
C=Path(__file__).resolve().parent;A=C.parent;R=A.parent;P=C/'payload';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');OLD=R.parent/'cga-source-exit-retention-20261023'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def copy(p,n=None):
 d=P/(n or p.relative_to(R));d.parent.mkdir(parents=True,exist_ok=True)
 if d.exists():assert sha(d)==sha(p),str(d)
 else:shutil.copy2(p,d)
 return str(d.relative_to(P))
assert not P.exists();P.mkdir()
final=read(R/'final-validation.json');assert sha(R/'final-validation.json')=='08b918b4f9e282d21b0fde5a5578ed8af836b9938d77fcafe160136518592fd6'
assert len(final['files'])==111 and len(final['source_files'])==34
for n,h in final['files'].items():assert sha(R/n)==h;copy(R/n)
for n in ['final-validation.json','committed-source-verification.json','route.py','verify-and-commit.py','record-runs.py','accounting.json','README.md','selection.json']:copy(R/n)
commit=read(R/'committed-source-verification.json');assert commit['commit']=='626e368b0529c4516aa3a7a4bb4bcdd034011e30' and commit['source_files']==final['source_files']
for n,h in final['source_files'].items():assert hashlib.sha256(subprocess.check_output(['git','show',commit['commit']+':'+n],cwd=S)).hexdigest()==h==sha(P/'complete-source'/n)
for case in ('default','final32'):
 receipt=read(R/f'route-{case}/receipt.json');assert receipt['binary_sha256']==final['binary_sha256']
 for n,h in receipt['artifacts'].items():assert sha(R/f'route-{case}'/n)==h;copy(R/f'route-{case}'/n)
 copy(R/f'route-{case}/receipt.json')
for p in sorted(A.rglob('*')):
 if p.is_file() and not {'capture','__pycache__'}&set(p.relative_to(A).parts):copy(p)
for p in sorted((R/'native-topology').rglob('*')):
 if p.is_file() and p.name!='tree-reader' and '__pycache__' not in p.parts:copy(p)
for p in sorted((R/'accounting-54').iterdir()):
 if p.is_file():copy(p)
assert sha(P/'accounting-54/continued-runs.jsonl')==read(R/'accounting.json')['journal_sha256']
omitted=[]
for p in [R/'nextpnr-mistral',R/'native-topology/tree-reader']:
 omitted.append({'original_path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'reason':'Executable omitted; only immutable records and saved outputs are replayed.'})
write(P/'omitted-payloads.json',{'files':omitted,'native_snapshot_manifest':'native-topology/frozen-manifest.json','scope':'All 401 native snapshot payloads and host test executables are omitted with recorded hashes. No native reader was needed for the unchanged trees; no test/native/GPU execution is replayed.'})
archive=OLD/'final-analysis/capture/capture.tar.gz';assert sha(archive)=='bb41b70758c9b2a2b09069ddcc7c3f5bde829a40f082dcf208310d1a5422f221'
bindings=[]
with tarfile.open(archive) as t:
 data=t.extractfile('manifest.json').read();m=json.loads(data)
 dependency={'archive_sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(t.getmembers()),'manifest_sha256':hashlib.sha256(data).hexdigest(),'manifest_path':'dependencies/exit-manifest.json'}
 assert dependency['members']==len(m)+1==418
 (P/'dependencies').mkdir();(P/dependency['manifest_path']).write_bytes(data)
 def retain(member,target):
  payload=t.extractfile(member).read();d=P/target;d.parent.mkdir(parents=True,exist_ok=True)
  if d.exists():assert d.read_bytes()==payload
  else:d.write_bytes(payload)
  assert sha(d)==m[member]['sha256'];bindings.append({'dependency':'exit','member':member,'retained_path':target,'sha256':sha(d)})
 prefixes=[('prepare-default/','references/prior-prepare/'),('complete-source/','references/prior-source/'),('references/reader-source/','references/reader-source/'),('route-default/','references/prior-route/'),('external-inputs/','external-inputs/'),('accounting-52/','references/accounting-52/')]
 for member in sorted(m):
  target=None
  for prefix,dest in prefixes:
   if member.startswith(prefix):target=dest+member[len(prefix):]
  if member in ('final-validation.json','committed-source-verification.json','archive-mode.json','CAPTURE-README.md'):target='references/exit-evidence/'+member
  if target:retain(member,target)
 for name in ('architecture-compatibility.json','prepare.py','independent-reader-review.json'):retain('native-topology/'+name,'references/exit-native/'+name)
 retain('references/prior-route/routed.json','fixtures/lut-permutation-budget32-20261023/route-budget32/routed.json')
 for original,h in read(R/'selection.json')['evidence_files'].items():
  member=str(Path(original).relative_to(OLD));target='references/selection-evidence/'+member
  retain(member,target);assert sha(P/target)==h
recorded={};receipt=read(R/'route-default/receipt.json')
for path,h in receipt['immutable_evidence_sha256'].items():
 original=Path(path)
 if original.is_relative_to(R):target=str(original.relative_to(R))
 else:assert original==OLD/'route-default/receipt.json';target='references/prior-route/receipt.json'
 assert sha(P/target)==h;recorded[path]={'retained_path':target,'sha256':h}
for original,h in read(R/'selection.json')['evidence_files'].items():
 target='references/selection-evidence/'+str(Path(original).relative_to(OLD));assert sha(P/target)==h;recorded[original]={'retained_path':target,'sha256':h}
for v in receipt['inputs'].values():
 target='external-inputs/'+v['sha256']+'-'+Path(v['path']).name;assert sha(P/target)==v['sha256'];recorded[v['path']]={'retained_path':target,'sha256':v['sha256']}
write(P/'archive-mode.json',{'recorded_files':recorded,'excluded_binary':{'original_path':receipt['nextpnr_command'][0],'sha256':final['binary_sha256']},'references':{'route':{'original_directory':str(OLD/'route-default'),'retained_path':'references/prior-route'}},'dependencies':{'exit':dependency},'selected_dependency_members':sorted(bindings,key=lambda x:(x['dependency'],x['member'],x['retained_path'])),'test_fixture':{'module':'test_graph_checks','root_override':'fixtures/current-task','retained_path':'fixtures/lut-permutation-budget32-20261023/route-budget32/routed.json','sha256':sha(P/'fixtures/lut-permutation-budget32-20261023/route-budget32/routed.json'),'scope':'Only the standalone corruption test fixture ROOT is rebound; production checker/support roots remain the archive root.'},'scope':'Every dependency member and selected mapping verified with no live original-path fallback. All original checker and proof bytes remain exact.'})
for n in ('prepare.py','replay.py','verify_capture.py','build_archive.py','README.md'):copy(C/n,'CAPTURE-README.md' if n=='README.md' else n)
print(json.dumps({'files':len([p for p in P.rglob('*') if p.is_file()]),'dependency':dependency},indent=2,sort_keys=True))
