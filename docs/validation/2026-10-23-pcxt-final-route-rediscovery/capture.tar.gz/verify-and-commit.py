#!/usr/bin/env python3
"""Root source/frozen evidence verification and exact selected-source commit."""
from pathlib import Path
import argparse, hashlib, json, subprocess
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(p):
 with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO)
def require(x,message):
 if not x: raise ValueError(message)
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--commit',action='store_true');args=parser.parse_args()
 final=ROOT/'final-validation.json';v=json.loads(final.read_text())
 identity=ROOT/'source-validation/final-host/source-identity.json';ident=json.loads(identity.read_text())
 require(v['final_source_identity_path']==str(identity.relative_to(ROOT)) and v['final_source_identity_sha256']==sha(identity),'final identity binding differs')
 require(len(ident['files'])==10 and len(v['source_files'])==34,'source union incomplete')
 require(v['validation']['passed'] is True,'incomplete host validation')
 require(v['enabled_final_route_rediscovery_route_admission'] is True,'missing final-route admission')
 host=json.loads((ROOT/'source-validation/validation.json').read_text())
 require(host['pass'] and host['sources_and_binaries_unchanged'],'incomplete focused host checks')
 groups={x['name']:x for x in host['results']};require(len(groups)==4,'unexpected focused validation groups')
 for name,count in [('final-source-native',9),('retained-native',22),('final-route-cli',7),('prior-route-cli',2)]:
  require(groups[name]['pass'] and groups[name]['returncode']==0 and groups[name]['expected_count']==groups[name]['observed_count']==count,'validation count/failure '+name)
 for p,h in v['files'].items(): require(sha(ROOT/p)==h,'evidence hash mismatch '+p)
 for p,h in v['source_files'].items(): require(sha(REPO/p)==h,'source mismatch '+p)
 for p,info in ident['files'].items():
  require(v['source_files'][p]==info['sha256'],'changed source not bound '+p)
  require(sha(identity.parent/'source'/p)==info['sha256'],'frozen source mismatch '+p)
 require(sha(ROOT/'nextpnr-mistral')==v['binary_sha256'],'frozen binary mismatch')
 require(v['independent_source_review_passed'] is True,'independent source review missing')
 review=json.loads((ROOT/'independent-source-review.json').read_text())
 proposal=ROOT/'source-identity.json';proposal_identity=json.loads(proposal.read_text())
 require(review['passed_source_review'] is True and review['files']==ident['files'],'independent final source review mismatch')
 require(review['source_identity_sha256']==sha(proposal)==ident['proposal_identity_sha256'],'independent proposal identity')
 require(review['final_source_identity_sha256']==sha(identity),'independent final identity')
 require(review['base_commit']==ident['base_commit'],'review base differs')
 fixture_path=identity.parent/'independent-fixture-registration-review.json';fixture=json.loads(fixture_path.read_text())
 require(fixture['passed'] is True and fixture['source_identity_sha256']==sha(identity),'independent fixture/registration review differs')
 require(fixture['fixture_sha256']==ident['files']['mistral/tests/final_route_source_coverage.cc']['sha256'] and fixture['cmake_sha256']==ident['files']['mistral/CMakeLists.txt']['sha256'],'fixture source differs')
 require(review['fixture_registration_review_sha256']==sha(fixture_path),'production review fixture binding differs')
 require(v['files'][str(fixture_path.relative_to(ROOT))]==sha(fixture_path),'final manifest omitted fixture review')
 for p,info in proposal_identity['files'].items():
  if p!='mistral/CMakeLists.txt':require(ident['files'][p]['sha256']==info['sha256'],'final production source drift '+p)
 old_cmake=(ROOT/'source/mistral/CMakeLists.txt').read_text();new_cmake=(identity.parent/'source/mistral/CMakeLists.txt').read_text()
 require(new_cmake.replace('TEST_SOURCES tests/final_route_source_coverage.cc ','TEST_SOURCES ',1)==old_cmake,'unexpected registration difference')
 for p,info in ident['files'].items():
  if info.get('new_file'):
   result=subprocess.run(['git','cat-file','-e',ident['base_commit']+':'+p],cwd=REPO,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   require(result.returncode!=0,'new file already exists in base '+p)
  else:require(digest(git('show',ident['base_commit']+':'+p))==info['before_sha256'],'base file differs '+p)
 require(v['control_proof_sha256']==sha(ROOT/'control-proof.json'),'control proof mismatch')
 changed=set()
 for row in git('status','--porcelain=v1','-z').decode().split('\0'):
  if row: changed.add(row[3:])
 require(changed==set(ident['files']),'unexpected unstaged changes '+str(changed.symmetric_difference(ident['files'])))
 require(not git('diff','--cached','--name-only').strip(),'unrelated staged files')
 subprocess.run(['git','diff','--check'],cwd=REPO,check=True)
 print(json.dumps({'status':'host/source verification passed','files_verified':len(v['files']),'source_files_verified':len(v['source_files']),'changed_files':len(changed),'binary_sha256':v['binary_sha256']}),flush=True)
 if not args.commit:return
 before=git('rev-parse','HEAD').decode().strip()
 subprocess.run(['git','add','--',*sorted(ident['files'])],cwd=REPO,check=True)
 require(set(git('diff','--cached','--name-only').decode().splitlines())==changed,'staged file set mismatch')
 subprocess.run(['git','commit','-m','mistral: rediscover guarded critical routes after LUT repairs'],cwd=REPO,check=True)
 commit=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
 for p,h in v['source_files'].items():require(digest(git('show',commit+':'+p))==h,'committed source mismatch '+p)
 receipt={'commit':commit,'tree':tree,'source_files':v['source_files'],'binary_sha256':v['binary_sha256'],'final_validation_sha256':sha(final),'all_recorded_source_bytes_match_commit':True,'scope':'Host admission for explicit bounded routed trials; no final routed timing or hardware acceptance','observed_build_parent':ident['base_commit'],'precommit_head':before,'verification_script_sha256':sha(__file__),'independent_source_review_sha256':sha(ROOT/'independent-source-review.json'),'final_fixture_review_sha256':sha(fixture_path),'final_source_identity_sha256':sha(identity)}
 (ROOT/'committed-source-verification.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'commit':commit,'tree':tree,'source_files_verified':len(v['source_files'])}),flush=True)
 subprocess.run(['git','push','origin','HEAD'],cwd=REPO,check=True)
if __name__=='__main__':main()
