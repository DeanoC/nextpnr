#!/usr/bin/env python3
"""Offline complete host/source/graph/timing/accounting replay; no native execution."""
from pathlib import Path
from decimal import Decimal
import contextlib,hashlib,importlib,io,json,runpy,sys
R=Path(__file__).resolve().parent;A=R/'final-analysis';sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
def main():
 mode=support.archive_mode();assert mode is not None and support.ROOT==R
 final=read(R/'final-validation.json');commit=read(R/'committed-source-verification.json');assert commit['commit']=='626e368b0529c4516aa3a7a4bb4bcdd034011e30' and commit['source_files']==final['source_files'] and commit['final_validation_sha256']==sha(R/'final-validation.json')
 assert len(final['files'])==111 and len(final['source_files'])==34
 for p,h in final['files'].items():assert sha(R/p)==h,p
 for p,h in final['source_files'].items():assert sha(R/'complete-source'/p)==h,p
 prior=read(R/'references/exit-evidence/final-validation.json');assert len(prior['source_files'])==30
 for p,h in prior['source_files'].items():assert sha(R/'references/prior-source'/p)==h,p
 identity=read(R/'source-validation/final-host/source-identity.json');assert len(identity['files'])==10 and identity['base_commit']=='1ba2e289f5bf4e584a8539f185d6f15383650c26'
 for p,v in identity['files'].items():
  assert sha(R/'source-validation/final-host/source'/p)==v['sha256']==final['source_files'][p]
  if not v.get('new_file'):
   assert sha(R/'source-validation/final-host/before'/p)==v['before_sha256']
   if p in prior['source_files']:assert v['before_sha256']==prior['source_files'][p]
 control=read(R/'control-proof.json');assert control['default_zero_raw_bytes_equal']
 for case in ('default','zero'):
  p=R/('prepare-'+case);q=R/'references/prior-prepare';a=(q/'placed.json').read_bytes();b=(p/'placed.json').read_bytes();x=json.loads(a);y=json.loads(b);ca=json.dumps(x.pop('creator')).encode();cb=json.dumps(y.pop('creator')).encode()
  assert x==y and a.count(ca)==1 and a.replace(ca,cb,1)==b and (p/'predicted-timing.json').read_bytes()==(q/'predicted-timing.json').read_bytes()
  assert read(p/'receipt.json')['reference_receipt_sha256']==sha(q/'receipt.json')
  for n,h in read(p/'receipt.json')['artifacts'].items():assert sha(p/n)==h
 assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
 summary=read(R/'source-validation/validation.json');assert summary['pass'] and summary['sources_and_binaries_unchanged'] and len(summary['results'])==4
 for name,count in [('final-source-native',9),('retained-native',22),('final-route-cli',7),('prior-route-cli',2)]:
  v=read(R/'source-validation'/(name+'.receipt.json'));assert v['pass'] and v['returncode']==0 and v['expected_count']==v['observed_count']==count and v in summary['results'] and v['log_sha256']==sha(R/'source-validation'/(name+'.log'))
 guard=read(R/'source-validation/final-host/unchanged-guards-proof.json');assert guard['passed'] and guard['parent_final_validation_sha256']==sha(R/'references/exit-evidence/final-validation.json')
 for name,h in guard['unchanged_complete_source_files'].items():assert final['source_files'][name]==prior['source_files'][name]==h
 native=R/'native-topology';build=read(native/'build-receipt.json');compat=read(native/'architecture-compatibility.json')
 assert build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9' and compat['passed'] and compat['route_compiler_commit']==commit['commit']
 for n,k in [('tree-reader.cc','helper_source_sha256'),('frozen-manifest.json','frozen_manifest_sha256'),('build-commands.json','build_commands_sha256'),('build.log','build_log_sha256')]:assert sha(native/n)==build[k]
 assert len(read(native/'frozen-manifest.json')['files'])==401
 for p,v in compat['changed_snapshotted_source_files'].items():assert sha(R/'references/reader-source'/p)==v['old_sha256'] and sha(R/'complete-source'/p)==v['new_sha256']
 for name in ('architecture-compatibility.json','prepare.py','independent-reader-review.json'):
  retained={'architecture-compatibility.json':'prior-exit-compatibility.json','prepare.py':'prior-exit-prepare.py','independent-reader-review.json':'prior-exit-reader-review.json'}[name]
  assert sha(native/retained)==sha(R/'references/exit-native'/name)
 parent=R/'source-validation/final-host/before';current=R/'complete-source'
 for p,v in compat['additional_committed_sources_outside_old_snapshot_inventory'].items():assert sha(parent/p)==v['reader_commit_sha256']==v['parent_commit_sha256'] and sha(current/p)==v['route_commit_sha256']
 a=(current/'mistral/arch.h').read_bytes();line=b'    int critical_final_route_budget = 0; // CLI-only final discovery after LUT repairs.\n';assert a.count(line)==1 and a.replace(line,b'').replace(b'void repair_critical_routes(bool final_after_lut = false);',b'void repair_critical_routes();')==(parent/'mistral/arch.h').read_bytes()
 a=(current/'mistral/routed_move.cc').read_bytes();term=b' && !critical_final_route_budget';assert a.count(term)==1 and a.replace(term,b'')==(parent/'mistral/routed_move.cc').read_bytes()
 a=(parent/'mistral/analogue.cc').read_bytes();b=(current/'mistral/analogue.cc').read_bytes();marker=b'void Arch::repair_critical_routes(';include=b'#include "private_pair_decomposition_native.h"\n';assert b[:b.index(marker)].count(include)==1 and b[:b.index(marker)].replace(include,b'')==a[:a.index(marker)]
 b=(current/'mistral/routed_lut6_swap.cc').read_bytes();start=b.index(b'// A separate final-route scope reuses the same bounded structural/native walker.');end=b.index(b'\nnamespace {',start);assert b[:start]+b[end+1:]==(parent/'mistral/routed_lut6_swap.cc').read_bytes()
 selection=read(R/'selection.json');assert selection['passed'] and not selection['retain_source_exits'] and selection['reference_receipt_sha256']==sha(R/'references/prior-route/receipt.json')
 for path,h in selection['evidence_files'].items():support.verify_recorded(path,h)
 account=read(R/'accounting.json');journal=R/'accounting-54/continued-runs.jsonl';rows=[json.loads(s) for s in journal.read_text().splitlines()];prior_journal=R/'references/accounting-52/continued-runs.jsonl'
 assert len(rows)==54 and len({v['case'] for v in rows})==54 and sha(journal)==account['journal_sha256'] and journal.read_bytes().startswith(prior_journal.read_bytes())
 assert Decimal(account['pre_journal_charge_seconds'])+sum(Decimal(v['charged_seconds_decimal']) for v in rows)==Decimal(account['cumulative_charge_seconds'])==Decimal('55746.72936571435947')
 accounting_review=read(A/'independent-actual-review/accounting-review.json');assert accounting_review['passed'] and accounting_review['journal_sha256']==sha(journal) and accounting_review['committed_readme_sha256']==sha(R/'accounting-54/README.md')
 assert accounting_review['fes_commit']==read(R/'accounting-54/source.json')['commit']=='5cb1677e95fe743a0be3caaddc021074dc1cc9ed'
 for case in ('default','final32'):
  found=[v for v in rows if v['case']=='out/final-critical-route-rediscovery-20261023/route-'+case];assert len(found)==1 and found[0]['receipt_sha256']==sha(R/f'route-{case}/receipt.json') and found[0]['receipt']==read(R/f'route-{case}/receipt.json')
 # Only the explicit corruption-fixture ROOT is rebound. Its final proof binds
 # the exact historical graph hash; graph/timing/support roots remain untouched.
 fixture=mode['test_fixture'];assert fixture['module']=='test_graph_checks' and fixture['root_override']=='fixtures/current-task' and fixture['retained_path']=='fixtures/lut-permutation-budget32-20261023/route-budget32/routed.json'
 assert sha(R/fixture['retained_path'])==fixture['sha256']==read(A/'checker-tests.json')['full_board_fixture_sha256']
 tests=importlib.import_module('test_graph_checks');tests.ROOT=R/fixture['root_override']
 original=sha(A/'independent-actual-review/review.json');proofs={name:sha(A/name) for name in ('decision-ledger.json','graph-proof.json','native-selection-specs.json','checker-tests.json','native-topology-checks.json','checker-evolution.json','topology-proof.json','route-comparison.json')}
 with contextlib.redirect_stdout(io.StringIO()):runpy.run_path(str(A/'independent-actual-review/review.py'),run_name='__main__')
 assert sha(A/'independent-actual-review/review.json')==original and proofs=={name:sha(A/name) for name in proofs}
 review=read(A/'independent-actual-review/review.json');assert review['passed'] and len(review['exact_replays'])==8 and not review['native_execution_needed'] and review['canonical_changed_trees']==0
 assert review['route_order_only_alias_changes']==15 and review['complete_endpoint_rows']==17199 and review['native_margin_delta_counts']=={'setup':{'unchanged':17194},'hold':{'unchanged':17194}}
 result={'passed':True,'source_files':34,'host_admission_files':111,'native_snapshot_manifest_members':401,'exact_original_proof_replays':review['exact_replays'],'independent_review_sha256':original,'complete_endpoint_rows':17199,'native_margin_delta_counts':review['native_margin_delta_counts'],'all_four_artifacts':review['all_four_final_artifacts'],'canonical_changed_trees':0,'route_order_only_alias_changes':15,'native_execution_needed':False,'accounting':{'records':54,'pair_charge_seconds':'2258.6285270126536','cumulative_charge_seconds':account['cumulative_charge_seconds']},'charged_route_seconds':0,'scope':'Complete offline source/host receipt, original graph/ledger/timing/checker and committed accounting replay. No host tests, native reader/STA, GPU route or hardware execution; zero changed trees require no reader.'}
 print(encoded(result).decode(),end='')
if __name__=='__main__':main()
