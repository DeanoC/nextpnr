#!/usr/bin/env python3
"""Focused corruption controls for exact graph, final decisions and native trees."""
from copy import deepcopy
from pathlib import Path
import hashlib,json
from support import HERE,ROOT,read,sha,digest,write
from prove_graph import prove,decisions,paired_decisions,bind_selected_inventory,ACCEPT

def fixture():
    def cell(kind,ports,directions,pins,bel):return {'type':kind,'parameters':{},'connections':ports,'port_directions':directions,'attributes':{'NEXTPNR_BEL':bel,'FES_PINMAP_V1':json.dumps({'count':len(pins),'pins':pins},separators=(',',':')).encode().hex()}}
    cells={'source':cell('MISTRAL_FF',{'Q':[1]},{'Q':'output'},{'Q':[0,'Q']},'FF.1.1.0'),
           'sink':cell('MISTRAL_FF',{'DATAIN':[1],'Q':[2]},{'DATAIN':'input','Q':'output'},{'DATAIN':[0,'DATAIN'],'Q':[0,'Q']},'FF.1.2.0')}
    nets={'n':{'bits':[1],'attributes':{'ROUTING':'R;;1;T;pRT;1'}},'alias':{'bits':[1],'attributes':{'ROUTING':'R;;1;T;pRT;1'}},
          'other':{'bits':[2],'attributes':{'ROUTING':'O;;1'}},'orphan':{'bits':[3],'attributes':{}}}
    return {'creator':'fixture','modules':{'top':{'cells':cells,'netnames':nets,'ports':{},'settings':{},'attributes':{'LAB_STATE':'exact'}}}}

def trial():return {'number':1,'net':'n','variant':0,'accepted':True,'reason':ACCEPT}
def moved(a):
    b=deepcopy(a)
    for n in ('n','alias'):b['modules']['top']['netnames'][n]['attributes']['ROUTING']='R;;1;M;pRM;1;T;pMT;1'
    return b

def log():return '\n'.join([
 'Info: Critical route repair: tried=0/32 kept=0; unchanged unsupported coverage is not qualification.',
 'Info: Critical LUT6 swap repair: tried=1/16 kept=1.',
 'Info: Final critical route rediscovery: fresh skew/reference timing and live inventory; budget=32.',
 'Info: Final critical route filter: net other: ordinary complete-user/public/protected-route boundary.',
 'Info: Final critical route selected 1: net n sink sink.DATAIN slack -23.000 ps.',
 'Info: Final critical route shortlist: failing ordinary sink rows=1 selected nets=1.',
 'Info: Final critical route generation 0: learned observations=2.',
 'Info: Final critical route candidates: generation 0 net n proposals=2.',
 'Info: Final critical route proposal: net n variant 0 native worst-sink gain 25.000 ps.',
 'Info: Final critical route proposal: net n variant 1 native worst-sink gain -inf ps.',
 'Info: Final critical route generation 1: learned observations=3.',
 'Info: Final critical route candidates: generation 1 net n proposals=2.',
 # One generated tree duplicates a prior tree and is skipped before proposal log.
 'Info: Final critical route proposal: net n variant 0 native worst-sink gain 26.000 ps.',
 'Info: Final critical route filter: net n: one or more sinks lack a characterized native analogue cache entry.',
 'Info: Final critical route trial 1: net n variant 0 accepted=1.',
 'Info:     Final critical route decision: '+ACCEPT+'.',
 'Info: Final critical route repair: tried=1/32 kept=1; unchanged unsupported coverage is not qualification.'])+'\n'

def main():
    failures=[];positives=[]
    def reject(name,fn):
        try:fn()
        except (ValueError,AssertionError,KeyError,TypeError):failures.append(name)
        else:raise AssertionError('corruption unexpectedly passed: '+name)
    a=fixture();b=moved(a);t=trial();proof=prove(a,b,[t]);assert proof['changed_canonical_net_bits']==[1];positives.append('synthetic whole-net change preserves complete logical graph')
    assert prove(a,a,[])['changed_canonical_net_bits']==[];positives.append('complete unchanged graph')
    order=deepcopy(a)
    for name in ('n','alias'):order['modules']['top']['netnames'][name]['attributes']['ROUTING']='T;pRT;1;R;;1'
    assert prove(a,order,[])['route_order_only_alias_changes']==2;positives.append('exact canonical route with changed tuple order')
    def mutate(name,fn,accepted=[t]):
        x=deepcopy(b);fn(x);reject(name,lambda:prove(a,x,accepted))
    mutate('cell parameter',lambda x:x['modules']['top']['cells']['source']['parameters'].update(X='1'))
    mutate('cell connection',lambda x:x['modules']['top']['cells']['sink']['connections'].update(DATAIN=[2]))
    mutate('cell BEL',lambda x:x['modules']['top']['cells']['source']['attributes'].update(NEXTPNR_BEL='FF.2.2.2'))
    mutate('physical map',lambda x:x['modules']['top']['cells']['source']['attributes'].update(FES_PINMAP_V1='00'))
    mutate('unknown cell field',lambda x:x['modules']['top']['cells']['source'].update(hidden='new'))
    mutate('cell inventory',lambda x:x['modules']['top']['cells'].pop('sink'))
    mutate('alias inventory',lambda x:x['modules']['top']['netnames'].pop('orphan'))
    mutate('hidden alias addition',lambda x:x['modules']['top']['netnames'].update(hidden=deepcopy(x['modules']['top']['netnames']['n'])))
    mutate('alias bit',lambda x:x['modules']['top']['netnames']['orphan'].update(bits=[4]))
    mutate('alias metadata',lambda x:x['modules']['top']['netnames']['orphan']['attributes'].update(keep='1'))
    mutate('module LAB state',lambda x:x['modules']['top']['attributes'].update(LAB_STATE='new'))
    mutate('settings',lambda x:x['modules']['top']['settings'].update(extra=1))
    mutate('creator',lambda x:x.update(creator='other binary'))
    mutate('alias class route disagreement',lambda x:x['modules']['top']['netnames']['alias']['attributes'].update(ROUTING='R;;1'))
    mutate('unaccepted different tree',lambda x:None,[])
    mutate('outside orphan new tree',lambda x:x['modules']['top']['netnames']['orphan']['attributes'].update(ROUTING='ORPHAN;;1'))
    mutate('explicit null route',lambda x:x['modules']['top']['netnames']['orphan']['attributes'].update(ROUTING=None))
    for name,route in [('changed root','X;;1;T;pXT;1'),('root strength','R;;2;T;pRT;1'),('protected route','R;;1;T;pRT;4'),('two roots','R;;1;T;;1'),('duplicate wire','R;;1;R;pTR;1'),('duplicate PIP','R;;1;M;pRT;1;T;pRT;1'),('partial tuple','R;;1;T;pRT')]:
        def both(x,route=route):
            for key in ('n','alias'):x['modules']['top']['netnames'][key]['attributes']['ROUTING']=route
        mutate(name,both)
    # Both inputs contain the same outside owners; selected candidate steals one.
    q=deepcopy(a);q['modules']['top']['netnames']['other']['attributes']['ROUTING']='O;;1;M;pOM;1'
    reject('foreign wire ownership',lambda:prove(q,moved(q),[t]))
    q=deepcopy(a);q['modules']['top']['netnames']['other']['attributes']['ROUTING']='O;;1;S;pRM;1'
    reject('foreign PIP ownership',lambda:prove(q,moved(q),[t]))
    reject('duplicate accepted canonical net',lambda:prove(a,b,[t,{**t,'net':'alias'}]))
    reject('unknown accepted alias',lambda:prove(a,b,[{**t,'net':'unknown'}]))
    reject('accepted false',lambda:prove(a,b,[{**t,'accepted':False}]))
    reject('accepted reason',lambda:prove(a,b,[{**t,'reason':'different guard'}]))
    for name,change in [('unsupported source',lambda x:x['modules']['top']['cells']['source'].update(type='MISTRAL_BUF')),
                        ('public accepted root',lambda x:x['modules']['top']['ports'].update(top={'bits':[1]}))]:
        q=deepcopy(a);change(q);reject(name,lambda q=q:prove(q,moved(q),[t]))
    text=log();base='\n'.join(text.splitlines()[:2])+'\n';ledger=paired_decisions(base,text)
    assert bind_selected_inventory(a,ledger)[0]['serialized_user']==['sink','DATAIN',0]
    assert ledger['final']['tried']==ledger['final']['kept']==1;positives.append('two feedback generations, skipped duplicate proposal, later coverage filter')
    empty=base+'Info: Final critical route rediscovery: fresh skew/reference timing and live inventory; budget=32.\nInfo: Final critical route shortlist: failing ordinary sink rows=0 selected nets=0.\nInfo: Final critical route repair: no eligible failing data nets.\n'
    assert paired_decisions(base,empty)['final']['tried']==0;positives.append('empty eligible frontier')
    edits=[('missing start','Info: Final critical route rediscovery: fresh skew/reference timing and live inventory; budget=32.\n',''),
      ('unknown record','Final critical route generation 0:','Final critical route unknown 0:'),
      ('changed budget','budget=32.','budget=16.'),('changed selected count','selected nets=1.','selected nets=2.'),
      ('positive selected slack','slack -23.000','slack 23.000'),('missing generation','generation 1: learned','generation 2: learned'),
      ('unknown trial net','trial 1: net n','trial 1: net missing'),('trial gap','trial 1:','trial 2:'),
      ('wrong accepted reason',ACCEPT,'setup regressed'),('wrong kept count','tried=1/32 kept=1','tried=1/32 kept=0'),
      ('missing decision','Info:     Final critical route decision: '+ACCEPT+'.\n',''),
      ('excess logged candidates','generation 0 net n proposals=2.','generation 0 net n proposals=0.'),
      ('unsupported variant','trial 1: net n variant 0','trial 1: net n variant 9'),
      ('no finite proposal','gain 25.000','gain 19.000')]
    for name,before,after in edits:
        altered=text.replace(before,after)
        if name=='no finite proposal':altered=altered.replace('gain 26.000','gain 19.000')
        reject(name,lambda altered=altered:paired_decisions(base,altered))
    reject('accepted net lacks canonical change',lambda:prove(a,a,[t]))
    malformed=deepcopy(ledger);malformed['final']['selected'][0]['sink']='missing.DATAIN';reject('selected sink absent from graph',lambda:bind_selected_inventory(a,malformed))
    reordered=text.splitlines();block=[x for x in reordered if 'Final critical route trial ' in x or 'Final critical route decision:' in x];reordered=[x for x in reordered if x not in block];pos=next(i for i,x in enumerate(reordered) if 'generation 1: learned' in x);reordered[pos:pos]=block
    reject('trial before complete generations',lambda:paired_decisions(base,'\n'.join(reordered)))
    reject('disabled control final execution',lambda:paired_decisions(text,text))
    reject('preceding decisions differ',lambda:paired_decisions(base.replace('kept=1','kept=0'),text))
    reject('late earlier repair',lambda:paired_decisions(base,text+base))
    reject('incomplete execution',lambda:decisions('\n'.join(text.splitlines()[:-1])))
    reject('duplicate completion',lambda:decisions(text+text.splitlines()[-1]+'\n'))
    # Full actual board baseline is a read-only completeness control, not final-route evidence.
    path=ROOT.parent/'lut-permutation-budget32-20261023/route-budget32/routed.json'
    board=read(path);whole=prove(board,board,[]);assert whole['complete_cells']==12397 and whole['complete_net_alias_records']==15546
    positives.append('complete existing board 12397 cells and15546 aliases exact')
    write('checker-tests.json',{'passed':True,'positive_checks':positives,'negative_cases':failures,'negative_count':len(failures),
      'full_board_fixture_sha256':sha(path),'checker_sha256':sha(HERE/'prove_graph.py'),'test_sha256':sha(__file__),
      'scope':'Synthetic graph/log corruption controls plus complete earlier board equality; no new final-route execution, native topology or timing result.'})
    print('PASS',len(positives),'positive,',len(failures),'negative graph/log checks')
if __name__=='__main__':main()
