#!/usr/bin/env python3
"""Retain the three independently reported checker gaps and their exact rejections."""
import importlib.util
from support import HERE,sha,write
import prove_graph as now
from test_graph_checks import fixture,moved,trial,log
spec=importlib.util.spec_from_file_location('initial_final_graph',HERE/'initial-checker/prove_graph.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
def main():
 text=log();base='\n'.join(text.splitlines()[:2])+'\n';rows=text.splitlines();block=[x for x in rows if 'Final critical route trial ' in x or 'Final critical route decision:' in x];rows=[x for x in rows if x not in block];pos=next(i for i,x in enumerate(rows) if 'generation 1: learned' in x);rows[pos:pos]=block;early='\n'.join(rows)
 missing=text.replace('sink sink.DATAIN','sink missing.DATAIN')
 cases=[('trial before complete generations',lambda:old.paired_decisions(base,early),lambda:now.paired_decisions(base,early)),
 ('selected sink absent from graph',lambda:old.prove(fixture(),moved(fixture()),old.paired_decisions(base,missing)['final']['accepted_trials']),lambda:now.bind_selected_inventory(fixture(),now.paired_decisions(base,missing))),
 ('accepted net has no canonical tree change',lambda:old.prove(fixture(),fixture(),[trial()]),lambda:now.prove(fixture(),fixture(),[trial()]))]
 results=[]
 for name,before,after in cases:
  before()
  try:after()
  except ValueError as error:results.append({'case':name,'initial_checker_accepted':True,'corrected_checker_rejected':True,'reason':str(error)})
  else:raise AssertionError('corrected checker missed '+name)
 write('checker-evolution.json',{'passed':True,'initial_checker_sha256':sha(HERE/'initial-checker/prove_graph.py'),'corrected_checker_sha256':sha(HERE/'prove_graph.py'),'test_sha256':sha(__file__),'mutations':results,'scope':'Checker-only correction evidence. Production sources, host admission, route recipes and active fresh routes are unchanged.'})
 print('PASS all3 independently reproduced checker gaps now reject')
if __name__=='__main__':main()
