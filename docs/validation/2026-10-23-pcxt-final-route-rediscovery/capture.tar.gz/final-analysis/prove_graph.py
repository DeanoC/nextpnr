#!/usr/bin/env python3
"""Complete direct graph and final whole-net reroute decision proof.

Cells, every physical pin map and all graph identities must remain exact. Only
logged accepted final-route nets may change canonical route trees. Electrical
source/PIP/sink connectivity is checked separately by the frozen native reader.
"""
from collections import defaultdict
from copy import deepcopy
import json,math,re
from route_graph_core import graph_edges,route_tree,physical_port
from native_port_identity import native_identity
from support import HERE,ROOT,need,read,sha,digest,write,paired_receipts

NUM=r'[-+]?(?:[0-9]+(?:\.[0-9]+)?|inf)'
ACCEPT='complete native inventory and both-frame clock guards passed'

def decisions(text,budget=32):
    lines=[]
    for line in text.splitlines():
        if 'Final critical route ' not in line:continue
        need(re.match(r'^Info:\s+Final critical route ',line) is not None,'invalid final-route log prefix')
        lines.append(line)
    need(lines,'missing final-route execution')
    patterns={
        'start':r'rediscovery: fresh skew/reference timing and live inventory; budget=([0-9]+)\.',
        'filter':r'filter: net (.+): (.+)\.',
        'selected':r'selected ([0-9]+): net (.+) sink (.+) slack ('+NUM+r') ps\.',
        'shortlist':r'shortlist: failing ordinary sink rows=([0-9]+) selected nets=([0-9]+)\.',
        'empty':r'repair: no eligible failing data nets\.',
        'generation':r'generation ([0-9]+): learned observations=([0-9]+)\.',
        'candidates':r'candidates: generation ([0-9]+) net (.+) proposals=([0-9]+)\.',
        'proposal':r'proposal: net (.+) variant ([0-9]+) native worst-sink gain ('+NUM+r') ps\.',
        'trial':r'trial ([0-9]+): net (.+) variant ([0-9]+) accepted=([01])\.',
        'decision':r'decision: (.+)\.',
        'summary':r'repair: tried=([0-9]+)/([0-9]+) kept=([0-9]+); unchanged unsupported coverage is not qualification\.',
    }
    records=[];selected=[];trials=[];proposals=[];generations=[];counts={};pending=None;shortlist=None;done=False
    accepted_nets=set();generation=None;candidate_counts={};candidate_seen=defaultdict(set)
    for i,line in enumerate(lines):
        body=line.split('Final critical route ',1)[1]
        hits=[(kind,re.fullmatch(pattern,body)) for kind,pattern in patterns.items()]
        hits=[(kind,m) for kind,m in hits if m]
        need(len(hits)==1,'unrecognized/ambiguous final-route record: '+line)
        kind,m=hits[0];v=m.groups();need(not done,'final-route record after completion')
        need(pending is None or kind=='decision','trial lacks immediately following decision')
        if i==0:need(kind=='start','final route lacks initial fresh inventory header')
        if kind=='start':need(i==0 and int(v[0])==budget,'duplicate/wrong final-route budget')
        elif kind=='filter':
            if shortlist is not None:need(v[0] in {s['net'] for s in selected},'late filter of undiscovered net')
        elif kind=='selected':
            need(shortlist is None and int(v[0])==len(selected)+1 and v[1] not in {s['net'] for s in selected},'invalid selected inventory')
            slack=float(v[3]);need(math.isfinite(slack) and slack<=0,'selected sink not finite/failing')
            selected.append({'number':int(v[0]),'net':v[1],'sink':v[2],'slack_ps':slack})
        elif kind=='shortlist':
            need(shortlist is None and int(v[1])==len(selected)<=budget and int(v[0])>=len(selected),'invalid shortlist counts')
            shortlist={'failing_ordinary_sink_rows':int(v[0]),'selected_nets':int(v[1])}
        elif kind=='empty':need(shortlist is not None and not selected and not trials and i==len(lines)-1,'invalid empty execution');done=True
        elif kind=='generation':
            need(not trials and shortlist is not None and selected and int(v[0])==len(generations)<2,'invalid proposal generation')
            generation=int(v[0]);generations.append({'generation':generation,'learned_observations':int(v[1])})
        elif kind=='candidates':
            g,net,n=int(v[0]),v[1],int(v[2]);key=(g,net)
            need(not trials and g==generation and net in {s['net'] for s in selected} and key not in candidate_counts and 0<=n<=4,'invalid proposal inventory')
            candidate_counts[key]=n
        elif kind=='proposal':
            net,variant,gain=v[0],int(v[1]),float(v[2]);key=(generation,net)
            need(not trials and key in candidate_counts and 0<=variant<4 and variant not in candidate_seen[key],'unknown/duplicate native proposal')
            candidate_seen[key].add(variant);proposals.append({'generation':generation,'net':net,'variant':variant,'gain_ps':gain if math.isfinite(gain) else None})
        elif kind=='trial':
            n,net,variant,accepted=int(v[0]),v[1],int(v[2]),bool(int(v[3]))
            need(generation==1 and len(generations)==2 and shortlist is not None and n==len(trials)+1<=budget and net not in accepted_nets,'invalid/repeated accepted net trial')
            witnesses=[p for p in proposals if p['net']==net and p['variant']==variant and p['gain_ps'] is not None and p['gain_ps']>=20]
            need(witnesses,'trial lacks preceding finite native gain proposal')
            pending={'number':n,'net':net,'variant':variant,'accepted':accepted}
        elif kind=='decision':
            need(pending is not None,'orphan final-route decision');pending['reason']=v[0]
            need((v[0]==ACCEPT)==pending['accepted'],'acceptance flag/reason differ')
            trials.append(pending)
            if pending['accepted']:accepted_nets.add(pending['net'])
            pending=None
        elif kind=='summary':
            need(shortlist is not None and int(v[0])==len(trials)<=budget and int(v[1])==budget and int(v[2])==len(accepted_nets) and i==len(lines)-1,'final-route summary differs')
            done=True
        records.append({'kind':kind,'line':line})
    need(done and pending is None,'incomplete final-route execution')
    need(all(len(candidate_seen[k])<=n for k,n in candidate_counts.items()),'logged unique proposals exceed generated count')
    need(not selected or len(generations)==2,'missing bounded feedback generation')
    return {'budget':budget,'all_verbatim_lines':lines,'records':records,'shortlist':shortlist,'selected':selected,'generations':generations,
            'proposals':proposals,'all_trials':trials,'accepted_trials':[x for x in trials if x['accepted']],
            'tried':len(trials),'kept':len(accepted_nets),'limits':['Discovery/proposals are bounded; logs do not prove exhaustive failing-path search or independently reproduce in-process rejected-state STA.']}

def paired_decisions(left,right):
    need('Final critical route ' not in left,'disabled control ran final rediscovery')
    markers=('Critical route ','Critical LUT6 ','Critical LUT permutation','Critical private pair')
    preceding=lambda text:[line for line in text.splitlines() if any(marker in line for marker in markers)]
    a,b=preceding(left),preceding(right);need(a and a==b,'complete preceding repair decisions differ')
    all_lines=right.splitlines();start=next(i for i,s in enumerate(all_lines) if 'Final critical route ' in s)
    need(not preceding('\n'.join(all_lines[start:])),'earlier repair occurred after final rediscovery')
    return {'preceding_repair_decisions_equal':True,'preceding_repair_all_lines':a,'final':decisions(right)}

def bind_selected_inventory(document,ledger):
    need(set(document['modules']) and len(document['modules'])==1,'selected graph module inventory')
    module=next(iter(document['modules'].values()));users,drivers,aliases,public=graph_edges(module)
    rows=[];seen=set()
    for selected in ledger['final']['selected']:
        name=selected['net'];need(name in module['netnames'],'selected net absent from complete graph')
        bit=module['netnames'][name]['bits'][0]
        need(bit not in seen and bit not in public and len(drivers[bit])==1 and 1<=len(users[bit])<=64,'selected net graph boundary');seen.add(bit)
        matches=[]
        for user in users[bit]:
            native=native_identity(module['cells'],user)
            if native[0]+'.'+native[1]==selected['sink']:matches.append({'serialized_user':user,'native_user':native})
        need(len(matches)==1,'selected sink is not one exact live user of its net')
        rows.append({'net':name,'bit':bit,'sink':selected['sink'],**matches[0]})
    return rows

def prove(left,right,accepted):
    need(left.keys()==right.keys() and set(left)=={'creator','modules'} and left['creator']==right['creator'],'top-level/creator differs')
    need(left['modules'].keys()==right['modules'].keys() and len(left['modules'])==1,'module inventory differs')
    a,b=next(iter(left['modules'].values())),next(iter(right['modules'].values()))
    need(a.keys()==b.keys(),'module schema differs')
    need({k:v for k,v in a.items() if k!='netnames'}=={k:v for k,v in b.items() if k!='netnames'},'cell/function/pinmap/placement/port/LAB/settings differs')
    need(a['netnames'].keys()==b['netnames'].keys(),'complete aliases differ')
    users,drivers,aliases,public=graph_edges(a)
    need((users,drivers,aliases,public)==graph_edges(b),'complete driver/user/alias/public graph differs')
    allowed={};accepted_records=[]
    for trial in accepted:
        need(trial['accepted'] and trial['reason']==ACCEPT and trial['net'] in a['netnames'],'unbound/unaccepted net')
        bit=a['netnames'][trial['net']]['bits'][0]
        need(bit not in allowed and bit not in public and len(drivers[bit])==1 and 1<=len(users[bit])<=64,'duplicate/public/unsupported accepted net')
        driver=drivers[bit][0];cell=a['cells'][driver[0]]
        need(driver[1:] == ['Q',0] and cell['type'] in ['MISTRAL_FF']+['MISTRAL_ALUT'+str(n) for n in range(2,7)],'accepted source outside native root scope')
        allowed[bit]=trial;accepted_records.append({'bit':bit,**trial})
    changes=[];changed=set();trees=[{},{}]
    for alias in sorted(a['netnames']):
        old,new=deepcopy(a['netnames'][alias]),deepcopy(b['netnames'][alias]);need(old.keys()==new.keys(),'alias schema differs')
        need(all('ROUTING' not in obj['attributes'] or isinstance(obj['attributes']['ROUTING'],str) for obj in (old,new)),'explicit null/nonstring route attribute')
        old_raw,new_raw=old['attributes'].pop('ROUTING',None),new['attributes'].pop('ROUTING',None)
        need(old==new,'nonroute alias identity/attribute differs: '+alias);bit=old['bits'][0]
        before,after=route_tree(old_raw),route_tree(new_raw)
        for store,tree in zip(trees,(before,after)):
            need(bit not in store or store[bit]==tree,'aliases disagree on route tree');store[bit]=tree
        canonical_changed=before!=after
        if canonical_changed:need(bit in allowed,'unaccepted canonical tree changed: '+alias);changed.add(bit)
        if old_raw!=new_raw:changes.append({'alias':alias,'bit':bit,'canonical_tree_changed':canonical_changed,'before_tree':before,'after_tree':after,'before_raw_sha256':digest(old_raw),'after_raw_sha256':digest(new_raw)})
    need(set(allowed)==changed,'logged accepted nets differ from actual changed canonical trees')
    selections=[]
    for bit in sorted(changed):
        roots=[]
        for store in trees:
            tree=store[bit];need(tree and len(tree)<=4096 and all(v[1]<=2 for v in tree.values()),'missing/oversize/protected selected tree')
            roots.append({w:v for w,v in tree.items() if not v[0]})
        need(len(roots[0])==1 and roots[0]==roots[1],'source root/strength differs')
        driver=physical_port(a['cells'],drivers[bit][0]);need(driver['state']==0,'selected native source is not PIN_SIG')
        transitions=[]
        for user in users[bit]:
            port=physical_port(a['cells'],user);transitions.append({'before':port,'after':port,'serialized_physical_sink_unchanged':True})
        selections.append({'bit':bit,'name':aliases[bit][0],'aliases':aliases[bit],'driver':driver,'serialized_driver':drivers[bit][0],
          'before_users':users[bit],'after_users':users[bit],'user_transitions':transitions,'source_root':roots[0],'canonical_tree_changed':True,
          'before_tree_sha256':digest(trees[0][bit]),'after_tree_sha256':digest(trees[1][bit])})
    ownership=[]
    for store in trees:
        wires={};pips={}
        for bit,tree in store.items():
            for wire,(pip,strength) in (tree or {}).items():
                need(wire not in wires,'global wire ownership collision');wires[wire]=bit
                if pip:need(pip not in pips,'global PIP ownership collision');pips[pip]=bit
        ownership.append({'wires':len(wires),'pips':len(pips),'single_net_ownership':True})
    return {'status':'pass','complete_cells':len(a['cells']),'complete_net_alias_records':len(a['netnames']),'complete_net_alias_classes':len(aliases),'complete_public_ports':len(a['ports']),
      'all_cells_functions_ports_placements_physical_pinmaps_exact':True,'settings_ports_module_attributes_LAB_state_equal':True,
      'complete_driver_user_alias_public_graph_equal':True,'complete_physical_ownership':dict(zip(('before','after'),ownership)),
      'accepted_nets':accepted_records,'allowed_net_bits':sorted(allowed),'changed_canonical_net_bits':sorted(changed),
      'every_raw_route_attribute_change':changes,'route_order_only_alias_changes':sum(not x['canonical_tree_changed'] for x in changes),
      'native_topology_selections':selections,'limits':['Complete serialized graph and canonical routing ownership proof only; native PIP/source/sink decoding remains separate.',
      'Whole-net rerouting may change every sink path and prune unused original source-exit stubs. No stationary-path retention is claimed.',
      'No unlogged cell, alias, physical pin, LAB or graph change is allowed. Native cache/index holes and rejected-state rollback remain separately tested.',
      'No native physical mask, setup/hold, clock or hardware signoff is inferred.']}

def main():
    paired_receipts();names=('default','final32');logs={n:(ROOT/('route-'+n)/'nextpnr.log').read_text() for n in names}
    ledger=paired_decisions(logs['default'],logs['final32']);documents=[read(ROOT/('route-'+n)/'routed.json') for n in names]
    ledger['selected_graph_bindings']=bind_selected_inventory(documents[0],ledger);result=prove(*documents,ledger['final']['accepted_trials'])
    result.update(graph_sha256={n:sha(ROOT/('route-'+n)/'routed.json') for n in names},checker_sha256=sha(__file__),core_sha256=sha(HERE/'route_graph_core.py'),native_port_resolver_sha256=sha(HERE/'native_port_identity.py'),support_sha256=sha(HERE/'support.py'))
    write('decision-ledger.json',ledger);write('graph-proof.json',result)
    write('native-selection-specs.json',{'schema':1,'graph_proof_sha256':sha(HERE/'graph-proof.json'),'graph_sha256':result['graph_sha256'],'selections':result['native_topology_selections'],
      'requirements':['Decode every changed complete tree and unchanged logical/physical source and sink inventory using the frozen native reader.',
      'Require one identical native source root, every sink reachable, no cycles/disconnected branches/foreign ownership. Whole-net paths and unused stubs may change.',
      'No configuration, pin assignment, routing or timing reload.']})
    print(json.dumps({k:result[k] for k in ['status','complete_cells','complete_net_alias_records','changed_canonical_net_bits']},sort_keys=True))
if __name__=='__main__':main()
