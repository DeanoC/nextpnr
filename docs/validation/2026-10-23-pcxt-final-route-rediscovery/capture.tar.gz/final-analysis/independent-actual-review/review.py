#!/usr/bin/env python3
"""Replay complete root-produced FINAL outputs without mutating those outputs."""
from pathlib import Path
import contextlib,hashlib,importlib,io,json,sys
from decimal import Decimal
H=Path(__file__).resolve().parent;A=H.parent;ROOT=A.parent
sys.path.insert(0,str(A));sys.dont_write_bytecode=True

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
inputs={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*')) if p.is_file() and p.suffix in ('.py','.h')};checks=[]
original_names=('decision-ledger.json','graph-proof.json','native-selection-specs.json','checker-tests.json','native-topology-checks.json','checker-evolution.json','topology-proof.json','route-comparison.json')
original_hashes={name:sha(A/name) for name in original_names}
def same(name,value):
 assert name in original_names and encoded(value)==(A/name).read_bytes(),name+' replay differs'
 checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
log=io.StringIO()
with contextlib.redirect_stdout(log):
 for name in ('prove_graph','test_graph_checks','test_native_topology','check_evolution','verify_topology'):
  module=importlib.import_module(name);module.write=same;module.main()
 module=importlib.import_module('compare_timing');module.R=H;module.main()
assert (H/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
assert len(checks)==len(original_names) and {x['proof'] for x in checks}==set(original_names)
assert inputs=={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*')) if p.is_file() and p.suffix in ('.py','.h')}
assert original_hashes=={name:sha(A/name) for name in original_names}
t=read(A/'route-comparison.json');g=read(A/'graph-proof.json');d=read(A/'decision-ledger.json');n=read(A/'topology-proof.json');nr=read(ROOT/'native-topology/paired-readback/receipt.json')
assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal'] and len(t['every_endpoint_row'])==17199
assert t['independent_complete_clock_guard']['pass'] and t['independent_emitted_inventory_guard']['nonregression_and_inventory_pass'] and not t['independent_emitted_inventory_guard']['all_violations']
assert t['native_margin_delta_counts']=={'setup':{'unchanged':17194},'hold':{'unchanged':17194}} and t['default_vs_prior_fixed_invariance_pass']
assert all(r['setup']=={'checked':17194,'failures':8,'minimum_ps':-434} and r['hold']=={'checked':17194,'failures':0,'minimum_ps':822} and r['unsupported_count']==105 and not r['complete'] for r in t['runs'].values())
assert g['status']=='pass' and g['complete_cells']==12397 and g['complete_net_alias_records']==15546
assert not g['accepted_nets'] and not g['changed_canonical_net_bits'] and not g['native_topology_selections'] and g['route_order_only_alias_changes']==15
assert len(g['every_raw_route_attribute_change'])==15 and all(not row['canonical_tree_changed'] and row['before_tree']==row['after_tree'] for row in g['every_raw_route_attribute_change'])
assert d['preceding_repair_decisions_equal'] and d['final']['shortlist']=={'failing_ordinary_sink_rows':24,'selected_nets':21}
assert len(d['selected_graph_bindings'])==21 and [v['generation'] for v in d['final']['generations']]==[0,1]
assert d['final']['tried']==d['final']['kept']==0 and not d['final']['all_trials']
proposals=d['final']['proposals'];assert proposals and all(p['gain_ps'] is not None and p['gain_ps']<0 for p in proposals)
assert max(p['gain_ps'] for p in proposals)==-20
assert n['passed'] and not n['native_readback_needed'] and nr['passed'] and not nr['native_execution_needed'] and nr['charged_route_seconds']==0
artifacts={}
for name in ('diagnostic.rbf','routed.json','timing.json','endpoints.json'):
 a,b=ROOT/'route-default'/name,ROOT/'route-final32'/name
 equal=a.read_bytes()==b.read_bytes();assert equal==(name!='routed.json'),name
 artifacts[name]={'byte_equal':equal,'default_sha256':sha(a),'final32_sha256':sha(b),'default_bytes':a.stat().st_size,'final32_bytes':b.stat().st_size}
left,right=read(ROOT/'route-default/routed.json'),read(ROOT/'route-final32/routed.json')
# Independent direct normalization strips only ROUTING strings, then requires
# every remaining field (including creator, module metadata and alias bits).
for doc in (left,right):
 for module in doc['modules'].values():
  for alias in module['netnames'].values():alias['attributes'].pop('ROUTING',None)
assert left==right
control=read(A/'default-control-result.json');selection=read(ROOT/'selection.json')
from support import reference_folder
reference=reference_folder();assert control['passed'] and control['complete_graph_except_creator_equal']
assert control['default_receipt_sha256']==sha(ROOT/'route-default/receipt.json') and control['reference_receipt_sha256']==sha(reference/'receipt.json')
old,new=read(reference/'routed.json'),read(ROOT/'route-default/routed.json')
assert old.keys()==new.keys() and {k:v for k,v in old.items() if k!='creator'}=={k:v for k,v in new.items() if k!='creator'}
assert control['creator_before']==old['creator'] and control['creator_after']==new['creator']
for name,equal in control['four_artifact_byte_equal'].items():assert equal==((reference/name).read_bytes()==(ROOT/'route-default'/name).read_bytes())
receipts={case:read(ROOT/('route-'+case)/'receipt.json') for case in ('default','final32')}
charge=sum(Decimal(str(v['charged_seconds'])) for v in receipts.values());assert str(charge)==t['pair_charge_seconds']=='2258.6285270126536'
mutation=read(A/'checker-tests.json');native_mutation=read(A/'native-topology-checks.json')
assert mutation['passed'] and mutation['negative_count']==54 and native_mutation['passed'] and native_mutation['negative_count']==24
result={'passed':True,'reviewer':'timing_strategy','review_script_sha256':sha(__file__),'inputs':inputs,'exact_replays':checks,
 'complete_endpoint_rows':17199,'native_margin_delta_counts':t['native_margin_delta_counts'],
 'all_four_final_artifacts':artifacts,'complete_cells':12397,'complete_aliases':15546,'canonical_changed_trees':0,'route_order_only_alias_changes':15,
 'default_complete_reference_reproduction':True,'default_control_proof_sha256':sha(A/'default-control-result.json'),
 'final_discovery':{'failing_ordinary_rows':24,'selected_nets':21,'generations':d['final']['generations'],'logged_proposals':len(proposals),'best_logged_gain_ps':-20,'trials':0,'kept':0},
 'native_execution_needed':False,'native_readback_receipt_sha256':sha(ROOT/'native-topology/paired-readback/receipt.json'),
 'paired_full_route_charge_seconds':str(charge),'review_charged_route_seconds':0,
 'findings':['Every prior repair decision matches before final discovery. Selected net/sink identities bind to the complete control graph; both proposal generations precede the empty trial sequence.',
 'All 12,397 cells and 15,546 aliases are retained. Fifteen raw ROUTING tuple-order differences normalize to exact canonical trees; no accepted or changed net exists.',
 'RBF, timing and endpoint files are byte-identical. All 17,199 identities and 17,194 setup/hold margins match, with eight setup failures at -434 ps, no hold failures and 105 unsupported obligations.',
 'Native topology verification correctly records no reader execution for zero changed trees. The fresh disabled control reproduces the prior source-exit-disabled result except creator provenance.'],
 'limits':['This agent authored the graph/topology scaffolds; their independent reviewer receipts remain separate. This task independently replays root-produced actual outputs and adds direct full artifact/control checks.',
 'Only emitted final timing is compared. No repeated native timing, proposal STA reconstruction, native reader, GPU route or hardware execution occurs here.',
 'The complete inventory remains complete=false; this no-gain diagnostic does not establish timing closure or hardware acceptance.']}
(H/'replay.log').write_text(log.getvalue());(H/'review.json').write_bytes(encoded(result));print(json.dumps({'passed':True,'exact_replays':len(checks),'review_sha256':sha(H/'review.json')},sort_keys=True))
