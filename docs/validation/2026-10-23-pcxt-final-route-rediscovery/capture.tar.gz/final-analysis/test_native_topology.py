#!/usr/bin/env python3
"""Corrupt recorded native topology without routing or loading a device model."""
from copy import deepcopy
from support import HERE,write,sha
from test_graph_checks import fixture,moved,trial
from prove_graph import prove
from verify_topology import validate
from route_graph_core import route_tree

def tree(selected,after):
    wires={'R':{'pip':None,'strength':1},'T':{'pip':'pMT' if after else 'pRT','strength':1,'source':'M' if after else 'R','destination':'T'}}
    if after:wires['M']={'pip':'pRM','strength':1,'source':'R','destination':'M'}
    user=selected['user_transitions'][0]['before'];return {'bit':selected['bit'],'selected_alias':selected['name'],'complete_aliases':selected['aliases'],
      'driver':{'cell':'source','port':'Q','native_port':selected['driver'],'source_wire':'R'},'complete_tree':wires,
      'complete_users':[{'cell':user['cell'],'port':user['port'],'native_port':user,'physical_sink_wires':['T'],'paths_to_source':{'T':['T','M','R'] if after else ['T','R']}}],
      'all_native_sinks_reached':True,'single_acyclic_source_root':True,'foreign_ownership_absent':True}

def main():
    a=fixture();b=moved(a);s=prove(a,b,[trial()])['native_topology_selections'][0]
    old,new=tree(s,False),tree(s,True)
    before=route_tree(a['modules']['top']['netnames']['n']['attributes']['ROUTING']);after=route_tree(b['modules']['top']['netnames']['n']['attributes']['ROUTING'])
    validate(old,s,before,'before');validate(new,s,after,'after')
    assert old['complete_users'][0]['paths_to_source']!=new['complete_users'][0]['paths_to_source']
    stub=deepcopy(old);stub['complete_tree']['UNUSED']={'pip':'pUnused','strength':1,'source':'R','destination':'UNUSED'}
    serial=deepcopy(before);serial['UNUSED']=['pUnused',1];validate(stub,s,serial,'before')
    failures=[]
    def bad(name,mutate,update_serial=False):
        obj=deepcopy(new);mutate(obj)
        serialized=after if not update_serial else {w:[v['pip'] or '',v['strength']] for w,v in obj['complete_tree'].items()}
        try:validate(obj,s,serialized,'after')
        except (ValueError,KeyError,TypeError,AssertionError):failures.append(name)
        else:raise AssertionError('native corruption accepted: '+name)
    bad('bit identity',lambda t:t.update(bit=99))
    bad('alias identity',lambda t:t.update(selected_alias='unknown'))
    bad('complete alias omitted',lambda t:t['complete_aliases'].pop())
    bad('driver cell',lambda t:t['driver'].update(cell='wrong'))
    bad('driver port',lambda t:t['driver'].update(port='D'))
    bad('driver saved map',lambda t:t['driver']['native_port'].update(state=3))
    bad('native source wire',lambda t:t['driver'].update(source_wire='M'))
    bad('complete tuple mismatch',lambda t:t['complete_tree']['M'].update(strength=2))
    bad('additional native root',lambda t:t['complete_tree']['M'].update(pip=None),True)
    bad('protected strength',lambda t:t['complete_tree']['M'].update(strength=3),True)
    bad('wrong PIP destination',lambda t:t['complete_tree']['M'].update(destination='T'))
    bad('missing PIP source',lambda t:t['complete_tree']['M'].update(source='absent'))
    bad('PIP cycle',lambda t:t['complete_tree']['M'].update(source='T'))
    bad('duplicate PIP',lambda t:t['complete_tree']['M'].update(pip='pMT'),True)
    bad('missing complete user',lambda t:t['complete_users'].clear())
    bad('duplicate complete user',lambda t:t['complete_users'].append(deepcopy(t['complete_users'][0])))
    bad('user physical map',lambda t:t['complete_users'][0]['native_port'].update(physical_pins=['OTHER']))
    bad('duplicate sink wire',lambda t:t['complete_users'][0].update(physical_sink_wires=['T','T']))
    bad('missing sink path',lambda t:t['complete_users'][0].update(paths_to_source={}))
    bad('wrong decoded path',lambda t:t['complete_users'][0].update(paths_to_source={'T':['T','R']}))
    bad('unreached physical sink',lambda t:t['complete_users'][0].update(physical_sink_wires=['UNKNOWN'],paths_to_source={'UNKNOWN':['UNKNOWN','R']}))
    for flag in ('all_native_sinks_reached','single_acyclic_source_root','foreign_ownership_absent'):bad(flag,lambda t,flag=flag:t.update({flag:False}))
    write('native-topology-checks.json',{'passed':True,'positive_cases':['same native source/sinks with wholly different sink path','original unused source-exit stub can disappear'],
      'rejected_corruptions':failures,'negative_count':len(failures),'checker_sha256':sha(HERE/'verify_topology.py'),'test_sha256':sha(__file__),
      'scope':'Offline synthetic decoder-record validation only. No new native reader execution, final route, timing or physical configuration claim.'})
    print('PASS2positive,',len(failures),'native topology corruption checks')
if __name__=='__main__':main()
