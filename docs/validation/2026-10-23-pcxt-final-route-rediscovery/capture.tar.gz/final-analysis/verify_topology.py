#!/usr/bin/env python3
"""Verify recorded native whole-net tree decoding; original sink paths may change."""
import json
from support import HERE,ROOT,need,read,sha,digest,write
from route_graph_core import route_tree

def validate(tree, selected, serialized, which):
    need(tree['bit']==selected['bit'] and tree['selected_alias']==selected['name'],'native selected identity differs')
    need(tree['complete_aliases']==selected['aliases'],'native complete aliases differ')
    need(tree['driver']['native_port']==selected['driver'],'native driver metadata differs')
    need(tree['driver']['cell']==selected['driver']['cell'] and tree['driver']['port']==selected['driver']['port'],'native driver identity differs')
    root=tree['driver']['source_wire'];wires=tree['complete_tree']
    need(wires and root in wires and len(wires)<=4096,'missing/oversize native tree')
    native_canonical={wire:[row['pip'] or '',row['strength']] for wire,row in wires.items()}
    need(native_canonical==serialized,'native tree does not decode complete serialized routing')
    need({wire:data for wire,data in serialized.items() if not data[0]}==selected['source_root'],'source root/strength differs')
    pips=set()
    for wire,row in wires.items():
        need(type(row['strength']) is int and 0<=row['strength']<=2,'native route has protected/invalid strength')
        if row['pip'] is None:
            need(wire==root and set(row)=={'pip','strength'},'additional native root')
        else:
            need(set(row)=={'pip','strength','source','destination'} and row['destination']==wire and row['source'] in wires,'bad native PIP endpoint')
            need(row['pip'] not in pips,'duplicate native PIP');pips.add(row['pip'])
        seen=set();cursor=wire
        while cursor!=root:
            need(cursor not in seen and cursor in wires and wires[cursor]['pip'] is not None,'native cycle/disconnected tree')
            seen.add(cursor);cursor=wires[cursor]['source']
    expected={(u[which]['cell'],u[which]['port']):u[which] for u in selected['user_transitions']}
    actual={}
    for user in tree['complete_users']:
        key=(user['cell'],user['port']);need(key not in actual,'duplicate native user');actual[key]=user
        need(key in expected and user['native_port']==expected[key],'unexpected native user/physical map')
        sinks=user['physical_sink_wires'];need(sinks and sinks==sorted(set(sinks)),'native sink vector missing/duplicate')
        need(set(user['paths_to_source'])==set(sinks),'native sink path inventory differs')
        for sink in sinks:
            need(sink in wires,'native sink absent from tree');path=[];cursor=sink
            while True:
                path.append(cursor)
                if cursor==root:break
                cursor=wires[cursor]['source']
            need(user['paths_to_source'][sink]==path,'recorded native source path differs from decoded PIPs')
    need(set(actual)==set(expected),'complete native user identities differ')
    need(all(tree[k] is True for k in ('all_native_sinks_reached','single_acyclic_source_root','foreign_ownership_absent')),'native readback failure flag')
    return actual

def main():
    H=ROOT/'native-topology';D=H/'paired-readback';proof=read(HERE/'graph-proof.json');spec=read(HERE/'native-selection-specs.json');receipt=read(D/'receipt.json')
    need(proof['status']=='pass' and receipt['passed'],'missing passed graph/readback')
    need(spec['graph_proof_sha256']==receipt['graph_proof_sha256']==sha(HERE/'graph-proof.json'),'graph proof identity mismatch')
    need(receipt['selection_specs_sha256']==sha(HERE/'native-selection-specs.json'),'selection identity differs')
    need(spec['selections']==proof['native_topology_selections'] and spec['graph_sha256']==proof['graph_sha256'],'selection graph identities differ')
    if not proof['changed_canonical_net_bits']:
        need(not receipt['native_execution_needed'] and not spec['selections'],'invalid no-readback claim')
        write('topology-proof.json',{'passed':True,'native_readback_needed':False,'reason':'No canonical routing tree changed','graph_proof_sha256':sha(HERE/'graph-proof.json'),'readback_receipt_sha256':sha(D/'receipt.json')});return
    need(receipt['native_execution_needed'] and len(receipt['records'])==2,'missing native executions')
    build=read(H/'build-receipt.json');compat=read(H/'architecture-compatibility.json')
    need(compat['passed'] and compat['reader_binary_sha256']==build['helper_binary_sha256'] and receipt['architecture_compatibility_sha256']==sha(H/'architecture-compatibility.json'),'structural compatibility differs')
    need(sha(H/'build-receipt.json')==receipt['build_receipt_sha256'],'build receipt differs')
    need(build['helper_source_sha256']==receipt['helper_source_sha256']==sha(H/'tree-reader.cc') and build['helper_binary_sha256']==receipt['helper_binary_sha256'],'native reader identities differ')
    trees={};modules={}
    for record in receipt['records']:
        case=record['case'];need(case in ('default','final32') and case not in trees and record['returncode']==0,'native case differs')
        need(sha(ROOT/('route-'+case)/'routed.json')==record['input_sha256']==proof['graph_sha256'][case],'native input differs')
        for suffix,key in (('-selection.json','selection_sha256'),('-topology.json','output_sha256'),('.log','log_sha256')):need(sha(D/(case+suffix))==record[key],'native output hash differs')
        output=read(D/(case+'-topology.json'));need(output['pass'],'native readback rejected')
        trees[case]={t['bit']:t for t in output['trees']};need(len(trees[case])==len(output['trees']),'duplicate native selected net')
        modules[case]=next(iter(read(ROOT/('route-'+case)/'routed.json')['modules'].values()))
    bits={s['bit'] for s in spec['selections']};need(bits==set(proof['changed_canonical_net_bits']) and set(trees)=={'default','final32'},'complete changed net inventory differs')
    need(all(set(v)==bits for v in trees.values()),'native selected inventory differs')
    records=[];users=0
    for selected in spec['selections']:
        bit=selected['bit'];by_case={}
        for case,which in (('default','before'),('final32','after')):
            netnames=modules[case]['netnames'];serialized=route_tree(netnames[selected['aliases'][0]]['attributes'].get('ROUTING'))
            need(digest(serialized)==selected[which+'_tree_sha256'],'serialized tree digest differs')
            need(all(netnames[a]['bits']==[bit] and route_tree(netnames[a]['attributes'].get('ROUTING'))==serialized for a in selected['aliases']),'alias trees differ')
            by_case[case]=validate(trees[case][bit],selected,serialized,which)
        a,b=trees['default'][bit],trees['final32'][bit];root=a['driver']['source_wire']
        need(b['driver']['source_wire']==root and a['complete_tree'][root]==b['complete_tree'][root],'native source root/strength changed')
        need(by_case['default'].keys()==by_case['final32'].keys(),'logical user inventory changed')
        user_rows=[]
        for key,before in by_case['default'].items():
            after=by_case['final32'][key];need(before['native_port']==after['native_port'] and before['physical_sink_wires']==after['physical_sink_wires'],'physical sink or pin map changed')
            user_rows.append({'cell':key[0],'port':key[1],'sinks':before['physical_sink_wires'],'path_changed':before['paths_to_source']!=after['paths_to_source']});users+=1
        old,new=a['complete_tree'],b['complete_tree'];records.append({'bit':bit,'aliases':selected['aliases'],'before_wires':len(old),'after_wires':len(new),
          'retired_wire_names':sorted(set(old)-set(new)),'new_wire_names':sorted(set(new)-set(old)),'changed_existing_wire_tuples':sorted(w for w in set(old)&set(new) if old[w]!=new[w]),'all_users':user_rows})
    write('topology-proof.json',{'passed':True,'native_readback_needed':True,'graph_proof_sha256':sha(HERE/'graph-proof.json'),'readback_receipt_sha256':sha(D/'receipt.json'),
      'checker_sha256':sha(__file__),'helper_source_sha256':build['helper_source_sha256'],'helper_binary_sha256':build['helper_binary_sha256'],'architecture_compatibility_sha256':sha(H/'architecture-compatibility.json'),
      'selected_nets':len(bits),'complete_users':users,'all_sources_and_physical_sinks_exact':True,'all_native_paths_reach_same_source':True,'nets':records,
      'limits':['Offline replay of recorded native source/PIP/sink decoding only; not a new native execution.',
      'Whole-net reroute may change every source-to-sink path and prune unused source-exit stubs. No stationary path or old unused stub retention is required or claimed.',
      'No pin allocation, physical-mask/configuration, routing, reload STA, RBF electrical or hardware acceptance.']})
    print('PASS complete native whole-net trees:',len(bits),'nets,',users,'users')
if __name__=='__main__':main()
