"""Exact complete graph readers retained from the qualified permutation checker.
Only the four parsing/identity helpers are reused; final-route acceptance is separate.
"""
import json,re
from collections import defaultdict
from support import need,unique
from native_port_identity import native_physical_port

def pinmap(cell):
    raw = cell['attributes']['FES_PINMAP_V1']
    data = json.loads(bytes.fromhex(raw).decode(), object_pairs_hook=unique)
    need(set(data) == {'count', 'pins'} and data['count'] == len(data['pins']), 'invalid physical pin snapshot')
    return data['pins']

def graph_edges(module):
    users, drivers, aliases = defaultdict(list), defaultdict(list), defaultdict(list)
    for name, cell in sorted(module['cells'].items()):
        need(cell['connections'].keys() == cell['port_directions'].keys(), 'port direction inventory: ' + name)
        for pin, bits in sorted(cell['connections'].items()):
            direction = cell['port_directions'][pin]
            need(direction in ('input', 'output', 'inout'), 'unknown port direction')
            for index, bit in enumerate(bits):
                if type(bit) is int:
                    if direction in ('input', 'inout'):
                        users[bit].append([name, pin, index])
                    if direction in ('output', 'inout'):
                        drivers[bit].append([name, pin, index])
    public = set()
    for name, port in sorted(module['ports'].items()):
        public.update(bit for bit in port['bits'] if type(bit) is int)
    for name, net in sorted(module['netnames'].items()):
        need(len(net['bits']) == 1, 'expected serialized scalar net/alias: ' + name)
        bit = net['bits'][0]
        need(type(bit) is int, 'noninteger routed net identity')
        aliases[bit].append(name)
    return users, drivers, aliases, public

def route_tree(raw):
    if raw is None:
        return None
    need(isinstance(raw, str), 'nonstring route attribute')
    # Property's JSON string encoding represents the empty string as one space.
    if raw in ('', ' '):
        return {}
    parts = raw.split(';')
    need(len(parts) % 3 == 0, 'partial route triple')
    result, pips = {}, set()
    for i in range(0, len(parts), 3):
        wire, pip, strength = parts[i:i + 3]
        need(wire and wire not in result, 'duplicate/empty route wire')
        need(re.fullmatch(r'[0-6]', strength) is not None, 'invalid native route strength')
        need(not pip or pip not in pips, 'duplicate route pip')
        if pip:
            pips.add(pip)
        result[wire] = [pip, int(strength)]
    return result

def physical_port(cells, user):
    return native_physical_port(cells, user, pinmap)
