#!/usr/bin/env python3
"""Qualify only structural JSON/tree decoding using the internally consistent old ABI."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess
H=Path(__file__).resolve().parent;R=H.parent;OLD=R.parent/'cga-source-exit-retention-20261023/native-topology';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def blob(commit,name):return subprocess.check_output(['git','show',commit+':'+name],cwd=S)
commit=read(R/'committed-source-verification.json');identity=read(R/'source-validation/final-host/source-identity.json');final=read(R/'final-validation.json')
new=commit['commit'];parent='1ba2e289f5bf4e584a8539f185d6f15383650c26';old='186637013e17461a72cd1d2cd17ca5ef174ed06f'
assert commit['all_recorded_source_bytes_match_commit'] and commit['final_validation_sha256']==sha(R/'final-validation.json') and commit['source_files']==final['source_files']
assert identity['base_commit']==parent and sha(R/'source-validation/final-host/source-identity.json')==final['final_source_identity_sha256']
for n in ['tree-reader','tree-reader.cc','build-receipt.json','build-commands.json','build.log','frozen-manifest.json','committed-source-verification.json']:
 p=H/n
 if p.exists():assert sha(p)==sha(OLD/n)
 elif n=='tree-reader':os.link(OLD/n,p)
 else:shutil.copy2(OLD/n,p)
for n,newname in [('architecture-compatibility.json','prior-exit-compatibility.json'),('prepare.py','prior-exit-prepare.py'),('independent-reader-review.json','prior-exit-reader-review.json')]:
 p=H/newname
 if p.exists():assert sha(p)==sha(OLD/n)
 else:shutil.copy2(OLD/n,p)
build=read(H/'build-receipt.json');prior=read(H/'prior-exit-compatibility.json');q=read(H/'committed-source-verification.json')
assert build['pass'] and sha(H/'tree-reader')==build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
assert sha(H/'tree-reader.cc')==build['helper_source_sha256'] and sha(H/'frozen-manifest.json')==build['frozen_manifest_sha256']
assert q['passed'] and q['source_commit']==old and prior['passed'] and prior['reader_compiler_commit']==old and prior['route_compiler_commit']==parent
same={};different={}
for name,h in q['source_files'].items():
 current=hashlib.sha256(blob(new,name)).hexdigest();(same if current==h else different)[name]={'old_sha256':h,'new_sha256':current}
assert len(same)+len(different)==309
expected={'mistral/CMakeLists.txt','mistral/analogue_repair.h','mistral/arch.h','mistral/main.cc','mistral/routed_lut6_swap.cc','mistral/routed_lut_permutation.cc','mistral/private_pair_decomposition.cc','mistral/analogue.cc','mistral/routed_move.cc'}
assert set(different)==expected
changed=set(subprocess.check_output(['git','diff','--name-only',parent,new,'--','mistral','common','json','generic','3rdparty'],cwd=S,text=True).splitlines())
assert changed==set(n for n in identity['files'] if n.startswith(('mistral/','common/','json/','generic/','3rdparty/')))
for name,h in final['source_files'].items():assert hashlib.sha256(blob(new,name)).hexdigest()==h
for name in ('mistral/routed_lut_permutation.cc','mistral/private_pair_decomposition.cc'):assert blob(parent,name)==blob(new,name)
a=blob(parent,'mistral/arch.h');b=blob(new,'mistral/arch.h')
line=b'    int critical_final_route_budget = 0; // CLI-only final discovery after LUT repairs.\n'
assert b.count(line)==1 and b.replace(line,b'').replace(b'void repair_critical_routes(bool final_after_lut = false);',b'void repair_critical_routes();')==a
a=blob(parent,'mistral/routed_move.cc');b=blob(new,'mistral/routed_move.cc');term=b' && !critical_final_route_budget'
assert b.count(term)==1 and b.replace(term,b'')==a
# The existing route transaction and every earlier analogue function remain exact.
a=blob(parent,'mistral/analogue.cc');b=blob(new,'mistral/analogue.cc');marker=b'void Arch::repair_critical_routes('
assert a[:a.index(marker)]==b[:b.index(marker)]
# Entire prior LUT/source/downstream implementation is recovered by removing only the new wrapper.
a=blob(parent,'mistral/routed_lut6_swap.cc');b=blob(new,'mistral/routed_lut6_swap.cc')
start=b.index(b'// A separate final-route scope reuses the same bounded structural/native walker.');end=b.index(b'\nnamespace {',start)
assert b[:start]+b[end+1:]==a
reader=(H/'tree-reader.cc').read_text();assert 'parse_json(in,argv[1],&c)' in reader and 'restore_cell_pin_map' in reader
for symbol in ('repair_critical_routes','critical_final_route_source_coverage','refresh_post_route_repair_checkpoint','critical_routed_lut_permutation_trial','configure_bitstream','TimingAnalyser','assign_alm_lut_inputs'):assert symbol not in reader
assert 'mistral/main.cc.o' not in (H/'build-commands.json').read_text()
v={'passed':True,'reader_compiler_commit':old,'route_compiler_commit':new,'reader_binary_sha256':sha(H/'tree-reader'),'reader_source_sha256':sha(H/'tree-reader.cc'),
 'reader_build_receipt_sha256':sha(H/'build-receipt.json'),'reader_frozen_manifest_sha256':sha(H/'frozen-manifest.json'),
 'route_source_identity_sha256':sha(R/'source-validation/final-host/source-identity.json'),'route_final_validation_sha256':sha(R/'final-validation.json'),
 'prior_exit_compatibility_sha256':sha(H/'prior-exit-compatibility.json'),'prior_exit_prepare_sha256':sha(H/'prior-exit-prepare.py'),'prior_exit_reader_review_sha256':sha(H/'prior-exit-reader-review.json'),
 'unchanged_snapshotted_source_files':same,'changed_snapshotted_source_files':different,'exact_production_delta_from_exit_commit':sorted(changed),
 'arch_only_budget_member_and_uncalled_method_signature':True,'routed_checkpoint_only_new_budget_condition':True,'existing_analogue_prefix_and_transaction_exact':True,'entire_prior_lut_source_recovered':True,
 'scope':'Structural saved-JSON source/sink/PIP decoding only. Old reader retains its internally consistent old Context ABI and all matching old linked objects; no new-object mixing. New budget/method signature, CLI, final route orchestration, source wrapper and checkpoint refresh are never invoked. Native parser/model/physical decoding sources remain exact. Whole-net sink paths and unused source-exit stubs may change; readback does not require stationary-path retention. No configuration, allocation, routing, STA or RBF electrical proof.'}
p=H/'architecture-compatibility.json';encoded=json.dumps(v,indent=2,sort_keys=True)+'\n'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(sha(p))
