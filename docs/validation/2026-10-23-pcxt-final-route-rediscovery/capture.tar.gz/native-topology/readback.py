#!/usr/bin/env python3
"""Native source/PIP/sink readback only after complete fresh paired graph receipts."""
from pathlib import Path
import hashlib,json,subprocess,time
H=Path(__file__).resolve().parent;E=H.parent;C=E/'final-analysis'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):
 assert not p.exists(),p;p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def main():
 proof=read(C/'graph-proof.json');spec=read(C/'native-selection-specs.json');build=read(H/'build-receipt.json');compat=read(H/'architecture-compatibility.json');commit=read(E/'committed-source-verification.json')
 assert proof['status']=='pass' and spec['graph_proof_sha256']==sha(C/'graph-proof.json') and spec['graph_sha256']==proof['graph_sha256'] and spec['selections']==proof['native_topology_selections']
 assert compat['passed'] and compat['reader_binary_sha256']==build['helper_binary_sha256'] and compat['route_compiler_commit']==commit['commit'] and compat['route_final_validation_sha256']==sha(E/'final-validation.json')
 assert set(proof['graph_sha256'])=={'default','final32'}
 for case,h in proof['graph_sha256'].items():
  directory=E/('route-'+case);receipt=read(directory/'receipt.json');assert receipt['returncode'] in (0,1)
  assert receipt['committed_source_verification']==commit and receipt['final_validation']==read(E/'final-validation.json')
  assert sha(directory/'routed.json')==receipt['artifacts']['routed.json']==h
  for name,expected in receipt['artifacts'].items():assert sha(directory/name)==expected
 assert build['pass'] and sha(H/'tree-reader')==build['helper_binary_sha256'] and sha(H/'tree-reader.cc')==build['helper_source_sha256'] and sha(H/'frozen-manifest.json')==build['frozen_manifest_sha256']
 D=H/'paired-readback';D.mkdir(exist_ok=False);records=[]
 if not proof['changed_canonical_net_bits']:
  assert not spec['selections'];save(D/'receipt.json',{'passed':True,'native_execution_needed':False,'reason':'No canonical routing tree changed','graph_proof_sha256':sha(C/'graph-proof.json'),'selection_specs_sha256':sha(C/'native-selection-specs.json'),'charged_route_seconds':0})
 else:
  assert sorted(s['bit'] for s in spec['selections'])==proof['changed_canonical_net_bits']
  for case,which in (('default','before'),('final32','after')):
   nets=[{'name':n['name'],'bit':n['bit'],'aliases':n['aliases'],'driver':n['driver'],'users':[u[which] for u in n['user_transitions']]} for n in spec['selections']]
   selection=D/(case+'-selection.json');save(selection,{'schema':2,'nets':nets,'graph_proof_sha256':sha(C/'graph-proof.json'),'graph_sha256':proof['graph_sha256'][case]})
   output=D/(case+'-topology.json');cmd=[str(H/'tree-reader'),str(E/('route-'+case)/'routed.json'),str(selection),str(output)];start=time.monotonic()
   with (D/(case+'.log')).open('w') as stream:rc=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT).returncode
   record={'case':case,'argv':cmd,'returncode':rc,'wall_seconds':time.monotonic()-start,'input_sha256':proof['graph_sha256'][case],'selection_sha256':sha(selection),'log_sha256':sha(D/(case+'.log')),'output_sha256':sha(output) if output.exists() else None}
   records.append(record);assert rc==0 and read(output)['pass']
  for case,h in proof['graph_sha256'].items():assert sha(E/('route-'+case)/'routed.json')==h
  assert sha(H/'tree-reader')==build['helper_binary_sha256'] and sha(H/'tree-reader.cc')==build['helper_source_sha256']
  save(D/'receipt.json',{'passed':True,'native_execution_needed':True,'records':records,'graph_proof_sha256':sha(C/'graph-proof.json'),'selection_specs_sha256':sha(C/'native-selection-specs.json'),'build_receipt_sha256':sha(H/'build-receipt.json'),'architecture_compatibility_sha256':sha(H/'architecture-compatibility.json'),'helper_binary_sha256':build['helper_binary_sha256'],'helper_source_sha256':build['helper_source_sha256'],'charged_route_seconds':0,'scope':'Native saved-tree source/PIP/sink interpretation only; whole-net paths and unused stubs may change. No routing, pin allocation, configuration, timing or RBF generation.'})
 subprocess.run(['python3',str(C/'verify_topology.py')],check=True)
if __name__=='__main__':main()
