#!/usr/bin/env python3
"""New wrapper9, retained native22, final CLI7 and prior CLI2; CPU host only."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,re,subprocess,sys,time
HERE=Path(__file__).resolve().parent;EVIDENCE=HERE.parent
env=dict(os.environ,TMPDIR=str(EVIDENCE/'build-tmp'))
ROOT=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');BUILD=ROOT.parent/'build-candidate'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
source=json.loads((HERE/'final-host/source-identity.json').read_text());identity=json.loads((HERE/'build-identity.json').read_text())
proof=json.loads((HERE/'final-host/unchanged-guards-proof.json').read_text());exe=BUILD/'nextpnr-mistral';test=BUILD/'nextpnr-mistral-test'
def unchanged():
    return (all(sha(ROOT/f)==r['sha256'] for f,r in source['files'].items()) and
        all(sha(ROOT/f)==h for f,h in proof['unchanged_complete_source_files'].items()) and
        all(sha(ROOT/f)==h for f,h in source['retained_validation_sources'].items()) and
        sha(exe)==identity['production_sha256'] and sha(test)==identity['native_test_sha256'] and
        sha(EVIDENCE/'nextpnr-mistral')==identity['production_sha256'])
assert unchanged()
retained=':'.join(['RoutedLut6SourceCoverage.*',
    'CriticalCohort.RouteGuardPreservesPositiveMarginsAndCoverage',
    'CriticalCohort.RouteTransactionRestoresBindingsMuxesAndExceptions',
    'CriticalCohort.RoutedInventoryUsesNativeSetupHoldAndFailsClosed',
    'CriticalCohort.StaticEndpointCoverageRequiresConstantProof','CriticalRouteRanking.*','PostRouteCheckpoint.*',
    '*PrivatePairBackend.CompleteNativeClockMetricsRejectEveryCoverageAndPositiveMarginRegression*',
    '*PrivatePairBackend.CompleteMultiCaptureCoverageRejectsHiddenUnsupportedAndPublicBranches*'])
cases=[('final-source-native',[str(test),'--gtest_filter=FinalRouteSourceCoverage.*'],9,True),
    ('retained-native',[str(test),'--gtest_filter='+retained],22,True),
    ('final-route-cli',[sys.executable,str(ROOT/'mistral/tests/final_critical_route_cli.py'),str(exe),'-v'],7,False),
    ('prior-route-cli',[sys.executable,str(ROOT/'mistral/tests/critical_cohort_cli.py'),str(exe),'-v',
        'CriticalCohortCli.test_routed_repair_requires_explicit_full_gpu_route',
        'CriticalCohortCli.test_move_route_is_bounded_explicit_and_exclusive'],2,False)]
def run(name,cmd,count,native):
    log=HERE/(name+'.log');assert not log.exists()
    names=[]
    if native:
        listing=subprocess.check_output(cmd+['--gtest_list_tests'],cwd=ROOT,env=env,text=True)
        (HERE/(name+'.list.txt')).write_text(listing);suite=''
        for line in listing.splitlines():
            if not line or line.startswith('Note:'):continue
            if line.startswith('  '):names.append(suite+line.strip().split(' #',1)[0])
            elif line.split(' #',1)[0].endswith('.'):suite=line.split(' #',1)[0]
        assert len(names)==count,(name,names)
    t=time.monotonic()
    with log.open('w') as f:rc=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
    matches=re.findall(r'\[  PASSED  \] (\d+) tests?\.' if native else r'Ran (\d+) tests? in',log.read_text())
    observed=int(matches[-1]) if matches else 0
    r={'name':name,'command':cmd,'cwd':str(ROOT),'returncode':rc,'elapsed_seconds':time.monotonic()-t,
       'log_sha256':sha(log),'expected_count':count,'observed_count':observed,'pass':rc==0 and observed==count}
    if native:r['test_names']=names;r['list_sha256']=sha(HERE/(name+'.list.txt'))
    (HERE/(name+'.receipt.json')).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r),flush=True);return r
with ThreadPoolExecutor(max_workers=3) as pool:
    jobs=[pool.submit(run,*case) for case in cases];results=[j.result() for j in jobs]
valid=unchanged();r={'build_identity_sha256':sha(HERE/'build-identity.json'),'results':results,
    'sources_and_binaries_unchanged':valid,'pass':valid and all(x['pass'] for x in results),
    'scope':'Host-only native source/clock/inventory/rollback checks and fail-closed CLI. No GPU or fresh board route execution.'}
(HERE/'validation.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r),flush=True)
sys.exit(0 if r['pass'] else 1)
