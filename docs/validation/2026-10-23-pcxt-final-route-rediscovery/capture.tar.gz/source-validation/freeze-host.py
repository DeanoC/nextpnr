#!/usr/bin/env python3
"""Freeze reviewed final-route host sources, retained checks and normalization proofs."""
from pathlib import Path
import hashlib,json,subprocess,shutil
HERE=Path(__file__).resolve().parent;R=HERE.parent;F=HERE/'final-host'
REPO=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
BASE='1ba2e289f5bf4e584a8539f185d6f15383650c26'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(b):return hashlib.sha256(b).hexdigest()
def write(p,obj):
    assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def copy(src,dst):
    assert not dst.exists(),dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
proposal=json.loads((R/'source-identity.json').read_text());assert proposal['base_commit']==BASE
review=json.loads((R/'supplemental-rebind-comment-review.json').read_text())
assert review['passed'] and review['source_identity_sha256']==sha(R/'source-identity.json')
parent_path=R.parent/'cga-source-exit-retention-20261023/final-validation.json'
parent=json.loads(parent_path.read_text())
old={k.removeprefix('complete-source/'):h for k,h in parent['files'].items() if k.startswith('complete-source/')};assert len(old)==30
files=set(proposal['files'])|{'mistral/tests/final_route_source_coverage.cc'};assert len(files)==10
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=REPO,text=True).splitlines())
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=REPO,text=True).splitlines())
assert changed|untracked==files,(changed,untracked)
token='tests/final_route_source_coverage.cc '
for f,row in proposal['files'].items():
    assert sha(R/'source'/f)==row['sha256']
    if f=='mistral/CMakeLists.txt':
        now=(REPO/f).read_text();assert now.count(token)==1 and now.replace(token,'')==(R/'source'/f).read_text()
    else:assert sha(REPO/f)==row['sha256']
    if not row.get('new_file'):assert digest(subprocess.check_output(['git','show',BASE+':'+f],cwd=REPO))==row['before_sha256']
fixture='mistral/tests/final_route_source_coverage.cc'
assert sha(REPO/fixture)==sha(R/'test-draft/final_route_source_coverage.cc')=='3ffece1123d8376065e6da878905f2d3ec4942861e5f5eb8db70bf2fb28f61c8'
for f,h in old.items():
    assert digest(subprocess.check_output(['git','show',BASE+':'+f],cwd=REPO))==h
    assert sha(parent_path.parent/'complete-source'/f)==h
    if f not in files:assert sha(REPO/f)==h
records={}
for f in sorted(files):
    copy(REPO/f,F/'source'/f);row={'sha256':sha(F/'source'/f)}
    if f in proposal['files'] and not proposal['files'][f].get('new_file'):
        b=subprocess.check_output(['git','show',BASE+':'+f],cwd=REPO)
        p=F/'before'/f;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);row['before_sha256']=digest(b)
    else:row['new_file']=True
    records[f]=row
retained={}
for f in ['mistral/tests/critical_cohort.cc','mistral/tests/post_route_checkpoint.cc','mistral/tests/critical_cohort_cli.py']:
    assert (REPO/f).read_bytes()==subprocess.check_output(['git','show',BASE+':'+f],cwd=REPO)
    copy(REPO/f,F/'retained-validation-source'/f);retained[f]=sha(REPO/f)
a=(F/'before/mistral/analogue.cc').read_text();b=(F/'source/mistral/analogue.cc').read_text()
start='bool critical_route_trial(';end='void Arch::repair_critical_routes('
native=a[a.index(start):a.index(end)];assert native==b[b.index(start):b.index(end)]
lutbefore=(F/'before/mistral/routed_lut6_swap.cc').read_text();lutafter=(F/'source/mistral/routed_lut6_swap.cc').read_text()
start=lutafter.index('// A separate final-route scope');end=lutafter.index('\nnamespace {',start)
assert lutafter[:start]+lutafter[end+1:]==lutbefore
assert b.index('if (!budget) return;')<b.index('Context *ctx = getCtx();',b.index('void Arch::repair_critical_routes('))
write(F/'source-identity.json',{'base_commit':BASE,'observed_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'proposal_identity_sha256':sha(R/'source-identity.json'),'files':records,'retained_validation_sources':retained,'scope':'Reviewed default-zero final route rediscovery plus focused native fixture/registration; host only.'})
write(F/'unchanged-guards-proof.json',{'passed':True,'parent_final_validation_sha256':sha(parent_path),'complete_parent_source_count':len(old),'final_complete_source_count':len(set(old)|files),'unchanged_complete_source_files':{f:h for f,h in sorted(old.items()) if f not in files},'retained_validation_sources':retained,'exact_native_route_transaction_sha256':digest(native.encode()),'entire_prior_lut_source_file_recovered_after_removing_new_wrapper':True,'cmake_only_one_native_registration_over_reviewed_proposal':True,'default_zero_returns_before_context_access':True,'supplemental_source_review_sha256':sha(R/'supplemental-rebind-comment-review.json'),'scope':'Existing route transaction and full source/downstream coverage implementations remain byte exact. New final-mode orchestration/CLI are reviewed separately; runtime controls and final fresh routes remain required.'})
print(json.dumps({'files':len(records),'complete_source_count':len(set(old)|files),'source_identity_sha256':sha(F/'source-identity.json'),'unchanged_guards_sha256':sha(F/'unchanged-guards-proof.json')},sort_keys=True))
