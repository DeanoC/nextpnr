#!/usr/bin/env python3
"""Build frozen final-route host sources and native checks; no GPU execution."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
HERE=Path(__file__).resolve().parent;EVIDENCE=HERE.parent
ROOT=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');BUILD=ROOT.parent/'build-candidate'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
source=json.loads((HERE/'final-host/source-identity.json').read_text());proof=json.loads((HERE/'final-host/unchanged-guards-proof.json').read_text())
review_path=HERE/'final-host/independent-fixture-registration-review.json'
assert review_path.exists()
observed_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
def unchanged():
    return (all(sha(ROOT/f)==r['sha256']==sha(HERE/'final-host/source'/f) for f,r in source['files'].items()) and
        all(sha(ROOT/f)==h for f,h in proof['unchanged_complete_source_files'].items()) and
        all(sha(ROOT/f)==h for f,h in source['retained_validation_sources'].items()))
assert unchanged();assert not (HERE/'build.log').exists()
tmp=EVIDENCE/'build-tmp';tmp.mkdir(exist_ok=True);env=dict(os.environ,TMPDIR=str(tmp))
before={'production_sha256':sha(BUILD/'nextpnr-mistral'),'native_test_sha256':sha(BUILD/'nextpnr-mistral-test')}
(HERE/'before-build-identity.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
cmd=['cmake','--build',str(BUILD),'--target','nextpnr-mistral','nextpnr-mistral-test','-j4'];t=time.monotonic()
with (HERE/'build.log').open('w') as f:rc=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
(HERE/'build-commands.txt').write_bytes(subprocess.check_output(['ninja','-t','commands','nextpnr-mistral','nextpnr-mistral-test'],cwd=BUILD))
receipt={'command':cmd,'cwd':str(ROOT),'returncode':rc,'elapsed_seconds':time.monotonic()-t,'log_sha256':sha(HERE/'build.log'),'sources_unchanged':unchanged(),'post_build_commands_sha256':sha(HERE/'build-commands.txt')}
(HERE/'build.receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
assert rc==0 and unchanged(),receipt
identity={'source_identity_sha256':sha(HERE/'final-host/source-identity.json'),'production_sha256':sha(BUILD/'nextpnr-mistral'),'native_test_sha256':sha(BUILD/'nextpnr-mistral-test'),'observed_head':observed_head,'source_base_commit':source['base_commit'],'supplemental_source_review_sha256':sha(EVIDENCE/'supplemental-rebind-comment-review.json'),'fixture_registration_review_sha256':sha(review_path),'unchanged_guards_proof_sha256':sha(HERE/'final-host/unchanged-guards-proof.json')}
(HERE/'build-identity.json').write_text(json.dumps(identity,indent=2,sort_keys=True)+'\n')
assert not (EVIDENCE/'nextpnr-mistral').exists();shutil.copyfile(BUILD/'nextpnr-mistral',EVIDENCE/'nextpnr-mistral');(EVIDENCE/'nextpnr-mistral').chmod(0o755)
print(json.dumps(identity),flush=True)
