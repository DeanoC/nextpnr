# PC/XT final critical-route rediscovery: no retained gain

Compiler `626e368b0529c4516aa3a7a4bb4bcdd034011e30` and frozen binary
`52dda57ca0a9da4c57f9f5836764e791aced3e9efab9da9b1c64543c51a417f5`
add a separate default-zero `--critical-final-route-budget` (maximum 32).
After the existing LUT repairs, it rebuilds live timing/cache state and discovers
ordinary FF/LUT Q-driven nets again. Both clock frames, complete endpoint
coverage, every native setup/hold margin and the existing atomic route
transaction remain required. Unused arithmetic leaves are not exempted in
this final pass. Host admission passed 31 native and nine CLI tests, with
exact default/explicit-zero controls. The complete host manifest binds 111
files and 34 source files; the committed source bytes match the frozen build.

Two fresh seed-1 routes use the same raw synthesis and original 100 MHz
CPU/system/microcode and 74.25 MHz pixel constraints. The control disables
final rediscovery; the candidate sets only `--critical-final-route-budget 32`.
Both retain route32, two LUT6 rounds/budget16 and ordinary permutation32;
source-exit retention stays disabled. The control reproduces the prior fixed
RBF/timing/endpoints byte for byte and the complete routed graph except its
creator label.

The final pass finds 24 failing ordinary sink rows and selects 21 nets. Two
proposal generations log 17 native candidates. Every gain is negative; the
best is -20 ps. Consequently no proposal reaches the +20 ps admission threshold,
no full timing trial runs and no change is retained. This is a bounded search
result, not proof that no legal improving route exists.

Both final RBFs, timing reports and endpoint inventories are byte-identical.
The complete 12,397-cell/15,546-alias graph is unchanged, including every
function, pin map, placement, LAB field, alias, source, user, wire, PIP and
strength. Routed JSON has 15 routing-attribute serialization-order differences;
no canonical route tree changes. The empty changed-tree set requires no new
native reader execution. All 17,199 endpoint identities/windows/flags/metadata
and all 17,194 setup and hold margins match.

Eight setup failures remain (two CPU, three CGA, two MDA and one PIC): CPU
worst -25 ps, whole-system worst -434 ps. Related hold has zero failures and
minimum +822 ps. There are still 105 unsupported boundaries and `complete=false`.
No timing closure, same-recipe seed qualification, sealed producer or hardware
acceptance is claimed. No RTL, clocks, constraints, lock or shared contracts
changed in this compiler experiment.

Root ran the complete timing and graph comparisons. The separate actual-output
review replays eight outputs exactly, including 54 graph/log and 24 native-record
negative controls and the three preserved checker corrections. Review SHA-256:
`110ee76bd47952b2b812f32ee3e2a9f7376d4a933a5cca741bd876b8ac931a89`.
The emitted final inventory is skew-aware; the reference-free acceptance frame
is checked inside the compiler and is not a separately emitted final report.
No rejected-state timing is reconstructed from a checkpoint.

Control charge is 1071.680669224821 seconds; final32 charge is
1186.9478577878326 seconds. Pair total is 2258.6285270126536 seconds.
The journal now contains 54 subsequent receipts, cumulative
55746.72936571435947 seconds including the pre-journal charge. Prior references,
proof replays and synthesis are not charged as additional routes.

The independent packet-renderer RTL proposal remains outside shared RTL. Its
exact one-cycle tuple relation and same-cycle MDA status passed formal checks;
unchanged display/display-machine/video-machine tests and 10 consumer boundary
runs passed. The latter cover 260 frames and 192 HOLD edges with complete-bank
write/publication checks. It has a separate host-only full-board synthesis
experiment. Any fresh route must inspect the new packet-to-MDA-status path and
include every added register/endpoint and unchanged physical timing obligations.
