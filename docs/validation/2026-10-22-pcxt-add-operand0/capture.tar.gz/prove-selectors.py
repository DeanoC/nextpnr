#!/usr/bin/env python3
from pathlib import Path
from collections import defaultdict
import json,hashlib
R=Path(__file__).resolve().parent;P='system.machine.cpu.cpu.u_eu_core.'
result={'runs':{},'evidence':'Exact raw FF control/observability inventory and exhaustive selector DATAIN proof, not whole-board sequential equivalence.'}
for mode in ('baseline','candidate'):
 path=R/mode/'synthesis/synth.json';m=json.loads(path.read_text())['modules']['top'];d={};a=defaultdict(list);u=defaultdict(list)
 for n,c in m['cells'].items():
  for p,bs in c['connections'].items():
   for i,b in enumerate(bs):
    if isinstance(b,str):continue
    if c['port_directions'][p]=='output':d[b]=(n,p,i)
    else:u[b].append((n,p,i))
 for n,v in m['netnames'].items():
  for i,b in enumerate(v['bits']):
   if isinstance(b,int):a[b].append((n,i))
 data=m['netnames'][P+'u_ucode_rom.data_half']['bits'][20:24];clock=m['netnames']['clocks']['bits'][0];selectors=m['netnames'][P+'eu_add_select0']['bits'];records=[]
 def evalbit(b,assignment,seen):
  if b in assignment:return assignment[b]
  if isinstance(b,str):assert b in ('0','1');return int(b)
  n,p,_=d[b];c=m['cells'][n];seen.add(n);assert c['type'] in ['MISTRAL_ALUT'+str(i) for i in range(2,7)] and p=='Q';width=int(c['type'][-1]);row=sum(evalbit(c['connections'][p][0],assignment,seen)<<i for i,p in enumerate('ABCDEF'[:width]));return int(c['parameters']['LUT'],2)>>row&1
 for i,q in enumerate(selectors):
  if isinstance(q,str):records.append({'selector_bit':i,'raw':q,'present':False});continue
  n,p,j=d[q];c=m['cells'][n];assert c['type']=='MISTRAL_FF' and p=='Q' and j==0 and not c['parameters'];assert c['connections']['CLK']==[clock];assert c['connections']['ACLR']==['1'] and c['connections']['ENA']==['1'];assert all(c['connections'][p]==['0'] for p in ('SCLR','SLOAD','SDATA'));assert int(c['attributes']['keep'],2)==1
  seen=set()
  for v in range(16):assert evalbit(c['connections']['DATAIN'][0],{b:v>>j&1 for j,b in enumerate(data)},seen)==(v==i)
  observers=[(p,j) for p,v in m['ports'].items() for j,b in enumerate(v['bits']) if b==q]
  records.append({'selector_bit':i,'present':True,'cell':n,'raw_cell':c,'q_aliases':a[q],'q_users':u[q],'top_observers':observers,'clock_alias':['clocks',0],'clock_driver':d[clock],'data_input_function':f'raw data_half[23:20] == {i}','exhaustive_rows':16,'data_cone':{n:m['cells'][n] for n in sorted(seen)}})
 result['runs'][mode]={'synth_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'selector_records':records,'actual_selector_ff_count':sum(x['present'] for x in records)}
a=result['runs']['baseline']['selector_records'];b=result['runs']['candidate']['selector_records'];added=[]
for x,y in zip(a,b):
 if not x['present'] and y['present']:
  assert x['raw']=='x' and not y['q_users'] and not y['top_observers'];added.append(y['selector_bit'])
assert added==[13,14,15]
result['added_selector_bits']=added;result['removed_selector_bits']=[];result['delta_explanation']='The committed source already declares independent kept ADD selectors. The hierarchy-preserved map retains three extra unobserved selector state bits; baseline bits 13..15 were pruned to x. Bits 13/14 are masked off; source 15 data is all zero. Every retained bit captures the same decoded microword nibble on existing clocks[0], with no enable/reset/load condition. These three added Q outputs have zero cell and top-port consumers. This is retained unused state, not an added consumer-visible pipeline stage. Other synthesis state correspondence is inventoried separately.'
(R/'selector-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'counts':{k:v['actual_selector_ff_count'] for k,v in result['runs'].items()},'added':added,'all_data_functions_exhaustive':True,'all_controls_exact':True,'new_outputs_unobserved':True},indent=2))
