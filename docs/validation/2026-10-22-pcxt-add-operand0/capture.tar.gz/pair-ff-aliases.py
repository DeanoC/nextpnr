#!/usr/bin/env python3
"""Correspondence inventory from actual RTL aliases, excluding generated names."""
from pathlib import Path
from collections import defaultdict
import json
R=Path(__file__).resolve().parent
ms=[json.loads((R/m/'synthesis/synth.json').read_text())['modules']['top'] for m in ('baseline','candidate')]
ds=[{b:(n,p) for n,c in m['cells'].items() for p,bs in c['connections'].items() if c['port_directions'][p]=='output' for b in bs if isinstance(b,int)} for m in ms]
def ffsource(ix,b,allow_not):
 if b not in ds[ix]:return None
 n,p=ds[ix][b];c=ms[ix]['cells'][n]
 if c['type']=='MISTRAL_FF':assert p=='Q';return n,0
 if allow_not and c['type']=='MISTRAL_NOT':
  x=ffsource(ix,c['connections']['A'][0],True);return (x[0],x[1]^1) if x else None
 return None
for polarity in (False,True):
 pairs=defaultdict(set);rev=defaultdict(set);witness={}
 for n in sorted(set(ms[0]['netnames'])&set(ms[1]['netnames'])):
  if '_MISTRAL_' in n or n.startswith('$'):continue
  a,b=[m['netnames'][n]['bits'] for m in ms]
  if len(a)!=len(b):continue
  for i,(x,y) in enumerate(zip(a,b)):
   xx,yy=ffsource(0,x,polarity),ffsource(1,y,polarity)
   if xx and yy:
    pairs[xx[0]].add((yy[0],xx[1]^yy[1]));rev[yy[0]].add((xx[0],xx[1]^yy[1]));witness[xx[0]]=(n,i,xx[1],yy[1])
 assert all(len(v)==1 for v in pairs.values()) and all(len(v)==1 for v in rev.values())
 if polarity:
  (R/'ff-polarity-alias-pairing.json').write_text(json.dumps({'pairs':{k:sorted(v) for k,v in pairs.items()},'witness':witness},indent=2)+'\n')
 else:
  fs=[{n:c for n,c in m['cells'].items() if c['type']=='MISTRAL_FF'} for m in ms]
  (R/'ff-rtl-alias-pairing.json').write_text(json.dumps({'baseline_to_candidate':{k:sorted(n for n,p in v) for k,v in pairs.items()},'candidate_to_baseline':{k:sorted(n for n,p in v) for k,v in rev.items()},'unmapped_baseline':sorted(set(fs[0])-set(pairs)),'unmapped_candidate':sorted(set(fs[1])-set(rev))},indent=2)+'\n')
 print('include explicit inversion',polarity,'unambiguous pairs',len(pairs),'opposite-polarity pairs',sum(next(iter(v))[1] for v in pairs.values()))
