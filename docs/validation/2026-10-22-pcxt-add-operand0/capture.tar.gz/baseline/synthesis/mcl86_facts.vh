`line 1 "mcl86_facts.vh" 0
// Generated from the verified MCL86 control ROM.
localparam [15:0] FES_MC_ADD_OP0_MASK = 16'h9eff;
localparam [15:0] FES_MC_ADD_OP1_MASK = 16'hbf10;
localparam FES_MC_JUMP7_USED = 1'b0;
