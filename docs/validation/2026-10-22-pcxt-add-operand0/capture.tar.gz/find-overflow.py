from pathlib import Path
from collections import defaultdict
import json
R=Path(__file__).resolve().parent;m=json.loads((R/'candidate/synthesis/synth.json').read_text())['modules']['top'];prefix='system.machine.cpu.cpu.u_eu_core.'
target=set(m['netnames'][prefix+'eu_register_dx']['bits'])|{m['netnames'][prefix+'eu_register_ax']['bits'][15]};assert len(target)==17
D={};U=defaultdict(list)
for n,c in m['cells'].items():
 for p,bs in c['connections'].items():
  for b in bs:
   if c['port_directions'][p]=='output':D[b]=(n,p)
   else:U[b].append((n,p))
cache={};active=set()
def support(b):
 if b in cache:return cache[b]
 if isinstance(b,str):return set()
 if b in target:return {b}
 if b not in D:return {b}
 n,p=D[b];c=m['cells'][n]
 if not c['type'] in ['MISTRAL_ALUT'+str(i) for i in range(2,7)]:return {b}
 assert b not in active;active.add(b);leaves=set()
 for p,bs in c['connections'].items():
  if c['port_directions'][p]=='input':
   for x in bs:leaves|=support(x)
 active.remove(b);cache[b]=leaves;return leaves
matches=[]
for n,c in m['cells'].items():
 if c['type'] not in ['MISTRAL_ALUT'+str(i) for i in range(2,7)]:continue
 b=c['connections']['Q'][0]
 if support(b)!=target:continue
 cells=set();front=set();order=[]
 def walk(b):
  if b in target:front.add(b);return
  if isinstance(b,str):return
  name,p=D[b];cell=m['cells'][name]
  if name in cells:return
  cells.add(name)
  for p,bs in cell['connections'].items():
   if cell['port_directions'][p]=='input':
    for x in bs:walk(x)
  order.append(name)
 walk(b);leaves=sorted(target);slots={x:i for i,x in enumerate(leaves)};prog=[]
 for name in order:
  cell=m['cells'][name];prog.append((int(cell['parameters']['LUT'],2),[slots.get(cell['connections'][p][0],cell['connections'][p][0]) for p in 'ABCDEF'[:int(cell['type'][-1])]]));slots[cell['connections']['Q'][0]]=len(slots)
 good=True;truecount=0
 for row in range(1<<17):
  values=[row>>i&1 for i in range(17)]
  for lut,pins in prog:values.append(lut>>sum((int(p) if isinstance(p,str) else values[p])<<i for i,p in enumerate(pins))&1)
  truecount+=values[-1]
  if values[-1]!=(row==0):good=False
 rec={'root':n,'cells':sorted(cells),'cell_count':len(cells),'exhaustive_rows':1<<17,'all_zero_function':good,'true_count':truecount,'private_outputs':all(len(U[m['cells'][k]['connections']['Q'][0]])==1 and U[m['cells'][k]['connections']['Q'][0]][0][0] in cells for k in cells if k!=n),'root_users':U[b]}
 matches.append(rec)
(R/'overflow-candidates.json').write_text(json.dumps({'target_bits':sorted(target),'candidates':matches},indent=2)+'\n')
for x in matches:print({k:v for k,v in x.items() if k not in ('cells','root_users')})
print('candidate count',len(matches))
