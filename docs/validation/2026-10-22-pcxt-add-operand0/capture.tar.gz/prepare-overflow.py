#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,time
R=Path(__file__).resolve().parent
ref=json.loads((R.parent/'hard-block-windows-20261022/prepare-windows-correct-overflow/receipt.json').read_text())
binary=Path(ref['command'][0]);root=json.loads((R/'overflow-candidates.json').read_text())['candidates'][0]['root']
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(binary)==ref['binary_sha256']
inputs={n:{'path':str(R/'candidate/synthesis'/n),'sha256':sha(R/'candidate/synthesis'/n)} for n in ('synth.json','constraints.qsf','clocks.sdc')}
for mode in ('control','balanced'):
 d=R/('overflow-native-'+mode);d.mkdir(exist_ok=False)
 cmd=[str(binary),'--device','5CSEBA6U23I7','--json',inputs['synth.json']['path'],'--qsf',inputs['constraints.qsf']['path'],'--sdc',inputs['clocks.sdc']['path'],'--freq','100.0','--seed','1','--no-pack','--no-place','--no-route','--write','export.json']
 if mode=='balanced':cmd+=['--balance-reduction-root',root]
 start=time.monotonic()
 with (d/'prepare.log').open('w') as f:p=subprocess.run(cmd,cwd=d,stdout=f,stderr=subprocess.STDOUT)
 rec={'command':cmd,'returncode':p.returncode,'elapsed_seconds':time.monotonic()-start,'binary_sha256':sha(binary),'binary_unchanged':sha(binary)==ref['binary_sha256'],'inputs':inputs,'selected_roots':[root] if mode=='balanced' else [],'evidence':'unpacked, unplaced, unrouted native diagnostic export; no timing or hardware acceptance'}
 if (d/'export.json').exists():rec['export_sha256']=sha(d/'export.json')
 (d/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(mode,rec['returncode'],flush=True)
 assert p.returncode==0
