#!/usr/bin/env python3
from pathlib import Path
from collections import defaultdict
import hashlib,json
R=Path(__file__).resolve().parent;sel=json.loads((R/'overflow-candidates.json').read_text());assert len(sel['candidates'])==1;s=sel['candidates'][0];assert s['all_zero_function'] and s['private_outputs'] and s['cell_count']==4
raw=json.loads((R/'candidate/synthesis/synth.json').read_text())['modules']['top'];native=json.loads((R/'overflow-native-control/export.json').read_text())['modules']['top'];P='system.machine.cpu.cpu.u_eu_core.'
dr={b:(n,p,i) for n,c in raw['cells'].items() for p,bs in c['connections'].items() if c['port_directions'][p]=='output' for i,b in enumerate(bs) if isinstance(b,int)}
leaves=[('eu_register_dx',i,b) for i,b in enumerate(raw['netnames'][P+'eu_register_dx']['bits'])]+[('eu_register_ax',15,raw['netnames'][P+'eu_register_ax']['bits'][15])];assert len(leaves)==17 and set(s['cells'])<=raw['cells'].keys();records=[]
for alias,i,b in leaves:
 n,p,j=dr[b];x,y=raw['cells'][n],native['cells'][n];assert x['type']==y['type']=='MISTRAL_FF' and p=='Q' and j==0
 records.append({'rtl_alias':[P+alias,i],'original_driver':[n,p,j],'raw_bit':b,'native_bit':y['connections'][p][j],'raw_ff':x,'native_ff':y})
for n in s['cells']:
 x,y=raw['cells'][n],native['cells'][n];assert x['type']==y['type'] and x['parameters']==y['parameters'] and x['port_directions']==y['port_directions']
 for p,bs in x['connections'].items():
  assert len(bs)==1 and isinstance(bs[0],int);owner,port,i=dr[bs[0]];assert owner in s['cells'] or raw['cells'][owner]['type']=='MISTRAL_FF';assert y['connections'][p]==[native['cells'][owner]['connections'][port][i]]
result={'candidate_root':s['root'],'source_synth_sha256':hashlib.sha256((R/'candidate/synthesis/synth.json').read_bytes()).hexdigest(),'native_control_sha256':hashlib.sha256((R/'overflow-native-control/export.json').read_bytes()).hexdigest(),'literal_bindings':records,'four_cell_raw_to_native_types_masks_connections_exact':True,'all_actual_131072_rows_all_zero':True,'native_guard_accepted':True,'guard_receipt':'overflow-native-balanced/receipt.json','complete_native_rewrite_proof':'overflow-native-proof.json','baseline_root':json.loads((R/'overflow-audit.json').read_text())['root'],'cross_resynthesis_scope':'Exact same RTL DX[15:0]/AX[15] condition; generated root and observer names change. No assertion of identical cross-resynthesis outside graph, alias class or observer inventory. Every original candidate observer remains exact under its own guarded balancing rewrite.'}
(R/'overflow-selection-proof.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='literal_bindings'})
