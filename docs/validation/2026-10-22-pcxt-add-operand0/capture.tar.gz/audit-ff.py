#!/usr/bin/env python3
"""Inventory state correspondence without equating generated cell names."""
from pathlib import Path
from collections import defaultdict,Counter
from functools import lru_cache
import json
R=Path(__file__).resolve().parent
mods=[json.loads((R/m/'synthesis/synth.json').read_text())['modules']['top'] for m in ('baseline','candidate')]
ff=[{n:c for n,c in m['cells'].items() if c['type']=='MISTRAL_FF'} for m in mods]
drv=[];alias=[];users=[]
for m in mods:
 d={};a=defaultdict(list);u=defaultdict(list)
 for n,c in m['cells'].items():
  for p,bs in c['connections'].items():
   for i,b in enumerate(bs):
    if not isinstance(b,int):continue
    if c['port_directions'][p]=='output':assert b not in d;d[b]=(n,p,i)
    else:u[b].append((n,p,i))
 for n,v in m['netnames'].items():
  if '_MISTRAL_' in n or n.startswith('$'):continue
  for i,b in enumerate(v['bits']):
   if isinstance(b,int):a[b].append((n,i))
 drv.append(d);alias.append(a);users.append(u)
polarity=json.loads((R/'ff-polarity-alias-pairing.json').read_text());assert all(len(v)==1 and v[0][1]==0 for v in polarity['pairs'].values());pairing={'baseline_to_candidate':{n:[v[0][0]] for n,v in polarity['pairs'].items()}}
pairs={a:bs[0] for a,bs in pairing['baseline_to_candidate'].items()};assert all(len(bs)==1 for bs in pairing['baseline_to_candidate'].values()) and len(set(pairs.values()))==len(pairs)
# Independent ROBDD evaluates actual LUT masks with A as LSB; shared variables
# bind exact RTL FF aliases. Unknown state variables never match across models.
nodes=[None,None];unique={}
def mk(v,l,h):
 if l==h:return l
 k=(v,l,h)
 if k not in unique:unique[k]=len(nodes);nodes.append(k)
 assert len(nodes)<1000000,'BDD diagnostic bound'
 return unique[k]
@lru_cache(None)
def ite(f,t,e):
 if f==1:return t
 if f==0:return e
 if t==e:return t
 vs=[nodes[x][0] for x in (f,t,e) if x>1];v=min(vs)
 def co(x,h):return nodes[x][2 if h else 1] if x>1 and nodes[x][0]==v else x
 return mk(v,ite(co(f,0),co(t,0),co(e,0)),ite(co(f,1),co(t,1),co(e,1)))
def lut(mask,args):
 if not args:return mask&1
 # Split on low input bit; lower and upper cofactor truth tables.
 width=1<<(len(args)-1);lo=sum(((mask>>(2*i))&1)<<i for i in range(width));hi=sum(((mask>>(2*i+1))&1)<<i for i in range(width))
 return ite(args[0],lut(hi,args[1:]),lut(lo,args[1:]))
records=[];common_alias={}
for n in set(mods[0]['netnames'])&set(mods[1]['netnames']):
 if '_MISTRAL_' in n or n.startswith('$'):continue
 a,b=[m['netnames'][n]['bits'] for m in mods]
 if len(a)==len(b):
  for i,(x,y) in enumerate(zip(a,b)):
   if isinstance(x,int) and isinstance(y,int):common_alias.setdefault((0,x),[]).append((n,i));common_alias.setdefault((1,y),[]).append((n,i))
for iteration in range(32):
 qvars={}
 for a,b in pairs.items():
  for ix,n in enumerate((a,b)):qvars[ix,ff[ix][n]['connections']['Q'][0]]='FF:'+a
 @lru_cache(None)
 def value(ix,b):
  if isinstance(b,str):
   if b in '01':return int(b)
   return mk('CONST:'+b,0,1)
  if (ix,b) in qvars:return mk(qvars[ix,b],0,1)
  if b not in drv[ix]:
   names=common_alias.get((ix,b));return mk('INPUT:'+repr(min(names)) if names else f'UNDRIVEN:{ix}:{b}',0,1)
  n,p,j=drv[ix][b];c=mods[ix]['cells'][n];typ=c['type']
  if typ in ['MISTRAL_ALUT'+str(w) for w in range(2,7)]:
   width=int(typ[-1]);return lut(int(c['parameters']['LUT'],2),tuple(value(ix,c['connections'][p][0]) for p in 'ABCDEF'[:width]))
  if typ=='MISTRAL_ALUT_ARITH':
   q0=lut(int(c['parameters']['LUT0'],2),tuple(value(ix,c['connections'][p][0]) for p in ('A','B','C','D0')));q1=lut(int(c['parameters']['LUT1'],2),tuple(value(ix,c['connections'][p][0]) for p in ('A','B','C','D1')));ci=value(ix,c['connections']['CI'][0]);negq1=ite(q1,0,1)
   assert p in ('SO','CO')
   return lut(0x96 if p=='SO' else 0xe8,(q0,negq1,ci))
  if typ=='MISTRAL_NOT':return ite(value(ix,c['connections']['A'][0]),0,1)
  if typ=='MISTRAL_FF':return mk(f'UNKNOWN_FF:{ix}:{n}',0,1)
  # Opaque common hard outputs are identity anchors, not a hard-block proof.
  names=common_alias.get((ix,b));token='HARD_ALIAS:'+repr(min(names)) if names else f'HARD:{ix}:{n}:{p}:{j}'
  return mk(token,0,1)
 @lru_cache(None)
 def support(ix,b):
  if isinstance(b,str):return frozenset()
  if (ix,b) in qvars:return frozenset([qvars[ix,b]])
  if b not in drv[ix]:return frozenset([('input',ix,b)])
  n,p,j=drv[ix][b];c=mods[ix]['cells'][n]
  if c['type'] in ['MISTRAL_ALUT'+str(w) for w in range(2,7)]+['MISTRAL_NOT','MISTRAL_ALUT_ARITH']:
   return frozenset().union(*(support(ix,x) for p,bs in c['connections'].items() if c['port_directions'][p]=='input' for x in bs))
  return frozenset([(ix,n,p,j)])
 groups=[];skipped=[[],[]]
 for ix in range(2):
  taken=set(pairs if ix==0 else pairs.values());g=defaultdict(list)
  for n,c in ff[ix].items():
   if n in taken:continue
   if 'u_eu_core' not in n and any(len(support(ix,b))>16 for p,bs in c['connections'].items() if p!='Q' for b in bs):skipped[ix].append(n);continue
   sig=(tuple(sorted(c['parameters'].items())),tuple((p,tuple(value(ix,b) for b in bs)) for p,bs in sorted(c['connections'].items()) if p!='Q'))
   g[sig].append(n)
  groups.append(g)
 added=0
 for sig in groups[0].keys()&groups[1].keys():
  aa,bb=[sorted(g[sig]) for g in groups]
  if len(aa)!=len(bb):continue
  for a,b in zip(aa,bb):pairs[a]=b;added+=1;records.append({'baseline':a,'candidate':b,'round':iteration,'group_size':len(aa),'input_function_bdd_ids':dict(sig[1]),'parameters':dict(sig[0])})
 print('round',iteration,'added',added,'total',len(pairs),'nodes',len(nodes),'skipped',list(map(len,skipped)),flush=True)
 if not added:break
unmatched={mode:sorted(set(fs)-set(pairs if ix==0 else pairs.values())) for ix,(mode,fs) in enumerate(zip(('baseline','candidate'),ff))}
# Preserve exact raw cells, controls, aliases and every observer for unmatched state.
unrecords={}
for ix,mode in enumerate(('baseline','candidate')):
 unrecords[mode]={}
 for n in unmatched[mode]:
  c=ff[ix][n];q=c['connections']['Q'][0]
  unrecords[mode][n]={'raw_cell':c,'ports':{p:[{'raw':b,'driver':drv[ix].get(b),'rtl_aliases':alias[ix].get(b,[])} if isinstance(b,int) else b for b in bs] for p,bs in c['connections'].items()},'output_users':users[ix][q],'top_port_observers':[(p,i) for p,v in mods[ix]['ports'].items() for i,b in enumerate(v['bits']) if b==q]}
result={'counts':[len(fs) for fs in ff],'rtl_q_alias_pairs':len(pairing['baseline_to_candidate']),'functionally_matched_extra_pairs':len(records),'complete_pairing':pairs,'function_pair_records':records,'unmatched':unrecords,'limits':'Exact stable RTL aliases establish correspondence anchors, not proved full-design sequential equivalence. Additional pair matching proves all actual FF input functions at those anchors and unchanged opaque common hard-output aliases; no assumption that generated FF names denote same state. Full hard-block or unrelated matched-state next-state equivalence is not claimed.'}
(R/'ff-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('unmatched', {k:len(v) for k,v in unmatched.items()})
