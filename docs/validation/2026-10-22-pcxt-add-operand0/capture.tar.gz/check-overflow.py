#!/usr/bin/env python3
"""Audit the exact legacy overflow conjunction in all complete raw netlists."""
from pathlib import Path
from collections import defaultdict
import json,hashlib
R=Path(__file__).resolve().parent;receipt=json.loads((R.parent/'hard-block-windows-20261022/prepare-windows-correct-overflow/receipt.json').read_text());cmd=receipt['command'];root=cmd[cmd.index('--balance-reduction-root')+1]
paths={'original':R.parent/'reduction-balanced-20261022/inputs/synth.json','baseline':R/'baseline/synthesis/synth.json','candidate':R/'candidate/synthesis/synth.json'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
result={'root':root,'runs':{},'comparisons':{}}
for mode,path in paths.items():
 m=json.loads(path.read_text())['modules']['top'];driver={};users=defaultdict(list);aliases=defaultdict(list);portbits=set(b for p in m['ports'].values() for b in p['bits'])
 for name,c in m['cells'].items():
  for p,bs in c['connections'].items():
   for i,b in enumerate(bs):
    if isinstance(b,str):continue
    if c['port_directions'][p]=='output':assert b not in driver;driver[b]=(name,p,i)
    else:users[b].append((name,p,i))
 for name,n in m['netnames'].items():
  for i,b in enumerate(n['bits']):
   if isinstance(b,int):aliases[b].append((name,i))
 seen={};frontier={};order=[];active=set()
 def visit(b):
  assert isinstance(b,int) and b in driver
  name,p,i=driver[b];c=m['cells'][name]
  if c['type']=='MISTRAL_FF':assert p=='Q' and i==0;frontier[b]=driver[b];return
  assert c['type'] in ['MISTRAL_ALUT'+str(x) for x in range(2,7)] and p=='Q' and i==0
  assert name not in seen and name not in active;active.add(name);width=int(c['type'][-1]);seen[name]=c
  assert set(c['connections'])==set('ABCDEF'[:width])|{'Q'}
  assert all(len(bs)==1 for bs in c['connections'].values()) and set(c['parameters'])=={'LUT'}
  assert not any(k in c['attributes'] for k in ('keep','dont_touch','NEXTPNR_BEL','FES_PINMAP_V1','BEL'))
  if name!=root:assert b not in portbits and len(users[b])==1
  for p in 'ABCDEF'[:width]:visit(c['connections'][p][0])
  active.remove(name);order.append(name)
 if root not in m['cells']:
  result['runs'][mode]={'synth_sha256':sha(path),'root_present':False};continue
 visit(m['cells'][root]['connections']['Q'][0]);assert len(seen)==4 and len(frontier)==17
 leaves=sorted(frontier,key=lambda b:frontier[b]);slots={b:i for i,b in enumerate(leaves)};program=[]
 for name in order:
  c=seen[name];width=int(c['type'][-1]);program.append((int(c['parameters']['LUT'],2),[slots[c['connections'][p][0]] for p in 'ABCDEF'[:width]]));slots[c['connections']['Q'][0]]=len(slots)
 for assignment in range(1<<17):
  values=[assignment>>i&1 for i in range(17)]
  for table,pins in program:values.append(table>>sum(values[b]<<i for i,b in enumerate(pins))&1)
  assert values[-1]==(assignment==0)
 def namedbit(b):return list(driver[b]) if isinstance(b,int) else b
 canonical={n:{**{k:v for k,v in c.items() if k not in ('connections','attributes')},'attributes':{k:v for k,v in c['attributes'].items() if k!='src'},'connections':{p:[namedbit(b) for b in bs] for p,bs in c['connections'].items()}} for n,c in seen.items()}
 signal_bits=set(frontier)|{c['connections']['Q'][0] for c in seen.values()};nets=[]
 for b in sorted(signal_bits,key=lambda b:driver[b]):
  records={n:{k:v for k,v in m['netnames'][n].items() if k!='bits'} for n,i in aliases[b]}
  assert all(not any(k in v['attributes'] for k in ('keep','dont_touch','clock','NEXTPNR_BEL')) for v in records.values())
  nets.append({'identity':namedbit(b),'aliases':sorted(aliases[b]),'alias_records':records,'users':sorted(users[b]),'top_port':b in portbits})
 result['runs'][mode]={'synth_sha256':sha(path),'root_present':True,'four_cells':canonical,'source_attributes':{n:c['attributes'].get('src') for n,c in seen.items()},'literal_identities':[list(frontier[b]) for b in leaves],'exhaustive_rows':1<<17,'function':'all seventeen actual FF-Q literals zero','three_internal_outputs_private_single_consumer':True,'signals':nets}
base=result['runs']['original']
for mode in ('baseline','candidate'):
 x=result['runs'][mode]
 if not x['root_present']:result['comparisons'][mode]={'root_present':False};continue
 a={tuple(s['identity']):s for s in base['signals']};b={tuple(s['identity']):s for s in x['signals']};assert set(a)==set(b)
 changed=[]
 def non_src(records):
  return {k:{**v,'attributes':{a:b for a,b in v['attributes'].items() if a!='src'}} for k,v in records.items()}
 for signal in sorted(a):
  u,v=a[signal],b[signal]
  if u!=v:changed.append({'identity':signal,'aliases_equal':u['aliases']==v['aliases'],'alias_records_equal':u['alias_records']==v['alias_records'],'alias_records_except_src_equal':non_src(u['alias_records'])==non_src(v['alias_records']),'users_equal':u['users']==v['users'],'top_port_equal':u['top_port']==v['top_port'],'before':u,'after':v})
 result['comparisons'][mode]={'root_present':True,'complete_cone_functions_connections_non_src_attributes_equal':base['four_cells']==x['four_cells'],'literal_identities_equal':base['literal_identities']==x['literal_identities'],'source_attributes_equal':base['source_attributes']==x['source_attributes'],'complete_signal_records_equal':not changed,'all_alias_classes_equal':all(a[k]['aliases']==b[k]['aliases'] for k in a),'all_alias_records_except_src_equal':all(non_src(a[k]['alias_records'])==non_src(b[k]['alias_records']) for k in a),'all_users_equal':all(a[k]['users']==b[k]['users'] for k in a),'changed_signal_records':changed}
(R/'overflow-audit.json').write_text(json.dumps(result,indent=2)+'\n')
for mode,c in result['comparisons'].items():print(mode,{k:v for k,v in c.items() if k!='changed_signal_records'},'changed signal records',len(c.get('changed_signal_records',[])))
