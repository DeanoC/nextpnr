#!/usr/bin/env python3
"""Inventory both complete frozen synthesis artifacts; no equivalence inference."""
from pathlib import Path
from collections import Counter
import hashlib,json
R=Path(__file__).resolve().parent

def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def delta(a,b):return {'removed':sorted(set(a)-set(b)),'added':sorted(set(b)-set(a)),'changed':sorted(k for k in set(a)&set(b) if a[k]!=b[k]),'unchanged_count':sum(a[k]==b[k] for k in set(a)&set(b))}
inputs={};graphs={};documents={};receipts={};result={'runs':{}}
for mode in ('baseline','candidate'):
 folder=R/mode;receipts[mode]=receipt=read(folder/'receipt.json');assert receipt['returncode']==0
 for n,h in receipt['artifacts'].items():assert sha(folder/'synthesis'/n)==h,(mode,n)
 inputs[mode]=read(folder/'inputs.json');documents[mode]=read(folder/'synthesis/synth.json');graphs[mode]=m=documents[mode]['modules']['top'];counts=Counter(c['type'] for c in m['cells'].values())
 mapped={n:c for n,c in m['cells'].items() if '.u_add_operand0_mux.' in n};drivers={b:n for n,c in mapped.items() for p,bs in c['connections'].items() if c['port_directions'][p]=='output' for b in bs}
 def depth(b):
  if b not in drivers:return 0
  c=mapped[drivers[b]];return 1+max(depth(b) for p,bs in c['connections'].items() if c['port_directions'][p]=='input' for b in bs)
 output=m['netnames'].get('system.machine.cpu.cpu.u_eu_core.eu_add_operand0',{})
 result['runs'][mode]={'commit':receipt['commit'],'synth_sha256':receipt['artifacts']['synth.json'],'cells':len(m['cells']),'nets':len(m['netnames']),'cell_types':dict(sorted(counts.items())),'add_operand0_mapped_cells':len(mapped),'add_operand0_mapped_types':dict(Counter(c['type'] for c in mapped.values())),'add_operand0_depth_from_macro_inputs':[depth(b) for b in output.get('bits',[])],'elapsed_seconds':receipt['elapsed_seconds']}
a,b=inputs['baseline'],inputs['candidate'];assert a['yosys']==b['yosys'];assert a['assembler_linker']==b['assembler_linker']
source=delta(a['source_sha256'],b['source_sha256']);generated=delta(a['generated_sha256'],b['generated_sha256']);result['inputs']={'sources':source,'generated':generated,'all_yosys_and_assembler_linker_identities_equal':True}
for n in ('constraints.qsf','clocks.sdc','mcl86_ucode.mem','mcl86_facts.vh','mcl86_ucode_byte0.mem','mcl86_ucode_byte1.mem','mcl86_ucode_byte2.mem','mcl86_ucode_byte3.mem','diagnostic.bin','pcxt_diagnostic.hex'):
 assert a['generated_sha256'][n]==b['generated_sha256'][n],n
m,n=graphs['baseline'],graphs['candidate'];da,db=documents['baseline'],documents['candidate']
result['complete_raw_graph_differences']={'root_fields':delta({k:v for k,v in da.items() if k!='modules'},{k:v for k,v in db.items() if k!='modules'}),'module_inventory':{'removed':sorted(set(da['modules'])-set(db['modules'])),'added':sorted(set(db['modules'])-set(da['modules']))},'modules':{}}
for name in sorted(set(da['modules'])|set(db['modules'])):
 a_module,b_module=da['modules'].get(name),db['modules'].get(name)
 if a_module is None or b_module is None:
  result['complete_raw_graph_differences']['modules'][name]={'present_in_baseline':a_module is not None,'present_in_candidate':b_module is not None};continue
 fields={'removed':sorted(set(a_module)-set(b_module)),'added':sorted(set(b_module)-set(a_module)),'fields':{}}
 for field in sorted(set(a_module)&set(b_module)):
  x,y=a_module[field],b_module[field]
  fields['fields'][field]=delta(x,y) if isinstance(x,dict) and isinstance(y,dict) else {'equal':x==y,'before':x,'after':y}
 result['complete_raw_graph_differences']['modules'][name]=fields
ports=lambda mod:{k:{'direction':v['direction'],'width':len(v['bits'])} for k,v in mod['ports'].items()}
assert ports(m)==ports(n);result['top_port_names_directions_widths_equal']=True
clock=lambda mod:{k:{'type':c['type'],'parameters':c['parameters']} for k,c in mod['cells'].items() if any(x in c['type'].lower() for x in ('pll','clkbuf','clkctrl'))}
assert clock(m)==clock(n);result['clock_primitive_types_parameters_equal']=clock(m)
assert result['runs']['candidate']['add_operand0_mapped_cells']==80
assert result['runs']['candidate']['add_operand0_mapped_types']=={'MISTRAL_ALUT6':64,'MISTRAL_ALUT4':16}
assert result['runs']['candidate']['add_operand0_depth_from_macro_inputs']==[2]*16
result['limits']='All graph records retained, differences inventoried without normalization. Input/clock/port equality and macro depth are structural diagnostics, not whole-design formal equivalence, full route, timing, RBF or hardware acceptance.'
(R/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'runs':result['runs'],'input_differences':result['inputs'],'limits':result['limits']},indent=2))
