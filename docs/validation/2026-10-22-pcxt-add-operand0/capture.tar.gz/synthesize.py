#!/usr/bin/env python3
"""Freeze a committed component and run its real board Yosys program, without routing.

This explicitly selected Yosys diagnostic does not call the producer authenticator
or claim a registered GPU producer, seal, timing acceptance or hardware evidence.
"""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,tarfile,time

ROOT=Path(__file__).resolve().parent
FES=ROOT.parent.parent
YOSYS=Path('/home/deano/fes/out/cache/misteross-toolchains/slots/8e7eeca0616bb73be28b6f12b17c33a19dd11c12dc9fdb56d964e086621867a2/install/bin/yosys')
EXPECTED_YOSYS='71eb21e86017064c141bca25e0ecd7fd39dcb3671f3d560fbc467eb880b2a650'
BASELINE='2a1cedf48efe68ccc92c0f7c7bfed52f0dc35dbd'

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=FES,text=True).strip()

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('mode',choices=('baseline','candidate'));parser.add_argument('--commit',required=True);args=parser.parse_args()
 commit=git('rev-parse','--verify',args.commit+'^{commit}')
 if args.mode=='baseline':assert commit==BASELINE
 assert sha(YOSYS)==EXPECTED_YOSYS,'locked diagnostic Yosys binary changed'
 run=ROOT/args.mode;run.mkdir(exist_ok=False)
 source=run/'source';source.mkdir();archive=run/'source.tar.gz'
 command=['git','archive','--format=tar.gz','--output',str(archive),commit,'sources/misteross']
 subprocess.run(command,cwd=FES,check=True)
 with tarfile.open(archive) as t:t.extractall(source,filter='data')
 component=source/'sources/misteross'
 all_sources={str(p.relative_to(source)):sha(p) for p in sorted(component.rglob('*')) if p.is_file()}
 dump(run/'snapshot.json',{'commit':commit,'tree':git('rev-parse',commit+'^{tree}'),'archive_sha256':sha(archive),'archive_command':command,'files_sha256':all_sources})
 # Execute the snapshot's real helper definitions, never the mutable worktree.
 sys.path[0:0]=[str(component/'scripts'),str(component)]
 import build_fes_pcxt as board
 assert board.ROOT==component
 for vendor in ('kf8259','kf8253','kf8255'):board.verify_vendor(vendor)
 output=run/'synthesis';output.mkdir();board.board_inputs(output)
 maps=tuple(board.CPU_MUX_MAPS) if hasattr(board,'CPU_MUX_MAPS') else (board.CPU_MUX_MAP,)
 selected=sorted(set(board.RTL)|set(maps)|{board.QSF,board.SDC,board.ROM_CLOCK_MAP,board.TOOLCHAIN_LOCK,'scripts/build_fes_pcxt.py','scripts/sim_fes_pcxt.py','cores/fes-pcxt/firmware/diagnostic.S'}|{str(p.relative_to(component)) for p in (component/'cores/fes-common/generated').glob('*.vh')}|{str(p.relative_to(component)) for p in (component/'cores/fes-pcxt/vendor').rglob('*') if p.suffix in ('.svh','.mem','.json')})
 source_hashes={s:sha(component/s) for s in selected}
 program=board.yosys_program(output,False,False,board.synthesis_command())
 (output/'synth.ys').write_text(program+'\n')
 shutil.copyfile(component/board.QSF,output/'constraints.qsf');shutil.copyfile(component/board.SDC,output/'clocks.sdc')
 generated={p.name:sha(p) for p in sorted(output.iterdir()) if p.is_file()}
 sharedir=YOSYS.parent.parent/'share/yosys'
 tool={'path':str(YOSYS),'sha256':sha(YOSYS),'version':subprocess.check_output([str(YOSYS),'-V'],text=True).strip(),'share_files_sha256':{str(p.relative_to(sharedir)):sha(p) for p in sorted(sharedir.rglob('*')) if p.is_file()}}
 ancillary={name:{'path':shutil.which(name),'sha256':sha(Path(shutil.which(name)))} for name in ('as','ld')}
 dump(run/'inputs.json',{'commit':commit,'source_sha256':source_hashes,'generated_sha256':generated,'yosys':tool,'assembler_linker':ancillary,'configuration':{'mda':False,'scanlines':False,'cpu_and_system_mhz':100,'microcode_phase_ps':2500},'authentication':'explicit frozen Yosys diagnostic; producer authentication not invoked; no authenticated producer or GPU/route claim'})
 command=[str(YOSYS),'-Q','-s','synth.ys'];start=time.monotonic()
 with (output/'yosys.log').open('w') as log:result=subprocess.run(command,cwd=output,stdout=log,stderr=subprocess.STDOUT)
 elapsed=time.monotonic()-start
 assert source_hashes=={s:sha(component/s) for s in selected},'frozen source changed during synthesis'
 assert tool['sha256']==sha(YOSYS),'Yosys binary changed during synthesis'
 assert tool['share_files_sha256']=={str(p.relative_to(sharedir)):sha(p) for p in sorted(sharedir.rglob('*')) if p.is_file()},'Yosys library changed during synthesis'
 receipt={'commit':commit,'command':command,'cwd':str(output),'returncode':result.returncode,'elapsed_seconds':elapsed,'yosys_sha256':tool['sha256'],'source_snapshot_sha256':sha(archive),'inputs_manifest_sha256':sha(run/'inputs.json'),'artifacts':{p.name:sha(p) for p in sorted(output.iterdir()) if p.is_file()},'evidence':'host diagnostic synthesis only; no route, timing, seal or hardware acceptance'}
 dump(run/'receipt.json',receipt)
 if result.returncode:raise SystemExit(result.returncode)
 print(json.dumps({'mode':args.mode,'commit':commit,'elapsed_seconds':elapsed,'synth_sha256':receipt['artifacts']['synth.json']},indent=2))
if __name__=='__main__':main()
