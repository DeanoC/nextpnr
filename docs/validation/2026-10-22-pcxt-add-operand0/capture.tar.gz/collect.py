#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;D=R/'capture-source';D.mkdir(exist_ok=False)
files=['README.md','synthesize.py','compare.py','comparison.json','comparison.log','committed-source-review.json','source-change.patch','prove-mapped.py','mapped-proof.json','mapped-proof.log','prove-mapped-packed.py','mapped-packed-proof.json','mapped-packed-proof.log','prove-selectors.py','selector-proof.json','selector-proof.log','pair-ff-aliases.py','ff-pairing.log','ff-rtl-alias-pairing.json','ff-polarity-alias-pairing.json','audit-ff.py','ff-audit.json','ff-audit.log','prove-cpu-generated-ff.py','cpu-generated-ff-proof.json','cpu-generated-ff-proof.log','check-overflow.py','overflow-audit.json','overflow-audit.log','find-overflow.py','overflow-candidates.json','overflow-candidates.log','prepare-overflow.py','prepare-overflow.log','prove-overflow-native.py','overflow-native-proof.json','overflow-native-proof.log','prove-overflow-selection.py','overflow-selection-proof.json','overflow-selection-proof.log','route.py','route.log','analyze-routes.py','route-analysis.json','route-analysis.log','prepare-routes.py','prepare-routes.log','prove-routed.py','routed-proof.json','routed-proof.log','proof-routed-support.py','collect.py']
copies={}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def cp(source,relative):
 dest=D/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest);assert sha(source)==sha(dest);copies[str(relative)]={'source':str(source),'sha256':sha(dest),'size':dest.stat().st_size}
for n in files:cp(R/n,Path(n))
for mode in ('baseline','candidate'):
 for n in ('source.tar.gz','snapshot.json','inputs.json','receipt.json'):cp(R/mode/n,Path(mode)/n)
 for source in sorted((R/mode/'synthesis').rglob('*')):
  if source.is_file():cp(source,source.relative_to(R))
for name in ('route-baseline','route-candidate','prepare-route-baseline','prepare-route-candidate','overflow-native-control','overflow-native-balanced'):
 for source in sorted((R/name).rglob('*')):
  if source.is_file():cp(source,source.relative_to(R))
for n in ('implementation-checks.json','add-map-tests.log','producer-hook-tests.log','cpu-selection-tests.log','logic-map-tests.log','toolchain-tests.log','cpu-simulation.log'):
 cp(R.parent/'cpu-cone-audit-20261022'/n,Path('validation')/n)
HB=R.parent/'hard-block-windows-20261022'
for n in ('source-identity.json','hard-block-build-frozen.log','hard-block-ctest.log','hard-block-native-frozen.log','hard-block-source.diff'):
 cp(HB/n,Path('compiler')/n)
for source in sorted((HB/'sources').rglob('*')):
 if source.is_file():cp(source,Path('compiler')/source.relative_to(HB))
cp(HB/'prepare-windows-correct-overflow/receipt.json',Path('references/legacy-overflow-receipt.json'))
cp(R.parent/'reduction-balanced-20261022/inputs/synth.json',Path('references/original-synth.json'))
model=Path('/home/deano/fes/out/cache/misteross-toolchains/slots/8e7eeca0616bb73be28b6f12b17c33a19dd11c12dc9fdb56d964e086621867a2/install/share/yosys/intel_alm/common/alm_sim.v');cp(model,Path('models/alm_sim.v'));cp(Path('/tmp/pcxt-capture.py'),Path('capture.py'))
(D/'collection.json').write_text(json.dumps({'copies':copies,'files':len(copies),'scope':'Only completed bare ADD synthesis/routes/proofs and native overflow preparation. No later balanced route artifacts, executable tool binaries or duplicated expanded source trees.'},indent=2)+'\n');print('collected',len(copies),'files')
