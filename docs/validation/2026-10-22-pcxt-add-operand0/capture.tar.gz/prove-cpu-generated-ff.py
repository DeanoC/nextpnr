#!/usr/bin/env python3
import runpy,json
from pathlib import Path
R=Path(__file__).resolve().parent
g=runpy.run_path(str(R/'audit-ff.py'))
names=[[n for n in g['unmatched'][m] if 'u_eu_core' in n and 'eu_add_select0' not in n] for m in ('baseline','candidate')];assert list(map(len,names))==[1,1];names=[v[0] for v in names]
for ix,n in enumerate(names):g['qvars'][ix,g['ff'][ix][n]['connections']['Q'][0]]='CPU_GENERATED_STATE_CORRESPONDENCE'
g['value'].cache_clear();records={}
for p in sorted(g['ff'][0][names[0]]['connections']):
 if p=='Q':continue
 v=[[g['value'](ix,b) for b in g['ff'][ix][n]['connections'][p]] for ix,n in enumerate(names)];records[p]={'baseline':v[0],'candidate':v[1],'equal':v[0]==v[1]}
assert all(v['equal'] for v in records.values()), 'generated CPU state input functions differ'
for key in ('type','parameters'):
 assert g['ff'][0][names[0]][key]==g['ff'][1][names[1]][key]
result={'baseline':names[0],'candidate':names[1],'all_input_functions_equal_under_state_correspondence':all(v['equal'] for v in records.values()),'inputs':records,'other_anchors':'ff-audit.json complete_pairing; all arithmetic LUT0/LUT1 and carry functions expanded using frozen Yosys alm_sim.v','limits':'Inductive input-function comparison under the stated state correspondence. Other RTL alias anchors are assumed corresponding and are not a whole-board sequential proof.'}
(R/'cpu-generated-ff-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
