#!/usr/bin/env python3
from pathlib import Path
import importlib.util,json,copy
R=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('bridge',R/'proof-routed-support.py');lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
records={};tests=[]
def norm(cmd):
 c=cmd[:]
 for flag in ('--rbf','--routed-endpoints','--compress-rbf','--no-route'):
  if flag in c:i=c.index(flag);del c[i:i+(1 if flag in ('--compress-rbf','--no-route') else 2)]
 for flag in ('--write','--report'):c[c.index(flag)+1]='<output>'
 return c
for mode in ('baseline','candidate'):
 pre=R/('prepare-route-'+mode);route=R/('route-'+mode);pr=lib.read(pre/'receipt.json');rr=lib.read(route/'receipt.json');assert pr['returncode']==0 and pr['binary_unchanged'];assert pr['binary_sha256']==rr['compiler']['binary_sha256'];assert norm(pr['command'])==norm(rr['nextpnr_command'])
 for path,receipt in [(pre,pr),(route,rr)]:
  for name,digest in receipt['artifacts'].items():assert lib.digest(path/name)==digest
 pd,rd=lib.read(pre/'placed.json'),lib.read(route/'routed.json');rec=lib.prepared_bridge(pd,rd);rec.update(prepared_sha256=lib.digest(pre/'placed.json'),routed_sha256=lib.digest(route/'routed.json'),exact_fresh_recipe_match_except_no_route=True);records[mode]=rec
 helper=rec['route_generated_buffers_proved'][0]['cell']
 def reject(label,mut):
  changed=copy.deepcopy(rd);mut(changed['modules']['top'])
  try:lib.prepared_bridge(pd,changed)
  except (ValueError,AssertionError,KeyError) as e:tests.append({'mode':mode,'mutation':label,'rejected':True,'reason':str(e)})
  else:raise AssertionError('accepted mutation '+label)
 def invert(m):
  p=lib.unpack(m['cells'][helper]['attributes']['FES_PINMAP_V1']);p['pins']['A'][0]=3;m['cells'][helper]['attributes']['FES_PINMAP_V1']=lib.pack(p)
 reject('route helper inversion',invert)
 reject('helper output extra alias',lambda m:m['netnames'].update({'mutation_alias':copy.deepcopy(m['netnames'][helper+'$conn$Q'])}))
 cell=next(n for n,c in pd['modules']['top']['cells'].items() if c['type']=='MISTRAL_ALUT6')
 def truth(m):
  old=m['cells'][cell]['parameters']['LUT'];m['cells'][cell]['parameters']['LUT']=('0' if old[0]=='1' else '1')+old[1:]
 reject('original LUT truth changed',truth)
result={'status':'pass','routed_bridges':records,'negative_mutations':tests,'checker_sha256':lib.digest(Path(__file__)),'support_sha256':lib.digest(R/'proof-routed-support.py'),'evidence':'Each complete reconstructed placed graph is independently compared with its own final routed artifact; every route-only helper receives an exact pin/function/private-alias/FF-consumer/physical-half ledger. No unmatched helpers or graph intersections are presumed equivalent.','limits':['Does not prove original RTL-to-raw-to-pack whole-board sequential equivalence; source helper and actual emitted macro proofs are separate.','No electrical route, RBF bit encoding, serialized LAB correctness, timing acceptance or hardware proof.']}
(R/'routed-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'pass','prepared_cells':{m:r['prepared_cell_count'] for m,r in records.items()},'helper_counts':{m:len(r['route_generated_buffers_proved']) for m,r in records.items()},'physical_pinmap_change_counts':{m:r['physical_pinmap_change_count'] for m,r in records.items()},'negative_mutations_rejected':len(tests)},indent=2))
