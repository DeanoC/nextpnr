#!/usr/bin/env python3
from pathlib import Path
from collections import defaultdict
import json,hashlib
R=Path(__file__).resolve().parent;paths=[R/'candidate/synthesis/synth.json',R/'prepare-route-candidate/placed.json'];a,b=[json.loads(p.read_text())['modules']['top'] for p in paths];names={n for n in a['cells'] if '.u_add_operand0_mux.' in n};assert len(names)==80
aliases=defaultdict(list)
for n,v in a['netnames'].items():
 for i,bit in enumerate(v['bits']):
  if isinstance(bit,int):aliases[bit].append((n,i))
drivers={bit:(n,p,i) for n,c in a['cells'].items() for p,bs in c['connections'].items() if c['port_directions'][p]=='output' for i,bit in enumerate(bs) if isinstance(bit,int)}
used={bit for n in names for bs in a['cells'][n]['connections'].values() for bit in bs};mapping={};witness={}
for bit in used:
 assert isinstance(bit,int) and bit in drivers
 owner,port,i=drivers[bit];x,y=a['cells'][owner],b['cells'][owner]
 assert owner in names or x['type']=='MISTRAL_FF'
 assert x['type']==y['type'] and x['parameters']==y['parameters']
 pins=json.loads(bytes.fromhex(y['attributes']['FES_PINMAP_V1']))['pins'];assert pins[port][0]==0
 mapping[bit]=y['connections'][port][i]
 records=[];retired=[]
 for name,j in aliases[bit]:
  v=a['netnames'][name];label=name if len(v['bits'])==1 and not v.get('offset',0) else name+'['+str(j+v.get('offset',0))+']'
  if label in b['netnames']:
   assert b['netnames'][label]['bits']==[mapping[bit]];records.append(label)
  else:retired.append(label)
 witness[bit]={'exact_original_driver':[owner,port,i],'raw_aliases':aliases[bit],'exported_aliases_consistent':records,'source_aliases_consolidated_by_import':retired}
assert len(set(mapping.values()))==len(mapping)
for n in names:
 x,y=a['cells'][n],b['cells'][n]
 assert x['type']==y['type'] and x['parameters']==y['parameters'] and x['port_directions']==y['port_directions'];assert {p:[mapping[v] for v in bs] for p,bs in x['connections'].items()}==y['connections']
 pins=json.loads(bytes.fromhex(y['attributes']['FES_PINMAP_V1']))['pins'];assert set(pins)==set(y['connections']) and all(v[0]==0 for v in pins.values())
result={'raw_sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),'prepared_sha256':hashlib.sha256(paths[1].read_bytes()).hexdigest(),'all_80_raw_mapped_cells_preserved':True,'types_masks_directions_connections_identical':True,'all_mapped_logical_pin_states_noninverting':True,'exact_raw_driver_identity_and_alias_ledger':witness,'distinct_macro_signal_count':len(mapping),'raw_exhaustive_macro_proof_sha256':hashlib.sha256((R/'mapped-proof.json').read_bytes()).hexdigest(),'limits':'Compositional bridge only for the 80 selected ADD0 LUT cells and exact original FF-Q/macro-Q identities. Source aliases consolidated by native import are explicitly listed, not claimed retained. Whole-board packing, physical LUT bit encoding and electrical/timing acceptance remain separate.'}
(R/'mapped-packed-proof.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='exact_raw_driver_identity_and_alias_ledger'})
