#!/usr/bin/env python3
"""Check every actual synthesized ADD-op0 lane against its recorded source/control nets.

This is an all-state combinational cone proof, not whole-board equivalence or
physical timing/signoff. The unmodified complete source graph is retained.
"""
from pathlib import Path
from collections import defaultdict
import hashlib,json
R=Path(__file__).resolve().parent
p=R/'candidate/synthesis/synth.json';m=json.loads(p.read_text())['modules']['top'];prefix='system.machine.cpu.cpu.u_eu_core.';cells={n:c for n,c in m['cells'].items() if n.startswith(prefix+'u_add_operand0_mux.')};assert len(cells)==80
sel=m['netnames'][prefix+'eu_add_select0']['bits'];data=m['netnames'][prefix+'eu_sources0']['bits'];outs=m['netnames'][prefix+'eu_add_operand0']['bits'];assert len(sel)==16 and len(data)==256 and len(outs)==16
assert "FES_MC_ADD_OP0_MASK = 16'h9eff" in (R/'candidate/synthesis/mcl86_facts.vh').read_text()
drivers={};users=defaultdict(list)
for n,c in m['cells'].items():
 for port,bs in c['connections'].items():
  for b in bs:
   if c['port_directions'][port]=='input':users[b].append([n,port])
   else:
    if isinstance(b,int):assert b not in drivers;drivers[b]=(n,port)
def truth(mask,vs,full):
 if not vs:return full if mask&1 else 0
 half=1<<(len(vs)-1);x=vs[-1]
 return ((~x)&truth(mask&((1<<half)-1),vs[:-1],full))|(x&truth(mask>>half,vs[:-1],full))
result={'synth_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_mask':'9eff','lanes':[],'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};visited=set()
for lane,out in enumerate(outs):
 terms=[(data[i*16+lane],sel[i],i) for i in range(16) if 0x9eff>>i&1 and data[i*16+lane]!='0'];assert len(terms)==12
 leaves=sorted({b for a,s,_ in terms for b in (a,s) if isinstance(b,int)});assert len(leaves)==24;rows=1<<len(leaves);full=(1<<rows)-1;nb=rows//8;columns={}
 for i,b in enumerate(leaves):
  if i<3:values=bytes(([0xaa,0xcc,0xf0][i],))*nb
  else:
   size=1<<(i-3);values=(bytes(size)+bytes([255])*size)*(nb//(2*size))
  columns[b]=int.from_bytes(values,'little')
 cache={};active=set();lane_cells=set()
 def ev(b):
  if b=='0':return 0
  if b=='1':return full
  if b in columns:return columns[b]
  if b in cache:return cache[b]
  assert b not in active;active.add(b);n,port=drivers[b];assert n in cells and port=='Q';c=cells[n];width=int(c['type'].removeprefix('MISTRAL_ALUT'));assert 2<=width<=6
  assert set(c['connections'])==set('ABCDEF'[:width])|{'Q'};assert all(len(bs)==1 for bs in c['connections'].values())
  v=truth(int(c['parameters']['LUT'],2),[ev(c['connections'][pin][0]) for pin in 'ABCDEF'[:width]],full);cache[b]=v;active.remove(b);lane_cells.add(n);return v
 expected=0
 for a,s,_ in terms:expected|=columns[a]&columns[s]
 actual=ev(out);assert actual==expected and actual!=(expected^full);assert len(lane_cells)==5
 assert visited.isdisjoint(lane_cells);visited.update(lane_cells)
 internal=[]
 for n in lane_cells:
  bit=cells[n]['connections']['Q'][0]
  if bit==out:continue
  assert len(users[bit])==1 and users[bit][0][0] in lane_cells
  internal.append({'cell':n,'output_bit':bit,'sole_user':users[bit][0]})
 result['lanes'].append({'lane':lane,'exhaustive_assignments':rows,'source_indices':[i for a,s,i in terms],'raw_source_bits':[[a,s] for a,s,i in terms],'output_bit':out,'output_users':users[out],'cells':sorted(lane_cells),'internal_output_users':internal,'truth_equal':True,'truth_sha256':hashlib.sha256(actual.to_bytes(nb,'little')).hexdigest()})
 print('lane',lane,'passed',rows,'assignments',flush=True)
assert visited==set(cells)
result['cells_accounted']=len(visited);result['limits']='Complete actual mapped helper function and private group-output checks for all selector/data states. No proof of unrelated remapped logic, sequential behavior, electrical/LAB/RBF encoding, setup/hold or physical acceptance.'
(R/'mapped-proof.json').write_text(json.dumps(result,indent=2)+'\n')
