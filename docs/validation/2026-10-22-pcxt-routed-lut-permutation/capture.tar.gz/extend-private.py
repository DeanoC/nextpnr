#!/usr/bin/env python3
"""Extend the not-yet-frozen pair payload with completed independent private4 rejection."""
from pathlib import Path
import hashlib,json,shutil
C=Path(__file__).resolve().parent;R=C.parent.parent;P=C/'payload'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def copy(p,n=None):
 d=P/(n or p.relative_to(R));d.parent.mkdir(parents=True,exist_ok=True)
 if d.exists():assert sha(d)==sha(p)
 else:shutil.copy2(p,d)
receipt=read(R/'route-private4/receipt.json')
for n,h in receipt['artifacts'].items():assert sha(R/'route-private4'/n)==h;copy(R/'route-private4'/n)
copy(R/'route-private4/receipt.json')
for sub in ['final-analysis-private4','native-topology/paired-readback-private4']:
 for p in sorted((R/sub).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:copy(p)
copy(R/'native-topology/readback-private4.py')
for n in ['continued-runs.jsonl','summary.json']:copy(R/'accounting-38'/n)
mode=read(P/'archive-mode.json')
for path,h in receipt['immutable_evidence_sha256'].items():assert mode['recorded_files'][path]['sha256']==h
for n in ['prepare.py','replay.py','replay-private.py','verify_capture.py','build_archive.py','extend-private.py','README.md']:
 target=P/('CAPTURE-README.md' if n=='README.md' else n)
 shutil.copy2(C/n,target)
print(json.dumps({'private_graph_sha256':sha(R/'final-analysis-private4/graph-proof.json'),'private_topology_sha256':sha(R/'final-analysis-private4/topology-proof.json'),'private_receipt_sha256':sha(R/'route-private4/receipt.json'),'scope':'Completed private4 only; sharedCPU16 retained once.'},sort_keys=True))
