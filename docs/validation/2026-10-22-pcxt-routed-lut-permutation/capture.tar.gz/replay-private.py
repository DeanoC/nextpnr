#!/usr/bin/env python3
"""Offline exact private4 no-op rejection proof; own process prevents shared module collision."""
from pathlib import Path
import contextlib,hashlib,importlib,io,json,sys,tempfile
from decimal import Decimal
R=Path(__file__).resolve().parent;A=R/'final-analysis-private4';sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support
assert support.archive_mode() is not None and support.ROOT==R

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
def read(p):return json.loads(Path(p).read_text())
accounting=read(R/'accounting-38/summary.json');journal=R/'accounting-38/continued-runs.jsonl';records=[json.loads(v) for v in journal.read_text().splitlines()]
assert sha(journal)==accounting['journal_sha256'] and len(records)==accounting['completed_subsequent_receipts']==38
assert len({v['case'] for v in records})==38
assert Decimal(accounting['pre_journal_charge_seconds'])+sum(Decimal(v['charged_seconds_decimal']) for v in records)==Decimal(accounting['cumulative_charge_seconds'])
for case in ['cpu16','permutation4','private4']:
 rows=[v for v in records if v['case']=='out/unobserved-arith-coverage-20261022/route-'+case];assert len(rows)==1 and rows[0]['receipt_sha256']==sha(R/f'route-{case}/receipt.json')
checks=[]
def compare_write(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs';checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
with contextlib.redirect_stdout(io.StringIO()):
 for name in ['prove_graph','test_checks','verify_topology']:
  m=importlib.import_module(name);m.write=compare_write;m.main()
 c=importlib.import_module('compare_timing')
 with tempfile.TemporaryDirectory(prefix='pcxt-private-noop-') as scratch:
  c.R=Path(scratch);c.main();assert (c.R/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
 checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
g=read(A/'graph-proof.json');t=read(A/'route-comparison.json');n=read(A/'topology-proof.json')
assert g['status']=='pass' and not g['changed_canonical_net_bits'] and not n['native_readback_needed']
assert len(t['every_endpoint_row'])==17199 and t['native_margin_delta_counts']=={'setup':{'unchanged':17194},'hold':{'unchanged':17194}}
assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal']
for name in ['diagnostic.rbf','timing.json','endpoints.json']:assert (R/'route-cpu16'/name).read_bytes()==(R/'route-private4'/name).read_bytes()
assert (R/'route-cpu16/routed.json').read_bytes()!=(R/'route-private4/routed.json').read_bytes()
print(encoded({'passed':True,'exact_replays':checks,'complete_endpoint_rows':17199,'native_margin_delta_counts':t['native_margin_delta_counts'],'RBF_timing_endpoints_bytes_exact':True,'routed_json_bytes_exact':False,'canonical_route_trees_exact':True,'pair_charge_seconds_recorded_not_additive_to_other_pair':t['pair_charge_seconds'],'charged_route_seconds':0,'historical_accounting_context':{'journal_records':38,'cumulative_charge_seconds':accounting['cumulative_charge_seconds'],'scope':'Arithmetic and these three receipt hashes checked; other historical route payloads are not included or reread.'},'scope':'Recorded rejected private4 trial; graph/aliases/settings and canonical routes unchanged. Six serialization-order-only route attributes remain explicit. No new native execution or route.'}).decode(),end='')
