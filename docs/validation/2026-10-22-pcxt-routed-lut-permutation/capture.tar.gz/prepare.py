#!/usr/bin/env python3
"""Capture only the completed7faa pair and immutable host/native evidence."""
from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
C=Path(__file__).resolve().parent;A=C.parent;R=A.parent;P=C/'payload';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def copy(p,n=None):
 dest=P/(n or p.relative_to(R));dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==sha(p),str(dest)
 else:shutil.copy2(p,dest)
 return str(dest.relative_to(P))
assert not P.exists(),'fresh payload required';P.mkdir()
final=read(R/'final-validation.json');assert sha(R/'final-validation.json')=='b9c15eaddbf4fd3c9c21e8ecf7b80d82b5a816e6140968cdcbefc3c84bfbdc32'
for n,h in final['files'].items():assert sha(R/n)==h;copy(R/n)
for n in ['final-validation.json','committed-source-verification.json','route.py'] :copy(R/n)
commit=read(R/'committed-source-verification.json');assert commit['commit']=='186637013e17461a72cd1d2cd17ca5ef174ed06f'
assert commit['source_files']==final['source_files']
for n,h in final['source_files'].items():
 data=subprocess.check_output(['git','show',commit['commit']+':'+n],cwd=S)
 assert hashlib.sha256(data).hexdigest()==h==sha(P/'complete-source'/n)
for case in ['cpu16','permutation4']:
 receipt=read(R/f'route-{case}/receipt.json');assert receipt['binary_sha256']==final['binary_sha256']
 for n,h in receipt['artifacts'].items():assert sha(R/f'route-{case}'/n)==h;copy(R/f'route-{case}'/n)
 copy(R/f'route-{case}/receipt.json')
for p in sorted(A.rglob('*')):
 if p.is_file() and not {'capture','__pycache__'}&set(p.relative_to(A).parts):copy(p)
# Native payload excludes compiled snapshot objects, executables, and inactive private4 output.
native=R/'native-topology';omitted=[]
for n in ['build-commands.json','build-receipt.json','build.log','build.py','freeze.py','committed-source-verification.json','frozen-manifest.json','tree-reader.cc','readback.py','test-reader.py','test-reader-final.py']:copy(native/n)
for sub in ['initial-build-failed-shadow','reader32-validated','reader-validation','reader-validation-final','paired-readback']:
 for p in sorted((native/sub).rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  if p.stat().st_size>3000000:
   omitted.append({'original_path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'reason':'Historical mutated-checkpoint native negative fixture; native test is recorded, not rerun offline.'})
  else:copy(p)
for p in [R/'nextpnr-mistral',native/'tree-reader']:
 omitted.append({'original_path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'reason':'Executable omitted; offline replay uses recorded outcomes and native decoded trees only.'})
write(P/'omitted-payloads.json',{'files':omitted,'complete_native_snapshot_manifest':'native-topology/frozen-manifest.json','complete_native_snapshot_payload':'All401 source/header/object snapshot members omitted; original hashes retained. No rebuild or new native execution is claimed.'})
# Exact archived dependencies: host admission and prior full CPU reference/input bytes.
deps={};bindings=[]
paths={'host':R/'final-host-capture/capture.tar.gz','cpu':R.parent/'lut6-source-coverage-20261022/final-analysis/capture/capture.tar.gz'}
for name,path in paths.items():
 with tarfile.open(path) as t:
  data=t.extractfile('manifest.json').read();m=json.loads(data);members=t.getmembers();assert len(members)==len(m)+1
  deps[name]={'archive_sha256':sha(path),'bytes':path.stat().st_size,'members':len(members),'manifest_sha256':hashlib.sha256(data).hexdigest(),'manifest_path':f'dependencies/{name}-manifest.json'}
  d=P/deps[name]['manifest_path'];d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
  if name=='host':
   for n in list(final['files'])+['final-validation.json','committed-source-verification.json']:
    member='evidence/unobserved-arith-coverage-20261022/'+n
    assert m[member]['sha256']==sha(P/n)
    bindings.append({'dependency':name,'member':member,'retained_path':n,'sha256':sha(P/n)})
  else:
   for member in sorted(m):
    if member.startswith('route-swap16/') or member.startswith('external-inputs/'):
     target=('references/prior-cpu/'+member.split('/',1)[1]) if member.startswith('route-swap16/') else member
     d=P/target;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(t.extractfile(member).read());assert sha(d)==m[member]['sha256']
     bindings.append({'dependency':name,'member':member,'retained_path':target,'sha256':sha(d)})
recorded={};receipt=read(R/'route-cpu16/receipt.json')
for path,h in receipt['immutable_evidence_sha256'].items():
 original=Path(path)
 target=str(original.relative_to(R)) if original.is_relative_to(R) else 'references/prior-cpu/receipt.json'
 assert sha(P/target)==h;recorded[path]={'retained_path':target,'sha256':h}
for v in receipt['inputs'].values():
 target='external-inputs/'+v['sha256']+'-'+Path(v['path']).name
 assert sha(P/target)==v['sha256'];recorded[v['path']]={'retained_path':target,'sha256':v['sha256']}
prior=str(R.parent/'lut6-source-coverage-20261022/route-swap16')
mode={'recorded_files':recorded,'excluded_binary':{'original_path':receipt['nextpnr_command'][0],'sha256':final['binary_sha256']},'references':{'route':{'original_directory':prior,'retained_path':'references/prior-cpu'}},'dependencies':deps,'selected_dependency_members':bindings,'scope':'No live-path fallback. Both complete dependency archives must be provided and verified; no dependency executables run.'}
write(P/'archive-mode.json',mode)
for n in ['prepare.py','replay.py','verify_capture.py','build_archive.py','README.md']:copy(C/n,'CAPTURE-README.md' if n=='README.md' else n)
print(json.dumps({'files':len([p for p in P.rglob('*') if p.is_file()]),'source_files':len(final['source_files']),'dependencies':deps},indent=2,sort_keys=True))
