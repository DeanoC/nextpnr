#!/usr/bin/env python3
"""Exact serialized graph and function proof for logged private ALUT3/ALUT5 rewrites.

Native electrical topology and stationary path retention require the separately
bound readback selected by native-selection-specs.json; this checker does not
infer PIP connectivity from names or claim timing from a reloaded checkpoint.
"""
from collections import Counter, defaultdict
from copy import deepcopy
import json
import re
from support import HERE, ROOT, need, read, unique, sha, digest, write, paired_receipts

PINS = 'ABCDE'
PIN_SIG, PIN_INV = 0, 3


def decisions(text):
    lines=[x for x in text.splitlines() if 'Critical private pair' in x]
    trial_re=re.compile(r'^Info: Critical private pair trial (\d+): producer=(.*?) definition=(\d+) bound=(\d+),(\d+),(\d+) prior-slack=(-?\d+)ps promoted-path-inputs=(\d+) native-source-rank=(-?\d+)ps accepted=([01]); (.*)\.$')
    discovery_re=re.compile(r'^Info: Critical private pair discovery: negative rows=(\d+) paths=(\d+) bounded producer witnesses=(\d+) eligible groups=(\d+); native path cap=16384, producer cap=64\.$')
    summary_re=re.compile(r'^Info: Critical private pair: tried=(\d+)/(\d+) kept=(\d+); unchanged unsupported coverage is not qualification\.$')
    delta_re=re.compile(r'^Info: Critical private pair (with-skew|reference) (?:setup|hold): clock=.+ before=-?\d+ps after=(?:missing|-?\d+ps)\.$|^Info: Critical private pair (?:with-skew|reference) Fmax: clock=.+ before=-?\d+\.\d{6}MHz after=-?\d+\.\d{6}MHz constraint=-?\d+\.\d{6}/-?\d+\.\d{6}MHz\.$')
    trials=[];filters=[];skips=[];discovery=[];summaries=[];deltas=[];pending=[]
    for line in lines:
        if (m:=trial_re.fullmatch(line)):
            n,producer,definition,a,b,c,slack,promoted,rank,accepted,reason=m.groups()
            trials.append({'number':int(n),'producer':producer,'definition':int(definition),'bound':list(map(int,(a,b,c))),
             'prior_path_slack_ps':int(slack),'promoted_path_inputs':int(promoted),'native_source_rank_ps':int(rank),
             'accepted':bool(int(accepted)),'reason':reason,'verbatim':line,'clock_delta_lines':pending});pending=[]
        elif (m:=re.fullmatch(r'Info: Critical private pair filter: producer=(.+): (.+)\.',line)):
            filters.append({'producer':m[1],'reason':m[2],'verbatim':line})
        elif (m:=re.fullmatch(r'Info: Critical private pair current eligibility: producer=(.+): (.+)\.',line)):
            skips.append({'producer':m[1],'reason':m[2],'verbatim':line})
        elif discovery_re.fullmatch(line):discovery.append(line)
        elif summary_re.fullmatch(line):summaries.append(line)
        elif delta_re.fullmatch(line):deltas.append(line);pending.append(line)
        else:need(False,'unparsed private-pair decision: '+line)
    need(not pending and len(discovery)==len(summaries)==1,'missing/duplicate complete discovery/summary or orphan clock delta')
    tried,budget,kept=map(int,summary_re.fullmatch(summaries[0]).groups())
    counts=dict(zip(('negative_rows','negative_paths','bounded_producer_witnesses','eligible_groups'),map(int,discovery_re.fullmatch(discovery[0]).groups())))
    need(budget==4 and tried==len(trials)<=4,'private-pair budget/count mismatch')
    need([t['number'] for t in trials]==list(range(1,tried+1)),'incomplete trial numbering')
    need(sum(t['accepted'] for t in trials)==kept,'accepted count differs')
    need(counts['bounded_producer_witnesses']<=64 and counts['eligible_groups']+len(filters)<=counts['bounded_producer_witnesses'],'discovery bound/group/filter mismatch')
    need(len({f['producer'] for f in filters})==len(filters),'duplicate filter')
    need(not ({f['producer'] for f in filters}&{t['producer'] for t in trials}),'filtered producer tried')
    need(len({t['producer'] for t in trials})<=counts['eligible_groups'],'trial producer count exceeds groups')
    seen=set()
    for t in trials:
        need(t['producer'] not in seen,'accepted producer retried')
        need(t['prior_path_slack_ps']<0 and counts['negative_rows']>0 and counts['negative_paths']>0,'trial lacks native negative path')
        need(0<=t['definition']<70 and len(set(t['bound']))==3 and t['bound']==sorted(t['bound']) and 0<=t['bound'][0]<t['bound'][-1]<7,'invalid logged decomposition identity')
        need(t['promoted_path_inputs']<=3,'invalid promoted input count')
        if t['accepted']:seen.add(t['producer'])
    return {'all_verbatim_lines':lines,'all_trials':trials,'all_filters':filters,'all_current_eligibility_skips':skips,
     'all_clock_delta_lines':deltas,'discovery':discovery[0],'discovery_counts':counts,'summary':summaries[0],
     'tried':tried,'budget':budget,'kept':kept,'all_trial_reason_counts':dict(sorted(Counter(t['reason'] for t in trials).items())),
     'limits':['Discovery is bounded to16384 paths and64 producers; ranking is not timing acceptance.']}


def pinmap(cell):
    raw = cell['attributes']['FES_PINMAP_V1']
    data = json.loads(bytes.fromhex(raw).decode(), object_pairs_hook=unique)
    need(set(data) == {'count', 'pins'} and data['count'] == len(data['pins']), 'invalid physical pin snapshot')
    return data['pins']


def graph_edges(module):
    users, drivers, aliases = defaultdict(list), defaultdict(list), defaultdict(list)
    for name, cell in sorted(module['cells'].items()):
        need(cell['connections'].keys() == cell['port_directions'].keys(), 'port direction inventory: ' + name)
        for pin, bits in sorted(cell['connections'].items()):
            direction = cell['port_directions'][pin]
            need(direction in ('input', 'output', 'inout'), 'unknown port direction')
            for index, bit in enumerate(bits):
                if type(bit) is int:
                    if direction in ('input', 'inout'):
                        users[bit].append([name, pin, index])
                    if direction in ('output', 'inout'):
                        drivers[bit].append([name, pin, index])
    public = set()
    for name, port in sorted(module['ports'].items()):
        public.update(bit for bit in port['bits'] if type(bit) is int)
    for name, net in sorted(module['netnames'].items()):
        need(len(net['bits']) == 1, 'expected serialized scalar net/alias: ' + name)
        bit = net['bits'][0]
        need(type(bit) is int, 'noninteger routed net identity')
        aliases[bit].append(name)
    return users, drivers, aliases, public


def route_tree(raw):
    if raw is None:
        return None
    need(isinstance(raw, str), 'nonstring route attribute')
    # Property's JSON string encoding represents the empty string as one space.
    if raw in ('', ' '):
        return {}
    parts = raw.split(';')
    need(len(parts) % 3 == 0, 'partial route triple')
    result, pips = {}, set()
    for i in range(0, len(parts), 3):
        wire, pip, strength = parts[i:i + 3]
        need(wire and wire not in result, 'duplicate/empty route wire')
        need(re.fullmatch(r'[0-6]', strength) is not None, 'invalid native route strength')
        need(not pip or pip not in pips, 'duplicate route pip')
        if pip:
            pips.add(pip)
        result[wire] = [pip, int(strength)]
    return result


def lut(cell, name):
    match = re.fullmatch(r'MISTRAL_ALUT([2-5])', cell['type'])
    need(match is not None, 'not an ordinary ALUT2..5: ' + name)
    width = int(match[1]); pins = PINS[:width]
    need(set(cell['parameters']) == {'LUT'}, 'unexpected LUT parameters')
    text = cell['parameters']['LUT']
    need(isinstance(text, str) and re.fullmatch('[01]{%d}' % (1 << width), text), 'undefined/malformed mask')
    need(set(cell['connections']) == set(pins + 'Q'), 'unexpected LUT port inventory')
    need(cell['port_directions'] == {**{p: 'input' for p in pins}, 'Q': 'output'}, 'unexpected LUT port directions')
    need(all(len(cell['connections'][p]) == 1 and type(cell['connections'][p][0]) is int for p in pins + 'Q'), 'non-scalar LUT net')
    bits = [cell['connections'][p][0] for p in pins]
    need(len(set(bits)) == width and cell['connections']['Q'][0] not in bits, 'aliased/constant/self-cyclic LUT inputs')
    maps = pinmap(cell)
    need(set(maps) == set(pins + 'Q'), 'physical port inventory differs')
    need(maps['Q'] == [PIN_SIG, 'COMBOUT'], 'output physical map changed')
    need(all(len(maps[p]) == 2 and type(maps[p][0]) is int and maps[p][0] in (PIN_SIG, PIN_INV)
             and maps[p][1] in ('A', 'B', 'C', 'D', 'E0', 'E1', 'F0', 'F1') for p in pins), 'invalid LUT input map/state')
    physical = [maps[p][1] for p in pins]
    need(len(set(physical)) == width, 'duplicate target physical input')
    need(set(physical) <= {'A', 'B', 'C', 'E0', 'F0'} or set(physical) <= {'A', 'B', 'D', 'E1', 'F1'}, 'mixed native LUT half pins')
    return width, pins, int(text, 2), bits, maps


def transposed_mask(mask, width, first, second):
    result = 0
    for row in range(1 << width):
        old = row
        if ((row >> first) ^ (row >> second)) & 1:
            old ^= (1 << first) | (1 << second)
        result |= ((mask >> old) & 1) << row
    return result


def physical_port(cells, user):
    name, port, index = user
    need(index == 0, 'selected net has nonscalar native port')
    cell = cells[name]
    maps = pinmap(cell)
    need(port in maps and len(maps[port]) >= 2, 'selected native port lacks physical map')
    return {'cell': name, 'port': port, 'index': index, 'BEL': cell['attributes']['NEXTPNR_BEL'],
            'state': maps[port][0], 'physical_pins': maps[port][1:]}


def evaluate(cells,producer,consumer,link,values):
    values=dict(values)
    def run(name):
        width,pins,mask,bits,maps=lut(cells[name],name)
        address=sum((values[bit]^(maps[p][0]==PIN_INV))<<i for i,(p,bit) in enumerate(zip(pins,bits)))
        return (mask>>address)&1
    values[link]=run(producer)
    return values[link],run(consumer)


def decompose(truth):
    """Independent finite two-cofactor classification, preserving policy order."""
    from itertools import combinations
    need(len(truth)==128 and all(v in (0,1) for v in truth),'invalid full truth table')
    need(all(any(truth[row]!=truth[row^(1<<i)] for row in range(128)) for i in range(7)),'nonessential external input')
    result=[]
    for bound in combinations(range(7),3):
        free=[i for i in range(7) if i not in bound];columns=[]
        for x in range(8):
            column=0
            for y in range(16):
                row=sum(((x>>i)&1)<<p for i,p in enumerate(bound))+sum(((y>>i)&1)<<p for i,p in enumerate(free))
                column|=truth[row]<<y
            columns.append(column)
        classes=sorted(set(columns))
        if len(classes)!=2:continue
        for complement in (0,1):
            producer=sum((int(value==classes[1])^complement)<<i for i,value in enumerate(columns))
            consumer=classes[complement]|(classes[1^complement]<<16)
            result.append({'bound':list(bound),'free':free,'producer_mask':producer,'consumer_mask':consumer})
    return result


def prove(left,right,accepted):
    need(set(left)==set(right)=={'creator','modules'},'root schema differs')
    need(left['modules'].keys()==right['modules'].keys() and len(left['modules'])==1,'module identity differs')
    a,b=next(iter(left['modules'].values())),next(iter(right['modules'].values()))
    need(a.keys()==b.keys(),'module schema differs')
    need({k:v for k,v in a.items() if k not in ('cells','netnames')}=={k:v for k,v in b.items() if k not in ('cells','netnames')},'complete settings/ports/LAB state differs')
    ac,bc=a['cells'],b['cells'];need(ac.keys()==bc.keys(),'complete cell inventory differs')
    need(a['netnames'].keys()==b['netnames'].keys(),'complete alias inventory differs')
    users,drivers,aliases,public=graph_edges(a);au,ad,aa,ap=graph_edges(b)
    need((drivers,aliases,public)==(ad,aa,ap),'complete drivers/aliases/public identities differ')
    pairs=[];targets=set();expected=deepcopy(users);transitions=defaultdict(dict)
    allowed=set();physical_changes=set();selected=set()
    for trial in accepted:
        need(trial['accepted'],'unaccepted selection')
        producer=trial['producer'];need(producer in ac and producer not in targets,'missing/duplicate producer')
        width,pins,mask,pbits,pmap=lut(ac[producer],producer);need(width==3,'producer is not ALUT3')
        link=ac[producer]['connections']['Q'][0]
        need(link not in public and len(users[link])==1,'private link has outside observer')
        consumer,link_pin,index=users[link][0];need(index==0 and consumer in ac and consumer!=producer and consumer not in targets,'invalid/overlapping consumer')
        need(lut(ac[consumer],consumer)[0]==5,'consumer is not ALUT5')
        output=ac[consumer]['connections']['Q'][0];need(output!=link,'pair output cycle')
        pair={producer,consumer};targets.update(pair)
        uses=Counter(ac[name]['connections'][p][0] for name in pair for p in PINS[:3 if name==producer else 5])
        after_uses=Counter(bc[name]['connections'][p][0] for name in pair for p in PINS[:3 if name==producer else 5])
        need(uses==after_uses and len(uses)==8 and set(uses.values())=={1} and uses[link]==1,'eight source-slot multiplicities differ')
        frontier=set(uses)-{link};need(len(frontier)==7 and output not in frontier,'invalid seven external input boundary')
        # Frozen jsonwrite.cc emits canonical ctx->nets names, not a guessed alias.
        # Require one exact serialized record for each selected signal before sorting.
        need(all(len(aliases[bit])==1 for bit in frontier),'ambiguous serialized canonical source identity')
        ordered=sorted(frontier,key=lambda bit:aliases[bit][0])
        for bit in frontier:
            need(bit not in public and len(drivers[bit])==1 and ac[drivers[bit][0][0]]['type'] in ('MISTRAL_FF','MISTRAL_M10K'),'external source is not exact private registered driver')
        truth=[evaluate(ac,producer,consumer,link,{bit:(row>>i)&1 for i,bit in enumerate(ordered)})[1] for row in range(128)]
        definitions=decompose(truth);need(0<=trial['definition']<len(definitions),'logged definition outside finite decomposition')
        definition=definitions[trial['definition']];need(definition['bound']==trial['bound'],'logged bound/definition mismatch')
        old_support=set(pbits);new_support={ordered[i] for i in definition['bound']};need(old_support!=new_support,'unchanged original partition was selected')
        need(bc[producer]['connections']=={**{p:[ordered[i]] for p,i in zip('ABC',definition['bound'])},'Q':[link]},'producer connections differ from logged exact partition')
        need(bc[consumer]['connections']=={**{p:[ordered[i]] for p,i in zip('ABCD',definition['free'])},'E':[link],'Q':[output]},'consumer connections differ from logged exact partition')
        need(int(bc[producer]['parameters']['LUT'],2)==definition['producer_mask'] and int(bc[consumer]['parameters']['LUT'],2)==definition['consumer_mask'],'actual masks differ from logged finite decomposition')
        changes=[]
        for name in pair:
            old,new=ac[name],bc[name];old_lut,new_lut=lut(old,name),lut(new,name)
            need(old_lut[:2]==new_lut[:2] and old.keys()==new.keys(),'target schema/type differs')
            need({k:v for k,v in old.items() if k not in ('parameters','connections','attributes')}=={k:v for k,v in new.items() if k not in ('parameters','connections','attributes')},'target nonrewrite fields differ')
            need({k:v for k,v in old['attributes'].items() if k!='FES_PINMAP_V1'}=={k:v for k,v in new['attributes'].items() if k!='FES_PINMAP_V1'},'target BEL/strength/other attributes differ')
            need(old['connections']['Q']==new['connections']['Q'],'target output net differs')
            need(all(new_lut[4][p][0]==PIN_SIG for p in new_lut[1]),'candidate inputs are not canonical noninverted encoding')
            changes.append({'cell':name,'before_mask':old['parameters']['LUT'],'after_mask':new['parameters']['LUT'],
             'before_connections':old['connections'],'after_connections':new['connections'],'before_pin_maps':old_lut[4],'after_pin_maps':new_lut[4]})
        need(au[link]==[[consumer,'E',0]],'rewritten private link observer differs')
        need(pmap['Q']==pinmap(bc[producer])['Q'] and pinmap(ac[consumer])['Q']==pinmap(bc[consumer])['Q'],'output physical maps differ')
        need(pinmap(ac[consumer])[link_pin][1:]==pinmap(bc[consumer])['E'][1:],'private link native physical sink changed')
        for bit in uses:
            old=[x for x in users[bit] if x[0] in pair];new=[x for x in au[bit] if x[0] in pair]
            need(len(old)==len(new)==1,'pair source use disappeared/duplicated')
            old,new=old[0],new[0];expected[bit].remove(old);expected[bit].append(new)
            need(tuple(old) not in transitions[bit],'overlapping original user slot')
            transitions[bit][tuple(old)]=new
            before_port,after_port=physical_port(ac,old),physical_port(bc,new)
            if (before_port['BEL'],before_port['physical_pins'])!=(after_port['BEL'],after_port['physical_pins']):
                need(bit in frontier,'private link physical sink changed');physical_changes.add(bit)
        allowed.update(frontier);selected.update(frontier|{link,output})
        table=[]
        for row in range(128):
            values={bit:(row>>i)&1 for i,bit in enumerate(ordered)};old=evaluate(ac,producer,consumer,link,values);new=evaluate(bc,producer,consumer,link,values)
            need(old[1]==new[1],'actual composed raw-net function differs')
            table.append({'raw_assignment':row,'before_internal':old[0],'after_internal':new[0],'before_output':old[1],'after_output':new[1]})
        pairs.append({'producer':producer,'consumer':consumer,'definition':trial['definition'],'bound':trial['bound'],
         'ordered_external_bits':ordered,'ordered_canonical_net_names':[aliases[bit][0] for bit in ordered],
         'link_bit':link,'output_bit':output,'target_changes':sorted(changes,key=lambda x:x['cell']),
         'finite_candidate_count':len(definitions),'all128_raw_net_rows':table})
    need({name for name in ac if ac[name]!=bc[name]}==targets,'complete target-change set differs from accepted pairs')
    for name in ac:
        if name not in targets:need(ac[name]==bc[name],'outside/stationary mate cell differs')
    need({k:sorted(v) for k,v in expected.items()}=={k:sorted(v) for k,v in au.items()},'complete user graph differs from exact pair source-use migration')
    trees=[{},{}];changes=[];changed=set()
    for alias in sorted(a['netnames']):
        old,new=a['netnames'][alias],b['netnames'][alias];need(old.keys()==new.keys() and old['bits']==new['bits'],'net schema/bit differs')
        bit=old['bits'][0];x,y=deepcopy(old),deepcopy(new);oraw,nraw=x['attributes'].pop('ROUTING',None),y['attributes'].pop('ROUTING',None)
        need(x==y,'nonroute net metadata differs');ot,nt=route_tree(oraw),route_tree(nraw)
        for store,tree in zip(trees,(ot,nt)):
            if bit in store:need(store[bit]==tree,'aliases disagree on canonical routing')
            else:store[bit]=tree
        if ot!=nt:need(bit in allowed and bit in physical_changes,'route changed outside changed external physical sinks');changed.add(bit)
        if oraw!=nraw:changes.append({'alias':alias,'bit':bit,'canonical_tree_changed':ot!=nt,'before_tree':ot,'after_tree':nt,'before_raw_sha256':digest(oraw),'after_raw_sha256':digest(nraw)})
    selections=[]
    for bit in sorted(selected):
        roots=[]
        for store in trees:
            tree=store[bit];need(tree and len(tree)<=4096 and all(v[1]<=2 for v in tree.values()),'selected route missing/oversize/protected')
            roots.append({w:v for w,v in tree.items() if not v[0]})
        need(len(roots[0])==1 and roots[0]==roots[1],'original source root/strength differs')
        need(bit not in public and len(drivers[bit])==1 and 1<=len(users[bit])<=64,'selected net observer/driver bound differs')
        moves=[]
        for u in users[bit]:
            v=transitions[bit].get(tuple(u),u);old,new=physical_port(ac,u),physical_port(bc,v)
            moves.append({'before':old,'after':new,'serialized_physical_sink_unchanged':(old['BEL'],old['physical_pins'])==(new['BEL'],new['physical_pins'])})
        need(sorted([[x['after']['cell'],x['after']['port'],x['after']['index']] for x in moves])==sorted(au[bit]),'native selection lacks complete users')
        selections.append({'bit':bit,'name':aliases[bit][0],'aliases':aliases[bit],'driver':physical_port(ac,drivers[bit][0]),'before_users':users[bit],'after_users':au[bit],
         'user_transitions':moves,'source_root':roots[0],'canonical_tree_changed':bit in changed,'before_tree_sha256':digest(trees[0][bit]),'after_tree_sha256':digest(trees[1][bit])})
    ownership=[]
    for store in trees:
        wires={};pips={}
        for bit,tree in store.items():
            for w,(p,strength) in (tree or {}).items():
                need(w not in wires,'physical wire has multiple complete net owners');wires[w]=bit
                if p:need(p not in pips,'physical PIP has multiple complete net owners');pips[p]=bit
        ownership.append({'wires':len(wires),'pips':len(pips),'single_net_ownership':True})
    return {'status':'pass','complete_cells':len(ac),'complete_net_alias_records':len(a['netnames']),'complete_net_alias_classes':len(aliases),
     'complete_public_ports':len(a['ports']),'settings_ports_module_attributes_LAB_state_equal':True,'outside_and_stationary_mate_cells_exact':True,
     'complete_driver_graph_equal':True,'complete_user_graph_exact_source_use_migrations':True,'complete_alias_classes_equal':True,
     'accepted_pairs':pairs,'allowed_external_input_net_bits':sorted(allowed),'input_bits_with_changed_physical_target_sinks':sorted(physical_changes),
     'changed_canonical_net_bits':sorted(changed),'every_raw_route_attribute_change':changes,'native_topology_selections':selections,
     'complete_physical_ownership':{'before':ownership[0],'after':ownership[1]},'creator_before':left['creator'],'creator_after':right['creator'],
     'limits':['Every serialized cell, port, alias, driver, user, module/LAB state and canonical route tuple is compared; no identity-set intersection is used.',
      'Selected frontier canonical names are used only when each has exactly one saved canonical net record, matching the frozen writer and native lexical policy order.',
      'Each exact logged decomposition is reconstructed independently and every128 raw assignment is checked with PIN_INV=3; private internal values may differ.',
      'Native indexed-slot holes, configuration muxes and physical masks are separate obligations. Source/root/sink/PIP readback must establish stationary path retention.',
      'No timing or hardware qualification is inferred; complete final timing proof remains separate.']}


def main():
    paired_receipts();cases=('cpu16','private4');logs={c:(ROOT/f'route-{c}/nextpnr.log').read_text() for c in cases}
    ledger=decisions(logs['private4']);ledger['preceding_repair_lines']={c:[x for x in text.splitlines() if 'Critical route ' in x or 'Critical LUT6 ' in x] for c,text in logs.items()}
    need(ledger['preceding_repair_lines']['cpu16']==ledger['preceding_repair_lines']['private4'],'preceding route/LUT6 repairs differ')
    need('Critical private pair' not in logs['cpu16'],'control unexpectedly ran private pass')
    result=prove(*[read(ROOT/f'route-{c}/routed.json') for c in cases],[t for t in ledger['all_trials'] if t['accepted']])
    result.update(checker_sha256=sha(__file__),support_sha256=sha(HERE/'support.py'),graph_sha256={c:sha(ROOT/f'route-{c}/routed.json') for c in cases})
    write('decision-ledger.json',ledger);write('graph-proof.json',result)
    write('native-selection-specs.json',{'schema':1,'graph_proof_sha256':sha(HERE/'graph-proof.json'),'graph_sha256':result['graph_sha256'],'selections':result['native_topology_selections'],
     'requirements':['Native decode all selected source/input/link/output trees and every complete user.','For every unchanged sink vector retain the complete original source path and each wire/PIP/strength tuple.','Do not reroute, allocate pins, configure bitstream or run STA during readback.']})
    print(json.dumps({k:result[k] for k in ('status','complete_cells','complete_net_alias_records','changed_canonical_net_bits')},sort_keys=True))


if __name__=='__main__':main()
