#!/usr/bin/env python3
"""Complete private-pair proof controls with seven real raw-net inputs."""
from copy import deepcopy
import json
from prove_graph import prove,decisions,decompose,evaluate,pinmap,physical_port
from support import HERE,need,read,write,sha,reference_folder


def encode(pins):return json.dumps({'count':len(pins),'pins':pins},sort_keys=True,separators=(',',':')).encode().hex()
def cell(kind,con,dirs,pins,bel,mask=None):
 return {'type':kind,'hide_name':0,'parameters':{} if mask is None else {'LUT':mask},'attributes':{'FES_PINMAP_V1':encode(pins),'NEXTPNR_BEL':bel,'NEXTPNR_BEL_STRENGTH':'1'},'connections':con,'port_directions':dirs}
def fixture():
 cells={};nets={}
 for name,width,bits,bel in [('producer',3,[10,11,12],'COMB.1.1.0'),('consumer',5,[13,14,15,16,30],'COMB.2.1.0')]:
  pins='ABCDE'[:width];pm={p:[3 if name=='producer' and p=='A' else 0,['A','B','C','E0','F0'][i]] for i,p in enumerate(pins)};pm['Q']=[0,'COMBOUT'];out=30 if name=='producer' else 40
  cells[name]=cell('MISTRAL_ALUT'+str(width),{**{p:[b] for p,b in zip(pins,bits)},'Q':[out]},{**{p:'input' for p in pins},'Q':'output'},pm,bel,format(1<<((1<<width)-1),'0%db'%(1<<width)))
 for i in range(7):
  bit=10+i;name='source'+str(i);cells[name]=cell('MISTRAL_FF',{'Q':[bit]},{'Q':'output'},{'Q':[0,'Q']},'FF.source.'+str(i))
  cells['watch'+str(i)]=cell('MISTRAL_FF',{'DATAIN':[bit]},{'DATAIN':'input'},{'DATAIN':[0,'DATAIN']},'FF.watch.'+str(i))
  target='producer' if i<3 else 'consumer';p='ABCDE'[i if i<3 else i-3];physical=pinmap(cells[target])[p][1]
  nets['ext'+str(i)]={'hide_name':0,'bits':[bit],'attributes':{'ROUTING':f'W{bit}.root;;1;W{bit}.watch;P{bit}.watch;2;{target}.{physical};P{bit}.{target}.{physical};1'}}
 cells['output_capture']=cell('MISTRAL_FF',{'DATAIN':[40]},{'DATAIN':'input'},{'DATAIN':[0,'DATAIN']},'FF.output')
 nets['private_link']={'hide_name':0,'bits':[30],'attributes':{'ROUTING':'link.root;;1;consumer.F0;P.link;1'}}
 nets['output']={'hide_name':0,'bits':[40],'attributes':{'ROUTING':'output.root;;1;output.sink;P.output;1'}}
 nets['unused_alias']={'hide_name':0,'bits':[99],'attributes':{'ROUTING':'outside.root;;1'}}
 cells['mate']=cell('MISTRAL_ALUT2',{'A':[70],'B':[71],'Q':[72]},{'A':'input','B':'input','Q':'output'},{'A':[0,'A'],'B':[0,'B'],'Q':[0,'COMBOUT']},'COMB.1.1.1','0110')
 for i in (70,71,72):nets['mate'+str(i)]={'hide_name':0,'bits':[i],'attributes':{'ROUTING':f'W{i}.root;;1'}}
 left={'creator':'fixture','modules':{'top':{'ports':{},'settings':{'strict':1},'attributes':{'FES_LABSTATE_V1':'fixed'},'cells':cells,'netnames':nets}}}
 truth=[evaluate(cells,'producer','consumer',30,{10+i:(row>>i)&1 for i in range(7)})[1] for row in range(128)];definitions=decompose(truth)
 index=next(i for i,c in enumerate(definitions) if c['bound']==[0,1,3]);definition=definitions[index]
 right=deepcopy(left);new=right['modules']['top']['cells']
 for name,inputs,mask in [('producer',definition['bound'],definition['producer_mask']),('consumer',definition['free']+[20],definition['consumer_mask'])]:
  target=new[name];pins='ABCDE'[:len(inputs)];pm=pinmap(target)
  for p,signal in zip(pins,inputs):target['connections'][p]=[30 if signal==20 else 10+signal];pm[p][0]=0
  target['parameters']['LUT']=format(mask,'0%db'%(1<<len(inputs)));target['attributes']['FES_PINMAP_V1']=encode(pm)
 for bit in range(10,17):
  before=next((n,p) for n in ('producer','consumer') for p,v in cells[n]['connections'].items() if p!='Q' and v==[bit]);after=next((n,p) for n in ('producer','consumer') for p,v in new[n]['connections'].items() if p!='Q' and v==[bit])
  oldwire=before[0]+'.'+pinmap(cells[before[0]])[before[1]][1];newwire=after[0]+'.'+pinmap(new[after[0]])[after[1]][1]
  if oldwire!=newwire:
   a=right['modules']['top']['netnames']['ext'+str(bit-10)]['attributes'];a['ROUTING']=a['ROUTING'].replace(oldwire+';P'+str(bit)+'.'+oldwire,newwire+';P'+str(bit)+'.'+newwire)
 return left,right,[{'accepted':True,'producer':'producer','definition':index,'bound':[0,1,3]}]


def main():
 l,r,a=fixture();result=prove(l,r,a);need(len(result['accepted_pairs'][0]['all128_raw_net_rows'])==128,'incomplete rows')
 need(result['changed_canonical_net_bits']==[12,13],'wrong external route footprint')
 need(len(result['native_topology_selections'])==9,'input/link/output selection incomplete')
 negatives=[]
 def reject(name,fn):
  l,r,a=fixture();fn(l,r,a)
  try:prove(l,r,a)
  except (ValueError,KeyError,TypeError) as e:negatives.append({'name':name,'rejection':str(e)});return
  raise AssertionError('corruption accepted: '+name)
 def cells(x):return x['modules']['top']['cells']
 def net(x,name):return x['modules']['top']['netnames'][name]
 reject('unlogged pair',lambda l,r,a:a.clear())
 reject('duplicate pair',lambda l,r,a:a.append(deepcopy(a[0])))
 reject('wrong logged definition',lambda l,r,a:a[0].update(definition=0))
 reject('wrong logged bound',lambda l,r,a:a[0].update(bound=[0,1,4]))
 reject('producer mask bit',lambda l,r,a:cells(r)['producer']['parameters'].update(LUT='11111111'))
 reject('consumer mask bit',lambda l,r,a:cells(r)['consumer']['parameters'].update(LUT='0'*32))
 reject('source slot duplicate',lambda l,r,a:cells(r)['producer']['connections'].update(A=[11]))
 reject('output changed',lambda l,r,a:cells(r)['consumer']['connections'].update(Q=[99]))
 reject('private link observer',lambda l,r,a:cells(r)['watch0']['connections'].update(DATAIN=[30]))
 reject('outside observer changed',lambda l,r,a:cells(r)['watch0']['connections'].update(DATAIN=[11]))
 reject('stationary mate mask',lambda l,r,a:cells(r)['mate']['parameters'].update(LUT='1111'))
 reject('private input public',lambda l,r,a:[x['modules']['top']['ports'].update(bad={'bits':[10],'direction':'input'}) for x in (l,r)])
 reject('ambiguous canonical alias',lambda l,r,a:[x['modules']['top']['netnames'].update(extra=deepcopy(net(x,'ext0'))) for x in (l,r)])
 reject('missing unused alias',lambda l,r,a:r['modules']['top']['netnames'].pop('unused_alias'))
 reject('changed target BEL',lambda l,r,a:cells(r)['producer']['attributes'].update(NEXTPNR_BEL='other'))
 reject('changed LAB state',lambda l,r,a:r['modules']['top']['attributes'].update(FES_LABSTATE_V1='changed'))
 reject('changed setting',lambda l,r,a:r['modules']['top']['settings'].update(strict=0))
 def state(r,name,p,value):
  c=cells(r)[name];pm=pinmap(c);pm[p][0]=value;c['attributes']['FES_PINMAP_V1']=encode(pm)
 reject('wrong PIN_INV',lambda l,r,a:state(r,'consumer','A',3))
 reject('PIN1 mistaken for inversion',lambda l,r,a:state(r,'producer','A',1))
 def phys(r,name,p,value):
  c=cells(r)[name];pm=pinmap(c);pm[p][1]=value;c['attributes']['FES_PINMAP_V1']=encode(pm)
 reject('private link physical sink',lambda l,r,a:phys(r,'consumer','E','A'))
 reject('stationary mate map',lambda l,r,a:phys(r,'mate','A','B'))
 def route(r,name,fn):
  x=net(r,name)['attributes'];x['ROUTING']=fn(x['ROUTING'])
 reject('output route changed',lambda l,r,a:route(r,'output',lambda s:s+';extra;P.extra;1'))
 reject('internal route changed',lambda l,r,a:route(r,'private_link',lambda s:s+';extra;P.extra;1'))
 reject('outside route changed',lambda l,r,a:route(r,'unused_alias',lambda s:s+';extra;P.extra;1'))
 reject('unchanged source sink route changed',lambda l,r,a:route(r,'ext0',lambda s:s+';extra;P.extra;1'))
 reject('original root strength changed',lambda l,r,a:route(r,'ext2',lambda s:s.replace('root;;1','root;;2')))
 reject('protected route',lambda l,r,a:route(r,'ext2',lambda s:s.replace('P12.watch;2','P12.watch;4')))
 reject('stolen wire',lambda l,r,a:route(r,'ext2',lambda s:s+';outside.root;P.stolen;1'))
 reject('stolen PIP',lambda l,r,a:route(r,'ext2',lambda s:s+';newwire;P.output;1'))
 reject('partial routing tuple',lambda l,r,a:route(r,'ext2',lambda s:s+';partial'))
 reject('net metadata changed',lambda l,r,a:net(r,'ext2')['attributes'].update(custom=1))
 lines='\n'.join(['Info: Critical private pair filter: producer=filtered: protected mate.',
  'Info: Critical private pair discovery: negative rows=10 paths=12 bounded producer witnesses=2 eligible groups=1; native path cap=16384, producer cap=64.',
  'Info: Critical private pair with-skew setup: clock=cpu before=-72ps after=-52ps.',
  'Info: Critical private pair trial 1: producer=producer definition=2 bound=0,1,3 prior-slack=-72ps promoted-path-inputs=1 native-source-rank=100ps accepted=1; .',
  'Info: Critical private pair: tried=1/4 kept=1; unchanged unsupported coverage is not qualification.'])
 need(decisions(lines)['kept']==1,'valid ledger failed');logs=[]
 for name,changed in [('wrong budget',lines.replace('1/4','1/5')),('wrong count',lines.replace('kept=1','kept=0')),('missing numbering',lines.replace('trial 1','trial 2')),
  ('nonnegative path',lines.replace('prior-slack=-72','prior-slack=72')),('invalid bound',lines.replace('bound=0,1,3','bound=0,0,3')),('invalid definition',lines.replace('definition=2','definition=70')),
  ('unknown decision',lines+'\nInfo: Critical private pair unexpected.')]:
  try:decisions(changed)
  except ValueError as e:logs.append({'name':name,'rejection':str(e)});continue
  raise AssertionError('log corruption accepted: '+name)
 reference=reference_folder()/'routed.json';full=read(reference);control=prove(full,full,[])
 need(control['complete_cells']>12000 and control['complete_net_alias_records']>15000,'full graph control incomplete')
 write('checker-tests.json',{'passed':True,'checker_sha256':sha(HERE/'prove_graph.py'),'test_sha256':sha(__file__),'raw_truth_rows':128,
  'complete_selected_nets':9,'changed_external_nets':[12,13],'graph_rejections':negatives,'log_rejections':logs,
  'full_noop_control':{'input_sha256':sha(reference),'cells':control['complete_cells'],'aliases':control['complete_net_alias_records']},
  'limits':['Checker controls only; no actual accepted pair/timing gain claim. Native topology readback remains separately required.']})
 print('PASS128 rows,',len(negatives),'graph rejections,',len(logs),'log rejections, complete',control['complete_cells'],'cell control')


if __name__=='__main__':main()
