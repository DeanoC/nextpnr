from pathlib import Path
import json,hashlib,subprocess,time,os
H=Path(__file__).resolve().parent; E=H.parent; P=json.loads((E/'board-eligibility/build-plan.json').read_text()); F=json.loads((H/'frozen-manifest.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify():
 for path,info in F['files'].items():assert sha(H/info['copy'])==info['sha256'],path
verify();assert sha(E/'board-eligibility/build-plan.json')==F['board_plan_sha256'];helper_source=sha(H/'tree-reader.cc');cc=[];it=iter(P['compile'])
for a in it:
 if a in ['-o','-c']:next(it);continue
 if a in ['-flto=auto','-fno-fat-lto-objects','-O3']:continue
 if a.startswith('-I'):
  frozen=H/'frozen'/str(Path(a[2:]).resolve()).lstrip('/')
  if frozen.exists():a='-I'+str(frozen)
 cc.append(a)
cc+=['-std=c++17','-O1','-c',str(H/'tree-reader.cc'),'-o',str(H/'tree-reader.o')]
link=[];it=iter(P['link'])
for a in it:
 if a=='-o':next(it);link+=['-o',str(H/'tree-reader')];continue
 if a.endswith('/board-eligibility/probe.o'):a=str(H/'tree-reader.o')
 elif a in F['files']:a=str(H/F['files'][a]['copy'])
 link.append(a)
commands={'compile':cc,'link':link};(H/'build-commands.json').write_text(json.dumps(commands,sort_keys=True,indent=2)+'\n');start=time.monotonic()
with (H/'build.log').open('w') as log:
 for cmd in [cc,link]:subprocess.run(cmd,cwd=H,env={**os.environ,'TMPDIR':str(H)},stdout=log,stderr=subprocess.STDOUT,check=True)
verify();assert sha(H/'tree-reader.cc')==helper_source;result={'pass':True,'source_base_commit':F['source_base_commit'],'source_identity_sha256':F['source_identity_sha256'],'production_binary_sha256':F['production_sha256'],'frozen_manifest_sha256':sha(H/'frozen-manifest.json'),'helper_source_sha256':sha(H/'tree-reader.cc'),'helper_binary_sha256':sha(H/'tree-reader'),'build_commands_sha256':sha(H/'build-commands.json'),'build_log_sha256':sha(H/'build.log'),'wall_seconds':time.monotonic()-start,'scope':'Standalone host reader only; no shared build mutation'};(H/'build-receipt.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result))
