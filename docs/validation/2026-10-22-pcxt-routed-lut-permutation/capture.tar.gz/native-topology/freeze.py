#!/usr/bin/env python3
"""Freeze matching 7faa headers and link inputs without writing the shared build."""
from pathlib import Path
import subprocess,json,hashlib,shutil
H=Path(__file__).resolve().parent;E=H.parent;S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');B=S.parent/'build-candidate'
P=json.loads((E/'board-eligibility/build-plan.json').read_text());I=json.loads((E/'source-validation/final-host/source-identity.json').read_text());manifest={}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(original,data,provenance):
 dest=H/'frozen'/str(original).lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 manifest[str(original)]={'copy':str(dest.relative_to(H)),'sha256':sha(dest),'bytes':len(data),'provenance':provenance}
 return str(dest)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
changed=set(subprocess.check_output(['git','diff','--name-only',head],cwd=S,text=True).splitlines())
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=S,text=True).splitlines())
assert changed|untracked==set(I['files']), (changed|untracked,set(I['files']))
for rel,row in I['files'].items():
 assert sha(S/rel)==row['sha256'] and sha(E/'source-validation/final-host/source'/rel)==row['sha256']
 save(S/rel,(S/rel).read_bytes(),'exact frozen 7faa source identity')
for rel in subprocess.check_output(['git','ls-tree','-r','--name-only',head],cwd=S,text=True).splitlines():
 if Path(rel).suffix not in ('.h','.hh','.hpp','.ipp','.inc') or rel in I['files']:continue
 data=subprocess.check_output(['git','show',f'{head}:{rel}'],cwd=S)
 assert (S/rel).read_bytes()==data,rel
 save(S/rel,data,'git:'+head)
for arg in P['compile']:
 if not arg.startswith('-I'):continue
 path=Path(arg[2:]).resolve()
 if not path.exists() or path.is_relative_to(S):continue
 for p in path.rglob('*'):
  if p.is_file() and p.suffix in ('.h','.hpp','.hh','.ipp','.inc'):save(p.resolve(),p.read_bytes(),'frozen build/model include')
for name,want in P['object_hashes'].items():
 p=Path(name);assert sha(p)==want,name;save(p,p.read_bytes(),'exact 7faa link object/library');assert sha(p)==want,name
assert sha(B/'nextpnr-mistral')==sha(E/'nextpnr-mistral')==P['binary_sha256']
for name,want in P['object_hashes'].items():assert sha(name)==want,name
for rel,row in I['files'].items():assert sha(S/rel)==row['sha256'],rel
out={'source_base_commit':head,'source_base_tree':subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=S,text=True).strip(),
 'source_identity_sha256':sha(E/'source-validation/final-host/source-identity.json'),'production_sha256':P['binary_sha256'],
 'board_plan_sha256':sha(E/'board-eligibility/build-plan.json'),'source_changes':I['files'],
 'object_count':len(P['object_hashes']),'files':manifest,'scope':'Frozen headers and exact link inputs; shared build/source were read only. Changed source identity supplements base git commit.'}
(H/'frozen-manifest.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print('FROZEN',len(manifest),'files',sha(H/'frozen-manifest.json'))
