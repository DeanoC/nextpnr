// Native topology only: no configuration, timing, placement or routing call.
#include "nextpnr.h"
#include "json_frontend.h"
#include "json11.hpp"
#include <fstream>
#include <iostream>
#include <set>
#include <map>
#include <algorithm>
#include <stdexcept>
USING_NEXTPNR_NAMESPACE
using J=json11::Json;
static void need(bool value,const std::string &reason){if(!value)throw std::runtime_error(reason);}
static J read(const char *p){std::ifstream f(p);need(bool(f),"missing selection");std::string error;auto j=J::parse(std::string(std::istreambuf_iterator<char>(f),{}),error);need(error.empty(),error);return j;}
static J native_port(Context &c,CellInfo *cell,IdString pin) {
 auto at=cell->pin_data.find(pin);need(at!=cell->pin_data.end(),"missing restored native port");
 J::array physical;for(auto p:at->second.bel_pins)physical.push_back(p.str(&c));
 return J::object{{"cell",cell->name.str(&c)},{"port",pin.str(&c)},{"index",0},
  {"BEL",c.getBelName(cell->bel).str(&c)},{"state",int(at->second.state)},{"physical_pins",physical}};
}
int main(int argc,char **argv){try{
 need(argc==4,"Usage: tree-reader routed.json selection.json output.json");
 need(!std::ifstream(argv[3]),"output already exists; immutable readback requires a fresh path");
 ArchArgs args;args.device="5CSEBA6U23I7";Context c(args);std::ifstream in(argv[1]);need(parse_json(in,argv[1],&c),"JSON read failed");
 need(c.attrs.at(id_step).as_string()=="route","requires final routed checkpoint");
 for(auto &entry:c.cells)need(c.restore_cell_pin_map(entry.second.get()),"missing saved physical pin map");
 auto selection=read(argv[2]);need(selection["schema"].int_value()==2,"selection schema");auto selected=selection["nets"].array_items();
 need(!selected.empty()&&selected.size()<=32,"expected one to 32 selected nets");
 std::set<NetInfo*> distinct;J::array trees;
 for(const auto &item:selected){
  auto alias=item["name"].string_value();auto *net=c.getNetByAlias(c.id(alias));need(net&&distinct.insert(net).second,"missing or duplicate selected net");
  auto *driver=net->driver.cell;need(driver&&driver->getPort(net->driver.port)==net,"missing native driver backreference");
  need(driver->name.str(&c)==item["driver"]["cell"].string_value()&&net->driver.port.str(&c)==item["driver"]["port"].string_value(),"unexpected native driver");
  need(native_port(c,driver,net->driver.port)==item["driver"],"native driver physical metadata differs");
  need(net->users.entries()>0&&net->users.entries()<=64&&net->wires.size()<=4096,"native selected net exceeds bounded transaction inventory");
  auto root=c.getNetinfoSourceWire(net);need(root!=WireId()&&net->wires.count(root),"missing native source wire");
  std::set<std::string> aliases,expected_aliases;for(const auto &a:c.net_aliases)if(a.second==net->name)aliases.insert(a.first.str(&c));
  for(const auto &a:item["aliases"].array_items()) { need(expected_aliases.insert(a.string_value()).second,"duplicate expected alias"); }
  need(aliases==expected_aliases,"complete alias inventory differs");
  std::set<std::pair<std::string,std::string>> expected_users,actual_users;
  std::map<std::pair<std::string,std::string>,J> expected_ports;
  for(const auto &u:item["users"].array_items()){auto key=std::make_pair(u["cell"].string_value(),u["port"].string_value());need(expected_users.insert(key).second,"duplicate expected user");expected_ports.emplace(key,u);}
  J::object wires;std::map<std::pair<std::string,std::string>,J> ordered_users;int roots=0;
  for(const auto &entry:net->wires){auto wire=entry.first;auto pip=entry.second.pip;need(c.getBoundWireNet(wire)==net,"foreign wire ownership");
   need(entry.second.strength<=STRENGTH_STRONG,"protected selected wire");J::object row{{"strength",int(entry.second.strength)}};
   if(pip==PipId()){++roots;need(wire==root,"additional or wrong root");row["pip"]=J();}
   else{auto src=c.getPipSrcWire(pip),dst=c.getPipDstWire(pip);need(dst==wire&&net->wires.count(src),"pip not joining saved endpoints");need(c.getBoundPipNet(pip)==net,"foreign pip ownership");row["pip"]=c.getPipName(pip).str(&c);row["source"]=c.getWireName(src).str(&c);row["destination"]=c.getWireName(dst).str(&c);}
   std::set<WireId> seen;for(auto cursor=wire;cursor!=root;){need(seen.insert(cursor).second,"route cycle");auto at=net->wires.find(cursor);need(at!=net->wires.end()&&at->second.pip!=PipId(),"disconnected route component");cursor=c.getPipSrcWire(at->second.pip);}wires.emplace(c.getWireName(wire).str(&c),row);
  }
  need(roots==1,"wrong root count");
  for(const auto &u:net->users){need(u.cell&&u.cell->ports.count(u.port),"missing user");const auto &port=u.cell->ports.at(u.port);need(port.net==net&&port.type==PORT_IN&&net->users.count(port.user_idx),"broken user slot");auto stored=net->users.at(port.user_idx);need(stored.cell==u.cell&&stored.port==u.port,"wrong indexed user backreference");
   need(actual_users.emplace(u.cell->name.str(&c),u.port.str(&c)).second,"duplicate logical user");auto all=c.getNetinfoSinkWires(net,u);need(all.size()!=0,"user has no native physical sinks");std::set<std::string> sinks;for(auto wire:all){need(net->wires.count(wire),"unreached native physical sink");sinks.insert(c.getWireName(wire).str(&c));}
   auto key=std::make_pair(u.cell->name.str(&c),u.port.str(&c));
   need(expected_ports.count(key)&&native_port(c,u.cell,u.port)==expected_ports.at(key),"native user physical metadata differs");
   J::array sink_rows;J::object paths;
   for(auto wire:all){J::array path;auto cursor=wire;
    while(true){path.push_back(c.getWireName(cursor).str(&c));if(cursor==root)break;cursor=c.getPipSrcWire(net->wires.at(cursor).pip);}
    paths.emplace(c.getWireName(wire).str(&c),path);
   }
   for(const auto &s:sinks)sink_rows.push_back(s);
   ordered_users.emplace(key,J::object{{"cell",u.cell->name.str(&c)},{"port",u.port.str(&c)},
    {"native_port",native_port(c,u.cell,u.port)},{"physical_sink_wires",sink_rows},{"paths_to_source",paths}});
  }
  need(actual_users==expected_users,"complete user inventory differs");
  J::array users;for(const auto &entry:ordered_users)users.push_back(entry.second);
  for(const auto &p:c.ports)need(p.second.net!=net,"unexpected public observer");
  J::array alias_rows;for(const auto &a:aliases)alias_rows.push_back(a);
  trees.push_back(J::object{{"bit",item["bit"]},{"selected_alias",alias},{"canonical_net",net->name.str(&c)},{"complete_aliases",alias_rows},{"driver",J::object{{"cell",driver->name.str(&c)},{"port",net->driver.port.str(&c)},{"source_wire",c.getWireName(root).str(&c)},{"native_port",native_port(c,driver,net->driver.port)}}},{"complete_users",users},{"complete_tree",wires},{"all_native_sinks_reached",true},{"single_acyclic_source_root",true},{"foreign_ownership_absent",true}});
 }
 std::ofstream out(argv[3]);out<<J(J::object{{"pass",true},{"trees",trees},{"scope","Read-only native pip/source/sink interpretation of exact selected saved trees; no timing, configuration, route or RBF execution"}}).dump()<<"\n";return 0;
}catch(const std::exception &e){std::cerr<<"REJECTED: "<<e.what()<<"\n";return 1;}}
