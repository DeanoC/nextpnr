#!/usr/bin/env python3
"""Positive complete native readback and malformed checkpoint/selection controls."""
from pathlib import Path
from copy import deepcopy
import hashlib,json,subprocess,time,sys
H=Path(__file__).resolve().parent;E=H.parent;C=E/'final-analysis-permutation4';sys.path.insert(0,str(C))
from prove_graph import graph_edges,physical_port,prove
D=H/'reader-validation-final';D.mkdir(exist_ok=True)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
R=E.parent/'lut6-source-coverage-20261022/route-swap16/routed.json';raw=read(R);m=next(iter(raw['modules'].values()));cells=m['cells']
name='system.machine.isa.slots[1].cga.card.card.pixel_MISTRAL_ALUT6_Q_F_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_Q_1'
assert cells[name]['type']=='MISTRAL_ALUT3'
u,d,a,public=graph_edges(m);bits=sorted({v[0] for v in cells[name]['connections'].values()});nets=[]
for bit in bits:
 assert len(d[bit])==1 and bit not in public
 nets.append({'name':a[bit][0],'aliases':a[bit],'driver':physical_port(cells,d[bit][0]),'users':[physical_port(cells,x) for x in u[bit]],'bit':bit})
selection=D/'selection.json';save(selection,{'schema':2,'nets':nets,'input_sha256':sha(R)})
records=[]
def run(label,input_path,sel):
 output=D/(label+'-result.json');assert not output.exists();cmd=[str(H/'tree-reader'),str(input_path),str(sel),str(output)];start=time.monotonic()
 with (D/(label+'.log')).open('w') as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 records.append({'case':label,'argv':cmd,'returncode':result.returncode,'wall_seconds':time.monotonic()-start,'input_sha256':sha(input_path),'selection_sha256':sha(sel),'log_sha256':sha(D/(label+'.log'))})
 return result.returncode,output
rc,output=run('complete-positive',R,selection);assert rc==0;positive=read(output);assert positive['pass'];assert len(positive['trees'])==4
assert any(len(t['complete_users'])>1 for t in positive['trees'])
shared=next(t for t in positive['trees'] if len(t['complete_users'])>1)
stationary=next(v for v in shared['complete_users'] if v['cell']!=name);assert stationary['physical_sink_wires']
for label,removed in [('missing_native_source',shared['driver']['source_wire']),('missing_stationary_sink',stationary['physical_sink_wires'][0])]:
 changed=deepcopy(raw);module=next(iter(changed['modules'].values()));bit=shared['bit']
 for alias,net in module['netnames'].items():
  if net['bits']!=[bit]:continue
  pieces=net['attributes']['ROUTING'].split(';');rows=[pieces[i:i+3] for i in range(0,len(pieces),3)];assert len([r for r in rows if r[0]==removed])==1
  net['attributes']['ROUTING']=';'.join(v for r in rows if r[0]!=removed for v in r)
 path=D/(label+'.json');save(path,changed);rc,out=run(label,path,selection);assert rc!=0 and not out.exists()
for label,change in [('missing_complete_user',lambda n:n['users'].pop()),('wrong_physical_pin',lambda n:n['users'][0]['physical_pins'].__setitem__(0,'bogus')),
                     ('wrong_alias_inventory',lambda n:n['aliases'].pop()),('wrong_source_state',lambda n:n['driver'].__setitem__('state',3 if n['driver']['state']==0 else 0))]:
 bad=deepcopy({'schema':2,'nets':nets});choice=next(n for n in bad['nets'] if len(n['users'])>1);change(choice)
 path=D/(label+'-selection.json');save(path,bad);rc,out=run(label,R,path);assert rc!=0 and not out.exists()
control=prove(raw,raw,[]);assert control['status']=='pass'
result={'passed':True,'helper_sha256':sha(H/'tree-reader'),'helper_source_sha256':sha(H/'tree-reader.cc'),'frozen_manifest_sha256':sha(H/'frozen-manifest.json'),
 'reference_sha256':sha(R),'reference_kind':'prior complete CPU10 routed checkpoint; electrical topology only, interpreted by matching7faa helper',
 'full_graph_self_comparison':{'cells':control['complete_cells'],'aliases':control['complete_net_alias_records'],'passed':True},
 'positive_complete_selected_nets':len(nets),'positive_complete_user_count':sum(len(n['users']) for n in nets),'records':records,
 'scope':'Host native reader positive/malformed controls only; no route, pin allocation, configuration or timing analysis.'}
save(D/'receipt.json',result);print('PASS',len(nets),'selected complete trees and',len(records)-1,'rejections',sha(D/'receipt.json'))
