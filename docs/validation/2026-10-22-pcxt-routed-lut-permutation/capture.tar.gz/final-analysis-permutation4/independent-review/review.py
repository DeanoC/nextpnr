#!/usr/bin/env python3
"""Read-only replay of the frozen graph, timing and decoded-topology evidence."""
import contextlib,hashlib,importlib,io,json,pathlib,sys
HERE=pathlib.Path(__file__).resolve().parent
SOURCE=HERE.parent
sys.path.insert(0,str(SOURCE))
import support

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
inputs={str(p.relative_to(SOURCE)):sha(p) for p in sorted(SOURCE.glob('*.py'))}
checks=[]
def compare_write(name,value):
 assert encoded(value)==(SOURCE/name).read_bytes(),name+' replay bytes differ'
 checks.append({'proof':name,'sha256':sha(SOURCE/name),'exact_replay':True})
log=io.StringIO()
with contextlib.redirect_stdout(log):
 graph=importlib.import_module('prove_graph');graph.write=compare_write;graph.main()
 topology=importlib.import_module('verify_topology');topology.write=compare_write;topology.main()
 timing=importlib.import_module('compare_timing');timing.R=HERE;timing.main()
assert (HERE/'route-comparison.json').read_bytes()==(SOURCE/'route-comparison.json').read_bytes()
checks.append({'proof':'route-comparison.json','sha256':sha(SOURCE/'route-comparison.json'),'exact_replay':True})
assert inputs=={str(p.relative_to(SOURCE)):sha(p) for p in sorted(SOURCE.glob('*.py'))}
t=support.read(SOURCE/'route-comparison.json');g=support.read(SOURCE/'graph-proof.json');p=support.read(SOURCE/'topology-proof.json');d=support.read(SOURCE/'decision-ledger.json')
assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal']
assert t['native_margin_delta_counts']=={'setup':{'improved':1,'unchanged':17193},'hold':{'unchanged':17194}}
assert len(g['accepted_cells'])==1 and g['changed_canonical_net_bits']==[54479,54480]
assert p['selected_nets']==6 and p['stationary_users']==16 and p['changed_physical_users']==2
assert p['retained_original_wire_tuples']==46
rows=[r for r in t['every_endpoint_row'] if r['margin_delta_ps']['setup']]
assert len(rows)==1 and rows[0]['identity']==['system.machine.isa.rgbi_MISTRAL_FF_Q_3','DATAIN']
assert rows[0]['cpu16']['setup']==-369 and rows[0]['selected']['setup']==-234
result={'passed':True,'reviewer':'review_branch_repair','review_script_sha256':sha(__file__),'replayed_inputs':inputs,'exact_replays':checks,
 'accepted_cell':g['accepted_cells'][0]['cell'],'accepted_swap':['D','E'],'complete_cells':g['complete_cells'],'complete_alias_records':g['complete_net_alias_records'],
 'native_topology':{k:p[k] for k in ('selected_nets','stationary_users','changed_physical_users','retained_original_wire_tuples')},
 'setup_improvement_ps':135,'setup_endpoint':rows[0]['identity'],'setup_before_ps':-369,'setup_after_ps':-234,
 'native_margin_delta_counts':t['native_margin_delta_counts'],'unchanged_complete_endpoint_identities':len(t['every_endpoint_row']),
 'pair_charge_seconds_recorded_not_recharged':t['pair_charge_seconds'],'charged_route_seconds':0,
 'findings':['Exact replay of complete graph, decisions, selection specs, final timing and native decoded-tree proofs reproduces every retained proof byte.',
 'Only the logged ALUT5 D/E swap and two selected canonical net trees change; all 32 raw-net truth rows match.',
 'Every decoded stationary source-to-sink path and its wire/PIP/strength tuple is preserved; selected roots remain identical.',
 'One previously failing setup row improves 135 ps; all other checked setup and hold rows remain exact; complete identities, windows, flags, metadata and clock summaries remain exact.',
 'The three rejected trials are retained in the decision ledger. No guard relaxation is inferred from rejection reasons.'],
 'limits':['This review replays already recorded native topology; it does not execute the native reader again or claim a new RBF mask proof.',
 'There remain 10 setup failures, worst system slack -434 ps; complete=false and 105 unsupported entries remain unchanged. This is a retained diagnostic improvement, not timing closure or coverage qualification.',
 'No hardware, deployment, new full route or route charge occurred.']}
(HERE/'replay.log').write_text(log.getvalue())
(HERE/'review.json').write_bytes(encoded(result))
print(json.dumps({'passed':True,'exact_replays':len(checks),'review_sha256':sha(HERE/'review.json')},sort_keys=True))
