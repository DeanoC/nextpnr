#!/usr/bin/env python3
"""Portable immutable proof replay; never launches native code or resolves live paths."""
from pathlib import Path
import contextlib,hashlib,importlib,io,json,sys,tempfile
R=Path(__file__).resolve().parent;A=R/'final-analysis-permutation4';sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
assert support.archive_mode() is not None and support.ROOT==R
final=read(R/'final-validation.json');commit=read(R/'committed-source-verification.json')
assert commit['commit']=='186637013e17461a72cd1d2cd17ca5ef174ed06f' and commit['source_files']==final['source_files'] and commit['final_validation_sha256']==sha(R/'final-validation.json')
for n,h in final['files'].items():assert sha(R/n)==h,n
for n,h in final['source_files'].items():assert sha(R/'complete-source'/n)==h,n
assert len(final['files'])==131 and len(final['source_files'])==29
native=R/'native-topology';build=read(native/'build-receipt.json');frozen=read(native/'frozen-manifest.json');qualified=read(native/'committed-source-verification.json')
assert build['production_binary_sha256']==final['binary_sha256']=='7faa854df524d0dd3a69cf90622b589692d2db078c031a36ac2c7a5d0deadf12'
assert build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
for name,key in [('tree-reader.cc','helper_source_sha256'),('frozen-manifest.json','frozen_manifest_sha256'),('build-commands.json','build_commands_sha256'),('build.log','build_log_sha256')]:assert sha(native/name)==build[key]
assert len(frozen['files'])==401 and qualified['source_commit']==commit['commit'] and qualified['frozen_manifest_sha256']==sha(native/'frozen-manifest.json')
older_build=read(native/'reader32-validated/build-receipt.json')
for name,key in [('tree-reader.cc','helper_source_sha256'),('build-commands.json','build_commands_sha256'),('build.log','build_log_sha256')]:assert sha(native/'reader32-validated'/name)==older_build[key]
assert older_build['frozen_manifest_sha256']==build['frozen_manifest_sha256'] and older_build['production_binary_sha256']==build['production_binary_sha256']
omitted=read(R/'omitted-payloads.json');omitted_hashes={v['original_path']:v['sha256'] for v in omitted['files']}
for directory in ['reader-validation','reader-validation-final']:
 receipt=read(native/directory/'receipt.json');assert receipt['passed'] and len(receipt['records'])==7
 for rec in receipt['records']:
  case=rec['case'];assert rec['returncode']==(0 if case=='complete-positive' else 1)
  assert sha(native/directory/(case+'.log'))==rec['log_sha256']
  selection=Path(rec['argv'][2]).name;assert sha(native/directory/selection)==rec['selection_sha256']
  input_path=rec['argv'][1]
  if case in ('missing_native_source','missing_stationary_sink'):assert omitted_hashes[input_path]==rec['input_sha256']
  else:assert sha(R/'references/prior-cpu/routed.json')==rec['input_sha256']
 expected_build=build if directory.endswith('-final') else older_build
 assert receipt['helper_sha256']==expected_build['helper_binary_sha256'] and receipt['helper_source_sha256']==expected_build['helper_source_sha256']
checks=[]
def compare_write(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs'
 checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
log=io.StringIO()
with contextlib.redirect_stdout(log):
 g=importlib.import_module('prove_graph');g.write=compare_write;g.main()
 t=importlib.import_module('test_checks');t.write=compare_write;t.main()
 n=importlib.import_module('verify_topology');n.write=compare_write;n.main()
 c=importlib.import_module('compare_timing')
 with tempfile.TemporaryDirectory(prefix='pcxt-permutation-proof-') as scratch:
  c.R=Path(scratch);c.main();assert (c.R/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
 checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
# Original independent reviewer script is replayed separately by the outer verifier.
graph=read(A/'graph-proof.json');timing=read(A/'route-comparison.json');topology=read(A/'topology-proof.json')
assert len(timing['every_endpoint_row'])==17199 and timing['native_margin_delta_counts']=={'setup':{'improved':1,'unchanged':17193},'hold':{'unchanged':17194}}
assert timing['endpoint_identity_inventory_equal'] and timing['all_row_domain_windows_and_flags_equal'] and timing['all_metadata_categories_equal']
assert len(graph['accepted_cells'])==1 and len(graph['accepted_cells'][0]['all_raw_net_rows'])==32
assert all(v['before_output']==v['after_output'] for v in graph['accepted_cells'][0]['all_raw_net_rows'])
assert topology['selected_nets']==6 and topology['stationary_users']==16 and topology['changed_physical_users']==2 and topology['retained_original_wire_tuples']==46
result={'passed':True,'source_commit':commit['commit'],'source_files':29,'host_admission_files':131,'native_snapshot_manifest_members':401,'exact_replays':checks,'complete_endpoint_rows':17199,'native_margin_delta_counts':timing['native_margin_delta_counts'],'all32_truth_rows_equal':True,'native_topology':{k:topology[k] for k in ('selected_nets','stationary_users','changed_physical_users','retained_original_wire_tuples')},'pair_route_charge_seconds_recorded_not_recharged':timing['pair_charge_seconds'],'charged_route_seconds':0,'scope':'Offline proof replay of complete saved artifacts/native decoded trees and recorded host receipts. No native execution, GPU route, emitted-RBF mask proof, reload STA or hardware acceptance.'}
print(encoded(result).decode(),end='')
