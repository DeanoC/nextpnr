#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil,subprocess
R=Path(__file__).resolve().parent;OUT=R.parents[1];S=R/'source'
assert (OUT/'post-route-checkpoint-20261022/route-only/receipt.json').exists(),'Fresh route incomplete'
assert (OUT/'post-route-checkpoint-20261022/analysis/native-tree-proof.json').exists(),'Native tree proof incomplete'
assert not S.exists(),'Capture is immutable once collected'
S.mkdir()
excluded=[]
def copy_tree(src,dst):
 for p in sorted(src.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(src)
  if any(x in rel.parts for x in ['__pycache__','capture','frozen-build']) or p.suffix in ['.o','.a'] or p.name in ['nextpnr-mistral','native-probe','tree-reader']:
   excluded.append(str(p));continue
  q=dst/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for name in ['local-route-repair-20261022','local-move-repair-20261022','post-route-checkpoint-20261022']:
 copy_tree(OUT/name,S/'out'/name)
for name in ['route-windows-correct-overflow','prepare-windows-correct-overflow']:
 copy_tree(OUT/'hard-block-windows-20261022'/name,S/'out/hard-block-windows-20261022'/name)
copy_tree(OUT/'hard-block-arrival-pins-20261022/prepare-baseline',S/'out/hard-block-arrival-pins-20261022/prepare-baseline')
copy_tree(OUT/'hard-block-windows-20261022/sources',S/'out/hard-block-windows-20261022/sources')
for name in ['source-identity.json']:
 p=OUT/'hard-block-windows-20261022'/name
 if p.exists():shutil.copy2(p,S/'out/hard-block-windows-20261022'/name)
base=json.loads((OUT/'hard-block-windows-20261022/route-windows-correct-overflow/receipt.json').read_text())
inputs={}
for name,info in base['inputs'].items():
 p=Path(info['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256'];q=S/'inputs'/p.name;q.parent.mkdir(exist_ok=True);shutil.copy2(p,q);inputs[name]={'historical_path':str(p),'archived_path':str(q.relative_to(S)),'sha256':info['sha256']}
# Preserve generated header dependencies while excluding the frozen object tree.
generated=OUT/'local-move-repair-20261022/native-probe/frozen-build'
for p in generated.rglob('*'):
 if p.is_file() and p.suffix in ['.h','.hpp','.inc','.ipp']:
  q=S/'native-generated-headers'/p.relative_to(generated);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
script=OUT.parent/'scripts/gpu-run';q=S/'scripts/gpu-run';q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(script,q)
for name in ['README.md','offline-verify.py','charge-summary.json']:
 shutil.copy2(R/name,S/name)
(S/'capture-tools').mkdir()
for name in ['collect.py','write-report.py']:
 shutil.copy2(R/name,S/'capture-tools'/name)
shutil.copy2('/tmp/pcxt-capture.py',S/'capture-tools/pcxt-capture.py')
(S/'archive-input-binding.json').write_text(json.dumps({'inputs':inputs,'binary_and_object_omissions':'Tool binaries and frozen object directory omitted deliberately; exact hashes/build commands/source identity retained. Native replay requires rebuilding/providing those exact dependencies.','excluded_file_count':len(excluded),'excluded_paths':excluded},indent=2)+'\n')
subprocess.run(['python3','/tmp/pcxt-capture.py',str(S),str(R/'capture.tar.gz')],stdout=(R/'archive-readback.json').open('w'),check=True)
print('collected and read back')
