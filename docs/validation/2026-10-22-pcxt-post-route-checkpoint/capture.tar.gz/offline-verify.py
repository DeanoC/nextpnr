#!/usr/bin/env python3
"""Offline JSON/evidence replay; no native tool or GPU execution."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parent;O=R/'out';fixed=O/'post-route-checkpoint-20261022';old=O/'local-route-repair-20261022';move=O/'local-move-repair-20261022';base=O/'hard-block-windows-20261022/route-windows-correct-overflow'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest=json.loads((R/'manifest.json').read_text())
for name,meta in manifest.items():
 p=R/name;assert p.stat().st_size==meta['size'] and sha(p)==meta['sha256'],name
for source in [base,old/'route-only',move/'move-only',fixed/'route-only',fixed/'prepare-default',fixed/'prepare-explicit-zero']:
 rec=json.loads((source/'receipt.json').read_text())
 for n,h in rec['artifacts'].items():assert sha(source/n)==h,(source,n)
for v in json.loads((R/'archive-input-binding.json').read_text())['inputs'].values():assert sha(R/v['archived_path'])==v['sha256']
# Recreate complete endpoint deltas from retained native outputs, no intersections.
for root in [old,move]:
 before=(root/'complete-comparison.json').read_bytes();subprocess.run([sys.executable,str(root/'analyze-complete.py')],stdout=subprocess.DEVNULL,check=True);assert before==(root/'complete-comparison.json').read_bytes()
before=(fixed/'analysis/final-comparison.json').read_bytes();subprocess.run([sys.executable,str(fixed/'analysis/compare-final.py')],stdout=subprocess.DEVNULL,check=True);assert before==(fixed/'analysis/final-comparison.json').read_bytes()
# Replay full original-function / routing-helper accounting from actual graphs.
spec=importlib.util.spec_from_file_location('graph',old/'native-graph-support.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
expected=g.read(old/'serialized-graph-proof.json')['complete_serialized_graph_bridge'];actual=g.prepared_bridge(g.read(O/'hard-block-arrival-pins-20261022/prepare-baseline/placed.json'),g.read(old/'route-only/routed.json'));assert json.loads(json.dumps(actual))==expected
# Bind the native source/destination interpretation of every changed tree back to
# every complete saved ROUTING entry. Native decoding itself is a retained result.
proof=g.read(fixed/'analysis/native-tree-proof.json');comparison=g.read(fixed/'analysis/final-comparison.json');module=g.read(fixed/'route-only/routed.json')['modules']['top'];seen=set()
for tree in proof['trees']:
 name=tree['selected_net'];assert name not in seen;seen.add(name);parts=module['netnames'][name]['attributes']['ROUTING'].split(';');expected={(parts[i],parts[i+1],int(parts[i+2])) for i in range(0,len(parts),3)};actual={(r['wire'],r['pip'] or '',r['strength']) for r in tree['complete_saved_tree']};assert actual==expected and len(actual)==len(tree['complete_saved_tree'])
 edges={r['wire']:r.get('source') for r in tree['complete_saved_tree']};root=tree['driver']['source_wire'];assert [w for w,p in edges.items() if p is None]==[root]
 for start in edges:
  visited=set();cursor=start
  while cursor!=root:assert cursor not in visited and cursor in edges;visited.add(cursor);cursor=edges[cursor]
 for user in tree['complete_users']:
  for sink in user['physical_sink_wires']:assert sink in edges
assert seen=={d['net'] for d in comparison['expected_accepted_decisions']}
print(json.dumps({'status':'pass','all_manifest_members_verified':len(manifest),'complete_endpoint_comparisons_exact_replay':True,'complete_fixed_graph_comparison_exact_replay':True,'full_original_graph_helper_bridge_replayed':True,'all_three_complete_native_tree_records_bound_to_actual_saved_strings':True,'native_decoder_not_reexecuted':True,'no_GPU_or_route_or_hardware_execution':True},indent=2))
