#ifndef VERSION_H
#define VERSION_H

#define GIT_DESCRIBE_STR "nextpnr-0.11.1-631-g36617f23"

#endif
