package require ::quartus::project
package require ::quartus::sta
project_open top
create_timing_netlist
read_sdc
create_generated_clock -name sdram_forwarded -source [get_ports FPGA_CLK1_50] -divide_by 1 -invert [get_ports DDR_OUT]
foreach corner [get_available_operating_conditions] {
    set_operating_conditions $corner
    update_timing_netlist
    file mkdir pulse-check/$corner
    report_min_pulse_width -detail full_path -nworst 100 -file pulse-check/$corner/pulse.rpt [get_ports DDR_OUT]
    report_clocks -file pulse-check/$corner/clocks.rpt
}
project_close
