Three new constant-inverted AD20 fits: loads 0,15,30pF; 600s limit each.
One pulse query using set_min_pulse_width failed: unsupported command in Quartus17.0.2.
Retained failed script and log. Revised query only adds generated output clock;
reported required pulse width is vendor zero, not the SDRAM requirement.
No PCXT routes, no hardware, no constraint or acceptance relaxation.
