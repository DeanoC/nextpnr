# PC/XT schema-7 coverage audit

The current compiler cannot produce full endpoint qualification for this PC/XT
build merely by enabling its existing contracts. Those contracts can expose
additional native diagnostic rows, but reset, forwarded-clock and unregistered
DQ models deliberately remain unqualified, and HPS I2C lacks a launch model.
Do not turn those statuses into acceptance or waive their predicates.

Scope: read-only audit of `candidate/endpoints.json`, frozen compiler source
`692a1c37`, current FES PC/XT source/docs and retained native reference audits.
No compiler runs, routes, kit access or hardware changes were performed for this
coverage audit. The chain preparation elsewhere is separate structural evidence.

## What the actual capture lacks

The snapshot has 17,199 endpoint rows, schema 7, `final_analogue=true`,
`complete=false`, **105 unsupported boundaries**, no IO constraints, and empty
output/registered/unregistered/reset/forwarded/primitive-clock contracts. Its
SDC only creates the 50 MHz FPGA reference; the PLL derives the internal clocks.
Two HPS physical obligations are already explicit.

| Unsupported class | Count | Existing support and limit |
| --- | ---: | --- |
| HDMI RGB/DE/HS/VS unregistered outputs | 27 | Explicit output min/max can expose native routing-boundary capture rows. They do not supply complete board/data-pad timing. |
| Dedicated SDRAM DQML/DQMH outputs | 2 | Same unregistered output mechanism. Actual addon wiring must establish whether these physical pins participate; they are active, not structurally constant. |
| HDMI forwarded clock | 1 | AG5 reference profile plus explicit source relationship; always reference-only. |
| SDRAM registered address/bank/command/CKE PAD | 20 | Existing RAMTEST pad profile plus supported declared load and output budgets can expose all data channels and primitive-clock checks. |
| Inverted SDRAM forwarded clock PAD | 1 | RAMTEST profile exposes both pad edges; explicit inverted point-load waveform diagnostic additionally retains pulse bounds and outstanding obligations. |
| SDRAM unregistered DQ data/OE | 16 + 16 | Native external output rows exist. Complete reference tails require the DQ_UNREGISTERED profile and separately selected BYPASS hardware configuration. |
| SDRAM fabric DQ capture FF DATAIN | 16 | Explicit input min/max and launch event allow native external-launch walks. The reference input prefix also requires the DQ profile/configuration. |
| Reset-chain FF ACLR | 4 | Ordered declarations can establish chain structure while preserving interstage/consumer setup and hold. They do not establish recovery/removal or MTBF. |
| HPS I2C OE | 2 | No native peripheral-clock launch bounds; unresolved even with external budgets. Constant-low data channels already have separate I-only proofs. |

Unlike the older dynamic-CE audit, **all twenty registered SDRAM output cells in
this capture have empty parameters and no CEOUT port**. Their inputs are the
current pipeline's `sdram_*_r` nets. The historical thirteen-pin dynamic-CE
extension is available but is not needed for this actual topology. Do not copy
older CE declarations onto these cells.

## Concrete supported path to additional evidence

1. Keep a separate immutable physical-constraint/profile input bundle. Derive
   input/output min/max from the actual fitted board, memory part and receiver
   configuration; include uncertainty in those bounds because clock uncertainty
   is currently a compatibility no-op. Do not reuse the synthetic -1..2 ns
   output / 1..3 ns input fixture values or RAM Tester's assumed flights.
2. For the twenty SDROUT pads and AD20 clock, explicitly select
   `NEXTPNR_GPIO_TIMING_PROFILE=QUARTUS_17_0_2_RAMTEST` and an evidenced supported
   `BOARD_MODEL_FAR_C` bound. The implementation requires the exact device,
   package pin/BEL, native selectors, supported electrical settings and controls.
   Apply explicit output min/max to every participating physical top port.
   The exporter already calls architecture-owned `getRegisteredIoTiming` and
   `getPrimitiveClockRequirements`, then requests both external directions and
   registered private endpoints from native STA. No new private alias naming or
   endpoint-API switch is needed.
3. For DQ, use independent input/output constraints on each bidirectional port,
   preserving falling controller-clock reference and the actual +180-degree
   fabric-capture relationship. Native input, data and OE are separate rows.
   The complete conditional DQ reference additionally requires
   `NEXTPNR_GPIO_TIMING_PROFILE=QUARTUS_17_0_2_DQ_UNREGISTERED`, a supported declared
   load, and **`NEXTPNR_INPUT_REG4_SEL=BYPASS`**. That last assignment changes
   emitted configuration from legacy LOCKED_DPA. This is a new artifact needing
   rerouting/requalification, not an annotation that qualifies the current RBF.
4. For HDMI clock, the implemented exact reference is
   `QUARTUS_17_0_2_AG5_CLOCK` on AG5 plus
   `timing/forwarded_clocks=[{"port":"HDMI_TX_CLK","clock":"clk_pixel"}]`.
   For inverted SDRAM clock the declaration names `SDRAM_CLK` and `clocks[0]`
   and additionally requires explicit `load_pf` and `uncertainty_ps`.
   Only the separately characterized 0/15/30 pF point-load scenarios exist;
   do not interpolate or confuse the scenario with a measured load. Both kinds
   of forwarded contract always carry `physically_qualified=false`.
5. Current reset-stage identities, derived from the actual connections and
   existing `async_reg=true`, are system
   `["locked_MISTRAL_FF_ACLR_1", "locked_MISTRAL_FF_ACLR_1_Q_MISTRAL_FF_DATAIN"]`
   and pixel
   `["locked_MISTRAL_FF_ACLR_DATAIN_MISTRAL_FF_Q", "locked_MISTRAL_FF_ACLR"]`.
   They can be submitted as ordered `stages` objects in `timing/reset_contracts`.
   Native validation must recheck the complete current fanout, constant first D,
   raw reset containment and uncut setup/hold; these observed identities alone
   are not proof or a waiver. One system first-D route uses a generated identity
   route-through, so keep its actual constant-chain proof.
6. Run a fresh full route with final analogue timing and `--routed-endpoints`,
   retaining matching QSF/SDC, source/tool/configuration identities and RBF.
   Missing or negative external checks remain failures. The old RAMTEST
   `path_coverage.py` assumes registered DQ and two constant mask outputs, so
   its 70-channel expectation does **not** describe this fabric-capture PC/XT
   topology unchanged; schema-7 native identities are the appropriate inventory.

This path improves modeled coverage only. No supplied option turns its reference
contracts into full acceptance. `mistral/routed_swap.py:rows()` rejects nonempty
`reset_contracts`, `forwarded_clocks`, and `unregistered_contracts` even if
`complete` is forged; it also rejects any physical obligations or unsupported
rows. `critical_swap_endpoint_snapshot()` always emits physical obligations for
those references. HPS OE additionally remains unsupported. Genuine qualified
architecture/interface models and evidence-bound acceptance handling would have
to be implemented and reviewed; changing the Boolean or weakening these guards
would not close the gap.

## Physical evidence still missing

- **Kit identity:** Kit A is MiSTer Pi and Kit B is SuperStation One, both with
  standard MiSTer SDRAM. That identifies families only. Record actual addon
  revision and fitted SDRAM part/speed grade; qualify Kit B separately.
- **SDRAM:** evidenced clock/read/write flight intervals, load and slew,
  chip-select inversion propagation where present, source/PLL/buffer waveform
  distortion, actual emitted DDIO selector correspondence, qualified route
  fast-corner lower bounds, receiver setup/hold and pulse requirements. Resolve
  dedicated DQML/DQMH AG13/AF13 wiring versus the controller's masks multiplexed
  onto A11/A12. High-Z disable, tHZ/tLZ, delayed DQM and bus turnaround remain
  separate from the modeled OE rise/fall arcs. Recompute clock-dependent budgets
  for the actual final route.
- **HDMI:** complete data/clock pad bounds, board skew/load, and the actual
  ADV7513 capture/register recipe. Runtime source currently describes RGB444,
  undivided input clock and `0xBA` no-delay setting; source defaults are not
  hardware readback. Receiver setup/hold alone does not cover board/pad delay.
- **Reset:** measured/specified assertion pulse, PLL lock/relock behavior,
  recovery/removal containment and metastability/MTBF qualification with the
  actual clock rates and implementation. Structural declarations retain these
  obligations explicitly.
- **HPS I2C:** actual HPS peripheral-clock/controller configuration, a validated
  hard-IP OE-launch and input-feedback model, pull-ups, bus capacitance and
  receiver requirements. Neither CPU/pixel clocks nor I2C bit rate can stand in
  for the missing peripheral-clock relationship. No such model exists in the
  current architecture API implementation.

The older FES independent-pad-envelope preflight remains useful evidence of
pessimism, but current compiler code additionally has same-corner sampled-load
inverted-clock pulse diagnostics. That newer work still does not qualify actual
kit loads, route fast corners, PLL waveform or board propagation.

## Evidence pointers

- Compiler: `mistral/critical_cohort.cc:1621` (reset validation), `:1735`
  (schema-7 export), `:1758` (forwarded clocks), `:1851` (native endpoint flags),
  `:1980` (unregistered contracts/obligations).
- Compiler: `mistral/delay.cc:80` (registered profile guards), `:356`
  (DQ reference), `:645` (registered channels), `:704` (primitive clocks).
- Compiler: `mistral/routed_swap.py:36` (strict qualification predicates),
  `docs/mistral-io-delay.md`,
  `docs/validation/2026-10-20-interface-contracts-265/summary.md`,
  `docs/validation/mistral-sdram-full-board-coverage.md`.
- FES: `sources/misteross/cores/fes-pcxt/README.md:33`,
  `sources/misteross/docs/architecture.md:355`,
  `docs/validation/2026-10-21-pcxt-interface-budget/summary.md`,
  `sources/misteross/cores/fes-pcxt/rtl/fes_pcxt_top.sv`,
  `sources/libmister-runtime/src/native/adv7513.hpp`.
