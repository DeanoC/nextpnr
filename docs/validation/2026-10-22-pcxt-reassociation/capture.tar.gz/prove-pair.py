#!/usr/bin/env python3
"""Prove the pair and complete surrounding graph from two final routed JSONs.

This is a Boolean/structural proof. It does not establish RBF encoding, timing,
physical IO margins, sequential equivalence of arbitrary rewrites, or hardware
acceptance. Every cell, named net/alias and top-level port is accounted for.
"""
import argparse
import collections
import copy
import hashlib
import itertools
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def unpack(value):
    return json.loads(bytes.fromhex(value).decode())


def pack(value):
    return json.dumps(value, sort_keys=True).encode().hex()


def pinmap(cell, name):
    payload = unpack(cell['attributes']['FES_PINMAP_V1'])
    require(set(payload) == {'count', 'pins'}, f'{name}: pin-map schema changed')
    pins = payload['pins']
    require(payload['count'] == len(pins), f'{name}: incomplete pin-map count')
    for port, bits in cell['connections'].items():
        # The JSON writer regroups scalar bus ports (for example M10K
        # A1ADDR[0..N]) into one connection vector; the pin snapshot keeps
        # the exact scalar identities. Require every lane, not an overlap.
        logical = [port] if port in pins else [f'{port}[{index}]' for index in range(len(bits))]
        require(logical and all(pin in pins for pin in logical), f'{name}.{port}: missing logical pin state')
        require(len(bits) <= 1 or port not in pins, f'{name}.{port}: ambiguous vector pin state')
    for pin, values in pins.items():
        require(isinstance(values, list) and values and type(values[0]) is int and values[0] in range(4),
                f'{name}.{pin}: invalid pin state')
        require(all(isinstance(value, str) for value in values[1:]), f'{name}.{pin}: invalid physical map')
    return pins


def site(cell):
    match = re.fullmatch(r'MISTRAL_(M?COMB)\.(\d+)\.(\d+)\.(\d+)', cell['attributes']['NEXTPNR_BEL'])
    require(match is not None, 'pair cell is not on a COMB BEL')
    kind, x, y, z = match.groups()
    z = int(z)
    require(z % 6 in (0, 1), 'pair cell is not on a LUT half')
    return int(x), int(y), int(kind == 'MCOMB'), z // 6


def proof(documents, producer, selected_input):
    a_doc, b_doc = documents
    require(set(a_doc) == set(b_doc) == {'creator', 'modules'}, 'root schema changed')
    require(a_doc['creator'] == b_doc['creator'], 'compiler creator label changed')
    require(set(a_doc['modules']) == set(b_doc['modules']) and len(a_doc['modules']) == 1,
            'module inventory changed or is not flat')
    module_name = next(iter(a_doc['modules']))
    modules = [document['modules'][module_name] for document in documents]
    a, b = modules
    require(set(a) == set(b) == {'settings', 'attributes', 'ports', 'cells', 'netnames'}, 'module schema changed')
    require(a['attributes']['step'] == b['attributes']['step'] == 'route', 'requires two final routed netlists')
    require(set(a['cells']) == set(b['cells']), 'complete cell inventory changed')
    require(set(a['netnames']) == set(b['netnames']), 'complete net-name/alias inventory changed')
    require(set(a['ports']) == set(b['ports']), 'top-level port inventory changed')

    # Establish a bijection using EVERY named-net bit, including every alias.
    # A merge or split of alias classes is rejected before examining cells.
    forward, reverse = {}, {}
    labels = collections.defaultdict(list)
    changed_routes = []
    for name in sorted(a['netnames']):
        x, y = a['netnames'][name], b['netnames'][name]
        require(set(x) == set(y) == {'hide_name', 'bits', 'attributes'}, f'{name}: net schema changed')
        require(x['hide_name'] == y['hide_name'], f'{name}: net visibility changed')
        require(len(x['bits']) == len(y['bits']), f'{name}: net width changed')
        for index, (old, new) in enumerate(zip(x['bits'], y['bits'])):
            require(type(old) is type(new), f'{name}[{index}]: signal/constant classification changed')
            if type(old) is int:
                require(old not in forward or forward[old] == new, f'{name}[{index}]: alias split')
                require(new not in reverse or reverse[new] == old, f'{name}[{index}]: alias merge')
                forward[old], reverse[new] = new, old
                labels[old].append((name, index))
            else:
                require(old == new and old in ('0', '1', 'x', 'z'), f'{name}[{index}]: literal changed')
        old_attrs = {key: value for key, value in x['attributes'].items() if key != 'ROUTING'}
        new_attrs = {key: value for key, value in y['attributes'].items() if key != 'ROUTING'}
        require(old_attrs == new_attrs, f'{name}: non-routing net attributes changed')
        if x['attributes'].get('ROUTING') != y['attributes'].get('ROUTING'):
            changed_routes.append(name)

    def normalize(bits, candidate):
        result = []
        for bit in bits:
            if type(bit) is int:
                require(bit in (reverse if candidate else forward), f'unnamed or unknown signal bit {bit}')
                result.append(reverse[bit] if candidate else bit)
            else:
                require(bit in ('0', '1', 'x', 'z'), f'unknown signal literal {bit!r}')
                result.append(bit)
        return result

    connections = []
    pinmaps = []
    for candidate, module in enumerate(modules):
        connections.append({name: {pin: normalize(bits, candidate) for pin, bits in cell['connections'].items()}
                            for name, cell in module['cells'].items()})
        pinmaps.append({name: pinmap(cell, name) for name, cell in module['cells'].items()})
    for name in a['ports']:
        x, y = a['ports'][name], b['ports'][name]
        require(set(x) == set(y) == {'direction', 'bits'}, f'{name}: top-level port schema changed')
        require(x['direction'] == y['direction'] and normalize(x['bits'], False) == normalize(y['bits'], True),
                f'{name}: external port connection changed')

    require(producer in a['cells'], 'selected producer missing')
    links = [connection[producer].get('Q') for connection in connections]
    require(links[0] == links[1] and len(links[0]) == 1 and type(links[0][0]) is int,
            'internal producer output identity changed')
    link = links[0][0]
    consumers = []
    for index, module in enumerate(modules):
        users, drivers = [], []
        for name, cell in module['cells'].items():
            require(set(cell) == {'hide_name', 'type', 'parameters', 'attributes', 'port_directions', 'connections'},
                    f'{name}: cell schema changed')
            require(set(cell['port_directions']) == set(cell['connections']), f'{name}: inconsistent port inventory')
            for pin, bits in connections[index][name].items():
                if link in bits:
                    direction = cell['port_directions'][pin]
                    require(direction in ('input', 'output'), 'internal link has an inout observer')
                    (users if direction == 'input' else drivers).extend((name, pin) for bit in bits if bit == link)
        require(drivers == [(producer, 'Q')], 'internal link driver is not exclusively producer Q')
        require(len(users) == 1, 'internal producer Q is not single-use')
        consumers.append(users[0][0])
        require(all(link not in normalize(port['bits'], index) for port in module['ports'].values()),
                'internal producer Q is externally observable')
    require(consumers[0] == consumers[1] and consumers[0] != producer, 'exclusive consumer identity changed')
    consumer = consumers[0]
    pair = {producer, consumer}
    require(connections[0][consumer]['Q'] == connections[1][consumer]['Q'], 'public consumer output identity changed')
    require(link != connections[0][consumer]['Q'][0], 'producer and consumer outputs alias')

    # Every outside cell is checked, including every generated route-through
    # cell. No graph intersection, cell-type filtering or buffer collapsing.
    outside_inputs = 0
    for name in sorted(set(a['cells']) - pair):
        x, y = a['cells'][name], b['cells'][name]
        states = [{pin: values[0] for pin, values in maps[name].items()} for maps in pinmaps]
        require(states[0] == states[1], f'{name}: outside logical pin state/inversion changed')
        for key in ('hide_name', 'type', 'parameters', 'port_directions', 'attributes'):
            require(x[key] == y[key], f'{name}: outside {key} changed')
        require(connections[0][name] == connections[1][name], f'{name}: outside functional connectivity changed')
        outside_inputs += sum(direction == 'input' for direction in x['port_directions'].values())

    networks = []
    external = set()
    for index, module in enumerate(modules):
        network = {}
        for name in pair:
            cell = module['cells'][name]
            match = re.fullmatch(r'MISTRAL_ALUT([2-6])', cell['type'])
            require(match is not None, f'{name}: unsupported pair primitive')
            width = int(match.group(1))
            pins = 'ABCDEF'[:width]
            require(set(cell['connections']) == set(pins) | {'Q'}, f'{name}: unexpected pair ports')
            require(set(cell['parameters']) == {'LUT'}, f'{name}: unexpected pair parameters')
            mask = cell['parameters']['LUT']
            require(len(mask) == 1 << width and set(mask) <= {'0', '1'}, f'{name}: undefined or malformed truth table')
            require(cell['port_directions']['Q'] == 'output' and pinmaps[index][name]['Q'][0] == 0,
                    f'{name}: unsupported output polarity/direction')
            require(all(len(bits) == 1 for bits in connections[index][name].values()), f'{name}: nonscalar pair port')
            data = []
            for pin in pins:
                require(cell['port_directions'][pin] == 'input', f'{name}.{pin}: unexpected direction')
                state = pinmaps[index][name][pin][0]
                require(state in (0, 3), f'{name}.{pin}: unsupported input state')
                signal = connections[index][name][pin][0]
                require(type(signal) is int, f'{name}.{pin}: pair has unsupported literal input')
                require(signal != connections[index][consumer]['Q'][0], 'pair feeds back from consumer output')
                if signal != link:
                    external.add(signal)
                data.append((signal, state == 3))
            network[name] = (data, int(mask, 2))
        require(all(signal != link for signal, _ in network[producer][0]), 'producer self-feedback')
        require(sum(signal == link for signal, _ in network[consumer][0]) == 1, 'consumer internal-link count changed')
        networks.append(network)
    for name in pair:
        x, y = a['cells'][name], b['cells'][name]
        require(x['hide_name'] == y['hide_name'], f'{name}: pair visibility changed')
        attrs = [{key: value for key, value in cell['attributes'].items()
                  if key not in ('FES_PINMAP_V1', 'NEXTPNR_BEL')} for cell in (x, y)]
        require(attrs[0] == attrs[1], f'{name}: unexpected pair attribute change')
    require(selected_input in a['cells'][producer]['connections'], 'selected input does not exist')
    require(a['cells'][producer]['attributes']['NEXTPNR_BEL'] == b['cells'][producer]['attributes']['NEXTPNR_BEL'],
            'producer unexpectedly moved')
    require(len(external) <= 11, 'pair proof exceeds exhaustive support bound')
    external = sorted(external)
    for assignment in itertools.product((False, True), repeat=len(external)):
        env = dict(zip(external, assignment))
        outputs = []
        for network in networks:
            def evaluate(name, internal):
                pins, mask = network[name]
                row = 0
                for position, (signal, inverted) in enumerate(pins):
                    value = internal if signal == link else env[signal]
                    row |= (int(value) ^ int(inverted)) << position
                return bool((mask >> row) & 1)
            outputs.append(evaluate(consumer, evaluate(producer, False)))
        require(outputs[0] == outputs[1], f'consumer truth table mismatch at assignment {assignment}')

    # Serialized ALM mode changes must be precisely the two-LUT width change;
    # unrelated LAB mode/control state is still checked in full.
    old_attrs = {key: value for key, value in a['attributes'].items() if key != 'FES_LABSTATE_V1'}
    new_attrs = {key: value for key, value in b['attributes'].items() if key != 'FES_LABSTATE_V1'}
    require(old_attrs == new_attrs, 'non-LAB module attributes changed')
    lab_states = [unpack(module['attributes']['FES_LABSTATE_V1']) for module in modules]
    require(set(lab_states[0]) == set(lab_states[1]) == {'device', 'labs'}, 'LAB-state schema changed')
    require(lab_states[0]['device'] == lab_states[1]['device'], 'device changed')
    labs = []
    for state in lab_states:
        table = {}
        for row in state['labs']:
            require(len(row) == 4 and len(row[3]) == 62, 'incomplete LAB state')
            key = tuple(row[:3])
            require(key not in table, 'duplicate LAB state')
            table[key] = row[3]
        labs.append(table)
    require(set(labs[0]) == set(labs[1]), 'LAB identity coverage changed')
    affected = {site(module['cells'][name]) for module in modules for name in pair}
    mode_changes = []
    for key in labs[0]:
        for index, (old, new) in enumerate(zip(labs[0][key], labs[1][key])):
            if old == new:
                continue
            alm = (index - 2) // 6
            require(index >= 2 and (index - 2) % 6 == 0 and (*key, alm) in affected,
                    f'unrelated serialized LAB state changed at {key}:{index}')
            for side in range(2):
                expected = any(cell['type'] == 'MISTRAL_ALUT6' and site(cell) == (*key, alm)
                               for cell in modules[side]['cells'].values())
                require(labs[side][key][index] == int(expected), 'serialized LUT6 mode disagrees with occupants')
            mode_changes.append({'lab': list(key), 'alm': alm, 'before_l6': old, 'after_l6': new})
    settings_changes = [{'key': key, 'before': a['settings'].get(key), 'after': b['settings'].get(key)}
                        for key in sorted(set(a['settings']) | set(b['settings']))
                        if a['settings'].get(key) != b['settings'].get(key)]
    require(settings_changes in ([], [{'key': 'gpurouter/localInputEscape', 'before': None, 'after': '0 '}]),
            'unexpected serialized settings difference')
    generated = sorted(name for name, cell in a['cells'].items()
                       if cell['type'] == 'MISTRAL_BUF' and '$ROUTETHRU' in name)
    return {
        'module': module_name, 'producer': producer, 'consumer': consumer, 'selected_input': selected_input,
        'complete_cell_inventory': len(a['cells']), 'complete_net_name_inventory': len(a['netnames']),
        'bijective_named_signal_bits': len(forward), 'external_ports_unchanged': len(a['ports']),
        'outside_pair_cells_unchanged': len(a['cells']) - 2, 'outside_pair_input_ports_checked': outside_inputs,
        'outside_pair_pin_states_checked': sum(len(pinmaps[0][name]) for name in a['cells'] if name not in pair),
        'outside_pair_functions_connections_pin_states_attributes_identical': True,
        'route_generated_buffers_exactly_matched': len(generated),
        'route_generated_buffer_identity_sha256': hashlib.sha256(json.dumps(generated).encode()).hexdigest(),
        'all_net_alias_classes_and_nonrouting_attributes_preserved': True,
        'internal_link_single_use_and_not_external': True,
        'external_signal_count': len(external), 'external_signal_identities': [sorted(labels[bit]) for bit in external],
        'assignments_exhaustively_checked': 1 << len(external), 'consumer_output_equivalent': True,
        'producer_internal_output_may_change': True, 'changed_route_attributes': len(changed_routes),
        'serialized_alm_mode_changes': mode_changes, 'serialized_settings_differences': settings_changes,
    }


def selftest(documents, producer, selected_input):
    candidate = documents[1]
    module = next(iter(candidate['modules'].values()))
    original = proof(documents, producer, selected_input)
    consumer = original['consumer']
    outside = next(name for name, cell in module['cells'].items()
                   if name not in (producer, consumer) and cell['type'] == 'MISTRAL_BUF' and '$ROUTETHRU' in name)
    tests = []

    def reject(label, mutate, restore):
        mutate()
        try:
            try:
                proof(documents, producer, selected_input)
            except (ValueError, KeyError) as error:
                tests.append({'mutation': label, 'rejected': True, 'reason': str(error)})
            else:
                raise AssertionError(f'mutation was accepted: {label}')
        finally:
            restore()

    params = copy.deepcopy(module['cells'][outside]['parameters'])
    reject('outside primitive parameter changed',
           lambda: module['cells'][outside]['parameters'].update({'MUTATED': '1'}),
           lambda: module['cells'][outside].update(parameters=params))
    saved = module['cells'][outside]['attributes']['FES_PINMAP_V1']
    mutated = unpack(saved)
    mutated['pins']['A'][0] = 3 if mutated['pins']['A'][0] == 0 else 0
    reject('outside input inversion changed',
           lambda: module['cells'][outside]['attributes'].update(FES_PINMAP_V1=pack(mutated)),
           lambda: module['cells'][outside]['attributes'].update(FES_PINMAP_V1=saved))
    cell = module['cells'][outside]
    reject('route-generated buffer removed', lambda: module['cells'].pop(outside),
           lambda: module['cells'].update({outside: cell}))
    old_bits = cell['connections']['A']
    reject('second observer of producer internal link',
           lambda: cell['connections'].update(A=module['cells'][producer]['connections']['Q']),
           lambda: cell['connections'].update(A=old_bits))
    mask = module['cells'][consumer]['parameters']['LUT']
    reject('consumer truth table complemented',
           lambda: module['cells'][consumer]['parameters'].update(LUT=''.join('1' if bit == '0' else '0' for bit in mask)),
           lambda: module['cells'][consumer]['parameters'].update(LUT=mask))
    name = next(name for name, net in module['netnames'].items() if any(type(bit) is int for bit in net['bits']))
    old = module['netnames'][name]['bits']
    altered = list(old)
    position = next(index for index, bit in enumerate(old) if type(bit) is int)
    altered[position] = 1000000000
    reject('named-net alias or connection identity changed',
           lambda: module['netnames'][name].update(bits=altered),
           lambda: module['netnames'][name].update(bits=old))
    port_name = next(iter(module['ports']))
    old = module['ports'][port_name]['bits']
    reject('external port observes producer internal link',
           lambda: module['ports'][port_name].update(bits=module['cells'][producer]['connections']['Q']),
           lambda: module['ports'][port_name].update(bits=old))
    require(proof(documents, producer, selected_input) == original, 'mutation tests failed to restore documents')
    return {'unchanged_valid_pair_accepted': True, 'negative_mutations': tests, 'all_mutations_rejected': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate', nargs='?', type=Path, default=ROOT / 'candidate/routed.json')
    parser.add_argument('--baseline', type=Path, default=ROOT / 'baseline/routed.json')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    paths = [args.baseline.resolve(), args.candidate.resolve()]
    documents = [read(path) for path in paths]
    selection = read(ROOT / 'selection.json')
    receipts = [read(path.parent / 'receipt.json') for path in paths]
    binary = receipts[0]['binary_sha256']
    require(binary == receipts[1]['binary_sha256'], 'compiler binary receipt hashes differ')
    require(digest(Path(receipts[0]['nextpnr_command'][0])) == binary, 'frozen compiler binary hash mismatch')
    require(receipts[1]['nextpnr_command'] == receipts[0]['nextpnr_command'] +
            ['--reassociate-producer', selection['producer'], '--reassociate-input', selection['input']],
            'route commands differ beyond selected reassociation')
    hashes = [digest(path) for path in paths]
    for path, receipt, value in zip(paths, receipts, hashes):
        require(receipt['artifacts'][path.name] == value, f'{path}: artifact receipt hash mismatch')
    result = proof(documents, selection['producer'], selection['input'])
    result.update(schema=2, evidence='final routed JSON Boolean and complete functional graph proof',
                  before={'path': str(paths[0]), 'sha256': hashes[0]}, after={'path': str(paths[1]), 'sha256': hashes[1]},
                  same_compiler_binary_sha256=binary, commands_differ_only_by_reassociation=True,
                  checker_sha256=digest(Path(__file__).resolve()),
                  limits=['No RBF decode or emitted physical-mask proof is performed by this checker.',
                          'No timing, routing-electrical, board IO or hardware acceptance is established.',
                          'The producer internal output may change; equivalence is proved at consumer Q.',
                          'All primitive functions outside the pair are assumed to retain their documented semantics.'])
    (ROOT / 'proof-routed.json').write_text(json.dumps(result, indent=2) + '\n')
    if args.self_test:
        tests = selftest(documents, selection['producer'], selection['input'])
        tests['checker_sha256'] = result['checker_sha256']
        (ROOT / 'proof-routed-selftest.json').write_text(json.dumps(tests, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('complete_cell_inventory', 'complete_net_name_inventory',
                        'outside_pair_cells_unchanged', 'outside_pair_input_ports_checked',
                        'route_generated_buffers_exactly_matched', 'assignments_exhaustively_checked',
                        'consumer_output_equivalent', 'serialized_alm_mode_changes')}, indent=2))


if __name__ == '__main__':
    main()
