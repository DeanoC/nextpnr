from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parent
old=json.loads((root.parent/'move-margins-20261022/baseline/receipt.json').read_text())
selection=json.loads((root/'selection.json').read_text())
wrapper=str(root.parents[1]/'scripts/gpu-run')
env=dict(os.environ);env['NEXTPNR_REQUIRE_GPU']='1'
for label,candidate in [('baseline',False),('candidate',True)]:
 p=root/label;p.mkdir(exist_ok=False)
 cmd=[x for x in old['command'] if x!='--gpu-cpu'];cmd[0]=str(root/'nextpnr-mistral')
 if candidate:cmd+=['--reassociate-producer',selection['producer'],'--reassociate-input',selection['input']]
 command=[wrapper,'--phase-lease','--owner','pcxt-timing','--label','pcxt-factor-'+label,'--',*cmd]
 receipt={'command':command,'nextpnr_command':cmd,'evidence':'leased GPU host diagnostic; not a producer or hardware acceptance','limit':'native bounded router iterations; no external GPU-job termination','binary_sha256':hashlib.file_digest(open(cmd[0],'rb'),'sha256').hexdigest()}
 start=time.monotonic()
 with (p/'nextpnr.log').open('w') as log:receipt['returncode']=subprocess.run(command,cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 receipt['charged_seconds']=time.monotonic()-start
 receipt['artifacts']={f.name:hashlib.file_digest(f.open('rb'),'sha256').hexdigest() for f in p.iterdir() if f.suffix in ['.json','.rbf']}
 (p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,receipt.get('returncode'),receipt['charged_seconds'],flush=True)
 if not all((p/n).exists() for n in ['routed.json','timing.json','endpoints.json','diagnostic.rbf']):break
