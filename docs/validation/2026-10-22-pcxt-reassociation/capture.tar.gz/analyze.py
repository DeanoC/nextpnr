from pathlib import Path
import json,collections
root=Path(__file__).resolve().parent
runs={};eps={}
for name in ['baseline','candidate']:
 t=json.loads((root/name/'timing.json').read_text());e=json.loads((root/name/'endpoints.json').read_text());eps[name]=e
 groups=collections.defaultdict(list)
 for k,rows in e['endpoints'].items():
  for r in rows:
   if r['setup_timed']:groups[str((r['launch'],r['capture'],r['setup_window']))].append((r['setup'],k))
 runs[name]={'timing_summary':t['timing_summary'],'fmax':t['fmax'],'complete':e['complete'],'unsupported':len(e['unsupported']),'endpoints':len(e['endpoints']),'setup_failure_rows':sum(r['setup_timed'] and r['setup']<0 for rs in e['endpoints'].values() for r in rs),'hold_failure_rows':sum(r['hold_related'] and r['hold']<0 for rs in e['endpoints'].values() for r in rs),'groups':{k:{'count':len(v),'failures':sum(s<0 for s,n in v),'wns_ps':min(v)[0],'worst':sorted(v)[:8]} for k,v in groups.items()}}
a,b=(eps[n] for n in ['baseline','candidate'])
assert set(a['endpoints'])==set(b['endpoints'])
deltas=[]
for key,rows in a['endpoints'].items():
 def identity(r):return tuple(r['launch']),tuple(r['capture']),r['setup_timed'],r['hold_related'],r['setup_window']
 ar={identity(r):r for r in rows};br={identity(r):r for r in b['endpoints'][key]};assert len(ar)==len(rows) and len(br)==len(b['endpoints'][key]);assert set(ar)==set(br),key
 for k,r in ar.items():
  s=br[k]
  if s!=r:deltas.append({'endpoint':json.loads(key),'launch':r['launch'],'capture':r['capture'],'before':r,'after':s,'setup_delta':s['setup']-r['setup'] if r['setup_timed'] else 0,'hold_delta':s['hold']-r['hold'] if r['hold_related'] else 0})
result={'evidence':'leased GPU host diagnostic; no hardware','runs':runs,'endpoint_identities_unchanged':True,'changed_rows':len(deltas),'setup_improved_rows':sum(d['setup_delta']>0 for d in deltas),'setup_worsened_rows':sum(d['setup_delta']<0 for d in deltas),'positive_hold_decreases':sum(d['before']['hold_related'] and d['before']['hold']>0 and d['hold_delta']<0 for d in deltas),'metadata_identical':{k:a[k]==b[k] for k in ['clocks','unsupported','unsupported_details','io_constraints','physical_obligations']},'route_allowance':'uncapped by user','charged_seconds':sum(json.loads((root/n/'receipt.json').read_text())['charged_seconds'] for n in runs),'previous_charged_seconds':8266.538578426464}
result['cumulative_charged_seconds']=result['previous_charged_seconds']+result['charged_seconds']
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');(root/'endpoint-deltas.json').write_text(json.dumps(deltas,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='runs'},indent=2))
for n,r in runs.items():print(n,r['setup_failure_rows'],r['hold_failure_rows'],[(k,g['failures'],g['wns_ps']) for k,g in r['groups'].items() if g['failures']])
