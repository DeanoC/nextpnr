from pathlib import Path
import hashlib,json,subprocess,time
root=Path(__file__).resolve().parent
prior=root.parent/'reassociate-20261022'
module=next(iter(json.loads((prior/'transformed-placed.json').read_text())['modules'].values()))
timing=json.loads((prior/'candidate/timing.json').read_text())
paths=[p for p in timing['critical_paths'] if p['from']==p['to']=='posedge clocks[0]']
worst=min(paths,key=lambda p:p['max_delay']-sum(s['delay'] for s in p['path']))
logic=[s['from']['cell'] for s in worst['path'] if s['type']=='logic' and s['from']['cell'] in module['cells']]
assert module['cells'][logic[1]]['type']=='MISTRAL_ALUT5'
assert int(module['cells'][logic[1]]['parameters']['LUT'],2)==0x10000
binary=prior/'nextpnr-mistral'
identity=json.loads((prior/'source-identity.json').read_text())
(root/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for stage,name,pin,source in [('step1',logic[1],'E',prior/'transformed-placed.json'),('step2',logic[2],'F',root/'step1/placed.json')]:
 d=root/stage;d.mkdir(exist_ok=False)
 selection={'producer':name,'input':pin,'prior_input':str(source),'purpose':'bypass current critical reduction cascade; no route or timing acceptance'}
 (d/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
 cmd=[str(binary),'--device','5CSEBA6U23I7','--json',str(source),'--qsf',str(prior/'inputs/constraints.qsf'),'--sdc',str(prior/'inputs/clocks.sdc'),'--no-pack','--no-place','--no-route','--reassociate-producer',name,'--reassociate-input',pin,'--write',str(d/'placed.json')]
 start=time.monotonic()
 with (d/'prepare.log').open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 receipt={'command':cmd,'returncode':code,'elapsed_seconds':time.monotonic()-start,'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'input_sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'evidence':'unrouted proof and placement diagnostic only'}
 if (d/'placed.json').exists():receipt['output_sha256']=hashlib.file_digest((d/'placed.json').open('rb'),'sha256').hexdigest()
 (d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(stage,code,flush=True)
 if code:break
