"""Independent exhaustive proof plus canonical-net/unchanged-cell checks for one step."""
from pathlib import Path
import collections,hashlib,itertools,json,sys
stage=Path(sys.argv[1]).resolve()
selection=json.loads((stage/'selection.json').read_text())
before=Path(selection['prior_input']);after=stage/'placed.json'
docs=[json.loads(p.read_text()) for p in (before,after)]
assert set(docs[0]['modules'])==set(docs[1]['modules'])
assert len(docs[0]['modules'])==1
mods=[next(iter(d['modules'].values())) for d in docs]
assert set(mods[0]['cells'])==set(mods[1]['cells'])
assert set(mods[0]['netnames'])==set(mods[1]['netnames'])
bits=[]
for m in mods:
 groups=collections.defaultdict(list)
 for name,net in m['netnames'].items():
  for index,bit in enumerate(net['bits']):
   if isinstance(bit,int):groups[bit].append((name,index))
 bits.append({bit:tuple(sorted(aliases)) for bit,aliases in groups.items()})
assert set(bits[0].values())==set(bits[1].values()),'net alias partition changed'
def canon(value,mapping):return mapping[value] if isinstance(value,int) else value
def connections(m,mapping):
 return {n:{p:tuple(canon(b,mapping) for b in bs) for p,bs in cell['connections'].items()} for n,cell in m['cells'].items()}
conns=[connections(m,bi) for m,bi in zip(mods,bits)]
for name in mods[0]['netnames']:
 a,b=(m['netnames'][name] for m in mods)
 assert tuple(canon(v,bits[0]) for v in a['bits'])==tuple(canon(v,bits[1]) for v in b['bits']),('net alias',name)
 assert {k:v for k,v in a.items() if k!='bits'}=={k:v for k,v in b.items() if k!='bits'},('net attributes',name)
for key in ('settings','attributes'):
 assert mods[0][key]==mods[1][key],key
assert set(mods[0]['ports'])==set(mods[1]['ports'])
for name in mods[0]['ports']:
 a,b=(m['ports'][name] for m in mods)
 assert tuple(canon(v,bits[0]) for v in a['bits'])==tuple(canon(v,bits[1]) for v in b['bits']),('port',name)
 assert {k:v for k,v in a.items() if k!='bits'}=={k:v for k,v in b.items() if k!='bits'},('port metadata',name)
producer=selection['producer'];link=conns[0][producer]['Q'][0]
uses=[(n,p) for n,c in mods[0]['cells'].items() for p in c['connections'] if c['port_directions'][p]=='input' and link in conns[0][n][p]]
assert len(uses)==1
consumer=uses[0][0];pair={producer,consumer}
assert all(link not in tuple(canon(x,bits[0]) for x in port['bits']) for port in mods[0]['ports'].values())
def states(cell):
 pins=json.loads(bytes.fromhex(cell['attributes']['FES_PINMAP_V1']).decode())['pins']
 return {p:state[0] for p,state in pins.items()}
def state(cell,pin):
 s=states(cell)[pin];assert s in (0,3),(pin,s)
 return s==3
physical={'FES_PINMAP_V1','NEXTPNR_BEL'}
changed_locations=[];changed_pinmaps=[]
for name in mods[0]['cells']:
 a,b=(m['cells'][name] for m in mods)
 if a['attributes'].get('NEXTPNR_BEL')!=b['attributes'].get('NEXTPNR_BEL'):changed_locations.append(name)
 if a['attributes'].get('FES_PINMAP_V1')!=b['attributes'].get('FES_PINMAP_V1'):changed_pinmaps.append(name)
 assert {k:v for k,v in a['attributes'].items() if k not in physical}=={k:v for k,v in b['attributes'].items() if k not in physical},('attrs',name)
 if name not in pair:
  assert a['type']==b['type'] and a['parameters']==b['parameters'] and a['port_directions']==b['port_directions'] and conns[0][name]==conns[1][name],('unchanged cell',name)
  assert states(a)==states(b),('logical pin state',name)
 else:
  assert {k:v for k,v in a['parameters'].items() if k!='LUT'}=={k:v for k,v in b['parameters'].items() if k!='LUT'}
for name in pair:assert conns[0][name]['Q']==conns[1][name]['Q']
assert set(changed_locations).issubset(pair)
signals=set()
for m,cs in zip(mods,conns):
 for name in pair:
  for pin,ns in cs[name].items():
   if m['cells'][name]['port_directions'][pin]=='input' and ns[0]!=link:signals.add(ns[0])
signals=sorted(signals);assert len(signals)<=11
for assignment in itertools.product((False,True),repeat=len(signals)):
 environment=dict(zip(signals,assignment));outputs=[]
 for m,cs in zip(mods,conns):
  def lut(name,internal):
   c=m['cells'][name];width=int(c['type'][-1]);row=0
   assert c['type']==f'MISTRAL_ALUT{width}'
   for bit,pin in enumerate('ABCDEF'[:width]):
    net=cs[name][pin][0];value=internal if net==link else environment[net]
    row|=(int(value)^int(state(c,pin)))<<bit
   return bool((int(c['parameters']['LUT'],2)>>row)&1)
  outputs.append(lut(consumer,lut(producer,False)))
 assert outputs[0]==outputs[1],assignment
result={'before':str(before),'after':str(after),'before_sha256':hashlib.file_digest(before.open('rb'),'sha256').hexdigest(),'after_sha256':hashlib.file_digest(after.open('rb'),'sha256').hexdigest(),'producer':producer,'consumer':consumer,'selected_input':selection['input'],'external_signals':len(signals),'assignments':1<<len(signals),'consumer_output_equivalent':True,'producer_output_unobserved_except_consumer':True,'other_cell_types_functions_connections_and_logical_pin_states_unchanged':True,'canonical_net_alias_partition_preserved':True,'top_ports_net_metadata_and_settings_unchanged':True,'changed_locations':changed_locations,'changed_physical_pinmaps':changed_pinmaps,'evidence':'independent structural proof only; no routed timing or hardware acceptance'}
(stage/'proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
