#!/usr/bin/env python3
"""Independent replay/review of root-authored full graph and final timing proofs."""
from pathlib import Path
import contextlib,hashlib,importlib,io,json,sys
HERE=Path(__file__).resolve().parent;A=HERE.parent;sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
inputs={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*.py'))};checks=[]
def compare_write(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs';checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
log=io.StringIO()
with contextlib.redirect_stdout(log):
 g=importlib.import_module('prove_graph');g.write=compare_write;g.main()
 for name in ('test_graph_checks','test_budget_checks','test_native_port_identity'):
  c=importlib.import_module(name);c.write=compare_write;c.main()
 n=importlib.import_module('verify_topology');n.write=compare_write;n.main()
 t=importlib.import_module('compare_timing');t.R=HERE;t.main()
assert (HERE/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
assert inputs=={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*.py'))}
g=read(A/'graph-proof.json');t=read(A/'route-comparison.json');n=read(A/'topology-proof.json');d=read(A/'decision-ledger.json')
assert len(g['accepted_cells'])==1 and g['accepted_cells'][0]['pins']==['A','C'] and len(g['accepted_cells'][0]['all_raw_net_rows'])==8
assert all(x['before_output']==x['after_output'] for x in g['accepted_cells'][0]['all_raw_net_rows'])
assert set(g['changed_canonical_net_bits'])=={57715,57717}
assert d['preceding_repair_decisions_equal'] and d['first_four_complete_decisions_equal'] and len(d['additional_accepted_trials'])==1
assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal'] and len(t['every_endpoint_row'])==17199
assert t['native_margin_delta_counts']=={'setup':{'improved':4,'unchanged':17190},'hold':{'unchanged':17194}}
assert t['independent_complete_clock_guard']['pass'] and t['independent_emitted_inventory_guard']['nonregression_and_inventory_pass'] and not t['independent_emitted_inventory_guard']['all_violations']
assert t['runs']['budget4']['setup']['failures']==10 and t['runs']['budget16']['setup']['failures']==10
assert all(x['unsupported_count']==105 and not x['complete'] and x['hold']['failures']==0 for x in t['runs'].values())
assert n['selected_nets']==4 and n['stationary_users']==2 and n['changed_physical_users']==2 and n['retained_original_wire_tuples']==19
changed=[x for x in t['every_endpoint_row'] if x['margin_delta_ps']['setup']]
result={'passed':True,'reviewer':'timing_strategy','review_script_sha256':sha(__file__),'inputs':inputs,'exact_replays':checks,'complete_endpoint_rows':17199,'native_margin_delta_counts':t['native_margin_delta_counts'],'setup_failure_counts':{k:v['setup']['failures'] for k,v in t['runs'].items()},'whole_system_setup_minimum_ps':{k:v['setup']['minimum_ps'] for k,v in t['runs'].items()},'changed_setup_rows':changed,'accepted_cell':g['accepted_cells'][0]['cell'],'accepted_pins':['A','C'],'complete_truth_rows':8,'native_topology':{k:n[k] for k in ('selected_nets','stationary_users','changed_physical_users','retained_original_wire_tuples')},'charged_route_seconds':0,'findings':['Complete graph, alias, settings/LAB, physical ownership and final setup/hold/native clock inventories replay exactly. Only two canonical input trees and their logged A/C endpoints change.','All first-four decisions and preceding route/LUT6 repair match; one additional sixth-trial permutation is proven directly between the complete final checkpoints. Intermediate state is not independently snapshotted.','Four MDA setup rows improve62ps, no positive-margin regressions occur, all17194 holds are exact. Ten setup failures remain; whole-system worst slack stays-434ps.','The complete native4-net frontier preserves every stationary path and source-root strength. Source/driver metadata and all8 logical rows remain exact.'],'limits':['Independent review of root-authored graph/timing checkers and exact offline replay. New native selection/readback integration was authored by this same reviewer and is separately subject to source review; this is not an independent implementation of that integration.','Emitted final reports use the recorded final timing frame; no reload STA or new reference-free report is invented. Live pass guards remain separately evidenced by the frozen implementation/logs.','Still10 setup failures,105 unsupported entries and complete=false. No hardware, electrical qualification or emitted-RBF mask equivalence is claimed.']}
(HERE/'replay.log').write_text(log.getvalue());(HERE/'review.json').write_bytes(encoded(result));print(json.dumps({'passed':True,'review_sha256':sha(HERE/'review.json'),'exact_replays':len(checks)},sort_keys=True))
