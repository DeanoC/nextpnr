#!/usr/bin/env python3
"""Test the saved graph/native-port bridge, including actual M10K bus bits."""
from copy import deepcopy
import json
from native_port_identity import native_identity, native_physical_port
from permutation_graph_core import pinmap
from support import HERE, ROOT, read, need, sha, write


def main():
    graph = read(ROOT / 'route-budget4/routed.json')
    cells = next(iter(graph['modules'].values()))['cells']
    name = 'system.machine.isa.slots[2].genblk1.mda.card.card.vram.3.0.0'
    original = cells[name]
    need(original['connections']['B1DATA'] == [57716, 57715], 'actual fixture changed')
    positives = []
    for index in [0, 1]:
        raw = [name, 'B1DATA', index]
        physical = native_physical_port(cells, raw, pinmap)
        need(physical['port'] == f'B1DATA[{index}]' and physical['index'] == 0, 'wrong native bit identity')
        need(physical['physical_pins'] == [f'DATABOUT[{index}]'], 'wrong actual saved map')
        positives.append({'serialized': raw, 'native': physical})
    scalar = deepcopy(original)
    scalar['connections'] = {'B1DATA[1]': [57715]}
    need(native_identity({name: scalar}, [name, 'B1DATA[1]', 0]) == [name, 'B1DATA[1]', 0], 'literal scalar renamed')
    rejected = []

    def bad(label, cell, raw):
        try:
            native_physical_port({name: cell}, raw, pinmap)
        except (ValueError, KeyError, TypeError) as error:
            rejected.append({'case': label, 'rejection': str(error)})
            return
        raise AssertionError('invalid native identity accepted: ' + label)

    for index in [-1, 2, True, 0.0]:
        bad('invalid index ' + repr(index), original, [name, 'B1DATA', index])
    bad('missing logical port', original, [name, 'B1DATA[0]', 0])
    duplicate = deepcopy(original)
    duplicate['connections']['B1DATA[1]'] = [57715]
    bad('ambiguous flattened port', duplicate, [name, 'B1DATA', 1])
    for key, value in [('missing exact indexed map', None), ('missing physical pin', [0])]:
        cell = deepcopy(original)
        mapping = pinmap(cell)
        if value is None:
            del mapping['B1DATA[1]']
        else:
            mapping['B1DATA[1]'] = value
        cell['attributes']['FES_PINMAP_V1'] = json.dumps({'count': len(mapping), 'pins': mapping}).encode().hex()
        bad(key, cell, [name, 'B1DATA', 1])
    write('native-port-identity-proof.json', {
        'passed': True, 'actual_positive_cases': positives, 'literal_scalar_preserved': True,
        'corruption_rejections': rejected, 'resolver_sha256': sha(HERE / 'native_port_identity.py'),
        'test_sha256': sha(__file__), 'actual_graph_sha256': sha(ROOT / 'route-budget4/routed.json'),
        'scope': 'Exact serialized-to-native identity controls; actual native driver/pin/root decoding remains required.',
    })
    print(json.dumps({'passed': True, 'actual_vector_cases': len(positives), 'rejections': len(rejected)}))


if __name__ == '__main__':
    main()
