#!/usr/bin/env python3
"""Synthetic fail-closed tests plus an exact prior full-graph no-op control."""
from copy import deepcopy
import json
from pathlib import Path
from prove_graph import prove, decisions, pinmap, transposed_mask, route_tree
from support import HERE, ROOT, need, read, write, sha, reference_folder


def encoded(pins):
    return json.dumps({'count': len(pins), 'pins': pins}, sort_keys=True, separators=(',', ':')).encode().hex()


def cell(kind, connections, directions, pins, bel, mask=None):
    return {'type': kind, 'hide_name': 0, 'parameters': {} if mask is None else {'LUT': mask},
            'attributes': {'NEXTPNR_BEL': bel, 'NEXTPNR_BEL_STRENGTH': '00000000000000000000000000000001',
                           'FES_PINMAP_V1': encoded(pins)}, 'port_directions': directions, 'connections': connections}


def fixture(width=3):
    pins='ABCDE'[:width]; physical=['A','B','C','E0','F0'][:width]
    mask=(0x7937a653 & ((1 << (1 << width))-1))
    cells={}; nets={}; target_pins={p:[3 if i==0 else 0,physical[i]] for i,p in enumerate(pins)}
    target_pins['Q']=[0,'COMBOUT']
    cells['target']=cell('MISTRAL_ALUT'+str(width), {**{p:[10+i] for i,p in enumerate(pins)},'Q':[40]},
                         {**{p:'input' for p in pins},'Q':'output'},target_pins,'MISTRAL_COMB.18.9.12',format(mask,'0%db'%(1<<width)))
    # A stationary ALM mate and two independent observers on every changed net.
    cells['mate']=cell('MISTRAL_ALUT2',{'A':[70],'B':[71],'Q':[72]}, {'A':'input','B':'input','Q':'output'},
                       {'A':[0,'A'],'B':[0,'B'],'Q':[0,'COMBOUT']},'MISTRAL_COMB.18.9.13','0110')
    for i,p in enumerate(pins):
        bit=10+i
        cells['driver'+p]=cell('MISTRAL_FF',{'Q':[bit]},{'Q':'output'},{'Q':[0,'Q']},'FF.source.'+p)
        for j in range(2):
            cells[f'watch{p}{j}']=cell('MISTRAL_FF',{'DATAIN':[bit]},{'DATAIN':'input'}, {'DATAIN':[0,'DATAIN']},f'FF.watch.{p}.{j}')
        route=f'W{bit}.root;;1;W{bit}.stationary;P{bit}.stationary;2;W{bit}.watch0;P{bit}.watch0;1;W{bit}.watch1;P{bit}.watch1;1;T.{physical[i]};P{bit}.target.{physical[i]};1'
        for alias in (f'net{bit}',f'alias{bit}'):
            nets[alias]={'hide_name':0,'bits':[bit],'attributes':{'ROUTING':route,'custom':'fixed'}}
    cells['capture']=cell('MISTRAL_FF',{'DATAIN':[40]},{'DATAIN':'input'},{'DATAIN':[0,'DATAIN']},'FF.capture')
    nets['output']={'hide_name':0,'bits':[40],'attributes':{'ROUTING':'W40.root;;1;W40.sink;P40.sink;1'}}
    for bit in (70,71,72,99):
        nets['outside'+str(bit)]={'hide_name':0,'bits':[bit],'attributes':{'ROUTING':f'W{bit}.root;;1'}}
    left={'creator':'synthetic','modules':{'top':{'settings':{'strict':1},'attributes':{'FES_LABSTATE_V1':'unchanged'},'ports':{},'cells':cells,'netnames':nets}}}
    right=deepcopy(left); new=right['modules']['top']['cells']['target']; first,second=pins[0],pins[-1]
    new['connections'][first],new['connections'][second]=new['connections'][second],new['connections'][first]
    new['parameters']['LUT']=format(transposed_mask(mask,width,0,width-1),'0%db'%(1<<width))
    maps=deepcopy(target_pins);maps[first][0],maps[second][0]=maps[second][0],maps[first][0]
    if width in (3,4):
        # The two swapped logical nets retain their physical endpoints; an
        # unswapped input moves during native allocation. Only its tree changes.
        maps[first][1],maps[second][1]=maps[second][1],maps[first][1]
        maps['B'][1]='F0'
    elif width==5:
        maps['B'][1],maps['D'][1]=maps['D'][1],maps['B'][1]
    new['attributes']['FES_PINMAP_V1']=encoded(maps)
    for p,bit in cells['target']['connections'].items():
        if p=='Q':continue
        bit=bit[0];np=second if p==first else first if p==second else p
        old_physical,new_physical=target_pins[p][1],maps[np][1]
        if old_physical!=new_physical:
            for alias in (f'net{bit}',f'alias{bit}'):
                record=right['modules']['top']['netnames'][alias]['attributes']
                record['ROUTING']=record['ROUTING'].replace(f'T.{old_physical};P{bit}.target.{old_physical}',f'T.{new_physical};P{bit}.target.{new_physical}')
    accepted=[{'accepted':True,'cell':'target','first':first,'second':second}]
    return left,right,accepted


def shared_fixture():
    """Two independently accepted LUTs share an input, with all stationary users."""
    l1,r1,a1=fixture(2);l2,r2,a2=fixture(2)
    def combine(one,two):
        one=deepcopy(one);a=one['modules']['top'];b=deepcopy(two['modules']['top'])
        bits={bit:(10 if bit==10 else bit+100) for n in b['netnames'].values() for bit in n['bits']}
        for name,c in b['cells'].items():
            for pin,values in c['connections'].items():c['connections'][pin]=[bits[v] for v in values]
            c['attributes']['NEXTPNR_BEL']='second.'+c['attributes']['NEXTPNR_BEL']
        b['cells'].pop('driverA')  # The shared source has one complete driver.
        a['cells'].update({'second.'+name:c for name,c in b['cells'].items()})
        shared_old=a['netnames']['net10']['attributes']['ROUTING']
        shared_new=None
        for name,net in b['netnames'].items():
            old_bit=net['bits'][0];net['bits']=[bits[old_bit]]
            parts=net['attributes']['ROUTING'].split(';');out=[]
            for i in range(0,len(parts),3):
                wire,pip,strength=parts[i:i+3]
                if old_bit==10 and not pip:continue
                out.extend(['second.'+wire,'second.'+pip if pip else '',strength])
            net['attributes']['ROUTING']=';'.join(out)
            if old_bit==10:
                net['attributes']['ROUTING']=shared_old+';'+net['attributes']['ROUTING']
                if shared_new is None:shared_new=net['attributes']['ROUTING']
                else:need(shared_new==net['attributes']['ROUTING'],'shared aliases disagree in fixture')
            a['netnames']['second.'+name]=net
        for alias,net in a['netnames'].items():
            if net['bits']==[10]:net['attributes']['ROUTING']=shared_new
        return one
    a2[0]['cell']='second.target'
    return combine(l1,l2),combine(r1,r2),a1+a2


def main():
    positive=[];negative=[]
    for width in range(2,6):
        left,right,accepted=fixture(width);result=prove(left,right,accepted)
        need(len(result['accepted_cells'][0]['all_raw_net_rows'])==1<<width,'wrong exhaustive row count')
        if width in (3,4):
            need(result['changed_canonical_net_bits']==[11],'unswapped remapped net missing')
            need(result['allowed_target_input_net_bits']!=result['changed_canonical_net_bits'],'incorrect every-net-changes assumption')
        positive.append({'width':width,'raw_rows':1<<width,'changed_route_bits':result['changed_canonical_net_bits']})
    ml,mr,ma=shared_fixture();multi=prove(ml,mr,ma)
    shared=next(n for n in multi['native_topology_selections'] if n['bit']==10)
    need(len(multi['accepted_cells'])==2 and len(shared['user_transitions'])==6,'shared multi-accept composition incomplete')
    need(sum(x['before']['port']!=x['after']['port'] for x in shared['user_transitions'])==2,'lost shared target transition')
    positive.append({'two_accepted_targets_shared_input':True,'complete_shared_users':6,'all_raw_rows':8})
    def bad(name,mutation):
        l,r,a=fixture();mutation(l,r,a)
        try:prove(l,r,a)
        except (ValueError,KeyError,TypeError) as e:negative.append({'name':name,'rejection':str(e)});return
        raise AssertionError('mutation accepted: '+name)
    def target(r):return r['modules']['top']['cells']['target']
    def map_edit(r,edit):
        t=target(r);m=pinmap(t);edit(m);t['attributes']['FES_PINMAP_V1']=encoded(m)
    bad('unlogged target',lambda l,r,a:a.clear())
    bad('duplicate accepted target',lambda l,r,a:a.append(deepcopy(a[0])))
    bad('unaccepted target',lambda l,r,a:a[0].update(accepted=False))
    bad('wrong pair',lambda l,r,a:a[0].update(first='B'))
    bad('wrong mask bit',lambda l,r,a:target(r)['parameters'].update(LUT='11111111'))
    bad('stale mask',lambda l,r,a:target(r)['parameters'].update(LUT=l['modules']['top']['cells']['target']['parameters']['LUT']))
    bad('inversion does not follow net',lambda l,r,a:map_edit(r,lambda m:m['A'].__setitem__(0,3)))
    bad('PIN1 mistaken for PIN_INV',lambda l,r,a:map_edit(r,lambda m:m['A'].__setitem__(0,1)))
    bad('unswapped inversion changed',lambda l,r,a:map_edit(r,lambda m:m['B'].__setitem__(0,3)))
    bad('duplicate physical input',lambda l,r,a:map_edit(r,lambda m:m['B'].__setitem__(1,m['A'][1])))
    bad('mixed physical half',lambda l,r,a:map_edit(r,lambda m:m['B'].__setitem__(1,'F1')))
    bad('output map changed',lambda l,r,a:map_edit(r,lambda m:m['Q'].__setitem__(1,'A')))
    bad('BEL changed',lambda l,r,a:target(r)['attributes'].update(NEXTPNR_BEL='other'))
    bad('target attribute added',lambda l,r,a:target(r)['attributes'].update(keep=1))
    bad('stationary mate mask',lambda l,r,a:r['modules']['top']['cells']['mate']['parameters'].update(LUT='1111'))
    bad('stationary observer port',lambda l,r,a:r['modules']['top']['cells']['watchA0']['connections'].update(DATAIN=[11]))
    bad('outside cell removed',lambda l,r,a:r['modules']['top']['cells'].pop('mate'))
    bad('unused alias removed',lambda l,r,a:r['modules']['top']['netnames'].pop('outside99'))
    bad('alias metadata changed',lambda l,r,a:r['modules']['top']['netnames']['net10']['attributes'].update(custom='changed'))
    bad('alias bit changed',lambda l,r,a:r['modules']['top']['netnames']['alias10'].update(bits=[11]))
    bad('driver changed',lambda l,r,a:r['modules']['top']['cells']['driverA']['connections'].update(Q=[11]))
    bad('LAB state changed',lambda l,r,a:r['modules']['top']['attributes'].update(FES_LABSTATE_V1='changed'))
    bad('settings changed',lambda l,r,a:r['modules']['top']['settings'].update(strict=0))
    bad('public observed input',lambda l,r,a:[x['modules']['top']['ports'].update(public={'direction':'input','bits':[10]}) for x in (l,r)])
    def routes(r,aliases,f):
        for alias in aliases:
            x=r['modules']['top']['netnames'][alias]['attributes'];x['ROUTING']=f(x['ROUTING'])
    bad('outside route changed',lambda l,r,a:routes(r,['outside99'],lambda s:s+';foreign;P.foreign;1'))
    bad('untouched physical input route changed',lambda l,r,a:routes(r,['net10','alias10'],lambda s:s+';foreign;P.foreign;1'))
    bad('alias stale physical route',lambda l,r,a:routes(r,['alias11'],lambda s:l['modules']['top']['netnames']['alias11']['attributes']['ROUTING']))
    bad('source root strength changed',lambda l,r,a:routes(r,['net11','alias11'],lambda s:s.replace('root;;1','root;;2')))
    bad('selected protected route',lambda l,r,a:routes(r,['net11','alias11'],lambda s:s.replace('P11.stationary;2','P11.stationary;4')))
    bad('wire stolen',lambda l,r,a:routes(r,['net11','alias11'],lambda s:s+';W99.root;P.stolen;1'))
    bad('PIP stolen',lambda l,r,a:routes(r,['net11','alias11'],lambda s:s+';new.wire;P40.sink;1'))
    bad('partial route tuple',lambda l,r,a:routes(r,['net11','alias11'],lambda s:s+';partial'))
    bad('duplicate wire',lambda l,r,a:routes(r,['net11','alias11'],lambda s:s+';W11.root;P.loop;1'))
    # Routing serialization order alone is not a physical change.
    l,r,a=fixture();records=r['modules']['top']['netnames']
    for name in ('outside99',):
        raw=records[name]['attributes']['ROUTING'];need(route_tree(raw)==route_tree(raw),'route parser')
    lines='\n'.join([
        'Info: Critical LUT permutation filter: cell=filtered: protected original source.',
        'Info: Critical LUT permutation discovery: negative rows=10 paths=12 bounded cell witnesses=2 eligible groups=1; native path cap=16384, cell cap=64.',
        'Info: Critical LUT permutation with-skew setup: clock=cpu before=-72ps after=-52ps.',
        'Info: Critical LUT permutation reference Fmax: clock=cpu before=99.000000MHz after=99.200000MHz constraint=100.000000/100.000000MHz.',
        'Info: Critical LUT permutation trial 1: cell=target pins=A/C prior-slack=-72ps native-arc-rank=190ps accepted=1; .',
        'Info: Critical LUT permutation: tried=1/4 kept=1; unchanged unsupported coverage is not qualification.'])
    need(decisions(lines)['kept']==1,'valid decision ledger failed')
    log_negative=[]
    for name,text in [('unknown line',lines+'\nInfo: Critical LUT permutation unknown.'),('wrong budget',lines.replace('tried=1/4','tried=1/5')),
                      ('missing trial',lines.replace('trial 1:','trial 2:')),('nonnegative path',lines.replace('prior-slack=-72','prior-slack=72')),
                      ('kept mismatch',lines.replace('kept=1','kept=0')),('missing discovery','\n'.join(x for x in lines.splitlines() if 'discovery' not in x)),
                      ('dangling clock delta',lines+'\nInfo: Critical LUT permutation reference hold: clock=cpu before=500ps after=499ps.')]:
        try:decisions(text)
        except ValueError as e:log_negative.append({'name':name,'rejection':str(e)});continue
        raise AssertionError('log corruption accepted: '+name)
    reference=reference_folder()/'routed.json'
    full=read(reference);control=prove(full,full,[])
    need(control['complete_cells']>12000 and control['complete_net_alias_records']>15000,'small full control')
    result={'passed':True,'checker_sha256':sha(HERE/'prove_graph.py'),'test_sha256':sha(__file__),
            'positive_cases':positive,'graph_rejections':negative,'log_rejections':log_negative,
            'complete_graph_noop_control':{'input_sha256':sha(reference),'cells':control['complete_cells'],'aliases':control['complete_net_alias_records']},
            'limits':['These are checker tests, not evidence that an actual permutation was accepted or preserves timing.',
                      'Stationary branch connectivity is a separate required native topology proof; serialized PIP names alone are not electrical proof.']}
    write('checker-tests.json',result)
    print(json.dumps({'passed':True,'positive_cases':len(positive),'graph_rejections':len(negative),'log_rejections':len(log_negative),'full_control_cells':control['complete_cells']},sort_keys=True))


if __name__=='__main__':main()
