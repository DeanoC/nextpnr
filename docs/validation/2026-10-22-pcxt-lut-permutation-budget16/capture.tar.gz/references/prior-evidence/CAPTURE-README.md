This capture retains the completed 7faa CPU16 baseline and independently routed
CPU16 + ordinary-LUT permutation4 + unobserved-arithmetic candidate. Both use
compiler source186637013e17461a72cd1d2cd17ca5ef174ed06f and the same raw graph,
QSF, SDC, seed1 and 100MHz recipe. The completed independent private4 candidate is also retained; no active or
later-round output is included.

One fixed-BEL ALUT5 D/E transposition improves the CGA rgbi[0] capture's setup
margin from -369ps to -234ps. All other17,193 timed setup rows and all17,194
related hold rows are exact. All17,199 endpoint identities, windows, flags,
metadata categories and clock summaries are retained. Ten setup failures remain,
with worst system slack -434ps; complete=false and105 unsupported entries remain.
This is a host-route diagnostic improvement, not timing closure or hardware
acceptance.

The complete graph proof checks every cell, alias, public port, LAB field,
physical owner, function and selected pin state. All32 raw-net truth assignments
match. Only two canonical input trees change. Recorded native readback decodes
all six selected trees and their users;16 stationary users retain46 original
wire/PIP/strength tuples, while two physical sinks change. Native readback does
not establish emitted RBF mask equivalence or electrical/hardware behavior.
The unchanged strict acceptance guards ran in both timing frames; the portable
final-report proof checks the emitted skewed reports, not a regenerated second
frame.

All three complete RBF/routed/endpoints/timing/log bundles and receipts are
retained, with the shared CPU16 control stored once. The permutation pair's
recorded route charge is1784.2650994360447seconds. The private candidate adds
608.085521012079seconds; the shared control must not be charged twice.
Replay adds zero. The private trial rejects a local route for mda_font_address[11];
RBF/timing/endpoints are byte-identical to CPU16. Its routed JSON has six route
serialization-order-only changes; complete canonical wire/PIP/strength maps,
all cells, aliases and settings remain exact. All17,194 setup and hold margins
are exact. The no-op topology proof requires no native re-execution.
The29 source files come from exact18663701 Git blobs and frozen host snapshots.
All131 host-admission files, independent review, initial failed reader compile,
reader32/final controls, complete401-member native snapshot manifest and matching
build/source receipts are retained. Executables, snapshot payloads and four
historical mutated-checkpoint payloads are explicitly omitted and hash-bound in
omitted-payloads.json. Their native execution results are historical records,
not replayed native tests.

The host-admission archive and prior CPU full-route archive are required explicit
dependencies. Every member of both archives is verified before checking selected
copied members. The raw input files and complete prior CPU route reference are
also copied here. archive-mode.json maps exact original receipt identities to
retained paths; there is no fallback to the original filesystem. Earlier host
archive dependencies are provenance references only: this verifier does not
re-run that archive's full host proof or retrieve transitive files.

Run the outer verify_capture.py with this archive, a fresh output directory, the
exact host archive, and the exact prior CPU archive. It checks every member,
replays all graph/decision/truth/timing/native-tree proofs and checker corruptions,
then reruns the unchanged independent-review script and requires identical
proof bytes. No compiler, native helper, GPU, kit or network is used.
