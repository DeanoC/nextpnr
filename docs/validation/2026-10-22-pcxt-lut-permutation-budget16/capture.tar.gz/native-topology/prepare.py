#!/usr/bin/env python3
"""Reuse an immutable structural reader with explicit source/schema compatibility."""
from pathlib import Path
import hashlib,json,shutil,subprocess
H=Path(__file__).resolve().parent;R=H.parent;OLD=R.parent/'unobserved-arith-coverage-20261022/native-topology';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
for n in ['tree-reader','tree-reader.cc','build-receipt.json','build-commands.json','build.log','frozen-manifest.json','committed-source-verification.json']:
 d=H/n
 if d.exists():assert sha(d)==sha(OLD/n)
 else:shutil.copy2(OLD/n,d)
build=read(H/'build-receipt.json');assert sha(H/'tree-reader')==build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
assert sha(H/'tree-reader.cc')==build['helper_source_sha256'] and sha(H/'frozen-manifest.json')==build['frozen_manifest_sha256']
old_commit='186637013e17461a72cd1d2cd17ca5ef174ed06f';new_commit='02ffa3aa6a74b71debbb23da24e5332b541cf742'
qualified=read(H/'committed-source-verification.json');assert qualified['source_commit']==old_commit and qualified['passed']
identity=read(R/'source-identity.json');assert identity['base_commit']=='5d566b0d0b93cbcb3773e4a2bd6094bbccd80353'
changed_source=set(subprocess.check_output(['git','diff','--name-only',old_commit,new_commit,'--','mistral','common','json','generic','3rdparty'],cwd=S,text=True).splitlines())
expected={'mistral/arch.h','mistral/main.cc','mistral/routed_lut6_swap.cc','mistral/tests/routed_lut6_swap_cli.py','mistral/routed_lut_permutation.cc','mistral/tests/routed_lut_permutation_cli.py'};assert changed_source==expected,changed_source
same={};different={}
for n,old_hash in qualified['source_files'].items():
 data=subprocess.check_output(['git','show',new_commit+':'+n],cwd=S);h=hashlib.sha256(data).hexdigest()
 (same if h==old_hash else different)[n]={'old_sha256':old_hash,'new_sha256':h}
assert set(different)=={'mistral/arch.h','mistral/main.cc','mistral/routed_lut6_swap.cc','mistral/routed_lut_permutation.cc'}
assert 'mistral/main.cc.o' not in (H/'build-commands.json').read_text()
prefix=read(H/'lut6-prefix-proof.json');old_lut=subprocess.check_output(['git','show',old_commit+':mistral/routed_lut6_swap.cc'],cwd=S);new_lut=subprocess.check_output(['git','show',new_commit+':mistral/routed_lut6_swap.cc'],cwd=S)
assert old_lut[:prefix['complete_prefix_bytes']]==new_lut[:prefix['complete_prefix_bytes']] and hashlib.sha256(old_lut[:prefix['complete_prefix_bytes']]).hexdigest()==prefix['complete_prefix_sha256']
permutation=read(R/'unchanged-transaction-coverage-proof.json')
old_perm=subprocess.check_output(['git','show',old_commit+':mistral/routed_lut_permutation.cc'],cwd=S);new_perm=subprocess.check_output(['git','show',new_commit+':mistral/routed_lut_permutation.cc'],cwd=S)
count=permutation['complete_permutation_prefix_bytes'];assert old_perm[:count]==new_perm[:count] and hashlib.sha256(old_perm[:count]).hexdigest()==permutation['complete_permutation_prefix_sha256']
assert old_perm.replace(b'critical_lut_permute_budget>4',b'critical_lut_permute_budget>16').replace(b'and budget 1..4.',b'and budget 1..16.')==new_perm
a=subprocess.check_output(['git','show',old_commit+':mistral/arch.h'],cwd=S);b=subprocess.check_output(['git','show',new_commit+':mistral/arch.h'],cwd=S)
added=[line for line in b.splitlines(keepends=True) if line not in a.splitlines(keepends=True)];assert len(added)==1 and added[0].strip()==b'int critical_lut6_swap_rounds = 1; // Explicit opt-in second discovery; one shared trial budget.'
assert b.replace(added[0],b'',1)==a
for n in identity['files']:
 data=subprocess.check_output(['git','show',new_commit+':'+n],cwd=S);assert hashlib.sha256(data).hexdigest()==identity['files'][n]['sha256']
value={'passed':True,'reader_compiler_commit':old_commit,'route_compiler_commit':new_commit,'reader_binary_sha256':sha(H/'tree-reader'),'reader_source_sha256':sha(H/'tree-reader.cc'),'reader_build_receipt_sha256':sha(H/'build-receipt.json'),'reader_frozen_manifest_sha256':sha(H/'frozen-manifest.json'),'route_source_identity_sha256':sha(R/'source-identity.json'),'unchanged_snapshotted_source_files':same,'changed_snapshotted_source_files':different,'production_source_changes':sorted(changed_source),'arch_header_change':added[0].decode().strip(),'unchanged_native_prefix_sha256':sha(H/'lut6-prefix-proof.json'),'permutation_transaction_proof_sha256':sha(R/'unchanged-transaction-coverage-proof.json'),'complete_permutation_source_only_two_limit_text_substitutions':True,'scope':'Read-only interpretation of saved JSON aliases/ports/maps and native wire/PIP/source/sink identities. All snapshotted parser/model/source-sink decoding bytes remain exact. The only changed snapshot files are an unused orchestration integer in Arch, CLI main (absent from helper link), and the LUT6/permutation repair orchestration (never called here; both native-helper prefixes exact, permutation source differs only in two budget-limit strings). Reader uses its own internally consistent old Context ABI. No configuration, pin allocation, placement, routing, STA or RBF generation occurs. No compatibility claim for executing new orchestration on old objects.'}
write(H/'architecture-compatibility.json',value);print(sha(H/'architecture-compatibility.json'))
