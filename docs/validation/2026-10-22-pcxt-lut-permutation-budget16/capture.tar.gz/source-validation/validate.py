#!/usr/bin/env python3
"""Frozen native45/CLI6 validation of explicit ordinary-LUT permutation budget16."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,re,subprocess,sys,time
HERE=Path(__file__).resolve().parent;EVIDENCE=HERE.parent
ROOT=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');BUILD=ROOT.parent/'build-candidate'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
source=json.loads((EVIDENCE/'source-identity.json').read_text());identity=json.loads((HERE/'build-identity.json').read_text())
proof=json.loads((EVIDENCE/'unchanged-transaction-coverage-proof.json').read_text())
exe=BUILD/'nextpnr-mistral';test=BUILD/'nextpnr-mistral-test'
def unchanged():
 return (all(sha(ROOT/f)==r['sha256'] for f,r in source['files'].items()) and
 all(sha(ROOT/f)==h for f,h in proof['unchanged_complete_source_files'].items()) and
 sha(exe)==identity['production_sha256'] and sha(test)==identity['native_test_sha256'] and
 sha(EVIDENCE/'nextpnr-mistral')==identity['production_sha256'])
assert unchanged()
def run(name,cmd,count,native):
 log=HERE/(name+'.log');assert not log.exists();t=time.monotonic()
 with log.open('w') as f:rc=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT).returncode
 matches=re.findall(r'\[  PASSED  \] (\d+) tests?\.' if native else r'Ran (\d+) tests? in',log.read_text())
 observed=int(matches[-1]) if matches else 0
 r={'name':name,'command':cmd,'cwd':str(ROOT),'returncode':rc,'elapsed_seconds':time.monotonic()-t,
 'log_sha256':sha(log),'expected_count':count,'observed_count':observed,'pass':rc==0 and observed==count}
 (HERE/(name+'.receipt.json')).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r),flush=True);return r
cases=[('permutation-native',[str(test),'--gtest_filter=RoutedLutPermutationPolicy.*:*RoutedLutPermutationBackend.*:*RoutedLutPermutationCoverage.*'],45,True),
('permutation-cli',[sys.executable,str(ROOT/'mistral/tests/routed_lut_permutation_cli.py'),str(exe),'-v'],6,False)]
with ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,*case) for case in cases];results=[f.result() for f in futures]
valid=unchanged();r={'build_identity_sha256':sha(HERE/'build-identity.json'),'results':results,
'sources_and_binaries_unchanged':valid,'pass':valid and all(x['pass'] for x in results)}
(HERE/'validation.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r),flush=True)
sys.exit(0 if r['pass'] else 1)
