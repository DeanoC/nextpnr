#!/usr/bin/env python3
"""Build the reviewed explicit permutation budget extension; no FPGA route."""
from pathlib import Path
import hashlib,json,shutil,subprocess,time
HERE=Path(__file__).resolve().parent;EVIDENCE=HERE.parent
ROOT=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');BUILD=ROOT.parent/'build-candidate'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
source=json.loads((EVIDENCE/'source-identity.json').read_text());proof=json.loads((EVIDENCE/'unchanged-transaction-coverage-proof.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==source['base_commit']
def unchanged():
 return all(sha(ROOT/f)==r['sha256']==sha(EVIDENCE/'source'/f) for f,r in source['files'].items()) and all(sha(ROOT/f)==h for f,h in proof['unchanged_complete_source_files'].items())
assert unchanged() and (EVIDENCE/'independent-source-review.json').exists()
assert not (HERE/'build.log').exists()
cmd=['cmake','--build',str(BUILD),'--target','nextpnr-mistral','nextpnr-mistral-test','-j8'];t=time.monotonic()
with (HERE/'build.log').open('w') as f:rc=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT).returncode
receipt={'command':cmd,'returncode':rc,'elapsed_seconds':time.monotonic()-t,'log_sha256':sha(HERE/'build.log'),'sources_unchanged':unchanged()}
(HERE/'build.receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
assert rc==0 and unchanged(),receipt
identity={'source_identity_sha256':sha(EVIDENCE/'source-identity.json'),'production_sha256':sha(BUILD/'nextpnr-mistral'),'native_test_sha256':sha(BUILD/'nextpnr-mistral-test'),'observed_head':source['base_commit'],'review_sha256':sha(EVIDENCE/'independent-source-review.json'),'unchanged_proof_sha256':sha(EVIDENCE/'unchanged-transaction-coverage-proof.json')}
(HERE/'build-identity.json').write_text(json.dumps(identity,indent=2,sort_keys=True)+'\n')
assert not (EVIDENCE/'nextpnr-mistral').exists();shutil.copyfile(BUILD/'nextpnr-mistral',EVIDENCE/'nextpnr-mistral');(EVIDENCE/'nextpnr-mistral').chmod(0o755)
print(json.dumps(identity),flush=True)
