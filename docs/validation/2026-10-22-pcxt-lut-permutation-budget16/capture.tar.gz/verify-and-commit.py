#!/usr/bin/env python3
"""Root source/frozen evidence verification and exact selected-source commit."""
from pathlib import Path
import argparse, hashlib, json, subprocess
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(p):
 with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO)
def require(x,message):
 if not x: raise ValueError(message)
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--commit',action='store_true');args=parser.parse_args()
 final=ROOT/'final-validation.json';v=json.loads(final.read_text())
 identity=ROOT/'source-identity.json';ident=json.loads(identity.read_text())
 require(v['validation']['passed'] is True,'incomplete host validation')
 for name in ['lut_permutation','lut_permutation_budget16']:
  require(v['enabled_'+name+'_route_admission'] is True,'missing '+name+' admission')
 for name,count in {'lut_permutation_native_count':45,'lut_permutation_cli_count':6}.items():
  require(v['validation'][name]==count,'count differs '+name)
 for p,h in v['files'].items(): require(sha(ROOT/p)==h,'evidence hash mismatch '+p)
 for p,h in v['source_files'].items(): require(sha(REPO/p)==h,'source mismatch '+p)
 for p,info in ident['files'].items():
  require(v['source_files'][p]==info['sha256'],'changed source not bound '+p)
  require(sha(ROOT/'source'/p)==info['sha256'],'frozen source mismatch '+p)
 require(sha(ROOT/'nextpnr-mistral')==v['binary_sha256'],'frozen binary mismatch')
 require(v['independent_source_review_passed'] is True,'independent source review missing')
 review=json.loads((ROOT/'independent-source-review.json').read_text())
 require(review['passed'] is True and not review['blockers'] and review['reviewed_files']==ident['files'],'frozen independent source review mismatch')
 require(review['source_identity_sha256']==sha(identity),'independent review source identity')
 require(review['base_commit']==ident['base_commit'],'review base differs')
 for p,info in ident['files'].items():require(digest(git('show',ident['base_commit']+':'+p))==info['before_sha256'],'base file differs '+p)
 require(v['control_proof_sha256']==sha(ROOT/'control-proof.json'),'control proof mismatch')
 changed=set()
 for row in git('status','--porcelain=v1','-z').decode().split('\0'):
  if row: changed.add(row[3:])
 require(changed==set(ident['files']),'unexpected unstaged changes '+str(changed.symmetric_difference(ident['files'])))
 require(not git('diff','--cached','--name-only').strip(),'unrelated staged files')
 subprocess.run(['git','diff','--check'],cwd=REPO,check=True)
 print(json.dumps({'status':'host/source verification passed','files_verified':len(v['files']),'source_files_verified':len(v['source_files']),'changed_files':len(changed),'binary_sha256':v['binary_sha256']}),flush=True)
 if not args.commit:return
 before=git('rev-parse','HEAD').decode().strip()
 subprocess.run(['git','add','--',*sorted(ident['files'])],cwd=REPO,check=True)
 require(set(git('diff','--cached','--name-only').decode().splitlines())==changed,'staged file set mismatch')
 subprocess.run(['git','commit','-m','mistral: allow up to sixteen guarded ordinary LUT permutation trials'],cwd=REPO,check=True)
 commit=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
 for p,h in v['source_files'].items():require(digest(git('show',commit+':'+p))==h,'committed source mismatch '+p)
 receipt={'commit':commit,'tree':tree,'source_files':v['source_files'],'binary_sha256':v['binary_sha256'],'final_validation_sha256':sha(final),'all_recorded_source_bytes_match_commit':True,'scope':'Host admission for explicit bounded routed trials; no final routed timing or hardware acceptance','observed_build_parent':ident['base_commit'],'precommit_head':before,'verification_script_sha256':sha(__file__),'independent_source_review_sha256':sha(ROOT/'independent-source-review.json')}
 (ROOT/'committed-source-verification.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'commit':commit,'tree':tree,'source_files_verified':len(v['source_files'])}),flush=True)
 subprocess.run(['git','push','origin','HEAD'],cwd=REPO,check=True)
if __name__=='__main__':main()
