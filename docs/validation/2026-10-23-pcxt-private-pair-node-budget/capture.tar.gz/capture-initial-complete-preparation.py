#!/usr/bin/env python3
"""Complete the first capture preparation, which stopped at the last README copy."""
from pathlib import Path
import hashlib,json,shutil
C=Path(__file__).resolve().parent;P=C/'payload';R=C.parent.parent
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert 'capture/README.md' in (C/'initial-prepare-error.log').read_text()
for n in ('prepare.py','replay.py','replay_review.py','verify_capture.py','build_archive.py'):assert sha(C/n)==sha(P/n)
for n,h in json.loads((R/'final-validation.json').read_text())['files'].items():assert sha(R/n)==sha(P/n)==h
for n,target in [('README.md','CAPTURE-README.md'),('initial-launch-note.txt','capture-initial-launch-note.txt'),('initial-prepare-error.log','capture-initial-prepare-error.log'),('complete-preparation.py','complete-preparation.py')]:
 assert not (P/target).exists();shutil.copy2(C/n,P/target)
print('complete: original partial payload verified, missing README and explicit preparation history retained')
