#!/usr/bin/env python3
"""Freeze host admission for private-pair-only explicit local-search allowance."""
from pathlib import Path
import hashlib,json,re,subprocess
R=Path(__file__).resolve().parent;F=R/'source-validation';OLD=R.parent/'lut-permutation-budget16-20261022';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
source=read(R/'source-identity.json');old=read(OLD/'final-validation.json');build=read(F/'build-identity.json');review=read(R/'independent-source-review.json');proof=read(R/'unchanged-transaction-coverage-proof.json')
base=source['base_commit'];assert base=='02ffa3aa6a74b71debbb23da24e5332b541cf742' and len(source['files'])==6
assert build['source_identity_sha256']==sha(R/'source-identity.json')==review['source_identity_sha256']==proof['source_identity_sha256']
assert build['review_sha256']==sha(R/'independent-source-review.json') and build['unchanged_proof_sha256']==sha(R/'unchanged-transaction-coverage-proof.json')
assert review['passed'] and not review['blockers'] and review['reviewed_files']==source['files']
assert sha(R/'production.patch')==review['production_patch_sha256']
assert sha(R/'nextpnr-mistral')==build['production_sha256']
files=dict(old['source_files']);files.update({p:v['sha256'] for p,v in source['files'].items()});assert len(files)==29 and files==proof['source_files']
for p,h in files.items():
 assert sha(S/p)==sha(R/'complete-source'/p)==h
 data=subprocess.check_output(['git','show',base+':'+p],cwd=S);before_hash=hashlib.sha256(data).hexdigest()
 if p in source['files']:
  assert before_hash==source['files'][p]['before_sha256']==old['source_files'][p]==sha(R/'before'/p)
  assert sha(R/'source'/p)==h
 else:assert before_hash==h
for p,h in proof['unchanged_complete_source_files'].items():assert files[p]==h
assert sha(S/'mistral/routed_move.cc')==proof['common_router_source_sha256']
summary=read(F/'validation.json');assert summary['pass'] and summary['sources_and_binaries_unchanged'] and summary['build_identity_sha256']==sha(F/'build-identity.json')
counts={'private-pair-native':81,'private-pair-cli':9};assert {x['name'] for x in summary['results']}==set(counts)
for name,n in counts.items():
 v=read(F/(name+'.receipt.json'));text=(F/(name+'.log')).read_text()
 assert v['returncode']==0 and v['pass'] and v['expected_count']==v['observed_count']==n and v['log_sha256']==sha(F/(name+'.log'))
 assert next(x for x in summary['results'] if x['name']==name)==v
 if name.endswith('cli'):assert re.search(r'Ran '+str(n)+r' tests in',text) and re.search(r'\nOK\s*$',text)
 else:
  run=re.findall(r'^\[ RUN      \] (.+)$',text,re.M);ok=re.findall(r'^\[       OK \] (.+) \(\d+ ms\)$',text,re.M)
  assert len(run)==len(ok)==len(set(run))==n and run==ok
  assert sum('LocalNodeBudgetsKeepDefaultTrialExactAndBoundsRollback' in x for x in run)==4
control=read(R/'control-proof.json');assert control['default_zero_raw_bytes_equal'] and control['default_parent_raw_bytes_equal'] and sorted(x['case'] for x in control['controls'])==['default','zero']
assert control['script_sha256']==sha(R/'prepare-controls.py')
prior=read(OLD/'prepare-default/receipt.json');oldbytes=(OLD/'prepare-default/placed.json').read_bytes()
for x in control['controls']:
 assert all(x[k] for k in ('complete_modules_equal','all_bytes_except_creator_equal','predicted_timing_bytes_equal'))
 folder=R/('prepare-'+x['case']);v=read(folder/'receipt.json')
 assert v['returncode']==0 and v['binary_sha256']==build['production_sha256'] and v['inputs']==prior['inputs']
 expected=prior['nextpnr_command'][:];expected[0]=v['nextpnr_command'][0]
 if x['case']=='zero':expected+=['--critical-private-pair-budget','0']
 assert v['nextpnr_command']==expected and '--no-route' in expected and '--rbf' not in expected
 for p,h in v['artifacts'].items():assert sha(folder/p)==h
 newbytes=(folder/'placed.json').read_bytes();assert newbytes==oldbytes
 assert (folder/'predicted-timing.json').read_bytes()==(OLD/'prepare-default/predicted-timing.json').read_bytes()
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
write(R/'retained-source-proof.json',{'earlier_commit':base,'earlier_final_validation_sha256':sha(OLD/'final-validation.json'),'unchanged_source_files':{p:h for p,h in old['source_files'].items() if p not in source['files']},'scope':'Current private-pair81 native/9 CLI rerun. Other passes retain their earlier exact source/build provenance; common router and acceptance guard code are unchanged.'})
inputs={}
for prefix in ('source','before','source-validation','complete-source','prepare-default','prepare-zero'):
 for p in sorted((R/prefix).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:inputs[str(p.relative_to(R))]=sha(p)
for name in ('source-identity.json','independent-source-review.json','unchanged-transaction-coverage-proof.json','production.patch','prepare-controls.py','prepare-controls.log','control-proof.json','retained-source-proof.json','freeze-validation.py','draft.py','run-host.py','README.md'):
 inputs[name]=sha(R/name)
for name in ('independent-tester-review.json',):
 if (R/name).exists():inputs[name]=sha(R/name)
final={'scope':'Host admission for private-pair-only explicit local-node allowance1..2000000, absent500000. The common router, search order, trial count, source/downstream eligibility and complete acceptance predicates are unchanged. No timing gain or hardware acceptance asserted.',
'binary_sha256':build['production_sha256'],'native_test_sha256':build['native_test_sha256'],'source_parent':base,'source_files':files,'files':inputs,
'independent_source_review_passed':True,'source_review_sha256':sha(R/'independent-source-review.json'),'control_proof_sha256':sha(R/'control-proof.json'),
'enabled_private_pair_route_admission':True,'enabled_private_pair_node_budget_route_admission':True,
'validation':{'passed':True,'private_pair_native_count':81,'private_pair_cli_count':9},
'native_execution_boundary':{'scope':'Native81 includes four new LAB/MLAB/half cases comparing default/explicit500000/2000000 transaction snapshot and exact rollback plus bounds/tiny-budget rejection. CLI9 checks explicit admission and saved-setting nonenablement. CPU default/zero controls compare full raw placement and predicted-report bytes to the parent; active option rejects --no-route, so enabled orchestration still requires paired fresh full routes.'},
'unchanged_transaction_coverage_proof_sha256':sha(R/'unchanged-transaction-coverage-proof.json'),
'retained_prior_validation':{'path':str(OLD/'final-validation.json'),'sha256':sha(OLD/'final-validation.json'),'unchanged_source_proof_sha256':sha(R/'retained-source-proof.json'),'scope':'Other passes keep original provenance. Only private native81/CLI9 rerun on this build.'}}
assert not (R/'final-validation.json').exists();write(R/'final-validation.json',final);print(sha(R/'final-validation.json'))
