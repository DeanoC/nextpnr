from pathlib import Path
import hashlib,json,difflib,subprocess
R=Path(__file__).resolve().parent;S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
base='02ffa3aa6a74b71debbb23da24e5332b541cf742';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==base
files=['mistral/main.cc','mistral/arch.h','mistral/private_pair_decomposition.cc','mistral/tests/routed_private_pair_cli.py','mistral/tests/routed_private_pair_backend.cc','docs/mistral-private-pair-decomposition.md']
before={p:(S/p).read_text() for p in files};after=dict(before)
def replace(p,a,b):
 assert after[p].count(a)==1,(p,a);after[p]=after[p].replace(a,b)
replace('mistral/main.cc','    specific.add_options()("critical-lut-permute-budget", po::value<int>(),', '    specific.add_options()("critical-private-pair-route-nodes", po::value<int>(),\n                           "local search nodes shared by each private-pair trial (1..2000000, default 500000)");\n    specific.add_options()("critical-lut-permute-budget", po::value<int>(),')
replace('mistral/main.cc','    ctx->critical_private_pair_budget = 0;','''    ctx->critical_private_pair_route_nodes = 500000;
    if (vm.count("critical-private-pair-route-nodes")) {
        const int nodes = vm["critical-private-pair-route-nodes"].as<int>();
        if (nodes < 1 || nodes > 2000000)
            log_error("--critical-private-pair-route-nodes must be between 1 and 2000000.\\n");
        if (!vm.count("critical-private-pair-budget") || vm["critical-private-pair-budget"].as<int>() <= 0)
            log_error("--critical-private-pair-route-nodes requires a positive private-pair budget.\\n");
        ctx->critical_private_pair_route_nodes = nodes;
    }
    ctx->critical_private_pair_budget = 0;''')
replace('mistral/arch.h','    int critical_private_pair_budget = 0; // Explicit CLI only; bounded live two-LUT decomposition.', '    int critical_private_pair_budget = 0; // Explicit CLI only; bounded live two-LUT decomposition.\n    int critical_private_pair_route_nodes = 500000; // Explicit CLI only; shared across one trial\'s changed nets.')
replace('mistral/private_pair_decomposition.cc','    if (visit_budget<=0 || visit_budget>500000) return fail("local route node budget must be 1..500000");','    if (visit_budget<=0 || visit_budget>2000000) return fail("local route node budget must be 1..2000000");')
replace('mistral/private_pair_decomposition.cc','        log_error("Critical private pair requires an ordinary completed route and budget 1..4.\\n");','''        log_error("Critical private pair requires an ordinary completed route and budget 1..4.\\n");
    if (critical_private_pair_route_nodes<1 || critical_private_pair_route_nodes>2000000)
        log_error("Critical private pair local route node budget must be 1..2000000.\\n");
    if (critical_private_pair_route_nodes!=500000)
        log_info("Critical private pair local search node budget: %d per trial.\\n",critical_private_pair_route_nodes);''')
replace('mistral/private_pair_decomposition.cc','critical_routed_private_pair_trial(ctx,choice.producer,choice.candidate,500000,[&]() {','critical_routed_private_pair_trial(ctx,choice.producer,choice.candidate,critical_private_pair_route_nodes,[&]() {')
replace('docs/mistral-private-pair-decomposition.md','500000-node local search extends those rooted trees without foreign rip-up.','''500000-node local search extends those rooted trees without foreign rip-up.
`--critical-private-pair-route-nodes N` explicitly changes this shared per-trial
allowance to 1..2000000 nodes and requires a positive private-pair trial budget.
The absent option and explicit 500000 use the same search/order; saved settings
never configure this allowance. This option does not alter other repair passes,
the maximum four trials, eligibility, or any setup/hold/coverage acceptance gate.
A larger allowance permits more search; it does not establish a timing gain.''')
replace('mistral/tests/routed_private_pair_cli.py',"    def test_missing_full_gpu_route_rejects(self):",'''    def test_local_node_bounds(self):
        for nodes in ('-1','0','2000001','2147483647'):
            result,output=self.run_case(['--critical-private-pair-route-nodes',nodes])
            self.assertNotEqual(result.returncode,0);self.assertIn('must be between 1 and 2000000',result.stdout);self.assertIsNone(output)

    def test_local_nodes_require_positive_private_budget(self):
        for nodes in ('1','500000','2000000'):
            for options in ([],['--critical-private-pair-budget','0']):
                result,output=self.run_case(['--critical-private-pair-route-nodes',nodes]+options)
                self.assertNotEqual(result.returncode,0);self.assertIn('requires a positive private-pair budget',result.stdout);self.assertIsNone(output)

    def test_valid_local_nodes_preserve_fresh_route_guard(self):
        for nodes in ('1','500000','2000000'):
            self.rejected(['--critical-private-pair-budget','1','--critical-private-pair-route-nodes',nodes])

    def test_missing_full_gpu_route_rejects(self):''')
replace('mistral/tests/routed_private_pair_cli.py',"settings={'critical-private-pair-budget':'4'}", "settings={'critical-private-pair-budget':'4','critical-private-pair-route-nodes':'2000000'}")
replace('mistral/tests/routed_private_pair_backend.cc','TEST_P(RoutedPrivatePairBackend, OriginalUnroutedGuardAndProtectedMalformedCandidatesFailClosed)','''TEST_P(RoutedPrivatePairBackend, LocalNodeBudgetsKeepDefaultTrialExactAndBoundsRollback)
{
    Snapshot before(ctx.get());
    EXPECT_EQ(ctx->critical_private_pair_route_nodes,500000);
    for (int nodes : {-1,0,2000001}) {
        bool touched=false,accepted=false;
        EXPECT_FALSE(trial([&]{accepted=true;return true;},[&](unsigned){touched=true;},nodes));
        EXPECT_FALSE(touched);EXPECT_FALSE(accepted);
        EXPECT_EQ(reason,"local route node budget must be 1..2000000");before.expect_exact(ctx.get());
    }
    bool accepted=false;
    EXPECT_FALSE(trial([&]{accepted=true;return true;},{},1));
    EXPECT_FALSE(accepted);before.expect_exact(ctx.get());
    std::unique_ptr<Snapshot> default_trial;std::vector<unsigned> default_stages;
    EXPECT_FALSE(trial([&]{default_trial=std::make_unique<Snapshot>(ctx.get());return false;},
                       [&](unsigned stage){default_stages.push_back(stage);}));
    ASSERT_NE(default_trial,nullptr);ASSERT_FALSE(default_stages.empty());EXPECT_EQ(default_stages.back(),21u);
    before.expect_exact(ctx.get());
    for (int nodes : {500000,2000000}) {
        bool inspected=false;std::vector<unsigned> stages;
        EXPECT_FALSE(trial([&]{inspected=true;default_trial->expect_exact(ctx.get());return false;},
                           [&](unsigned stage){stages.push_back(stage);},nodes));
        EXPECT_TRUE(inspected);EXPECT_EQ(stages,default_stages);before.expect_exact(ctx.get());
    }
}
TEST_P(RoutedPrivatePairBackend, OriginalUnroutedGuardAndProtectedMalformedCandidatesFailClosed)''')
manifest={}
patch=''
for p in files:
 for sub,data in [('before',before[p]),('source',after[p])]:
  dest=R/sub/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(data)
 manifest[p]={'before_sha256':hashlib.sha256(before[p].encode()).hexdigest(),'sha256':hashlib.sha256(after[p].encode()).hexdigest()}
 patch+=''.join(difflib.unified_diff(before[p].splitlines(True),after[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p))
(R/'production.patch').write_text(patch)
(R/'source-identity.json').write_text(json.dumps({'base_commit':base,'files':manifest,'scope':'Private-pair-only explicit local node budget1..2000000; absent500000, common router/order and all acceptance guards unchanged.'},sort_keys=True,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'source_identity_sha256':hashlib.sha256((R/'source-identity.json').read_bytes()).hexdigest()}))
