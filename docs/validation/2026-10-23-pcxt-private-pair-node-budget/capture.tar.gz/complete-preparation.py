#!/usr/bin/env python3
"""Complete the first capture preparation, which stopped at the last README copy."""
from pathlib import Path
import hashlib,json,shutil
C=Path(__file__).resolve().parent;P=C/'payload';R=C.parent.parent
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert 'capture/README.md' in (C/'initial-prepare-error.log').read_text()
for n in ('prepare.py','replay.py','replay_review.py','build_archive.py'):assert sha(C/n)==sha(P/n)
old=(P/'verify_capture.py').read_text();new=(C/'verify_capture.py').read_text()
assert old.replace('PRIOR_PERMUTATION.tar.gz ROUNDS.tar.gz','PRIOR_PRIVATE.tar.gz BUDGET16.tar.gz')==new
shutil.copy2(C/'verify_capture.py',P/'verify_capture.py')
for n,h in json.loads((R/'final-validation.json').read_text())['files'].items():assert sha(R/n)==sha(P/n)==h
for n,target in [('README.md','CAPTURE-README.md'),('initial-launch-note.txt','capture-initial-launch-note.txt'),('initial-prepare-error.log','capture-initial-prepare-error.log'),('complete-preparation.py','complete-preparation.py'),('initial-complete-preparation.py','capture-initial-complete-preparation.py'),('initial-complete-preparation-error.log','capture-initial-complete-preparation-error.log')]:
 assert not (P/target).exists();shutil.copy2(C/n,P/target)
print('complete: original partial payload verified, missing README and explicit preparation history retained')
