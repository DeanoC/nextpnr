#!/usr/bin/env python3
from pathlib import Path
from decimal import Decimal
import hashlib,json,re
ROOT=Path(__file__).resolve().parent;TASK=ROOT.parent.parent
JOURNAL=TASK/'sources/misteross/docs/validation/2026-10-22-pcxt-pad-pipeline/continued-runs.jsonl'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
rows=[json.loads(x) for x in JOURNAL.read_text().splitlines()];seen={x['case'] for x in rows};added=[]
for case in ['default500k','nodes2m']:
 folder=ROOT/('route-'+case);rp=folder/'receipt.json';label=str(folder.relative_to(TASK))
 if label in seen or not rp.exists():continue
 receipt=json.loads(rp.read_text());charged=json.loads(rp.read_text(),parse_float=Decimal)['charged_seconds'];assert receipt['returncode'] in [0,1]
 for name,digest in receipt['artifacts'].items():assert sha(folder/name)==digest
 timing=json.loads((folder/'timing.json').read_text());endpoints=json.loads((folder/'endpoints.json').read_text());entries=[r for v in endpoints['endpoints'].values() for r in v]
 log=(folder/'nextpnr.log').read_text().splitlines()
 row={'case':label,'charged_seconds_decimal':str(charged),'core':'fes-pcxt diagnostic CGA Direct','evidence':'Fresh leased host diagnostic at fixed original clocks; full comparisons determine retention, no timing closure or hardware acceptance','hardware':False,'receipt':receipt,'receipt_sha256':sha(rp),'timing_report_available':True,'clocks':timing['timing_summary']['clocks'],'gpu_log':[l for l in log if 'GPU lease:' in l or 'GPU router time' in l or ('backend hip:' in l and 'ready in' in l)],'final_endpoint_summary':{'rows':len(entries),'setup_failures':sum(r['setup_timed'] and r['setup']<0 for r in entries),'hold_failures':sum(r['hold_related'] and r['hold']<0 for r in entries),'unsupported':len(endpoints['unsupported'])}}
 rows.append(row);added.append(row)
if added:
 with JOURNAL.open('a') as f:
  for row in added:f.write(json.dumps(row,sort_keys=True)+'\n')
base=Decimal('14417.71786836162136');total=base+sum(Decimal(r['charged_seconds_decimal']) for r in rows)
result={'new_cases':[r['case'] for r in added],'completed_subsequent_receipts':len(rows),'pre_journal_charge_seconds':str(base),'cumulative_charge_seconds':str(total),'journal_sha256':sha(JOURNAL)}
print(json.dumps(result,indent=2))
