#!/usr/bin/env python3
"""Corrupt the bounded private-node comparison ledger independently."""
import json
from prove_graph import NODE_LINE, decisions, paired_decisions
from support import HERE, ROOT, need, sha, write


def main():
    fixture = ROOT.parent / 'unobserved-arith-coverage-20261022/route-private4/nextpnr.log'
    left = fixture.read_text()
    old = decisions(left)
    need(old['kept'] == 0 and old['tried'] == 1, 'baseline fixture changed')
    right = left.replace(old['all_verbatim_lines'][0], NODE_LINE + '\n' + old['all_verbatim_lines'][0], 1)
    need(not paired_decisions(left, right)['additional_accepted_trials'], 'false retention')
    rejected = []

    def bad(name, candidate, control=left):
        try:
            paired_decisions(control, candidate)
        except (ValueError, KeyError, TypeError) as error:
            rejected.append({'case': name, 'rejection': str(error)})
            return
        raise AssertionError('corruption accepted: ' + name)

    bad('missing node allowance', right.replace(NODE_LINE, ''))
    bad('duplicate node allowance', right.replace(NODE_LINE, NODE_LINE + '\n' + NODE_LINE))
    bad('wrong node allowance', right.replace(NODE_LINE, NODE_LINE.replace('2000000', '2000001')))
    bad('late node allowance', right.replace(NODE_LINE + '\n', '') + '\n' + NODE_LINE)
    bad('control overrides node allowance', right, right)
    bad('preceding repair changes', right + '\nInfo: Critical route unexpected.')
    bad('initial discovery changes', right.replace('negative rows=10 paths=10', 'negative rows=9 paths=10'))
    bad('first candidate rank changes', right.replace(old['all_trials'][0]['verbatim'], old['all_trials'][0]['verbatim'].replace('native-source-rank=', 'native-source-rank=1')))
    bad('duplicate summary', right + '\n' + old['summary'])
    trial = old['all_trials'][0]['verbatim']
    bad('early summary', right.replace(trial, old['summary'] + '\n' + trial).rsplit(old['summary'], 1)[0])
    retained = left.replace(trial, trial.replace('accepted=0;', 'accepted=1;')).replace('tried=1/4 kept=0;', 'tried=1/4 kept=1;')
    bad('retained control requires another comparison', right, retained)
    write('node-checks-proof.json', {
        'passed': True,
        'positive_cases': 1,
        'corruption_rejections': rejected,
        'checker_sha256': sha(HERE / 'prove_graph.py'),
        'test_sha256': sha(__file__),
        'fixture_sha256': sha(fixture),
        'scope': 'Parser controls only; future fresh candidate physical/timing outcome is unproven.',
    })
    print(json.dumps({'passed': True, 'rejections': len(rejected)}))


if __name__ == '__main__':
    main()
