#!/usr/bin/env python3
"""Compare a rejected default-budget private trial with its bounded2m candidate."""
import json
from private_graph_core import prove,decisions,decompose,evaluate,pinmap,physical_port
from support import HERE,ROOT,need,read,write,sha,paired_receipts

NODE_LINE='Info: Critical private pair local search node budget: 2000000 per trial.'

def paired_decisions(left,right):
    need('Critical private pair local search node budget:' not in left,'default unexpectedly overrides node budget')
    lines=[x for x in right.splitlines() if 'Critical private pair' in x]
    need(lines and lines[0]==NODE_LINE and lines.count(NODE_LINE)==1,'missing/duplicate/misplaced node budget')
    after=decisions('\n'.join(lines[1:]));before=decisions(left)
    for ledger in [before,after]:need(ledger['all_verbatim_lines'][-1]==ledger['summary'],'summary must be last')
    need(before['kept']==0,'baseline retained a decomposition; cannot compare independent rewrites')
    need(before['discovery']==after['discovery'] and before['all_filters']==after['all_filters'],'initial candidate inventory differs')
    a=before['all_trials'];b=after['all_trials'];need(a and b,'node experiment lacks trial')
    for key in ['number','producer','definition','bound','prior_path_slack_ps','promoted_path_inputs','native_source_rank_ps']:
        need(a[0][key]==b[0][key],'first candidate identity/ranking differs: '+key)
    preceding={name:[x for x in text.splitlines() if 'Critical route ' in x or 'Critical LUT6 ' in x] for name,text in [('default500k',left),('nodes2m',right)]}
    need(preceding['default500k']==preceding['nodes2m'],'preceding repair decisions differ')
    return {'control':before,'selected':after,'node_budget_line':NODE_LINE,'default_node_budget':500000,'selected_node_budget':2000000,'initial_candidate_inventory_equal':True,'first_candidate_identity_equal':True,'preceding_repair_all_lines':preceding,'additional_accepted_trials':[t for t in b if t['accepted']],'limits':['Candidate outcomes may change after increased bounded search; no intermediate checkpoint or timing reload is inferred.']}

def main():
    paired_receipts();cases=('default500k','nodes2m');logs={c:(ROOT/f'route-{c}/nextpnr.log').read_text() for c in cases}
    ledger=paired_decisions(logs['default500k'],logs['nodes2m'])
    result=prove(*[read(ROOT/f'route-{c}/routed.json') for c in cases],ledger['additional_accepted_trials'])
    result.update(checker_sha256=sha(__file__),graph_core_sha256=sha(HERE/'private_graph_core.py'),support_sha256=sha(HERE/'support.py'),graph_sha256={c:sha(ROOT/f'route-{c}/routed.json') for c in cases})
    write('decision-ledger.json',ledger);write('graph-proof.json',result)
    write('native-selection-specs.json',{'schema':1,'graph_proof_sha256':sha(HERE/'graph-proof.json'),'graph_sha256':result['graph_sha256'],'selections':result['native_topology_selections'],'requirements':['Native decode all selected source/input/link/output trees and complete users. Preserve every stationary path/strength; no routing, allocation, configuration or STA.']})
    print(json.dumps({k:result[k] for k in ['status','complete_cells','complete_net_alias_records','changed_canonical_net_bits']},sort_keys=True))
if __name__=='__main__':main()
