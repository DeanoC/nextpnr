#!/usr/bin/env python3
"""Independent replay/review of root-authored full graph and final timing proofs."""
from pathlib import Path
import contextlib,hashlib,importlib,io,json,sys
HERE=Path(__file__).resolve().parent;A=HERE.parent;sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
inputs={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*.py'))};checks=[]
def compare_write(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs';checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
log=io.StringIO()
with contextlib.redirect_stdout(log):
 g=importlib.import_module('prove_graph');g.write=compare_write;g.main()
 for name in ('test_checks','test_node_checks'):
  c=importlib.import_module(name);c.write=compare_write;c.main()
 n=importlib.import_module('verify_topology');n.write=compare_write;n.main()
 t=importlib.import_module('compare_timing');t.R=HERE;t.main()
assert (HERE/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
assert inputs=={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*.py'))}
g=read(A/'graph-proof.json');t=read(A/'route-comparison.json');n=read(A/'topology-proof.json');d=read(A/'decision-ledger.json')
assert not g['accepted_pairs'] and not g['changed_canonical_net_bits'] and not g['every_raw_route_attribute_change']
assert d['preceding_repair_decisions_equal'] and d['initial_candidate_inventory_equal'] and d['first_candidate_identity_equal']
assert d['control']['tried']==d['selected']['tried']==1 and d['control']['kept']==d['selected']['kept']==0
assert 'mda_font_address[11]' in d['control']['all_trials'][0]['reason']
assert '942.000000->936.000000 ps' in d['selected']['all_trials'][0]['reason']
assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal'] and len(t['every_endpoint_row'])==17199
assert t['default_vs_prior_fixed_invariance_pass']
assert t['native_margin_delta_counts']=={'setup':{'unchanged':17194},'hold':{'unchanged':17194}}
assert t['independent_complete_clock_guard']['pass'] and t['independent_emitted_inventory_guard']['nonregression_and_inventory_pass'] and not t['independent_emitted_inventory_guard']['all_violations']
assert all(x['setup']['failures']==10 and x['unsupported_count']==105 and not x['complete'] and x['hold']['failures']==0 for x in t['runs'].values())
assert n['passed'] and not n['native_readback_needed']
root=read(A/'root-final-byte-comparison.json');assert root['passed'] and len(root['files'])==4
for row in root['files']:
 p=A.parent/'route-default500k'/row['artifact'];q=A.parent/'route-nodes2m'/row['artifact']
 assert row['byte_identical'] and sha(p)==sha(q)==row['sha256'] and p.read_bytes()==q.read_bytes()
changed=[x for x in t['every_endpoint_row'] if x['margin_delta_ps']['setup']]
result={'passed':True,'reviewer':'timing_strategy','review_script_sha256':sha(__file__),'inputs':inputs,'exact_replays':checks,'complete_endpoint_rows':17199,'native_margin_delta_counts':t['native_margin_delta_counts'],'setup_failure_counts':{k:v['setup']['failures'] for k,v in t['runs'].items()},'whole_system_setup_minimum_ps':{k:v['setup']['minimum_ps'] for k,v in t['runs'].items()},'accepted_private_pairs':0,'changed_canonical_trees':0,'raw_route_attribute_changes':0,'root_complete_byte_comparison_sha256':sha(A/'root-final-byte-comparison.json'),'root_artifact_bytes_independently_compared':root['files'],'native_readback_needed':False,'charged_route_seconds':0,'findings':['Complete graph, aliases, settings/LAB, physical ownership and final setup/hold/native clock inventories replay exactly. All12397 cells and15546 alias records are exact.','Each recipe attempts the same single partition. Default500k stops at font_address[11] local search;2m reaches native STA and rejects a still-positive hold margin regression942→936ps. This logged rejected live state is not reconstructed from final artifacts.','Both trials roll back. All four final routedJSON/RBF/timing/endpoints files are byte-identical, also matching the earlier private4 control. All17194 setup and hold margins are exact.','Ten setup failures remain at worst−434ps,105unsupported andcomplete=false. No eligibility/guard waiver.'],'limits':['Independent checker/source review and exact offline proof replay; no new native tree execution is needed because every complete canonical tree and all raw artifacts are equal.','Prepared native compatibility is structural only and unused for this no-change result. Initial verifier import mismatch and correction are retained separately; no native execution occurred.','No rejected-state full endpoint report, physical mask or electrical proof is invented. No hardware acceptance or full timing closure is claimed.']}
(HERE/'replay.log').write_text(log.getvalue());(HERE/'review.json').write_bytes(encoded(result));print(json.dumps({'passed':True,'review_sha256':sha(HERE/'review.json'),'exact_replays':len(checks)},sort_keys=True))
