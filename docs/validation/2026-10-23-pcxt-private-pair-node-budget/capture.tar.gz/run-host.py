#!/usr/bin/env python3
"""Launch CPU validation only after the frozen build receipt and binary exist."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
R=Path(__file__).resolve().parent

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
while True:
 identity=R/'source-validation/build-identity.json';binary=R/'nextpnr-mistral'
 if identity.exists() and binary.exists():
  build=json.loads(identity.read_text())
  if sha(binary)==build['production_sha256']:break
 receipt=R/'source-validation/build.receipt.json'
 if receipt.exists() and json.loads(receipt.read_text())['returncode']!=0:raise SystemExit('Build failed; no validation started')
 time.sleep(1)
print('Frozen build available; launching native81/CLI9 and CPU controls.',flush=True)
jobs=[]
for script,logname in [('source-validation/validate.py','source-validation/validation-run.log'),('prepare-controls.py','prepare-controls.log')]:
 log=R/logname;assert not log.exists();stream=log.open('w');cmd=[sys.executable,str(R/script)]
 process=subprocess.Popen(cmd,cwd=R,env={**os.environ,'TMPDIR':str(R)},stdout=stream,stderr=subprocess.STDOUT)
 jobs.append((script,process,stream))
results=[]
for script,process,stream in jobs:
 rc=process.wait();stream.close();results.append({'script':script,'returncode':rc});print(json.dumps(results[-1]),flush=True)
assert all(x['returncode']==0 for x in results),results
subprocess.run([sys.executable,str(R/'freeze-validation.py')],cwd=R,check=True,env={**os.environ,'TMPDIR':str(R)})
print('Host validation and final freeze complete.',flush=True)
