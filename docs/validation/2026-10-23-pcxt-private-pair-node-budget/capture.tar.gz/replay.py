#!/usr/bin/env python3
"""Portable complete private-node rejection proof; no native execution or live paths."""
from pathlib import Path
from decimal import Decimal
import contextlib,hashlib,importlib,io,json,sys,tempfile
R=Path(__file__).resolve().parent;A=R/'final-analysis';sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
assert support.archive_mode() is not None and support.ROOT==R
final=read(R/'final-validation.json');commit=read(R/'committed-source-verification.json')
assert commit['commit']=='f5c6b90df4b8a36a6a8f631998d52ef160c2044b' and commit['source_files']==final['source_files'] and commit['final_validation_sha256']==sha(R/'final-validation.json')
for n,h in final['files'].items():assert sha(R/n)==h,n
for n,h in final['source_files'].items():assert sha(R/'complete-source'/n)==h,n
assert len(final['files'])==74 and len(final['source_files'])==29
for key in ('prior','budget'):
 prior=read(R/f'references/{key}-evidence/final-validation.json')
 for n,h in prior['source_files'].items():assert sha(R/f'references/{key}-source'/n)==h,n
identity=read(R/'source-identity.json');assert identity['base_commit']=='02ffa3aa6a74b71debbb23da24e5332b541cf742'
for n,v in identity['files'].items():assert sha(R/'before'/n)==v['before_sha256']==sha(R/'references/budget-source'/n) and sha(R/'source'/n)==v['sha256']
controls=read(R/'control-proof.json');assert controls['default_zero_raw_bytes_equal'] and controls['default_parent_raw_bytes_equal']
for case in ('default','zero'):
 p=R/('prepare-'+case);q=R/'references/prior-prepare'
 assert (p/'placed.json').read_bytes()==(q/'placed.json').read_bytes()
 assert (p/'predicted-timing.json').read_bytes()==(q/'predicted-timing.json').read_bytes()
 assert read(p/'receipt.json')['reference_receipt_sha256']==sha(q/'receipt.json')
 for n,h in read(p/'receipt.json')['artifacts'].items():assert sha(p/n)==h
summary=read(R/'source-validation/validation.json');assert summary['pass']
for name,count in [('private-pair-native',81),('private-pair-cli',9)]:
 v=read(R/'source-validation'/(name+'.receipt.json'));assert v['pass'] and v['returncode']==0 and v['observed_count']==v['expected_count']==count
 assert v['log_sha256']==sha(R/'source-validation'/(name+'.log')) and v in summary['results']
# The optional reader was prepared but never executed: complete tree equality
# makes changed-tree readback unnecessary. Preserve its exact compatibility scope.
native=R/'native-topology';build=read(native/'build-receipt.json');compat=read(native/'architecture-compatibility.json')
assert build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
for name,key in [('tree-reader.cc','helper_source_sha256'),('frozen-manifest.json','frozen_manifest_sha256'),('build-commands.json','build_commands_sha256'),('build.log','build_log_sha256')]:assert sha(native/name)==build[key]
assert len(read(native/'frozen-manifest.json')['files'])==401
assert compat['passed'] and compat['route_compiler_commit']==commit['commit'] and compat['reader_compiler_commit']=='186637013e17461a72cd1d2cd17ca5ef174ed06f'
assert compat['reader_binary_sha256']==build['helper_binary_sha256'] and compat['route_source_identity_sha256']==sha(R/'source-identity.json')
for n,v in compat['changed_snapshotted_source_files'].items():assert sha(R/'references/prior-source'/n)==v['old_sha256'] and sha(R/'complete-source'/n)==v['new_sha256']
assert sha(native/'prior-budget-compatibility.json')==compat['prior_budget_compatibility_sha256']==sha(R/'references/budget-native/architecture-compatibility.json')
assert sha(native/'prior-budget-reader-review.json')==compat['prior_budget_reader_review_sha256']==sha(R/'references/budget-native/independent-reader-review.json')
old=(R/'references/budget-source/mistral/arch.h').read_bytes();new=(R/'complete-source/mistral/arch.h').read_bytes()
added=b'    '+compat['arch_header_addition'].encode()+b'\n';assert new.count(added)==1 and new.replace(added,b'')==old
old=(R/'references/budget-source/mistral/private_pair_decomposition.cc').read_bytes();new=(R/'complete-source/mistral/private_pair_decomposition.cc').read_bytes()
extra=b'    if (critical_private_pair_route_nodes<1 || critical_private_pair_route_nodes>2000000)\n        log_error("Critical private pair local route node budget must be 1..2000000.\\n");\n    if (critical_private_pair_route_nodes!=500000)\n        log_info("Critical private pair local search node budget: %d per trial.\\n",critical_private_pair_route_nodes);\n'
assert new.count(extra)==1
assert new.replace(extra,b'').replace(b'visit_budget>2000000',b'visit_budget>500000').replace(b'local route node budget must be 1..2000000',b'local route node budget must be 1..500000').replace(b'choice.candidate,critical_private_pair_route_nodes,[&]()',b'choice.candidate,500000,[&]()')==old
nreceipt=read(native/'paired-readback/receipt.json');assert nreceipt['passed'] and not nreceipt['native_execution_needed']
origin=read(A/'indexed-port-resolution-origin.json');assert origin['frontend_sha256']==sha(A/'pinned-frontend_base.h') and origin['module_sha256']==sha(A/'native_port_identity.py')
resolver=read(A/'indexed-resolver-review.json');assert resolver['passed'] and resolver['cores']['private_nodes']['new_core_sha256']==sha(A/'private_graph_core.py')
accounting=read(R/'accounting-46/summary.json');journal=R/'accounting-46/continued-runs.jsonl';records=[json.loads(v) for v in journal.read_text().splitlines()]
assert sha(journal)==accounting['journal_sha256'] and len(records)==accounting['completed_subsequent_receipts']==46
assert len({v['case'] for v in records})==46
assert Decimal(accounting['pre_journal_charge_seconds'])+sum(Decimal(v['charged_seconds_decimal']) for v in records)==Decimal(accounting['cumulative_charge_seconds'])
for case in ('default500k','nodes2m'):
 rows=[v for v in records if v['case']=='out/private-pair-node-budget-20261022/route-'+case];assert len(rows)==1 and rows[0]['receipt_sha256']==sha(R/f'route-{case}/receipt.json')
checks=[]
def compare_write(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs';checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
with contextlib.redirect_stdout(io.StringIO()):
 for name in ('prove_graph','test_checks','test_node_checks','verify_topology'):
  m=importlib.import_module(name);m.write=compare_write
  if name=='test_node_checks':m.ROOT=R/'references'/'fixture-context'
  m.main()
 c=importlib.import_module('compare_timing')
 with tempfile.TemporaryDirectory(prefix='pcxt-private-node-proof-') as scratch:
  c.R=Path(scratch);c.main();assert (c.R/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
 checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
g=read(A/'graph-proof.json');t=read(A/'route-comparison.json');n=read(A/'topology-proof.json');d=read(A/'decision-ledger.json')
assert not g['accepted_pairs'] and not g['changed_canonical_net_bits'] and not g['every_raw_route_attribute_change']
assert len(t['every_endpoint_row'])==17199 and t['native_margin_delta_counts']=={'setup':{'unchanged':17194},'hold':{'unchanged':17194}}
assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal'] and t['default_vs_prior_fixed_invariance_pass']
assert n['passed'] and not n['native_readback_needed']
assert d['control']['tried']==d['selected']['tried']==1 and d['control']['kept']==d['selected']['kept']==0
assert 'mda_font_address[11]' in d['control']['all_trials'][0]['reason'] and '942.000000->936.000000 ps' in d['selected']['all_trials'][0]['reason']
root=read(A/'root-final-byte-comparison.json');assert root['passed'] and len(root['files'])==4
for row in root['files']:
 p=R/'route-default500k'/row['artifact'];q=R/'route-nodes2m'/row['artifact'];prior=R/'references/prior-cpu'/row['artifact']
 assert row['byte_identical'] and sha(p)==sha(q)==row['sha256'] and p.read_bytes()==q.read_bytes()==prior.read_bytes()
result={'passed':True,'source_commit':commit['commit'],'source_files':29,'host_admission_files':74,'native_snapshot_manifest_members':401,'exact_replays':checks,'complete_endpoint_rows':17199,'native_margin_delta_counts':t['native_margin_delta_counts'],'accepted_private_pairs':0,'all_four_final_artifacts_byte_equal_to_prior_and_each_other':True,'native_readback_needed':False,'pair_route_charge_seconds_recorded_not_recharged':t['pair_charge_seconds'],'charged_route_seconds':0,'historical_accounting_context':{'journal_records':46,'cumulative_charge_seconds':accounting['cumulative_charge_seconds'],'scope':'Journal arithmetic and these two receipt hashes checked; other historical routes are context only.'},'scope':'Offline replay of complete saved graph, final timing and rollback proof. Native81/CLI9 are retained host receipts, not rerun. No native reader execution, GPU route, rejected-state timing reconstruction, emitted-RBF electrical proof or hardware acceptance.'}
print(encoded(result).decode(),end='')
