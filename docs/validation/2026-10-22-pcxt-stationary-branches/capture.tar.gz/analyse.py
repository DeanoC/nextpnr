from pathlib import Path
import json,hashlib,re,importlib.util,math
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('guard','/home/deano/harnesses/pcxt-compiler-repair/nextpnr/mistral/routed_swap.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
r={'evidence':'CPU-reference host diagnostic; no hardware','runs':{}}
for label in ['baseline','candidate']:
 p=root/label;rec=json.loads((p/'receipt.json').read_text());row={'receipt':rec}
 if (p/'timing.json').exists():
  t=json.loads((p/'timing.json').read_text());e=json.loads((p/'endpoints.json').read_text())
  row.update({'timing_summary':t.get('timing_summary'),'fmax':t.get('fmax'),'complete':e['complete'],'unsupported':len(e['unsupported'])})
  row['failing_setup_rows']=sum(x['setup_timed'] and x['setup']<0 for rows in e['endpoints'].values() for x in rows)
 log=(p/'nextpnr.log').read_text()
 row['proposals']=[{'net':n,'variant':int(v),'native_worst_sink_gain_ps':float(d) if math.isfinite(float(d)) else None} for n,v,d in re.findall(r'Critical route proposal: net (.*?) variant (\d+) native worst-sink gain ([^ ]+) ps\.',log)]
 row['trials']=re.findall(r'Critical move trial .*',log)
 row['decisions']=re.findall(r'Critical move trial .*?accepted=[01]; (.*)',log)
 r['runs'][label]=row
r['charged_seconds']=sum(x['receipt']['charged_seconds'] for x in r['runs'].values())
r['route_allowance']='uncapped by user'; r['previous_charged_seconds']=7594.42670651758
if all((root/n/'endpoints.json').exists() for n in ['baseline','candidate']):
 r['retention_decision']=g.compare(*[json.loads((root/n/'endpoints.json').read_text()) for n in ['baseline','candidate']])
prior=Path('/tmp/pcxt-route-preserve-routes-20261022/baseline')
r['default_off_artifacts_match_prior']={n:hashlib.file_digest((root/'baseline'/n).open('rb'),'sha256').hexdigest()==hashlib.file_digest((prior/n).open('rb'),'sha256').hexdigest() for n in ['diagnostic.rbf','timing.json','endpoints.json'] if (root/'baseline'/n).exists()}
(root/'analysis.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='runs'},indent=2))
for name,v in r['runs'].items():print(name,'proposals',len(v['proposals']),'whole-tree',sum(x['variant']>=100 for x in v['proposals']),'positive',sum(x['native_worst_sink_gain_ps'] is not None and x['native_worst_sink_gain_ps']>=20 for x in v['proposals']),'trials',len(v['trials']),v['decisions'])
