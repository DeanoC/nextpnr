#!/usr/bin/env python3
"""Capture immutable source-exit evidence; portable checker copies are separately declared."""
from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,difflib
C=Path(__file__).resolve().parent;A=C.parent;R=A.parent;P=C/'payload';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def copy(p,n=None):
 d=P/(n or p.relative_to(R));d.parent.mkdir(parents=True,exist_ok=True)
 if d.exists():assert sha(d)==sha(p),str(d)
 else:shutil.copy2(p,d)
 return str(d.relative_to(P))
assert not P.exists();P.mkdir()
final=read(R/'final-validation.json');assert sha(R/'final-validation.json')=='a3762f00fdb6a84e54b0e2daf63a3aae9e12a3ff3d0c8efc12051e8790122c0e'
assert len(final['files'])==191 and len(final['source_files'])==30
for n,h in final['files'].items():assert sha(R/n)==h;copy(R/n)
for n in ['final-validation.json','committed-source-verification.json','route.py','verify-and-commit.py','record-runs.py','accounting.json','README.md']:copy(R/n)
commit=read(R/'committed-source-verification.json');assert commit['commit']=='1ba2e289f5bf4e584a8539f185d6f15383650c26' and commit['source_files']==final['source_files']
for n,h in final['source_files'].items():assert hashlib.sha256(subprocess.check_output(['git','show',commit['commit']+':'+n],cwd=S)).hexdigest()==h==sha(P/'complete-source'/n)
for case in ('default','retain'):
 receipt=read(R/f'route-{case}/receipt.json');assert receipt['binary_sha256']==final['binary_sha256']
 for n,h in receipt['artifacts'].items():assert sha(R/f'route-{case}'/n)==h;copy(R/f'route-{case}'/n)
 copy(R/f'route-{case}/receipt.json')
for p in sorted(A.rglob('*')):
 if p.is_file() and not {'capture','__pycache__'}&set(p.relative_to(A).parts):copy(p)
for p in sorted((R/'native-topology').rglob('*')):
 if p.is_file() and p.name!='tree-reader' and '__pycache__' not in p.parts:copy(p)
for p in sorted((R/'accounting-52').iterdir()):
 if p.is_file():copy(p)
accounting=read(R/'accounting.json');assert sha(P/'accounting-52/continued-runs.jsonl')==accounting['journal_sha256']
assert read(P/'accounting-52/source.json')['commit']=='826dbbe1c5b671f0c9facbdddb6692d1d4242bc4'
omitted=[]
for p in [R/'nextpnr-mistral',R/'native-topology/tree-reader']:
 omitted.append({'original_path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'reason':'Executable omitted; exact recorded artifacts and native outputs are replayed offline.'})
write(P/'omitted-payloads.json',{'files':omitted,'native_snapshot_manifest':'native-topology/frozen-manifest.json','native_snapshot_payload':'All401 old object/header/source payloads omitted. Isolated pre-admission helper binaries/build objects, large mutated checkpoint inputs and GTest libraries are hash-bound by their original receipts but omitted; no original native test/probe/reader execution is replayed.'})
paths={'cap32':R.parent/'lut-permutation-budget32-20261023/final-analysis/capture/capture.tar.gz','combined':R.parent/'cpu2-permutation16-20261022/final-analysis/capture/capture.tar.gz'}
expected={'cap32':'5c8771558434c8713f8ba79cd1afce75c6398315012058f27c96df4d0d2b3b02','combined':'3333e2524c928aec6704c3fd8374b45208cc4964ff3598c5fdfac4604971d22b'}
dependencies={};bindings=[]
for kind,path in paths.items():
 assert sha(path)==expected[kind]
 with tarfile.open(path) as t:
  data=t.extractfile('manifest.json').read();m=json.loads(data);spec={'archive_sha256':sha(path),'bytes':path.stat().st_size,'members':len(t.getmembers()),'manifest_sha256':hashlib.sha256(data).hexdigest(),'manifest_path':f'dependencies/{kind}-manifest.json'}
  assert spec['members']==len(m)+1;dependencies[kind]=spec;(P/spec['manifest_path']).parent.mkdir(parents=True,exist_ok=True);(P/spec['manifest_path']).write_bytes(data)
  def retain(member,target):
   payload=t.extractfile(member).read();d=P/target;d.parent.mkdir(parents=True,exist_ok=True)
   if d.exists():assert d.read_bytes()==payload
   else:d.write_bytes(payload)
   assert sha(d)==m[member]['sha256'];bindings.append({'dependency':kind,'member':member,'retained_path':target,'sha256':sha(d)})
  prefixes=[('prepare-default/','references/prior-prepare/'),('complete-source/','references/prior-source/'),('references/prior-source/','references/reader-source/'),('route-budget32/','references/prior-route/'),('external-inputs/','external-inputs/'),('accounting-50/','references/accounting-50/')] if kind=='cap32' else [('route-cpu2/','references/common/'),('route-combined16/nextpnr.log','references/fixture/nextpnr.log')]
  for member in sorted(m):
   target=None
   for prefix,dest in prefixes:
    if member.startswith(prefix):target=dest+member[len(prefix):]
   if member in ('final-validation.json','committed-source-verification.json','archive-mode.json','CAPTURE-README.md'):target=f'references/{kind}-evidence/'+member
   if target:retain(member,target)
  if kind=='cap32':
   for member in ('native-topology/architecture-compatibility.json','native-topology/prepare.py','native-topology/independent-reader-review.json'):retain(member,'references/cap32-native/'+Path(member).name)
recorded={};receipt=read(R/'route-default/receipt.json')
for path,h in receipt['immutable_evidence_sha256'].items():
 original=Path(path)
 if original.is_relative_to(R):target=str(original.relative_to(R))
 elif original.parent.name=='route-cpu2':target='references/common/receipt.json'
 else:assert original.parent.name=='route-budget32';target='references/prior-route/receipt.json'
 assert sha(P/target)==h;recorded[path]={'retained_path':target,'sha256':h}
for v in receipt['inputs'].values():
 target='external-inputs/'+v['sha256']+'-'+Path(v['path']).name;assert sha(P/target)==v['sha256'];recorded[v['path']]={'retained_path':target,'sha256':v['sha256']}
references={
 'route':{'original_directory':str(R.parent/'lut-permutation-budget32-20261023/route-budget32'),'retained_path':'references/prior-route'},
 'common':{'original_directory':str(R.parent/'cpu2-permutation16-20261022/route-cpu2'),'retained_path':'references/common'},
 'fixture':{'original_directory':str(R.parent/'cpu2-permutation16-20261022/route-combined16'),'retained_path':'references/fixture'}}
write(P/'archive-mode.json',{'recorded_files':recorded,'excluded_binary':{'original_path':receipt['nextpnr_command'][0],'sha256':final['binary_sha256']},'references':references,'dependencies':dependencies,'selected_dependency_members':sorted(bindings,key=lambda x:(x['dependency'],x['member'],x['retained_path'])),'scope':'Every dependency member and selected mapping is verified; no live original-path fallback.'})
# Live analysis is retained byte-for-byte. Only these declared path lookup edits
# are made in separate portable copies. Acceptance predicates are unchanged.
portable=P/'portable-analysis';portable.mkdir()
for p in sorted((P/'final-analysis').iterdir()):
 if p.is_file():shutil.copy2(p,portable/p.name)
(portable/'independent-review').mkdir()
for p in sorted((P/'final-analysis/independent-review').iterdir()):
 if p.is_file():shutil.copy2(p,portable/'independent-review'/p.name)
changes={
 'prove_graph.py':[
 ('sha, paired_receipts, receipt, verify_recorded','sha, paired_receipts, receipt, verify_recorded, reference_folder, reference_original'),
 ("common = ROOT.parent / 'cpu2-permutation16-20261022/route-cpu2'","common = reference_folder('common')"),
 ("verify_recorded(common / 'receipt.json', value['immutable_evidence_sha256'][str(common / 'receipt.json')])","verify_recorded(reference_original('common') + '/receipt.json', value['immutable_evidence_sha256'][reference_original('common') + '/receipt.json'])")],
 'test_sequence_checks.py':[
 ('ROOT,HERE,need,write,sha','ROOT,HERE,need,write,sha,reference_folder,reference_original'),
 ("reference=ROOT.parent/'cpu2-permutation16-20261022/route-cpu2/nextpnr.log'","reference=reference_folder('common')/'nextpnr.log'"),
 ("fixture=ROOT.parent/'cpu2-permutation16-20261022/route-combined16/nextpnr.log'","fixture=reference_folder('fixture')/'nextpnr.log'"),
 ("{str(reference):sha(reference),str(fixture):sha(fixture)}","{reference_original('common')+'/nextpnr.log':sha(reference),reference_original('fixture')+'/nextpnr.log':sha(fixture)}")],
 'verify_topology.py':[
 ('HERE,ROOT,need,read,sha,digest,write','HERE,ROOT,need,read,sha,digest,write,reference_folder'),
 ("ROOT.parent/'cpu2-permutation16-20261022/route-cpu2' if case=='cpu2'","reference_folder('common') if case=='cpu2'")],
}
adapter={};patch=[]
for name,pairs in changes.items():
 original=(P/'final-analysis'/name).read_text();adapted=original
 for before,after in pairs:assert adapted.count(before)==1,(name,before);adapted=adapted.replace(before,after,1)
 (portable/name).write_text(adapted);adapter[name]={'original_sha256':sha(P/'final-analysis'/name),'adapted_sha256':sha(portable/name),'exact_replacements':[{'before':a,'after':b} for a,b in pairs]}
 patch.extend(difflib.unified_diff(original.splitlines(True),adapted.splitlines(True),fromfile='final-analysis/'+name,tofile='portable-analysis/'+name))
(P/'portable-path-adapter.patch').write_text(''.join(patch));write(P/'portable-path-adapter.json',{'files':adapter,'patch_sha256':sha(P/'portable-path-adapter.patch'),'scope':'Archive-copy only path lookup adaptation. Original live checker and proof bytes are retained. All acceptance logic and substantive proof content must remain exact; declared script/digest provenance differences are separately recorded.'})
for n in ('prepare.py','replay.py','verify_capture.py','build_archive.py','README.md'):copy(C/n,'CAPTURE-README.md' if n=='README.md' else n)
print(json.dumps({'files':len([p for p in P.rglob('*') if p.is_file()]),'dependencies':dependencies,'adapters':adapter},indent=2,sort_keys=True))
