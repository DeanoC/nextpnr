#!/usr/bin/env python3
"""Freeze installed reviewed source and the independent native fixture before build."""
from pathlib import Path
import hashlib,json,subprocess,shutil
HERE=Path(__file__).resolve().parent;R=HERE.parent;F=HERE/'final-host'
REPO=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
BASE='134b858165a4dd0c00c8b5d5371fbf90fdac63a3'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,obj):
 assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
proposal=json.loads((R/'source-identity.json').read_text());assert proposal['base_commit']==BASE
review=json.loads((R/'independent-source-review.json').read_text());assert review['passed_source_review'] and review['source_identity_sha256']==sha(R/'source-identity.json')
parent=json.loads((R.parent/'lut-permutation-budget32-20261023/final-validation.json').read_text())
old={k.removeprefix('complete-source/'):h for k,h in parent['files'].items() if k.startswith('complete-source/')};assert len(old)==29
files=set(proposal['files'])|{'mistral/CMakeLists.txt','mistral/tests/source_exit_retention_backend.cc'};assert len(files)==8
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=REPO,text=True).splitlines())
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=REPO,text=True).splitlines())
unrelated_docs={f for f in untracked if f.startswith('docs/validation/2026-10-23-pcxt-private-pair-node-budget/')}
assert changed|(untracked-unrelated_docs)==files,(changed,untracked)
for f,row in proposal['files'].items():assert sha(REPO/f)==row['sha256']==sha(R/'source'/f)
for f,h in old.items():
 before=subprocess.check_output(['git','show',BASE+':'+f],cwd=REPO);assert hashlib.sha256(before).hexdigest()==h
 if f not in files:assert sha(REPO/f)==h
cmake=(REPO/'mistral/CMakeLists.txt').read_text();token='tests/source_exit_retention_backend.cc '
assert cmake.count(token)==1
original=subprocess.check_output(['git','show',BASE+':mistral/CMakeLists.txt'],cwd=REPO,text=True)
assert cmake.replace(token,'')==original
records={}
for f in sorted(files):
 p=F/'source'/f;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();shutil.copyfile(REPO/f,p)
 row={'sha256':sha(p)}
 if f in old:
  row['before_sha256']=old[f];p=F/'before'/f;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(subprocess.check_output(['git','show',BASE+':'+f],cwd=REPO))
 else:row['new_file']=True
 records[f]=row
write(F/'source-identity.json',{'base_commit':BASE,'observed_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'proposal_identity_sha256':sha(R/'source-identity.json'),'files':records,'excluded_unrelated_untracked_docs':{f:sha(REPO/f) for f in sorted(unrelated_docs)},'scope':'Reviewed source-exit retention plus focused native fixture and registration; no full route.'})
write(F/'unchanged-guards-proof.json',{'passed':True,'complete_parent_source_count':len(old),'final_complete_source_count':len(old)+1,'unchanged_complete_source_files':{f:h for f,h in sorted(old.items()) if f not in files},'production_normalization_review_sha256':sha(R/'independent-source-review.json'),'cmake_only_one_test_registration':True,'scope':'All retained source/coverage/clock/inventory/LUT6/private code bytes exact; ordinary transaction changes restricted to independently reviewed optional original exit capture.'})
print(json.dumps({'files':len(records),'source_identity_sha256':sha(F/'source-identity.json'),'unchanged_guards_sha256':sha(F/'unchanged-guards-proof.json')},sort_keys=True))
