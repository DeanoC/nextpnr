#!/usr/bin/env python3
"""Consolidate the reviewed source-exit host admission; no GPU route or timing acceptance."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
R=Path(__file__).resolve().parent;F=R/'source-validation';H=F/'final-host';OLD=R.parent/'lut-permutation-budget32-20261023';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):
 assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert sha(OLD/'final-validation.json')=='b3c202d37aae84c678f84f221c170111fe8db9fef071ea0d55dc1be3ab1f3a6f'
old=read(OLD/'final-validation.json');source=read(H/'source-identity.json');build=read(F/'build-identity.json');proposal=read(R/'source-identity.json');review=read(R/'independent-source-review.json');proof=read(H/'unchanged-guards-proof.json')
base=source['base_commit'];assert base=='134b858165a4dd0c00c8b5d5371fbf90fdac63a3' and len(source['files'])==8 and len(proposal['files'])==6
assert source['proposal_identity_sha256']==sha(R/'source-identity.json')==review['source_identity_sha256']
assert review['passed_source_review'] and review['normalization_exact'] and review['base_commit']==base
fixture_review_path=H/'independent-fixture-registration-review.json';fixture_review=read(fixture_review_path)
assert sha(fixture_review_path)=='9111cb59949b0139d0f3d94b61e1104d222073d5b0228880de409cf0c6cff877'
assert fixture_review['passed'] and not fixture_review['route_admission'] and fixture_review['source_identity_sha256']==sha(H/'source-identity.json')
assert fixture_review['files']==source['files']
assert fixture_review['fixture_sha256']==source['files']['mistral/tests/source_exit_retention_backend.cc']['sha256']
assert fixture_review['cmake_sha256']==source['files']['mistral/CMakeLists.txt']['sha256']
assert fixture_review['inherited_production_review']=={'file':str(R/'independent-source-review.json'),'sha256':sha(R/'independent-source-review.json'),'passed':True}
runner_review=read(F/'independent-runner-preflight-review.json')
assert runner_review['passed_source_review'] and runner_review['only_early_reference_receipt_validation_changed']
assert runner_review['final_runner_sha256']==sha(R/'route.py')=='ecf71ca51cce4009ac7de5a982d969d24b8a12fe68c0d81730e6491f764dc083'
assert runner_review['prior_review_sha256']==sha(F/'independent-route-checker-review.json')
assert build['source_identity_sha256']==sha(H/'source-identity.json') and build['review_sha256']==sha(R/'independent-source-review.json') and build['unchanged_guards_proof_sha256']==sha(H/'unchanged-guards-proof.json')
assert sha(R/'nextpnr-mistral')==build['production_sha256']
assert proof['passed'] and proof['complete_parent_source_count']==29 and proof['final_complete_source_count']==30 and proof['cmake_only_one_test_registration']
assert proof['production_normalization_review_sha256']==sha(R/'independent-source-review.json')
sources=dict(old['source_files']);sources.update({p:v['sha256'] for p,v in source['files'].items()});assert len(sources)==30
for p,h in sources.items():
 origin=H/'source'/p if p in source['files'] else OLD/'complete-source'/p
 assert sha(origin)==h==sha(S/p)
 if p in old['source_files']:
  prior=subprocess.check_output(['git','show',base+':'+p],cwd=S);prior_hash=hashlib.sha256(prior).hexdigest();assert prior_hash==old['source_files'][p]
  if p in source['files']:assert source['files'][p]['before_sha256']==prior_hash==sha(H/'before'/p)
  else:assert prior_hash==h
 else:assert source['files'][p]['new_file'] and p=='mistral/tests/source_exit_retention_backend.cc'
 dest=R/'complete-source'/p;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==h
 else:shutil.copy2(origin,dest)
for p,v in proposal['files'].items():assert source['files'][p]['sha256']==v['sha256']==sha(R/'source'/p) and source['files'][p]['before_sha256']==v['before_sha256']
for p,h in proof['unchanged_complete_source_files'].items():assert sources[p]==h==old['source_files'][p]
cmake=(H/'source/mistral/CMakeLists.txt').read_bytes();token=b'tests/source_exit_retention_backend.cc ';assert cmake.count(token)==1 and cmake.replace(token,b'')==(H/'before/mistral/CMakeLists.txt').read_bytes()
summary=read(F/'validation.json');assert summary['pass'] and summary['sources_and_binaries_unchanged'] and summary['build_identity_sha256']==sha(F/'build-identity.json')
counts={'source-exit-native':12,'permutation-native':45,'permutation-cli':8};assert len(summary['results'])==3 and {x['name'] for x in summary['results']}==set(counts)
for name,n in counts.items():
 v=read(F/(name+'.receipt.json'));text=(F/(name+'.log')).read_text();assert v['returncode']==0 and v['pass'] and v['expected_count']==v['observed_count']==n and v['log_sha256']==sha(F/(name+'.log'))
 assert next(x for x in summary['results'] if x['name']==name)==v
 if name.endswith('cli'):assert re.search(r'Ran '+str(n)+r' tests in',text) and re.search(r'\nOK\s*$',text)
 else:
  run=re.findall(r'^\[ RUN      \] (.+)$',text,re.M);ok=re.findall(r'^\[       OK \] (.+) \(\d+ ms\)$',text,re.M);assert len(run)==len(ok)==len(set(run))==n and run==ok
control=read(R/'control-proof.json');assert control['default_zero_raw_bytes_equal'] and sorted(x['case'] for x in control['controls'])==['default','zero'] and control['script_sha256']==sha(R/'prepare-controls.py')
prior=read(OLD/'prepare-default/receipt.json');oldbytes=(OLD/'prepare-default/placed.json').read_bytes()
for x in control['controls']:
 assert all(x[k] for k in ('complete_modules_equal','all_bytes_except_creator_equal','predicted_timing_bytes_equal'))
 folder=R/('prepare-'+x['case']);v=read(folder/'receipt.json');assert v['returncode']==0 and v['binary_sha256']==build['production_sha256'] and v['inputs']==prior['inputs']
 expected=prior['nextpnr_command'][:];expected[0]=v['nextpnr_command'][0]
 if x['case']=='zero':expected+=['--critical-lut-permute-budget','0']
 assert v['nextpnr_command']==expected and '--no-route' in expected and '--rbf' not in expected
 for p,h in v['artifacts'].items():assert sha(folder/p)==h
 newbytes=(folder/'placed.json').read_bytes();a=json.loads(oldbytes);b=json.loads(newbytes);ca=json.dumps(a.pop('creator')).encode();cb=json.dumps(b.pop('creator')).encode()
 assert a==b and oldbytes.count(ca)==1 and oldbytes.replace(ca,cb,1)==newbytes
 assert (folder/'predicted-timing.json').read_bytes()==(OLD/'prepare-default/predicted-timing.json').read_bytes()
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
# The actual-board probe is a deliberately rejected native structural exercise,
# never reloaded STA or proof of retained timing improvement.
board=read(R/'isolated-native-v2/proof.json');assert board['passed'] and len(board['cases'])==3
bound={}
for p,h in board['immutable_inputs_sha256'].items():assert sha(p)==h;bound[p]=h
write(R/'board-admission-binding.json',{'proof_sha256':sha(R/'isolated-native-v2/proof.json'),'verified_immutable_inputs_sha256':bound,'scope':'Actual saved-board native physical/configuration and exact rollback probe. Isolated old internally consistent ABI; no full-route timing, no retained board candidate and no hardware acceptance. Executables and object payload are not part of the compact host manifest.'})
write(R/'retained-source-proof.json',{'earlier_commit':base,'earlier_final_validation_sha256':sha(OLD/'final-validation.json'),'unchanged_source_files':proof['unchanged_complete_source_files'],'scope':'Only current source-exit12, existing ordinary-permutation45 and CLI8 reran. Other LUT6/source/private/unused/cache suites retain earlier exact source/build provenance.'})
files={}
for prefix in ('source','before','source-validation','complete-source','prepare-default','prepare-zero'):
 if not (R/prefix).exists():continue
 for p in sorted((R/prefix).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:files[str(p.relative_to(R))]=sha(p)
for name in ('source-identity.json','independent-source-review.json','production.patch','prepare-controls.py','controls.log','control-proof.json','retained-source-proof.json','board-admission-binding.json','freeze-validation.py','route.py'):
 assert (R/name).is_file(),name;files[name]=sha(R/name)
# Retain failed fixture attempts and exact source/readback identities; omit all
# compiler objects, binaries, copied GTest libraries/headers and scratch files.
allowed={'.json','.log','.cc','.py','.patch'}
for prefix in ('native-tests','isolated-native','isolated-native-v2'):
 for p in sorted((R/prefix).rglob('*')):
  rel=p.relative_to(R)
  if not p.is_file() or p.suffix not in allowed or any(x in {'__pycache__','gtest-include','gtest-lib'} for x in rel.parts) or p.name.startswith('cc'):continue
  files[str(rel)]=sha(p)
for p in sorted(R.glob('*.json')):
 if p.name in {'final-validation.json','committed-source-verification.json'}:continue
 files[p.name]=sha(p)
final={'scope':'Host-only admission for opt-in retention of original protected-LAB native source exits during the existing ordinary-LUT permutation transaction. Default unchanged; complete native physical/setup/hold/clock/coverage guards remain. No timing gain or hardware acceptance.',
'binary_sha256':build['production_sha256'],'native_test_sha256':build['native_test_sha256'],'source_parent':base,'source_files':sources,'files':files,
'final_source_identity_path':'source-validation/final-host/source-identity.json','final_source_identity_sha256':sha(H/'source-identity.json'),
'independent_source_review_passed':True,'source_review_path':'independent-source-review.json','source_review_sha256':sha(R/'independent-source-review.json'),
'independent_fixture_registration_review_path':str(fixture_review_path.relative_to(R)),'independent_fixture_registration_review_sha256':sha(fixture_review_path),
'control_proof_sha256':sha(R/'control-proof.json'),
'enabled_lut_permutation_route_admission':True,'enabled_lut_permutation_source_exit_route_admission':True,
'validation':{'passed':True,'source_exit_native_count':12,'lut_permutation_native_count':45,'total_native_count':57,'source_exit_total_native_count':57,'lut_permutation_cli_count':8},
'board_probe_scope':{'proof_sha256':sha(R/'isolated-native-v2/proof.json'),'binding_sha256':sha(R/'board-admission-binding.json'),'scope':'Structural/configuration/rollback only, no live original STA or timing acceptance'},
'retained_prior_validation':{'path':str(OLD/'final-validation.json'),'sha256':sha(OLD/'final-validation.json'),'unchanged_source_proof_sha256':sha(R/'retained-source-proof.json'),'scope':'Earlier suites retain original provenance; only12+45+8 rerun.'}}
write(R/'final-validation.json',final);print(sha(R/'final-validation.json'))
