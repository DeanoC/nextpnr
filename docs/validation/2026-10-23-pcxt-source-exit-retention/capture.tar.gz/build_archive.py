#!/usr/bin/env python3
from pathlib import Path
import gzip,hashlib,json,tarfile
C=Path(__file__).resolve().parent;P=C/'payload'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest={str(p.relative_to(P)):{'sha256':sha(p),'size':p.stat().st_size} for p in sorted(P.rglob('*')) if p.is_file() and p!=P/'manifest.json'}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');(C/'manifest.json').write_bytes((P/'manifest.json').read_bytes())
with (C/'capture.tar.gz').open('wb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6) as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for p in sorted(P.rglob('*')):
    if p.is_file():
     info=t.gettarinfo(str(p),str(p.relative_to(P)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
     with p.open('rb') as stream:t.addfile(info,stream)
v={'archive_sha256':sha(C/'capture.tar.gz'),'bytes':(C/'capture.tar.gz').stat().st_size,'members':len(manifest)+1,'manifest_sha256':sha(C/'manifest.json')};(C/'archive-identity.json').write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');print(json.dumps(v,sort_keys=True))
