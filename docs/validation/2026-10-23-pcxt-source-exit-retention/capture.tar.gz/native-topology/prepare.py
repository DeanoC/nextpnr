#!/usr/bin/env python3
"""Bind the internally consistent old structural reader to source-exit JSON evidence."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess
H=Path(__file__).resolve().parent;R=H.parent;OLD=R.parent/'lut-permutation-budget32-20261023/native-topology';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def blob(commit,name):return subprocess.check_output(['git','show',commit+':'+name],cwd=S)
for n in ['tree-reader','tree-reader.cc','build-receipt.json','build-commands.json','build.log','frozen-manifest.json','committed-source-verification.json']:
 p=H/n
 if p.exists():assert sha(p)==sha(OLD/n)
 elif n=='tree-reader':os.link(OLD/n,p)
 else:shutil.copy2(OLD/n,p)
for n,newname in [('architecture-compatibility.json','prior-cap32-compatibility.json'),('prepare.py','prior-cap32-prepare.py'),('independent-reader-review.json','prior-cap32-reader-review.json')]:
 p=H/newname
 if p.exists():assert sha(p)==sha(OLD/n)
 else:shutil.copy2(OLD/n,p)
build=read(H/'build-receipt.json');assert build['pass'] and sha(H/'tree-reader')==build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
assert sha(H/'tree-reader.cc')==build['helper_source_sha256'] and sha(H/'frozen-manifest.json')==build['frozen_manifest_sha256']
old='186637013e17461a72cd1d2cd17ca5ef174ed06f';parent='134b858165a4dd0c00c8b5d5371fbf90fdac63a3';new='1ba2e289f5bf4e584a8539f185d6f15383650c26'
q=read(H/'committed-source-verification.json');prior=read(H/'prior-cap32-compatibility.json');identity=read(R/'source-validation/final-host/source-identity.json');commit=read(R/'committed-source-verification.json')
assert q['passed'] and q['source_commit']==old and prior['passed'] and prior['reader_compiler_commit']==old and prior['route_compiler_commit']==parent
assert commit['commit']==new and identity['base_commit']==parent and commit['all_recorded_source_bytes_match_commit']
assert sha(R/'final-validation.json')==commit['final_validation_sha256']=='a3762f00fdb6a84e54b0e2daf63a3aae9e12a3ff3d0c8efc12051e8790122c0e'
delta=set(subprocess.check_output(['git','diff','--name-only',parent,new,'--','mistral','common','json','generic','3rdparty'],cwd=S,text=True).splitlines())
assert delta=={'mistral/CMakeLists.txt','mistral/analogue_repair.h','mistral/arch.h','mistral/main.cc','mistral/routed_lut_permutation.cc','mistral/tests/routed_lut_permutation_cli.py','mistral/tests/source_exit_retention_backend.cc'}
same={};different={}
for name,h in q['source_files'].items():
 current=hashlib.sha256(blob(new,name)).hexdigest();(same if current==h else different)[name]={'old_sha256':h,'new_sha256':current}
assert len(same)+len(different)==309
assert set(different)=={'mistral/CMakeLists.txt','mistral/analogue_repair.h','mistral/arch.h','mistral/main.cc','mistral/routed_lut6_swap.cc','mistral/routed_lut_permutation.cc','mistral/private_pair_decomposition.cc'}
assert 'mistral/main.cc.o' not in (H/'build-commands.json').read_text()
for name in ('mistral/routed_lut6_swap.cc','mistral/private_pair_decomposition.cc'):assert blob(parent,name)==blob(new,name)
line=b'    bool critical_lut_permute_retain_source_exits = false; // Preserve only original protected-LAB source exits.\n'
after=blob(new,'mistral/arch.h');assert after.count(line)==1 and after.replace(line,b'')==blob(parent,'mistral/arch.h')
a=blob(parent,'mistral/analogue_repair.h');b=blob(new,'mistral/analogue_repair.h');suffix=b'const std::function<void(unsigned)> &stage = {}, bool keep_source_exits = false);'
assert b.count(suffix)==1 and b.replace(suffix,b'const std::function<void(unsigned)> &stage = {});')==a
b=blob(new,'mistral/CMakeLists.txt');token=b'tests/source_exit_retention_backend.cc ';assert b.count(token)==1 and b.replace(token,b'')==blob(parent,'mistral/CMakeLists.txt')
for name,v in identity['files'].items():assert hashlib.sha256(blob(new,name)).hexdigest()==v['sha256']
reader=(H/'tree-reader.cc').read_text()
assert 'parse_json(in,argv[1],&c)' in reader and 'restore_cell_pin_map' in reader
assert all(s not in reader for s in ('critical_routed_lut_permutation_trial','repair_critical_lut_permutations','configure_bitstream','TimingAnalyser','assign_alm_lut_inputs'))
v={'passed':True,'reader_compiler_commit':old,'route_compiler_commit':new,'reader_binary_sha256':sha(H/'tree-reader'),'reader_source_sha256':sha(H/'tree-reader.cc'),'reader_build_receipt_sha256':sha(H/'build-receipt.json'),'reader_frozen_manifest_sha256':sha(H/'frozen-manifest.json'),'route_source_identity_sha256':sha(R/'source-validation/final-host/source-identity.json'),'route_final_validation_sha256':sha(R/'final-validation.json'),'prior_cap32_compatibility_sha256':sha(H/'prior-cap32-compatibility.json'),'prior_cap32_prepare_sha256':sha(H/'prior-cap32-prepare.py'),'prior_cap32_reader_review_sha256':sha(H/'prior-cap32-reader-review.json'),'unchanged_snapshotted_source_files':same,'changed_snapshotted_source_files':different,'production_delta_from_cap32_commit':sorted(delta),'new_arch_member_only':True,'new_header_declaration_only':True,'new_cmake_test_registration_only':True,'scope':'Structural saved-JSON source/sink/PIP decoding only. Native parser/model/physical decoding sources remain exact. Reader retains its internally consistent old Context ABI and all original linked objects; no new-object mixing. New Arch boolean, changed trial signature, CLI and permutation native implementation are not invoked by this reader. Source-exit transaction behavior and per-trial ownership are not proved by structural readback. No routing, allocation, configuration, STA or emitted-RBF verification.'}
p=H/'architecture-compatibility.json';encoded=json.dumps(v,indent=2,sort_keys=True)+'\n'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(sha(p))
