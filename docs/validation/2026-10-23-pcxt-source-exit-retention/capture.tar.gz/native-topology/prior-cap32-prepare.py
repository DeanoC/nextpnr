#!/usr/bin/env python3
"""Qualify the immutable structural reader through the exact cap32 compiler commit."""
from pathlib import Path
import hashlib,json,shutil,subprocess
H=Path(__file__).resolve().parent;R=H.parent;OLD=R.parent/'private-pair-node-budget-20261022/native-topology';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def blob(commit,name):return subprocess.check_output(['git','show',commit+':'+name],cwd=S)
for n in ['tree-reader','tree-reader.cc','build-receipt.json','build-commands.json','build.log','frozen-manifest.json','committed-source-verification.json']:
 p=H/n
 if p.exists():assert sha(p)==sha(OLD/n)
 else:shutil.copy2(OLD/n,p)
for n,newname in [('architecture-compatibility.json','prior-private-compatibility.json'),('prepare.py','prior-private-prepare.py')]:
 p=H/newname
 if p.exists():assert sha(p)==sha(OLD/n)
 else:shutil.copy2(OLD/n,p)
build=read(H/'build-receipt.json');assert build['pass'] and sha(H/'tree-reader')==build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
assert sha(H/'tree-reader.cc')==build['helper_source_sha256'] and sha(H/'frozen-manifest.json')==build['frozen_manifest_sha256']
old='186637013e17461a72cd1d2cd17ca5ef174ed06f';parent='f5c6b90df4b8a36a6a8f631998d52ef160c2044b';new='134b858165a4dd0c00c8b5d5371fbf90fdac63a3'
q=read(H/'committed-source-verification.json');prior=read(H/'prior-private-compatibility.json');identity=read(R/'source-identity.json');commit=read(R/'committed-source-verification.json')
assert q['passed'] and q['source_commit']==old and prior['passed'] and prior['reader_compiler_commit']==old and prior['route_compiler_commit']==parent
assert commit['commit']==new and identity['base_commit']==parent and commit['all_recorded_source_bytes_match_commit']
delta=set(subprocess.check_output(['git','diff','--name-only',parent,new,'--','mistral','common','json','generic','3rdparty'],cwd=S,text=True).splitlines())
assert delta=={'mistral/main.cc','mistral/routed_lut_permutation.cc','mistral/tests/routed_lut_permutation_cli.py'}
same={};different={}
for name,h in q['source_files'].items():
 current=hashlib.sha256(blob(new,name)).hexdigest();(same if current==h else different)[name]={'old_sha256':h,'new_sha256':current}
assert set(different)=={'mistral/arch.h','mistral/main.cc','mistral/routed_lut6_swap.cc','mistral/routed_lut_permutation.cc','mistral/private_pair_decomposition.cc'}
assert 'mistral/main.cc.o' not in (H/'build-commands.json').read_text()
for name in ('mistral/arch.h','mistral/routed_lut6_swap.cc','mistral/private_pair_decomposition.cc'):assert blob(parent,name)==blob(new,name)
a=blob(parent,'mistral/routed_lut_permutation.cc');b=blob(new,'mistral/routed_lut_permutation.cc')
assert a.count(b'critical_lut_permute_budget>16')==a.count(b'budget 1..16.')==1
assert a.replace(b'critical_lut_permute_budget>16',b'critical_lut_permute_budget>32').replace(b'budget 1..16.',b'budget 1..32.')==b
policy=read(R/'unchanged-transaction-coverage-proof.json');n=policy['complete_permutation_prefix_bytes']
assert a[:n]==b[:n] and hashlib.sha256(a[:n]).hexdigest()==policy['complete_permutation_prefix_sha256']
for name,v in identity['files'].items():assert hashlib.sha256(blob(new,name)).hexdigest()==v['sha256']
v={'passed':True,'reader_compiler_commit':old,'route_compiler_commit':new,'reader_binary_sha256':sha(H/'tree-reader'),'reader_source_sha256':sha(H/'tree-reader.cc'),'reader_build_receipt_sha256':sha(H/'build-receipt.json'),'reader_frozen_manifest_sha256':sha(H/'frozen-manifest.json'),'route_source_identity_sha256':sha(R/'source-identity.json'),'prior_private_compatibility_sha256':sha(H/'prior-private-compatibility.json'),'prior_private_prepare_sha256':sha(H/'prior-private-prepare.py'),'unchanged_snapshotted_source_files':same,'changed_snapshotted_source_files':different,'production_delta_from_private_node_commit':sorted(delta),'ordinary_permutation_source_exact_after_two_cap_text_substitutions':True,'permutation_native_prefix_bytes':n,'permutation_native_prefix_sha256':policy['complete_permutation_prefix_sha256'],'scope':'Structural saved-JSON source/sink/PIP decoding only. All native parser/model/physical decoding bytes remain exact. Inherited old reader uses its internally consistent old Context ABI; added Arch integers and changed CLI/orchestration functions are never accessed or executed. Additional cap32 delta is exactly two uncalled orchestration bound/error strings plus CLI. No routing, pin allocation, configuration, STA or new-object ABI execution authorized.'}
(H/'architecture-compatibility.json').write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');print(sha(H/'architecture-compatibility.json'))
