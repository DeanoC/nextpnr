from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / sys.argv[1]
FROZEN = ROOT.parent.parent / "unobserved-arith-coverage-20261022/native-topology"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


build = json.loads((BUILD / "build-receipt.json").read_text())
assert build["passed"] and sha(BUILD / "native-tests") == build["binary_sha256"]
assert not (BUILD / "test-receipt.json").exists()
snapshot = json.loads((BUILD / "snapshot.json").read_text())
frozen = json.loads((FROZEN / "frozen-manifest.json").read_text())


def verify():
    for record in snapshot["files"].values():
        assert sha(BUILD / record["copy"]) == record["sha256"]
    for record in frozen["files"].values():
        assert sha(FROZEN / record["copy"]) == record["sha256"]


verify()
command = [str(BUILD / "native-tests"), "--gtest_color=no", "--gtest_output=xml:" + str(BUILD / "tests.xml")]
started = time.monotonic()
with (BUILD / "tests.log").open("w") as log:
    code = subprocess.run(command, cwd=BUILD, env={**os.environ, "TMPDIR": str(BUILD)},
                          stdout=log, stderr=subprocess.STDOUT).returncode
verify()
assert sha(BUILD / "native-tests") == build["binary_sha256"]
root = ET.parse(BUILD / "tests.xml").getroot() if (BUILD / "tests.xml").exists() else None
attrs = dict(root.attrib) if root is not None else {}
tests = [{"suite": suite.get("name"), "name": case.get("name"), "status": case.get("status"),
          "result": case.get("result"), "failed": case.find("failure") is not None}
         for suite in root or [] for case in suite.findall("testcase")]
result = {"passed": code == 0 and attrs.get("tests") == "12" and attrs.get("failures") == "0",
          "returncode": code, "wall_seconds": time.monotonic() - started, "argv": command,
          "binary_sha256": build["binary_sha256"], "build_receipt_sha256": sha(BUILD / "build-receipt.json"),
          "snapshot_sha256": sha(BUILD / "snapshot.json"), "test_log_sha256": sha(BUILD / "tests.log"),
          "test_xml_sha256": sha(BUILD / "tests.xml") if root is not None else None,
          "xml_summary": attrs, "tests": tests, "shared_source_build_mutated": False,
          "scope": "Isolated 12-case native physical/rollback fixture, frozen old ABI plus revised native object; no full route or STA qualification."}
(BUILD / "test-receipt.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
print(json.dumps({key: result[key] for key in ("passed", "returncode", "wall_seconds", "xml_summary")}, sort_keys=True))
assert result["passed"]
