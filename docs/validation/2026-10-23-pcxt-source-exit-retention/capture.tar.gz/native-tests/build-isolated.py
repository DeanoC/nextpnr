"""Build the focused fixture against the immutable 7faa ABI and revised native object."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / (sys.argv[2] if len(sys.argv) > 2 else "isolated-build")
FROZEN = ROOT.parent.parent / "unobserved-arith-coverage-20261022/native-topology"
VARIANT = ROOT.parent / "isolated-native-v2"
REPO = Path("/home/deano/harnesses/pcxt-compiler-repair/nextpnr")
BUILD = REPO.parent / "build-candidate"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


expected = sys.argv[1]
source = ROOT / "source_exit_retention_backend.cc"
assert sha(source) == expected
assert not OUT.exists(), "Preserve previous attempts in their original directories"
OUT.mkdir()
shutil.copyfile(__file__, OUT / "build-driver.py")
manifest = json.loads((FROZEN / "frozen-manifest.json").read_text())


def verify_frozen():
    for record in manifest["files"].values():
        assert sha(FROZEN / record["copy"]) == record["sha256"]


verify_frozen()
copies = {}
inputs = [source, VARIANT / "routed_lut_permutation.cc.o", VARIANT / "routed_lut_permutation.cc",
          VARIANT / "build-receipt.json", VARIANT / "build-plan.json", VARIANT / "variant-identity.json"]
inputs += sorted((REPO / "3rdparty/googletest/googletest/include").rglob("*.h"))
inputs += [BUILD / "lib/libgtest_main.a", BUILD / "lib/libgtest.a"]
for path in inputs:
    if path == source:
        dest = OUT / source.name
    elif path.is_relative_to(VARIANT):
        dest = OUT / "variant" / path.name
    elif path.is_relative_to(REPO / "3rdparty/googletest/googletest/include"):
        dest = OUT / "gtest-include" / path.relative_to(REPO / "3rdparty/googletest/googletest/include")
    else:
        dest = OUT / "libraries" / path.name
    before = sha(path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, dest)
    assert sha(path) == before == sha(dest)
    copies[str(path)] = {"copy": str(dest.relative_to(OUT)), "sha256": before}
write(OUT / "snapshot.json", {"files": copies, "frozen_manifest_sha256": sha(FROZEN / "frozen-manifest.json")})
commands = json.loads((FROZEN / "build-commands.json").read_text())
compile_cmd = [str(OUT / source.name) if x == str(FROZEN / "tree-reader.cc") else
               str(OUT / "fixture.o") if x == str(FROZEN / "tree-reader.o") else x
               for x in commands["compile"]]
compile_cmd.insert(1, "-I" + str(OUT / "gtest-include"))
link_cmd = [str(OUT / "fixture.o") if x == str(FROZEN / "tree-reader.o") else
            str(OUT / "native-tests") if x == str(FROZEN / "tree-reader") else
            str(OUT / "variant/routed_lut_permutation.cc.o")
            if x.endswith("/mistral/CMakeFiles/nextpnr-mistral.dir/routed_lut_permutation.cc.o") else x
            for x in commands["link"]]
link_cmd += [str(OUT / "libraries/libgtest_main.a"), str(OUT / "libraries/libgtest.a"), "-pthread"]
plan = {"compile": compile_cmd, "link": link_cmd, "snapshot_sha256": sha(OUT / "snapshot.json"),
        "fixture_sha256": expected, "frozen_build_commands_sha256": sha(FROZEN / "build-commands.json"),
        "scope": "Only the native permutation object is replaced; old Context ABI and old orchestration remain exact."}
write(OUT / "build-plan.json", plan)
start = time.monotonic()
codes = []
with (OUT / "build.log").open("w") as log:
    for command in (compile_cmd, link_cmd):
        codes.append(subprocess.run(command, cwd=OUT, env={**os.environ, "TMPDIR": str(OUT)},
                                    stdout=log, stderr=subprocess.STDOUT).returncode)
        if codes[-1]:
            break
verify_frozen()
for record in copies.values():
    assert sha(OUT / record["copy"]) == record["sha256"]
result = {"passed": codes == [0, 0], "returncodes": codes, "wall_seconds": time.monotonic() - start,
          "build_plan_sha256": sha(OUT / "build-plan.json"), "log_sha256": sha(OUT / "build.log"),
          "binary_sha256": sha(OUT / "native-tests") if (OUT / "native-tests").exists() else None,
          "shared_source_build_mutated": False, "native_only": True, "gpu_routes": 0}
write(OUT / "build-receipt.json", result)
print(json.dumps(result, sort_keys=True))
assert result["passed"]
