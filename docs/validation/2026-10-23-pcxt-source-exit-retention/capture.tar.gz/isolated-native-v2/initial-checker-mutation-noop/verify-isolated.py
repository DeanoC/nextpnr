"""Exact native saved-context comparison; this deliberately makes no STA claim."""
from pathlib import Path
import copy
import hashlib
import json

ROOT = Path(__file__).resolve().parent
AUDIT = ROOT.parent / "cga-selector-audit-20261023"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def indexed(rows, key):
    result = {key(row): row for row in rows}
    assert len(result) == len(rows)
    return result


def path(net, sink):
    # Frozen native Arch::getPipName concatenates its exact source/destination.
    tree = net["tree"]
    result = {}
    cursor = sink
    while True:
        assert cursor in tree and cursor not in result
        edge = tree[cursor]
        result[cursor] = edge
        if cursor == net["source"]:
            assert edge[0] is None
            return result
        parents = [wire for wire in tree if edge[0] == wire + "." + cursor]
        assert len(parents) == 1
        cursor = parents[0]


def check_on(result):
    assert result["passed"] and result["keep_source_exits"]
    assert not result["accepted"] and result["accept_callback_reached"]
    assert result["complete_rollback_verified"] and not result["rbf_reload_configuration_delta"]
    assert result["restored_ff_cache_mismatches"] == 0 and result["restored_illegal_locations"] == 0
    stages = indexed(result["stages"], lambda row: row["stage"])
    assert 3 in stages and 20 in stages and 21 in stages
    before = indexed(result["original"], lambda row: row["net"])
    after = indexed(stages[21]["selected"], lambda row: row["net"])
    pruned = indexed(stages[3]["selected"], lambda row: row["net"])
    assert before.keys() == after.keys() == pruned.keys()
    for delta in stages[21]["configuration_delta"].values():
        assert delta["before"]["excluded_by_guard"] and delta["before"]["mux"] == "LUT_MASK"
        assert delta["before"]["index"] == result["original_lab"]["target_alm"]
    old_lab, new_lab = result["original_lab"], stages[21]["lab_state"]
    assert old_lab.keys() == new_lab.keys()
    assert old_lab["occupants"].keys() == new_lab["occupants"].keys()
    for name, cell in old_lab["occupants"].items():
        if name != result["target"]:
            assert cell == new_lab["occupants"][name]
    # All output selectors/ownership, including unrelated occupants, stay exact.
    assert len(old_lab["alms"]) == len(new_lab["alms"])
    for original_alm, final_alm in zip(old_lab["alms"], new_lab["alms"]):
        assert original_alm["output_muxes"] == final_alm["output_muxes"]
    stationary_count = 0
    retained_exits = []
    changed_nets = []
    for name, old in before.items():
        final, retained = after[name], pruned[name]
        assert old["source"] == final["source"] == retained["source"]
        original_users = indexed(old["users"], lambda u: (u["cell"], u["index"]))
        final_users = indexed(final["users"], lambda u: (u["cell"], u["index"]))
        assert original_users.keys() == final_users.keys()
        required = {old["source"]: old["tree"][old["source"]]}
        changed = False
        for key, original_user in original_users.items():
            final_user = final_users[key]
            if original_user["cell"] != result["target"]:
                assert original_user == final_user
                for sink in original_user["sinks"]:
                    original_path = path(old, sink["wire"])
                    assert original_path == path(final, sink["wire"])
                    required.update(original_path)
                stationary_count += 1
            else:
                changed |= original_user["sinks"] != final_user["sinks"]
            for sink in final_user["sinks"]:
                assert sink["owner"] == name
                path(final, sink["wire"])
        if changed:
            changed_nets.append(name)
            for alm in old_lab["alms"]:
                for mux, state in alm["output_muxes"].items():
                    wire = state["wire_state"]["wire"]
                    if state["wire_state"]["owner"] != name:
                        continue
                    if state["comb_source"]["wire"] != old["source"]:
                        continue
                    assert wire in old["tree"]
                    edge = old["tree"][wire]
                    assert edge[0] == old["source"] + "." + wire
                    assert state["wire_state"]["pip"] == edge[0]
                    assert state["comb_connected"] and not state["ff_connected"]
                    if wire not in required:
                        retained_exits.append({"net": name, "mux": mux, "wire": wire,
                                               "pip": edge[0], "strength": edge[1]})
                    required[wire] = edge
            assert retained["tree"] == required
        else:
            assert retained["tree"] == old["tree"]
        for wire, edge in retained["tree"].items():
            assert old["tree"].get(wire) == edge
            assert final["tree"].get(wire) == edge
    assert changed_nets and retained_exits
    return {"changed_nets": sorted(changed_nets), "stationary_users": stationary_count,
            "additional_original_rooted_exits": retained_exits,
            "configuration_delta_keys": sorted(stages[21]["configuration_delta"])}


def main():
    cases = []
    fixtures = []
    checked_inputs = {}
    for pair in ("de", "dc", "db"):
        mode_results = {}
        for mode in ("off", "on"):
            folder = ROOT / "isolated-native-v2" / (mode + "-" + pair)
            receipt = load(folder / "receipt.json")
            assert receipt["passed"] and receipt["returncode"] == 0
            assert receipt["native_only"] and not receipt["timing_analyzed"] and not receipt["candidate_retained"]
            assert sha(folder / "result.json") == receipt["result_sha256"]
            for filename, digest in receipt["immutable_inputs_sha256"].items():
                if filename not in checked_inputs:
                    assert sha(filename) == digest
                    checked_inputs[filename] = digest
                assert checked_inputs[filename] == digest
            result = load(folder / "result.json")
            # Pre-mutation validation has no effect on valid-state behavior.
            assert result == load(ROOT / "isolated-native" / (mode + "-" + pair) / "result.json")
            mode_results[mode] = result
        off = copy.deepcopy(mode_results["off"])
        assert not off.pop("keep_source_exits")
        assert off == load(AUDIT / "owner-readback" / ("control-" + pair) / "result.json")
        fields = check_on(mode_results["on"])
        assert mode_results["on"]["original"] == mode_results["off"]["original"]
        assert mode_results["on"]["original_lab"] == mode_results["off"]["original_lab"]
        fixtures.append(mode_results["on"])
        cases.append({"pair": pair, "default_equals_original_diagnostic": True,
                      "revision1_equals_revision0_valid_state": True, **fields})
    negative_checks = []
    for label in ("missing_original_exit", "changed_retained_strength", "changed_stationary_path", "changed_unrelated_mux"):
        result = copy.deepcopy(fixtures[0])
        stages = {s["stage"]: s for s in result["stages"]}
        exits = cases[0]["additional_original_rooted_exits"]
        if label in ("missing_original_exit", "changed_retained_strength"):
            item = exits[0]
            net = next(n for n in stages[3]["selected"] if n["net"] == item["net"])
            if label == "missing_original_exit":
                del net["tree"][item["wire"]]
            else:
                net["tree"][item["wire"]][1] += 1
        elif label == "changed_stationary_path":
            net = next(n for n in stages[21]["selected"] if any(u["cell"] != result["target"] for u in n["users"]))
            user = next(u for u in net["users"] if u["cell"] != result["target"])
            net["tree"][user["sinks"][0]["wire"]][1] += 1
        else:
            alm = stages[21]["lab_state"]["alms"][0]
            next(iter(alm["output_muxes"].values()))["ff_connected"] = True
        try:
            check_on(result)
        except AssertionError:
            negative_checks.append(label)
        else:
            raise AssertionError("Mutation accepted: " + label)
    output = {"passed": True, "cases": cases, "negative_checks_rejected": negative_checks,
              "script_sha256": sha(__file__), "immutable_inputs_sha256": checked_inputs,
              "scope": "Six deliberately rejected native saved-context transactions; no STA, no accepted candidate, no full route.",
              "checks": ["Default and revised valid-state behaviors match immutable earlier native observations exactly.",
                         "All three opt-in trials pass the unchanged native configuration guard and reach the inspection callback.",
                         "After pruning, changed input trees contain exactly original stationary paths, root and original direct source exits.",
                         "Every retained tuple is original; all stationary complete paths and all native output mux owners remain exact.",
                         "Only the target LUT mask changes in native configuration; full rollback is checked by the native helper."],
              "limits": ["Saved native table-delay replay is not live routed STA or timing acceptance.",
                         "The retained exit stub may change loading relative to old pruning; full-route setup/hold/clock guards remain required.",
                         "Native fixture tests separately exercise malformed selector preflight and exception/failure rollback."]}
    (ROOT / "isolated-native-v2/proof.json").write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"passed": True, "cases": cases, "negative_checks_rejected": negative_checks}, sort_keys=True))


if __name__ == "__main__":
    main()
