from pathlib import Path
import json,hashlib,subprocess,time,os
R=Path(__file__).resolve().parent
B=R.parent.parent/'lut-permutation-budget16-20261022'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,j):p.write_text(json.dumps(j,sort_keys=True,indent=2)+'\n')
assert json.loads((R/'build-receipt.json').read_text())['passed']
target='system.machine.isa.slots[1].cga.card.card.pixel_MISTRAL_ALUT6_Q_F_MISTRAL_ALUT5_Q'
for case,first,second,keep in [('off-de','D','E',0),('off-dc','D','C',0),('off-db','D','B',0),('on-de','D','E',1),('on-dc','D','C',1),('on-db','D','B',1)]:
 d=R/case;d.mkdir(exist_ok=False);source=B/'route-budget4';inputs=[R/'probe',R/'probe.cc',R/'build-receipt.json',R.parent.parent/'cga-selector-audit-20261023/compatibility.json',R/'variant-identity.json',R/'routed_lut_permutation.cc',source/'routed.json',source/'diagnostic.rbf',source/'receipt.json',B/'final-analysis/decision-ledger.json'];before={str(p):sha(p) for p in inputs}
 cmd=[str(R/'probe'),str(source/'routed.json'),str(source/'diagnostic.rbf'),target,first,second,str(keep),str(d/'result.json')];t=time.monotonic()
 with (d/'run.log').open('w') as log:rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':str(R)}).returncode
 after={str(p):sha(p) for p in inputs};assert before==after
 j={'passed':rc==0,'argv':cmd,'returncode':rc,'wall_seconds':time.monotonic()-t,'immutable_inputs_sha256':before,'log_sha256':sha(d/'run.log'),'result_sha256':sha(d/'result.json') if (d/'result.json').exists() else None,'native_only':True,'timing_analyzed':False,'candidate_retained':False};save(d/'receipt.json',j);print(json.dumps(j),flush=True)
 assert rc==0
