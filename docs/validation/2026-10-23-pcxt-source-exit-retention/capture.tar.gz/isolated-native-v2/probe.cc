// Isolated structural local-search diagnostic. No STA or timing acceptance.
#include "nextpnr.h"
#include "json_frontend.h"
#include "jsonwrite.h"
#include "json11.hpp"
#include "analogue_repair.h"
#include "cyclonev.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <set>
#include <map>
#include <stdexcept>
USING_NEXTPNR_NAMESPACE
using J=json11::Json;
namespace nextpnr_mistral { bool critical_routed_lut_permutation_trial(Context*,CellInfo*,IdString,IdString,int,const std::function<bool()>&,std::string*,const std::function<void(unsigned)>&,bool); }

static void need(bool yes,const std::string &why){if(!yes)throw std::runtime_error(why);}
static J decoded(const Property &property){auto text=property.as_string();need(text.size()%2==0,"hex length");std::string out,error;
 auto digit=[](char ch){if(ch>='0'&&ch<='9')return ch-'0';if(ch>='a'&&ch<='f')return ch-'a'+10;if(ch>='A'&&ch<='F')return ch-'A'+10;throw std::runtime_error("hex digit");};
 for(size_t i=0;i<text.size();i+=2){out.push_back(char(16*digit(text[i])+digit(text[i+1])));}
 auto result=J::parse(out,error);need(error.empty(),error);return result;}
static J routes(Context &c){J::object result;for(const auto &entry:c.nets){J::object tree;for(const auto &w:entry.second->wires)tree[c.getWireName(w.first).str(&c)]=J::array{w.second.pip==PipId()?J():J(c.getPipName(w.second.pip).str(&c)),int(w.second.strength)};result[entry.first.str(&c)]=tree;}return result;}
static J pins(Context &c){J::object result;for(const auto &entry:c.cells){J::object map;for(const auto &pin:entry.second->pin_data){J::array p{int(pin.second.state)};for(auto b:pin.second.bel_pins)p.push_back(b.str(&c));map[pin.first.str(&c)]=p;}result[entry.first.str(&c)]=map;}return result;}
static std::string graph(Context &c){std::ostringstream out;std::string name="diagnostic";need(write_json_file(out,name,&c),"serialize");return out.str();}
static J selected(Context &c,const std::vector<NetInfo*> &nets){J::array result;for(auto *n:nets){J::array users;for(const auto &u:n->users){J::array sinks,pp;for(auto w:c.getNetinfoSinkWires(n,u)){auto *owner=c.getBoundWireNet(w);sinks.push_back(J::object{{"wire",c.getWireName(w).str(&c)},{"owner",owner?J(owner->name.str(&c)):J()}});}for(auto p:u.cell->pin_data.at(u.port).bel_pins)pp.push_back(p.str(&c));users.push_back(J::object{{"cell",u.cell->name.str(&c)},{"pin",u.port.str(&c)},{"index",int(u.cell->ports.at(u.port).user_idx.idx())},{"BEL",c.getBelName(u.cell->bel).str(&c)},{"physical_pins",pp},{"sinks",sinks}});}
 J::object tree;for(auto w:n->wires)tree[c.getWireName(w.first).str(&c)]=J::array{w.second.pip==PipId()?J():J(c.getPipName(w.second.pip).str(&c)),int(w.second.strength)};
 result.push_back(J::object{{"net",n->name.str(&c)},{"source",c.getWireName(c.getNetinfoSourceWire(n)).str(&c)},{"users",users},{"tree",tree}});}return result;}

using CV=mistral::CycloneV;
static J netname(Context &c,const NetInfo *n){return n?J(n->name.str(&c)):J();}
static J wire(Context &c,WireId w){if(w==WireId())return J();auto *n=c.getBoundWireNet(w);auto p=n&&n->wires.count(w)?n->wires.at(w).pip:PipId();return J::object{{"wire",c.getWireName(w).str(&c)},{"owner",netname(c,n)},{"pip",p==PipId()?J():J(c.getPipName(p).str(&c))}};}
static J config(Context &c,CellInfo *target){auto d=c.bel_data(target->bel).lab_data;auto &lab=c.labs[d.lab];auto type=lab.is_mlab?CV::MLAB:CV::LAB;J::object out;
 for(const auto &v:c.cyclonev->bmux_get()){if(v.btype!=type||v.pos.v!=target->bel.pos.v)continue;J::array raw,bits;for(auto b:v.r)raw.push_back(int(b));std::vector<std::pair<uint32_t,uint32_t>> coords;bool resolved=c.cyclonev->bmux_cram_bits(v.btype,v.pos,v.mux,v.midx,coords);for(auto b:coords)bits.push_back(J::array{int(b.first),int(b.second)});
 std::string key=std::string(CV::bmux_type_names[v.mux])+"["+std::to_string(v.midx)+"]";
 out[key]=J::object{{"block",CV::block_type_names[v.btype]},{"x",int(v.pos.x())},{"y",int(v.pos.y())},{"mux",CV::bmux_type_names[v.mux]},{"index",v.midx},{"type",v.type},{"default",v.def},{"value",double(v.s)},{"setting",v.type==CV::MT_MUX?J(CV::bmux_type_names[v.s]):J()},{"ram",raw},{"cram_coordinates_resolved",resolved},{"cram_coordinates",bits},{"excluded_by_guard",v.mux==CV::LUT_MASK&&v.midx==int(d.alm)}};
 }return out;}
static J labstate(Context &c,CellInfo *target){auto d=c.bel_data(target->bel).lab_data;auto &lab=c.labs[d.lab];J::array alms;J::object occupants;
 for(unsigned i=0;i<lab.alms.size();++i){auto &a=lab.alms[i];J::array clk,ena,aclr,ef,fi,fo,co,lb,fb;for(auto w:a.sel_clk)clk.push_back(wire(c,w));for(auto w:a.sel_ena)ena.push_back(wire(c,w));for(auto w:a.sel_aclr)aclr.push_back(wire(c,w));for(auto w:a.sel_ef)ef.push_back(wire(c,w));for(auto w:a.ff_in)fi.push_back(wire(c,w));for(auto w:a.ff_out)fo.push_back(wire(c,w));for(auto w:a.comb_out)co.push_back(wire(c,w));for(auto b:a.lut_bels)lb.push_back(c.getBelName(b).str(&c));for(auto b:a.ff_bels)fb.push_back(c.getBelName(b).str(&c));
 J::object outputs;const std::array<CV::bmux_type_t,6> muxes{CV::TDFF0,CV::TDFF1,CV::TDFF1L,CV::BDFF0,CV::BDFF1,CV::BDFF1L};const std::array<CV::port_type_t,6> pts{CV::FFT0,CV::FFT1,CV::FFT1L,CV::FFB0,CV::FFB1,CV::FFB1L};const std::array<int,6> ffidx{0,1,1,2,3,3};auto bt=lab.is_mlab?CV::MLAB:CV::LAB;auto pos=a.lut_bels[0].pos;
 for(unsigned k=0;k<6;++k){auto w=c.get_port(bt,pos.x(),pos.y(),i,pts[k]);auto *ff=c.getBoundBelCell(a.ff_bels[ffidx[k]]);outputs[CV::bmux_type_names[muxes[k]]]=J::object{{"port",CV::port_type_names[pts[k]]},{"wire_state",wire(c,w)},{"comb_source",wire(c,a.comb_out[k/3])},{"comb_connected",c.wires_connected(a.comb_out[k/3],w)},{"ff_source",wire(c,a.ff_out[ffidx[k]])},{"ff_connected",c.wires_connected(a.ff_out[ffidx[k]],w)},{"ff_BEL",c.getBelName(a.ff_bels[ffidx[k]]).str(&c)},{"ff_occupant",ff?J(ff->name.str(&c)):J()}};}
 alms.push_back(J::object{{"index",int(i)},{"l6",a.l6_mode},{"carry",a.carry_mode},{"input_count",a.unique_input_count},{"clk_ena_idx",J::array{a.clk_ena_idx[0],a.clk_ena_idx[1]}},{"aclr_idx",J::array{a.aclr_idx[0],a.aclr_idx[1]}},{"sel_clk",clk},{"sel_ena",ena},{"sel_aclr",aclr},{"sel_ef",ef},{"ff_in",fi},{"ff_out",fo},{"comb_out",co},{"lut_bels",lb},{"ff_bels",fb},{"output_muxes",outputs}});}
 for(auto &e:c.cells){auto *x=e.second.get();if(x->bel==BelId())continue;auto loc=c.getBelLocation(x->bel),tloc=c.getBelLocation(target->bel);if(loc.x!=tloc.x||loc.y!=tloc.y)continue;J::object ports,pm;for(auto &p:x->ports)ports[p.first.str(&c)]=J::object{{"direction",int(p.second.type)},{"net",netname(c,p.second.net)},{"index",int(p.second.user_idx.idx())}};for(auto &p:x->pin_data){J::array a{int(p.second.state)};for(auto n:p.second.bel_pins)a.push_back(n.str(&c));pm[p.first.str(&c)]=a;}
 J::object v{{"type",x->type.str(&c)},{"BEL",c.getBelName(x->bel).str(&c)},{"strength",int(x->belStrength)},{"ports",ports},{"pins",pm}};if(x->type==id_MISTRAL_FF){v["cached_datain"]=netname(c,x->ffInfo.datain);v["cached_sdata"]=netname(c,x->ffInfo.sdata);}occupants[e.first.str(&c)]=v;
 }return J::object{{"lab",int(d.lab)},{"target_alm",int(d.alm)},{"target_half",int(d.idx)},{"is_mlab",lab.is_mlab},{"alms",alms},{"occupants",occupants}};}
static J delta(const J&a,const J&b){J::object out;for(auto&e:a.object_items()){need(b.object_items().count(e.first),"configuration key disappeared");if(e.second!=b[e.first])out[e.first]=J::object{{"before",e.second},{"after",b[e.first]}};}need(a.object_items().size()==b.object_items().size(),"configuration key added");return out;}

int main(int argc,char **argv){try{
 need(argc==8,"probe checkpoint rbf target first second keep output");need(std::string(argv[6])=="0"||std::string(argv[6])=="1","invalid keep");const bool keep=std::string(argv[6])=="1";need(!std::ifstream(argv[7]),"immutable output exists");ArchArgs a;a.device="5CSEBA6U23I7";Context c(a);std::ifstream in(argv[1]);need(parse_json(in,argv[1],&c),"parse");need(c.attrs.at(id_step).as_string()=="route","not routed");
 c.restore_placed_pin_maps();
 for(auto &e:c.cells){need(c.restore_cell_pin_map(e.second.get()),"saved pins missing");if(c.is_comb_cell(e.second->type)||e.second->type.in(id_MISTRAL_BUF,id_MISTRAL_MLAB))c.assign_comb_info(e.second.get());else if(e.second->type==id_MISTRAL_FF)c.assign_ff_info(e.second.get());}
 for(auto &e:c.cells)if(e.second->bel!=BelId())c.update_bel(e.second->bel);
 auto saved=decoded(c.attrs.at(c.id("FES_LABSTATE_V1")));need(saved["device"].string_value()==a.device&&saved["labs"].array_items().size()==c.labs.size(),"lab snapshot");
 for(size_t i=0;i<c.labs.size();++i){auto &lab=c.labs[i];auto e=saved["labs"][i];auto loc=c.getBelLocation(lab.alms[0].lut_bels[0]);need(e.array_items().size()==4&&e[0].int_value()==loc.x&&e[1].int_value()==loc.y&&e[2].int_value()==int(lab.is_mlab)&&e[3].array_items().size()==62,"lab geometry");auto s=e[3].array_items();lab.aclr_used={bool(s[0].int_value()),bool(s[1].int_value())};for(size_t ai=0;ai<10;++ai){auto &x=lab.alms[ai];size_t k=2+6*ai;x.l6_mode=s[k].int_value();x.carry_mode=s[k+1].int_value();x.clk_ena_idx={s[k+2].int_value(),s[k+3].int_value()};x.aclr_idx={s[k+4].int_value(),s[k+5].int_value()};}}
 int illegal=0,ff_mismatch=0;for(auto &e:c.cells){auto *x=e.second.get();if(x->bel!=BelId()&&!c.isBelLocationValid(x->bel))++illegal;if(x->type==id_MISTRAL_FF&&(x->ffInfo.datain!=x->getPort(id_DATAIN)||x->ffInfo.sdata!=x->getPort(id_SDATA)))++ff_mismatch;}
 need(!illegal&&!ff_mismatch,"restored native legality/cache failure");c.check();c.pip_delay_calibrated=false;c.configure_bitstream();

 auto *target=c.cells.at(c.id(argv[3])).get();std::ifstream ri(argv[2],std::ios::binary);std::vector<uint8_t> actual_rbf((std::istreambuf_iterator<char>(ri)),std::istreambuf_iterator<char>());need(!actual_rbf.empty(),"missing actual RBF");c.cyclonev->rbf_load(actual_rbf.data(),actual_rbf.size());auto actual_config=config(c,target);c.configure_bitstream();auto baseline_config=config(c,target);auto rbf_reload_delta=delta(actual_config,baseline_config);
 auto before_routes=routes(c),before_pins=pins(c);auto before_graph=graph(c);std::vector<uint8_t> before_rbf;c.cyclonev->rbf_save(before_rbf);J::array stages;auto original_lab=labstate(c,target);std::vector<NetInfo*> observed;for(auto &p:target->ports)if(p.second.net)observed.push_back(p.second.net);std::sort(observed.begin(),observed.end(),[&](auto*x,auto*y){return x->name.str(&c)<y->name.str(&c);});observed.erase(std::unique(observed.begin(),observed.end()),observed.end());auto original=selected(c,observed);
 std::string reason;bool accept_called=false;bool accepted=critical_routed_lut_permutation_trial(&c,target,c.id(argv[4]),c.id(argv[5]),500000,[&](){accept_called=true;return false;},&reason,[&](unsigned stage){J::object s{{"stage",int(stage)},{"selected",selected(c,observed)}};if(stage==2||stage==20||stage==21){s["lab_state"]=labstate(c,target);if(stage>=20){s["configuration"]=config(c,target);s["configuration_delta"]=delta(baseline_config,s["configuration"]);}}stages.push_back(s);},keep);
 need(!accepted,"diagnostic must never retain candidate");need(routes(c)==before_routes&&pins(c)==before_pins&&graph(c)==before_graph,"complete graph/routes/pins rollback differs");std::vector<uint8_t> after_rbf;c.cyclonev->rbf_save(after_rbf);need(before_rbf==after_rbf,"native configured-state rollback differs");need(labstate(c,target)==original_lab,"LAB/selectors/occupants rollback differs");c.check();
 J result=J::object{{"keep_source_exits",keep},{"passed",true},{"target",target->name.str(&c)},{"first",argv[4]},{"second",argv[5]},{"original",original},{"original_lab",original_lab},{"actual_rbf_configuration",actual_config},{"baseline_configuration",baseline_config},{"rbf_reload_configuration_delta",rbf_reload_delta},{"stages",stages},{"accepted",accepted},{"accept_callback_reached",accept_called},{"reason",reason},{"restored_illegal_locations",illegal},{"restored_ff_cache_mismatches",ff_mismatch},{"complete_rollback_verified",true},{"cost_mode","native table delays; live learned pip observations are not serialized"},{"scope","Isolated structural transaction from saved final topology; actual RBF target-LAB configuration independently compared. No GPU, full route, STA or timing acceptance. Candidate always rejected."}};
 std::ofstream out(argv[7]);out<<result.dump()<<"\n";return 0;
}catch(const std::exception &e){std::cerr<<"REJECTED: "<<e.what()<<"\n";return 1;}}
