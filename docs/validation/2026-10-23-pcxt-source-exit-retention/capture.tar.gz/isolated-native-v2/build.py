from pathlib import Path
import json,hashlib,subprocess,difflib,time,os
R=Path(__file__).resolve().parent;F=R.parent.parent/'unobserved-arith-coverage-20261022/native-topology';repo=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');base='186637013e17461a72cd1d2cd17ca5ef174ed06f'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest=json.loads((F/'frozen-manifest.json').read_text())
def verify():
 for record in manifest['files'].values():assert sha(F/record['copy'])==record['sha256']
verify()
commands=json.loads((F/'build-commands.json').read_text())
compile=[[str(R/source) if x==str(F/'tree-reader.cc') else str(R/(source+'.o')) if x==str(F/'tree-reader.o') else x for x in commands['compile']] for source in ('probe.cc','routed_lut_permutation.cc')]
link=[str(R/'probe.cc.o') if x==str(F/'tree-reader.o') else str(R/'probe') if x==str(F/'tree-reader') else str(R/'routed_lut_permutation.cc.o') if x.endswith('/mistral/CMakeFiles/nextpnr-mistral.dir/routed_lut_permutation.cc.o') else x for x in commands['link']]
plan={'compile':compile,'link':link,'frozen_manifest_sha256':sha(F/'frozen-manifest.json'),'frozen_build_commands_sha256':sha(F/'build-commands.json'),'production_source_commit':base,'source_sha256':{p:sha(R/p) for p in ('probe.cc','routed_lut_permutation.cc','isolated-variant.patch')}}
(R/'build-plan.json').write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n');t=time.monotonic();codes=[]
with (R/'build.log').open('w') as log:
 for cmd in compile+[link]:
  rc=subprocess.run(cmd,cwd=R,env={**os.environ,'TMPDIR':str(R)},stdout=log,stderr=subprocess.STDOUT).returncode;codes.append(rc)
  if rc:break
verify();assert all(sha(R/p)==h for p,h in plan['source_sha256'].items())
receipt={'passed':codes==[0,0,0],'returncodes':codes,'build_plan_sha256':sha(R/'build-plan.json'),'log_sha256':sha(R/'build.log'),'binary_sha256':sha(R/'probe') if (R/'probe').exists() else None,'wall_seconds':time.monotonic()-t,'shared_source_build_mutated':False}
(R/'build-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps(receipt));assert receipt['passed']
