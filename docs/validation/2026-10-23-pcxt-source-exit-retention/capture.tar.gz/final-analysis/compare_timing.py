#!/usr/bin/env python3
"""Complete final native endpoint/metadata comparison; no intersected evidence."""
from pathlib import Path
from collections import Counter,defaultdict
from decimal import Decimal
from support import paired_receipts, finite_tree, verify_recorded, verify_binary, reference_folder, reference_original
import hashlib,json
R=Path(__file__).resolve().parent;ROOT=R.parent
def need(value,message):
 if not value:raise ValueError(message)
def unique(pairs):
 result={}
 for k,v in pairs:need(k not in result,'duplicate JSON key '+k);result[k]=v
 return result
def read(p):
 value=json.loads(p.read_text(),object_pairs_hook=unique);finite_tree(value);return value
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def verify_input(info):
 verify_recorded(info['path'],info['sha256'])
def index(s):
 out={}
 for identity,values in s['endpoints'].items():
  for value in values:
   key=(identity,tuple(value['launch']),tuple(value['capture']));need(key not in out,'duplicate endpoint/domain identity');out[key]=value
 return out
def metric(values):
 values=list(values);out={'rows':len(values)}
 for field,flag in [('setup','setup_timed'),('hold','hold_related')]:
  margins=[v[field] for v in values if v[flag]]
  out[field]={'checked':len(margins),'failures':sum(x<0 for x in margins),'minimum_ps':min(margins,default=None)}
 return out
def cohorts(rows):
 groups=defaultdict(list)
 for key,value in rows.items():groups[key[1:]].append((key[0],value))
 return [{'launch':k[0],'capture':k[1],**metric(v for _,v in group),
          'CPU_capture_rows':metric(v for ident,v in group if json.loads(ident)[0].startswith('system.machine.cpu.'))}
         for k,group in sorted(groups.items())]
def paths(timing,cpu):
 result=[]
 for path in timing['critical_paths']:
  if path['from']!=path['to'] or path['to']!='posedge clocks[0]':continue
  capture=path['path'][-1]['to']
  if cpu and not capture['cell'].startswith('system.machine.cpu.'):continue
  total=defaultdict(float)
  for segment in path['path']:total[segment['type']]+=segment['delay']
  result.append({'slack_ns':path['max_delay']-sum(s['delay'] for s in path['path']),
                 'segment_sum_ns':dict(total),'complete_path':path})
 return sorted(result,key=lambda p:p['slack_ns'])[:10]

def endpoint_guard(before,after):
 """Independently reproduce the emitted final inventory nonregression predicate."""
 left,right=index(before),index(after);errors=[];gains=[]
 if before.get('schema')!=7 or after.get('schema')!=7 or not left or not right or not before.get('clocks') or not after.get('clocks'):errors.append('missing/nonempty native inventory precondition')
 if before.keys()!=after.keys():errors.append('complete top-level endpoint schema differs')
 if {k:v for k,v in before.items() if k!='endpoints'}!={k:v for k,v in after.items() if k!='endpoints'}:errors.append('complete metadata/physical/clock contract differs')
 if left.keys()!=right.keys():errors.append('complete endpoint/domain identity inventory differs')
 for key in sorted(set(left)|set(right)):
  x,y=left.get(key),right.get(key)
  if x is None or y is None:continue
  if {k:v for k,v in x.items() if k not in {'setup','hold','min_path','max_path'}}!={k:v for k,v in y.items() if k not in {'setup','hold','min_path','max_path'}}:errors.append({'row':key,'reason':'window/domain/flag metadata differs'})
  for margin,flag in [('setup','setup_timed'),('hold','hold_related')]:
   if type(x.get(flag)) is not bool or type(y.get(flag)) is not bool:errors.append({'row':key,'reason':'invalid timing flag'});continue
   if x[flag] and y[flag]:
    if type(x.get(margin)) not in (int,float) or type(y.get(margin)) not in (int,float):errors.append({'row':key,'reason':'missing timed margin'});continue
    if y[margin]<x[margin]:errors.append({'row':key,'reason':margin+' regression','before_ps':x[margin],'after_ps':y[margin],'previously_positive':x[margin]>0})
    if margin=='setup' and x[margin]<0 and y[margin]>=x[margin]+20:gains.append({'row':key,'gain_ps':y[margin]-x[margin]})
   elif x.get(margin)!=y.get(margin):errors.append({'row':key,'reason':'untimed margin changed'})
  for field in ('min_path','max_path'):
   if type(x.get(field)) not in (int,float) or type(y.get(field)) not in (int,float):errors.append({'row':key,'reason':'invalid path extrema'})
  if not x['setup_timed'] and (y['max_path']>x['max_path'] or y['min_path']<x['min_path']):errors.append({'row':key,'reason':'untimed extrema regression'})
 return {'nonregression_and_inventory_pass':not errors,'all_violations':errors,'all_failing_setup_gains_at_least20ps':gains,
         'scope':'Emitted final skewed inventory only. Both internal skewed/reference-free acceptance analyses are guarded in-process but the reference-free final inventory is not separately emitted.'}

def clock_guard(before,after):
 errors=[];a,b=before['timing_summary'],after['timing_summary']
 if not a.get('clocks') or not b.get('clocks'):errors.append('empty native clock summary inventory')
 if a.keys()!=b.keys() or {k:v for k,v in a.items() if k!='clocks'}!={k:v for k,v in b.items() if k!='clocks'}:errors.append('native clock summary metadata differs')
 if a['clocks'].keys()!=b['clocks'].keys():errors.append('native clock summary inventory differs')
 for clock in sorted(set(a['clocks'])|set(b['clocks'])):
  x,y=a['clocks'].get(clock),b['clocks'].get(clock)
  if x is None or y is None:continue
  if x.keys()!=y.keys():errors.append({'clock':clock,'reason':'clock field inventory differs'});continue
  for field in x:
   if field not in ('setup_wns_ns','hold_wns_ns'):
    if x[field]!=y[field]:errors.append({'clock':clock,'field':field,'reason':'unrecognized clock field changed'})
   elif type(x[field]) not in (int,float) or type(y[field]) not in (int,float) or y[field]<x[field]:errors.append({'clock':clock,'field':field,'before':x[field],'after':y[field],'reason':'clock margin regression/invalid value'})
 a,b=before['fmax'],after['fmax']
 if not a or not b:errors.append('empty native fmax inventory')
 if a.keys()!=b.keys():errors.append('complete fmax inventory differs')
 for clock in sorted(set(a)|set(b)):
  x,y=a.get(clock),b.get(clock)
  if x is None or y is None:continue
  if x.keys()!=y.keys() or {k:v for k,v in x.items() if k!='achieved'}!={k:v for k,v in y.items() if k!='achieved'}:errors.append({'clock':clock,'reason':'fmax constraints/metadata differ'})
  if type(x.get('achieved')) not in (int,float) or type(y.get('achieved')) not in (int,float) or x['achieved']<=0 or y['achieved']<x['achieved']:errors.append({'clock':clock,'reason':'fmax regression/invalid value'})
 return {'pass':not errors,'all_violations':errors}
def main():
 names=['default','retain'];runs={};reports={};snapshots={};rows={};receipts=paired_receipts()
 for name in names:
  folder=ROOT/('route-'+name);receipt=read(folder/'receipt.json');receipts[name]=receipt
  for artifact,digest in receipt['artifacts'].items():need(sha(folder/artifact)==digest,'route artifact digest '+name+'/'+artifact)
  need(receipt['returncode'] in [0,1],'launch/runtime failure cannot be a timing result')
  for info in receipt['inputs'].values():verify_input(info)
  t=read(folder/'timing.json');s=read(folder/'endpoints.json')
  need(s['final_analogue'] is True and t['timing_summary']['final_analogue_model'] is True,'not final analogue timing')
  reports[name]=t;snapshots[name]=s;rows[name]=index(s)
  runs[name]={'receipt_sha256':sha(folder/'receipt.json'),'artifact_sha256':receipt['artifacts'],
              'returncode':receipt['returncode'],'charged_seconds':receipt['charged_seconds'],
              'schema':s['schema'],'complete':s['complete'],'unsupported_count':len(s['unsupported']),
              **metric(rows[name].values()),'all_clock_pairs':cohorts(rows[name]),
              'all_clock_summaries':t['timing_summary'],'all_fmax':t['fmax'],
              'worst_CPU_system_paths':paths(t,True),'worst_whole_system_paths':paths(t,False)}
 a,b=[receipts[n] for n in names];need(a['binary_sha256']==b['binary_sha256'],'route binary mismatch')
 verify_binary(a['binary_sha256'],a['nextpnr_command'][0])
 expected=a['nextpnr_command'][:];need(expected[expected.index('--critical-lut-permute-budget')+1]=='32','control budget');need('--critical-lut-permute-retain-source-exits' not in expected,'control retention enabled');expected.append('--critical-lut-permute-retain-source-exits');need(b['nextpnr_command']==expected,'unexpected route command difference')
 need(a['inputs']==b['inputs'],'unexpected input difference')
 need(a['committed_source_verification']==b['committed_source_verification'],'route committed sources differ')
 ar,br=[rows[n] for n in names];deltas=[];counts={m:Counter() for m in ['setup','hold']};cohort_deltas=defaultdict(lambda:{m:Counter() for m in ['setup','hold']})
 identity_equal=ar.keys()==br.keys();flags_equal=True
 for key in sorted(set(ar)|set(br)):
  x,y=ar.get(key),br.get(key);entry={'identity':json.loads(key[0]),'launch':key[1],'capture':key[2],'default':x,'selected':y}
  if x is None or y is None:
   entry['inventory_change']='added' if x is None else 'removed';flags_equal=False
  else:
   entry['all_fields_equal']=x==y
   fields=set(x)|set(y);entry['all_field_deltas']={k:{'before':x.get(k),'after':y.get(k)} for k in sorted(fields) if k not in x or k not in y or x[k]!=y[k]}
   margins={'setup','hold','min_path','max_path'}
   if {k:v for k,v in x.items() if k not in margins}!={k:v for k,v in y.items() if k not in margins}:flags_equal=False
   entry['margin_delta_ps']={m:y[m]-x[m] if type(x.get(m)) in [int,float] and type(y.get(m)) in [int,float] else None for m in margins}
   for margin,flag in [('setup','setup_timed'),('hold','hold_related')]:
    if x[flag] and y[flag]:
     d=y[margin]-x[margin];label='improved' if d>0 else 'regressed' if d<0 else 'unchanged';counts[margin][label]+=1;cohort_deltas[key[1:]][margin][label]+=1
  deltas.append(entry)
 metadata={}
 for key in sorted((set(snapshots[names[0]])|set(snapshots[names[1]]))-{'endpoints'}):
  x,y=snapshots[names[0]].get(key),snapshots[names[1]].get(key)
  metadata[key]={'present_default':key in snapshots[names[0]],'present_selected':key in snapshots[names[1]],'equal':key in snapshots[names[0]] and key in snapshots[names[1]] and x==y,'default':x,'selected':y}
 detailed_margin_summary={}
 for margin,flag in [('setup','setup_timed'),('hold','hold_related')]:
  comparable=[entry for entry in deltas if entry['default'] is not None and entry['selected'] is not None and entry['default'][flag] and entry['selected'][flag]]
  values=[entry['margin_delta_ps'][margin] for entry in comparable]
  detailed_margin_summary[margin]={'largest_improvement_ps':max(values,default=None),'largest_regression_ps':min(values,default=None),
       'positive_margin_regressions':sum(entry['default'][margin]>0 and entry['selected'][margin]<entry['default'][margin] for entry in comparable),
       'previously_negative_now_nonnegative':sum(entry['default'][margin]<0<=entry['selected'][margin] for entry in comparable),
       'previously_nonnegative_now_negative':sum(entry['selected'][margin]<0<=entry['default'][margin] for entry in comparable)}
 def saved_path(report,entry):
  launch=('posedge ' if entry['launch'][1]==0 else 'negedge ')+entry['launch'][0]
  capture=('posedge ' if entry['capture'][1]==0 else 'negedge ')+entry['capture'][0]
  matches=[path for path in report['critical_paths'] if path['from']==launch and path['to']==capture and
           [path['path'][-1]['to']['cell'],path['path'][-1]['to']['port']]==entry['identity']]
  need(len(matches)<=1,'ambiguous bounded path identity')
  if not matches:return None
  path=matches[0];source=next((s['from'] for s in path['path'] if s['type']=='clk-to-q'),None)
  family='other_or_unavailable'
  if source:
   cell=source['cell']
   if cell.startswith('system.machine.cpu.'):family='CPU'
   elif '.mda.' in cell:family='MDA'
   elif '.cga.' in cell:family='CGA'
   elif '.pic_device.' in cell:family='PIC'
  return {'actual_saved_launch_cell_and_pin':source,'family_inferred_from_actual_launch_cell':family,'complete_path':path}
 old_negative=[]
 for entry in deltas:
  if entry['default'] is not None and entry['default']['setup_timed'] and entry['default']['setup']<0:
   old_negative.append({**entry,'default_saved_setup_path':saved_path(reports['default'],entry),'selected_saved_setup_path':saved_path(reports['retain'],entry)})
 failures={}
 for name in names:
  failures[name]=[{'identity':json.loads(key[0]),'launch':key[1],'capture':key[2],'native_row':value,
                  'actual_saved_source_and_path':saved_path(reports[name],{'identity':json.loads(key[0]),'launch':key[1],'capture':key[2]})}
                 for key,value in sorted(rows[name].items()) if value['setup_timed'] and value['setup']<0]
 timing_categories={}
 for key in sorted(set(reports[names[0]])|set(reports[names[1]])):
  x,y=reports[names[0]].get(key),reports[names[1]].get(key)
  entry={'present_default':key in reports[names[0]],'present_selected':key in reports[names[1]],'equal':key in reports[names[0]] and key in reports[names[1]] and x==y}
  if key not in ['critical_paths','detailed_net_timings']:entry.update(default=x,selected=y)
  else:
   def k(v):
    if key=='critical_paths':return v['from'],v['to'],v['path'][-1]['to']['cell'],v['path'][-1]['to']['port']
    return v['driver'],v['port'],v['event'],v['net']
   left={};right={}
   for target,values in [(left,x),(right,y)]:
    for position,value in enumerate(values):
     identity=k(value);need(identity not in target,'duplicate timing record');target[identity]=(position,value)
   entry.update(default_count=len(left),selected_count=len(right),identities_equal=left.keys()==right.keys())
   changes=[];order=[]
   for identity in sorted(set(left)|set(right)):
    old,new=left.get(identity),right.get(identity)
    if old is None or new is None or old[1]!=new[1]:changes.append({'identity':identity,'default':old[1] if old else None,'selected':new[1] if new else None})
    if old and new and old[0]!=new[0]:order.append({'identity':identity,'default_index':old[0],'selected_index':new[0]})
   entry.update(all_changed_records=changes,all_record_order_changes=order)
  timing_categories[key]=entry
 reference=reference_folder();reference_comparison={}
 prior=read(reference/'receipt.json');need(sha(reference/'receipt.json')==a['immutable_evidence_sha256'][reference_original()+'/receipt.json'],'prior reference receipt mismatch')
 for name,digest in prior['artifacts'].items():need(sha(reference/name)==digest,'prior reference artifact mismatch')
 for name in ['diagnostic.rbf','routed.json','timing.json','endpoints.json']:
  reference_comparison[name]={'reference_sha256':sha(reference/name),'default_sha256':sha(ROOT/'route-default'/name),'byte_identical':(reference/name).read_bytes()==(ROOT/'route-default'/name).read_bytes()}
 old_graph,new_graph=read(reference/'routed.json'),read(ROOT/'route-default/routed.json')
 default_graph={'top_level_field_inventory_equal':old_graph.keys()==new_graph.keys(),
                'creator_before':old_graph.get('creator'),'creator_after':new_graph.get('creator'),
                'every_other_serialized_field_equal':{k:v for k,v in old_graph.items() if k!='creator'}=={k:v for k,v in new_graph.items() if k!='creator'}}
 default_invariance=all(reference_comparison[n]['byte_identical'] for n in ('diagnostic.rbf','timing.json','endpoints.json')) and default_graph['top_level_field_inventory_equal'] and default_graph['every_other_serialized_field_equal']
 native_guard=endpoint_guard(snapshots['default'],snapshots['retain']);native_clocks=clock_guard(reports['default'],reports['retain'])
 result={'status':'complete_comparison','scope':'Complete final native reports for two fresh routes; physical IO and hardware qualification remain separate.',
         'checker_sha256':sha(Path(__file__)),'runs':runs,'endpoint_identity_inventory_equal':identity_equal,
         'all_row_domain_windows_and_flags_equal':flags_equal,'all_nonendpoint_categories':metadata,
         'all_metadata_categories_equal':all(v['equal'] for v in metadata.values()),'every_endpoint_row':deltas,
         'native_margin_delta_counts':counts,'all_clock_pair_delta_counts':[{'launch':k[0],'capture':k[1],'counts':v} for k,v in sorted(cohort_deltas.items())],
         'margin_extrema_and_positive_regressions':detailed_margin_summary,'every_previously_failing_endpoint_with_actual_saved_source':old_negative,
         'every_setup_failure_each_run':failures,'independent_emitted_inventory_guard':native_guard,'independent_complete_clock_guard':native_clocks,
         'all_emitted_timing_categories':timing_categories,'default_vs_prior_fixed_route_artifact_bytes':reference_comparison,
         'default_vs_prior_fixed_complete_graph':default_graph,
         'default_vs_prior_fixed_invariance_pass':default_invariance,
         'pair_charge_seconds':str(sum(Decimal(str(receipts[n]['charged_seconds'])) for n in names)),
         'charge_scope':'This comparison includes a fresh budget32 control and source-exit candidate; prior references are not recharged.',
         'limits':['No report or graph intersection hides removed/added identities. All metadata categories and all endpoint rows are retained.',
                   'Critical path lists remain bounded report detail; the complete endpoint ledger determines setup/hold inventory.',
                   'The full final inventory remains complete=false with its unchanged unsupported rows; no coverage qualification is inferred.',
                   'Boolean final-graph proof, native route topology, RBF configuration, board obligations and hardware acceptance are separate.']}
 (R/'route-comparison.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
 print(json.dumps({'status':result['status'],'runs':{n:{k:runs[n][k] for k in ['returncode','rows','setup','hold','unsupported_count']} for n in names},
                   'identities_equal':identity_equal,'windows_flags_equal':flags_equal,'all_metadata_equal':result['all_metadata_categories_equal'],
                   'delta_counts':counts,'pair_charge_seconds':result['pair_charge_seconds']},indent=2))
 need(default_invariance,'default full-route behavior changed')
 # Complete direct nonregression results remain explicit in the output.
 # Candidate retention is per-trial versus its live baseline, not versus
 # the option-off run's potentially different accepted sequence.
if __name__=='__main__':main()
