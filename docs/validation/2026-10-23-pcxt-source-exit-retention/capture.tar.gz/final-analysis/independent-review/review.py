#!/usr/bin/env python3
"""Complete independent source-exit pair replay, including both common-baseline proofs."""
from pathlib import Path
import contextlib,hashlib,importlib,io,json,sys
H=Path(__file__).resolve().parent;A=H.parent;ROOT=A.parent
sys.path.insert(0,str(A));sys.dont_write_bytecode=True

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
inputs={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*.py'))};checks=[]
def same(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs';checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
log=io.StringIO()
with contextlib.redirect_stdout(log):
 p=importlib.import_module('prove_graph');p.write=same;p.main()
 p=importlib.import_module('test_sequence_checks');p.write=same;p.main()
 p=importlib.import_module('test_native_port_identity');p.write=same;p.main()
 p=importlib.import_module('verify_topology');p.write=same;p.main()
 p=importlib.import_module('compare_timing');p.R=H;p.main()
assert (H/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
assert inputs=={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*.py'))}
t=read(A/'route-comparison.json')
assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal'] and len(t['every_endpoint_row'])==17199
assert t['independent_complete_clock_guard']['pass'] and t['independent_emitted_inventory_guard']['nonregression_and_inventory_pass'] and not t['independent_emitted_inventory_guard']['all_violations']
assert t['native_margin_delta_counts']=={'setup':{'unchanged':17194},'hold':{'unchanged':17194}} and t['default_vs_prior_fixed_invariance_pass']
assert all(r['setup']['failures']==8 and r['setup']['minimum_ps']==-434 and r['hold']['failures']==0 and r['unsupported_count']==105 and not r['complete'] for r in t['runs'].values())
artifacts={}
for name in ('diagnostic.rbf','routed.json','timing.json','endpoints.json'):
 a,b=ROOT/'route-default'/name,ROOT/'route-retain'/name
 assert a.read_bytes()==b.read_bytes(),name
 artifacts[name]={'byte_equal':True,'sha256':sha(a),'bytes':a.stat().st_size}
per_case={}
for case in ('default','retain'):
 g=read(A/(case+'-graph-proof.json'));n=read(A/(case+'-topology-proof.json'));d=read(A/(case+'-decision-ledger.json'));guards=read(A/(case+'-common-timing-guards.json'))
 assert g['status']=='pass' and g['complete_cells']==12397 and g['complete_net_alias_records']==15546 and g['changed_canonical_net_bits']==[54479,54480,57715,57717]
 assert d['tried']==23 and d['kept']==2 and len(g['accepted_cells'])==2
 assert guards['endpoints']['nonregression_and_inventory_pass'] and guards['clocks']['pass']
 assert n['passed'] and n['native_readback_needed']
 for cell in g['accepted_cells']:
  rows=cell['all_raw_net_rows'];assert len(rows)==1<<cell['width'] and all(x['before_output']==x['after_output'] for x in rows)
 per_case[case]={'accepted_cells':[{'cell':c['cell'],'pins':c['pins'],'truth_rows':len(c['all_raw_net_rows'])} for c in g['accepted_cells']],
  'complete_cells':g['complete_cells'],'complete_aliases':g['complete_net_alias_records'],'changed_canonical_net_bits':g['changed_canonical_net_bits'],
  'native':{k:n[k] for k in ('selected_nets','stationary_users','changed_physical_users','retained_original_wire_tuples')},
  'readback_receipt_sha256':sha(ROOT/'native-topology/paired-readback'/case/'receipt.json')}
result={'passed':True,'reviewer':'timing_strategy','review_script_sha256':sha(__file__),'inputs':inputs,'exact_replays':checks,
 'all_four_final_artifacts':artifacts,'complete_endpoint_rows':17199,'native_margin_delta_counts':t['native_margin_delta_counts'],
 'common_CPU2_comparisons':per_case,'charged_route_seconds':0,
 'findings':['Every accepted permutation is independently proved against common CPU2; option-off accepted transpositions are not applied twice to option-on.',
 'Complete cell, alias, physical mapping, LAB, route ownership and all raw truth rows replay exactly. Both native full-tree readbacks include every logical sink and stationary source-to-sink tuple.',
 'All four final artifacts are byte-identical across the fresh default/retained-exit pair. Every17199 metadata identity and17194 setup/hold margin is retained; eight setup failures remain.',
 'The fresh option-on experiment retained no additional repair. Exact native selector and per-trial source-exit ownership remain live transaction guards; final equality does not reconstruct rejected intermediate state.'],
 'limits':['This agent authored the native readback adaptation; its structural compatibility is separately independently reviewed.',
 'The source-exit stub may be created by an earlier accepted permutation and is not inferred to have existed in the common baseline. Native readback proves final trees only.',
 'Both in-process timing frames remain bound by source/logs; only emitted skewed final timing is independently replayed here. No reload STA, mask/electrical or hardware acceptance is claimed.',
 'Unsupported105 and complete=false remain unchanged.']}
(H/'replay.log').write_text(log.getvalue());(H/'review.json').write_bytes(encoded(result));print(json.dumps({'passed':True,'exact_replays':len(checks),'review_sha256':sha(H/'review.json')},sort_keys=True))
