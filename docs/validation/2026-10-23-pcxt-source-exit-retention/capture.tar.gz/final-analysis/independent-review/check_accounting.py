#!/usr/bin/env python3
"""Exact Decimal/prefix/committed-journal accounting check; no route execution."""
from pathlib import Path
from decimal import Decimal
import json,hashlib,subprocess
H=Path(__file__).resolve().parent;R=H.parent.parent;TASK=R.parent.parent;OLD=R.parent/'lut-permutation-budget32-20261023'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def main():
 source=read(R/'accounting-52/source.json');commit=source['commit'];assert commit=='826dbbe1c5b671f0c9facbdddb6692d1d4242bc4'
 journal=R/'accounting-52/continued-runs.jsonl';prior=OLD/'accounting-50/continued-runs.jsonl';rows=[json.loads(s) for s in journal.read_text().splitlines()];previous=[json.loads(s) for s in prior.read_text().splitlines()]
 assert len(rows)==52 and len(previous)==50 and rows[:50]==previous and journal.read_bytes().startswith(prior.read_bytes())
 assert len({r['case'] for r in rows})==52
 accounting=read(R/'accounting.json');assert sha(journal)==accounting['journal_sha256'] and accounting['completed_subsequent_receipts']==52
 total=Decimal(accounting['pre_journal_charge_seconds'])+sum(Decimal(r['charged_seconds_decimal']) for r in rows);assert str(total)==accounting['cumulative_charge_seconds']=='53488.10083870170587'
 pair=Decimal(0)
 for row in rows[-2:]:
  assert row['case'] in ['out/cga-source-exit-retention-20261023/route-default','out/cga-source-exit-retention-20261023/route-retain']
  path=TASK/row['case']/'receipt.json';receipt=read(path);assert row['receipt_sha256']==sha(path) and row['receipt']==receipt and Decimal(row['charged_seconds_decimal'])==Decimal(str(receipt['charged_seconds']))
  assert receipt['returncode'] in (0,1);pair+=Decimal(row['charged_seconds_decimal'])
 assert str(pair)=='2603.1843361197972' and Decimal(read(OLD/'accounting.json')['cumulative_charge_seconds'])+pair==total
 # Locate the exact committed journal and README rather than assuming a live working file.
 files=subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=TASK,text=True).splitlines();matches=[]
 for name in files:
  if name.endswith('continued-runs.jsonl'):
   blob=subprocess.check_output(['git','show',commit+':'+name],cwd=TASK)
   if hashlib.sha256(blob).hexdigest()==sha(journal):matches.append(name)
 assert len(matches)==1
 readme_name=matches[0].rsplit('/',1)[0]+'/README.md';blob=subprocess.check_output(['git','show',commit+':'+readme_name],cwd=TASK)
 assert blob==(R/'accounting-52/README.md').read_bytes()
 result={'passed':True,'completed_receipts':52,'exact_prior50_prefix':True,'each_new_receipt_bound':True,'pair_charge_seconds':str(pair),'cumulative_charge_seconds':str(total),'journal_sha256':sha(journal),'prior50_journal_sha256':sha(prior),'accounting_sha256':sha(R/'accounting.json'),'fes_commit':commit,'committed_journal_path':matches[0],'committed_readme_sha256':sha(R/'accounting-52/README.md'),'checker_sha256':sha(__file__),'scope':'Exact Decimal journal/prefix and committed evidence review. All routes remain charged despite no retained gain; no historical route re-execution.'}
 (H/'accounting-review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'passed':True,'sha256':sha(H/'accounting-review.json'),'pair':str(pair),'cumulative':str(total)},sort_keys=True))
if __name__=='__main__':main()
