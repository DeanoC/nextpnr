"""Use the pinned native frontend cell-bit naming rule, then require its saved map."""
from support import need

def native_identity(cells, user):
    name, port, index = user
    need(name in cells and isinstance(port, str), 'missing native cell/port identity')
    cell = cells[name]
    need(port in cell['connections'], 'selected logical port absent')
    bits = cell['connections'][port]
    need(type(index) is int and 0 <= index < len(bits), 'selected logical bit index out of range')
    # frontend/frontend_base.h get_bit_name and import_leaf_cell use width only
    # for cell ports: no offset/upto arguments are supplied at this call site.
    seen = set()
    for base, vector in cell['connections'].items():
        for i in range(len(vector)):
            key = base if len(vector) == 1 else f'{base}[{i}]'
            need(key not in seen, 'ambiguous native cell-bit identity')
            seen.add(key)
    return [name, port if len(bits) == 1 else f'{port}[{index}]', 0]

def native_physical_port(cells, user, pinmap):
    name, port, index = native_identity(cells, user)
    cell = cells[name]
    maps = pinmap(cell)
    need(port in maps and len(maps[port]) >= 2, 'selected native bit-port lacks exact physical map')
    return {'cell': name, 'port': port, 'index': index, 'BEL': cell['attributes']['NEXTPNR_BEL'],
            'state': maps[port][0], 'physical_pins': maps[port][1:]}
