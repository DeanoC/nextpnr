#!/usr/bin/env python3
"""Exact serialized graph and function proof for logged ordinary-LUT permutations.

Native electrical topology and stationary path retention require the separately
bound readback selected by native-selection-specs.json; this checker does not
infer PIP connectivity from names or claim timing from a reloaded checkpoint.
"""
from collections import Counter, defaultdict
from native_port_identity import native_identity,native_physical_port
from copy import deepcopy
import json
import re
from support import HERE, ROOT, need, read, unique, sha, digest, write, paired_receipts

PINS = 'ABCDE'
PIN_SIG, PIN_INV = 0, 3


def decisions(text, expected_budget=4):
    lines = [line for line in text.splitlines() if 'Critical LUT permutation' in line]
    trials, filters, current, discovery, summaries, deltas = [], [], [], [], [], []
    trial_re = re.compile(r'^Info: Critical LUT permutation trial (\d+): cell=(.*?) pins=([A-E])/([A-E]) prior-slack=(-?\d+)ps native-arc-rank=(-?\d+)ps accepted=([01]); (.*)\.$')
    summary_re = re.compile(r'^Info: Critical LUT permutation: tried=(\d+)/(\d+) kept=(\d+); unchanged unsupported coverage is not qualification\.$')
    discovery_re = re.compile(r'^Info: Critical LUT permutation discovery: negative rows=(\d+) paths=(\d+) bounded cell witnesses=(\d+) eligible groups=(\d+); native path cap=16384, cell cap=64\.$')
    integer_delta = re.compile(r'^Info: Critical LUT permutation (with-skew|reference) (setup|hold): clock=(.+) before=(-?\d+)ps after=(missing|-?\d+ps)\.$')
    fmax_delta = re.compile(r'^Info: Critical LUT permutation (with-skew|reference) Fmax: clock=(.+) before=(-?\d+\.\d{6})MHz after=(-?\d+\.\d{6})MHz constraint=(-?\d+\.\d{6})/(-?\d+\.\d{6})MHz\.$')
    pending_deltas = []
    for line in lines:
        match = trial_re.fullmatch(line)
        if match:
            number, cell, first, second, slack, rank, accepted, reason = match.groups()
            trials.append({'number': int(number), 'cell': cell, 'first': first, 'second': second,
                           'prior_path_slack_ps': int(slack), 'native_arc_rank_ps': int(rank),
                           'accepted': bool(int(accepted)), 'reason': reason, 'verbatim': line,
                           'clock_delta_lines': pending_deltas})
            pending_deltas = []
        elif (match := re.fullmatch(r'Info: Critical LUT permutation filter: cell=(.+): (.+)\.', line)):
            filters.append({'cell': match[1], 'reason': match[2], 'verbatim': line})
        elif (match := re.fullmatch(r'Info: Critical LUT permutation current eligibility: cell=(.+): (.+)\.', line)):
            current.append({'cell': match[1], 'reason': match[2], 'verbatim': line})
        elif discovery_re.fullmatch(line):
            discovery.append(line)
        elif summary_re.fullmatch(line):
            summaries.append(line)
        elif integer_delta.fullmatch(line) or fmax_delta.fullmatch(line):
            deltas.append(line)
            pending_deltas.append(line)
        else:
            need(False, 'unparsed permutation decision line: ' + line)
    need(not pending_deltas, 'clock deltas without following trial')
    need(len(discovery) == len(summaries) == 1, 'missing/duplicate discovery/final summary')
    tried, budget, kept = map(int, summary_re.fullmatch(summaries[0]).groups())
    counts = dict(zip(('negative_rows', 'negative_paths', 'bounded_cell_witnesses', 'eligible_groups'),
                      map(int, discovery_re.fullmatch(discovery[0]).groups())))
    need(expected_budget in (4,16,32) and budget == expected_budget and tried == len(trials) <= budget, 'trial budget/count mismatch')
    need([t['number'] for t in trials] == list(range(1, tried + 1)), 'incomplete trial numbering')
    need(sum(t['accepted'] for t in trials) == kept, 'accepted count mismatch')
    need(all(t['first'] != t['second'] and t['prior_path_slack_ps'] < 0 for t in trials), 'invalid/ nonnegative path trial')
    need(counts['bounded_cell_witnesses'] <= 64 and counts['eligible_groups'] <= counts['bounded_cell_witnesses'], 'discovery bound mismatch')
    need(len(filters) + counts['eligible_groups'] <= counts['bounded_cell_witnesses'], 'discovery filter/group mismatch')
    need(len({f['cell'] for f in filters}) == len(filters), 'duplicate filter cell')
    need(not ({f['cell'] for f in filters} & {t['cell'] for t in trials}), 'filtered cell was tried')
    need(len({t['cell'] for t in trials}) <= counts['eligible_groups'], 'trial groups exceed eligibility')
    need(not trials or counts['negative_rows'] > 0 and counts['negative_paths'] > 0, 'trials without native negative paths')
    accepted = set()
    for trial in trials:
        need(trial['cell'] not in accepted, 'accepted cell was retried')
        if trial['accepted']:
            accepted.add(trial['cell'])
    return {'all_verbatim_lines': lines, 'all_trials': trials, 'all_filters': filters,
            'all_current_eligibility_skips': current, 'all_clock_delta_lines': deltas,
            'discovery': discovery[0], 'discovery_counts': counts, 'summary': summaries[0],
            'tried': tried, 'budget': budget, 'kept': kept,
            'all_trial_reason_counts': dict(sorted(Counter(t['reason'] for t in trials).items())),
            'path_cap': 16384, 'cell_cap': 64,
            'limits': ['Discovery is bounded; logs do not establish that every native failing path was searched.']}


def pinmap(cell):
    raw = cell['attributes']['FES_PINMAP_V1']
    data = json.loads(bytes.fromhex(raw).decode(), object_pairs_hook=unique)
    need(set(data) == {'count', 'pins'} and data['count'] == len(data['pins']), 'invalid physical pin snapshot')
    return data['pins']


def graph_edges(module):
    users, drivers, aliases = defaultdict(list), defaultdict(list), defaultdict(list)
    for name, cell in sorted(module['cells'].items()):
        need(cell['connections'].keys() == cell['port_directions'].keys(), 'port direction inventory: ' + name)
        for pin, bits in sorted(cell['connections'].items()):
            direction = cell['port_directions'][pin]
            need(direction in ('input', 'output', 'inout'), 'unknown port direction')
            for index, bit in enumerate(bits):
                if type(bit) is int:
                    if direction in ('input', 'inout'):
                        users[bit].append([name, pin, index])
                    if direction in ('output', 'inout'):
                        drivers[bit].append([name, pin, index])
    public = set()
    for name, port in sorted(module['ports'].items()):
        public.update(bit for bit in port['bits'] if type(bit) is int)
    for name, net in sorted(module['netnames'].items()):
        need(len(net['bits']) == 1, 'expected serialized scalar net/alias: ' + name)
        bit = net['bits'][0]
        need(type(bit) is int, 'noninteger routed net identity')
        aliases[bit].append(name)
    return users, drivers, aliases, public


def route_tree(raw):
    if raw is None:
        return None
    need(isinstance(raw, str), 'nonstring route attribute')
    # Property's JSON string encoding represents the empty string as one space.
    if raw in ('', ' '):
        return {}
    parts = raw.split(';')
    need(len(parts) % 3 == 0, 'partial route triple')
    result, pips = {}, set()
    for i in range(0, len(parts), 3):
        wire, pip, strength = parts[i:i + 3]
        need(wire and wire not in result, 'duplicate/empty route wire')
        need(re.fullmatch(r'[0-6]', strength) is not None, 'invalid native route strength')
        need(not pip or pip not in pips, 'duplicate route pip')
        if pip:
            pips.add(pip)
        result[wire] = [pip, int(strength)]
    return result


def lut(cell, name):
    match = re.fullmatch(r'MISTRAL_ALUT([2-5])', cell['type'])
    need(match is not None, 'not an ordinary ALUT2..5: ' + name)
    width = int(match[1]); pins = PINS[:width]
    need(set(cell['parameters']) == {'LUT'}, 'unexpected LUT parameters')
    text = cell['parameters']['LUT']
    need(isinstance(text, str) and re.fullmatch('[01]{%d}' % (1 << width), text), 'undefined/malformed mask')
    need(set(cell['connections']) == set(pins + 'Q'), 'unexpected LUT port inventory')
    need(cell['port_directions'] == {**{p: 'input' for p in pins}, 'Q': 'output'}, 'unexpected LUT port directions')
    need(all(len(cell['connections'][p]) == 1 and type(cell['connections'][p][0]) is int for p in pins + 'Q'), 'non-scalar LUT net')
    bits = [cell['connections'][p][0] for p in pins]
    need(len(set(bits)) == width and cell['connections']['Q'][0] not in bits, 'aliased/constant/self-cyclic LUT inputs')
    maps = pinmap(cell)
    need(set(maps) == set(pins + 'Q'), 'physical port inventory differs')
    need(maps['Q'] == [PIN_SIG, 'COMBOUT'], 'output physical map changed')
    need(all(len(maps[p]) == 2 and type(maps[p][0]) is int and maps[p][0] in (PIN_SIG, PIN_INV)
             and maps[p][1] in ('A', 'B', 'C', 'D', 'E0', 'E1', 'F0', 'F1') for p in pins), 'invalid LUT input map/state')
    physical = [maps[p][1] for p in pins]
    need(len(set(physical)) == width, 'duplicate target physical input')
    need(set(physical) <= {'A', 'B', 'C', 'E0', 'F0'} or set(physical) <= {'A', 'B', 'D', 'E1', 'F1'}, 'mixed native LUT half pins')
    return width, pins, int(text, 2), bits, maps


def transposed_mask(mask, width, first, second):
    result = 0
    for row in range(1 << width):
        old = row
        if ((row >> first) ^ (row >> second)) & 1:
            old ^= (1 << first) | (1 << second)
        result |= ((mask >> old) & 1) << row
    return result


def physical_port(cells, user):
    return native_physical_port(cells, user, pinmap)


def prove(left, right, accepted):
    need(left.keys() == right.keys() and set(left) == {'creator', 'modules'}, 'top-level schema differs')
    need(left['modules'].keys() == right['modules'].keys() and len(left['modules']) == 1, 'module inventory differs')
    a, b = next(iter(left['modules'].values())), next(iter(right['modules'].values()))
    need(a.keys() == b.keys(), 'module schema differs')
    need({k: v for k, v in a.items() if k not in ('cells', 'netnames')} ==
         {k: v for k, v in b.items() if k not in ('cells', 'netnames')}, 'module settings/ports/LAB state differ')
    ac, bc = a['cells'], b['cells']
    need(ac.keys() == bc.keys(), 'complete cell inventory differs')
    need(a['netnames'].keys() == b['netnames'].keys(), 'complete alias inventory differs')
    users, drivers, aliases, public = graph_edges(a)
    after_users, after_drivers, after_aliases, after_public = graph_edges(b)
    need(aliases == after_aliases and public == after_public, 'complete alias/public identities differ')
    need(drivers == after_drivers, 'complete driver graph differs')
    by_cell = {}
    for trial in accepted:
        need(trial['accepted'] and trial['cell'] not in by_cell, 'duplicate/unaccepted target')
        by_cell[trial['cell']] = trial
    need({name for name in ac if ac[name] != bc[name]} == set(by_cell), 'cell changes differ from logged accepted inventory')
    expected_users = deepcopy(users)
    proofs, allowed_nets, physical_changes, selected_nets = [], set(), set(), set()
    transitions = defaultdict(dict)
    for name in sorted(ac):
        old, new = ac[name], bc[name]
        if name not in by_cell:
            need(old == new, 'outside/stationary cell differs: ' + name)
            continue
        trial = by_cell[name]; first, second = trial['first'], trial['second']
        width, pins, old_mask, bits, old_map = lut(old, name)
        new_width, new_pins, new_mask, new_bits, new_map = lut(new, name)
        need((width, pins) == (new_width, new_pins), 'LUT width/type differs')
        need(first in pins and second in pins and first != second, 'invalid logged pair')
        need(old.keys() == new.keys(), 'target field inventory differs')
        need({k: v for k, v in old.items() if k not in ('connections', 'parameters', 'attributes')} ==
             {k: v for k, v in new.items() if k not in ('connections', 'parameters', 'attributes')}, 'target nonpermutation field differs')
        need({k: v for k, v in old['attributes'].items() if k != 'FES_PINMAP_V1'} ==
             {k: v for k, v in new['attributes'].items() if k != 'FES_PINMAP_V1'}, 'target BEL/strength/other attributes differ')
        expected = deepcopy(old['connections']); expected[first], expected[second] = expected[second], expected[first]
        need(new['connections'] == expected, 'connections are not exactly logged transposition')
        need(new_mask == transposed_mask(old_mask, width, pins.index(first), pins.index(second)), 'mask is not exact logged transposition')
        for pin in pins:
            previous = second if pin == first else first if pin == second else pin
            need(new_map[pin][0] == old_map[previous][0], 'PIN_INV/SIG state did not follow original net')
        cell_physical_changes = []
        for pin, bit in zip(pins, bits):
            new_pin = second if pin == first else first if pin == second else pin
            before_user, after_user = [name, pin, 0], [name, new_pin, 0]
            need(bit not in public and bit in aliases and len(drivers[bit]) == 1, 'selected source is public/missing/ambiguous')
            need(users[bit].count(before_user) == 1, 'missing/duplicate selected original user')
            need(1 <= len(users[bit]) <= 64, 'selected net exceeds native user bound')
            expected_users[bit].remove(before_user); expected_users[bit].append(after_user)
            key = tuple(before_user)
            need(key not in transitions[bit], 'duplicate selected user transition')
            transitions[bit][key] = after_user
            allowed_nets.add(bit); selected_nets.add(bit)
            if old_map[pin][1:] != new_map[new_pin][1:]:
                physical_changes.add(bit); cell_physical_changes.append(bit)
        need(cell_physical_changes, 'accepted target has no changed physical input sink')
        selected_nets.add(old['connections']['Q'][0])
        table = []
        for row in range(1 << width):
            values = {bit: (row >> i) & 1 for i, bit in enumerate(bits)}
            old_address = sum((values[old['connections'][p][0]] ^ (old_map[p][0] == PIN_INV)) << i for i, p in enumerate(pins))
            new_address = sum((values[new['connections'][p][0]] ^ (new_map[p][0] == PIN_INV)) << i for i, p in enumerate(pins))
            before, after = (old_mask >> old_address) & 1, (new_mask >> new_address) & 1
            need(before == after, 'raw-net LUT function differs')
            table.append({'raw_assignment': row, 'before_mask_index': old_address, 'after_mask_index': new_address,
                          'before_output': before, 'after_output': after})
        proofs.append({'cell': name, 'pins': [first, second], 'width': width, 'BEL': old['attributes']['NEXTPNR_BEL'],
                       'input_bits': bits, 'output_bit': old['connections']['Q'][0],
                       'before_mask': old['parameters']['LUT'], 'after_mask': new['parameters']['LUT'],
                       'before_pin_maps': old_map, 'after_pin_maps': new_map, 'all_raw_net_rows': table,
                       'input_bits_with_changed_physical_target_sink': sorted(cell_physical_changes)})
    need({bit: sorted(rows) for bit, rows in expected_users.items()} ==
         {bit: sorted(rows) for bit, rows in after_users.items()}, 'complete user graph differs from exact transpositions')
    changes, changed_bits, trees = [], set(), [{}, {}]
    for alias in sorted(a['netnames']):
        old, new = a['netnames'][alias], b['netnames'][alias]
        need(old.keys() == new.keys() and old['bits'] == new['bits'], 'alias identity/schema differs: ' + alias)
        bit = old['bits'][0]
        old_copy, new_copy = deepcopy(old), deepcopy(new)
        old_raw, new_raw = old_copy['attributes'].pop('ROUTING', None), new_copy['attributes'].pop('ROUTING', None)
        need(old_copy == new_copy, 'nonroute alias metadata differs: ' + alias)
        old_tree, new_tree = route_tree(old_raw), route_tree(new_raw)
        for store, tree in zip(trees, (old_tree, new_tree)):
            if bit in store:
                need(store[bit] == tree, 'alias class disagrees on physical routing')
            else:
                store[bit] = tree
        changed = old_tree != new_tree
        if changed:
            need(bit in allowed_nets and bit in physical_changes, 'route changed without changed selected physical sink: ' + alias)
            changed_bits.add(bit)
        if old_raw != new_raw:
            changes.append({'alias': alias, 'bit': bit, 'canonical_tree_changed': changed,
                            'before_tree': old_tree, 'after_tree': new_tree,
                            'before_raw_sha256': digest(old_raw), 'after_raw_sha256': digest(new_raw)})
    selections = []
    for bit in sorted(selected_nets):
        need(bit in aliases and len(drivers[bit]) == 1 and bit not in public, 'selected net lacks exact private driver/aliases')
        roots = []
        for store in trees:
            tree = store[bit]
            need(tree and len(tree) <= 4096, 'selected net has missing/oversize route')
            need(all(data[1] <= 2 for data in tree.values()), 'selected route has protected strength')
            roots.append({wire: data for wire, data in tree.items() if data[0] == ''})
        need(len(roots[0]) == 1 and roots[0] == roots[1], 'selected source root/strength differs')
        user_changes = []
        for user in users[bit]:
            dest = transitions[bit].get(tuple(user), user)
            before_port, after_port = physical_port(ac, user), physical_port(bc, dest)
            need(before_port['BEL'] == after_port['BEL'], 'selected user placement changed')
            stationary = before_port['physical_pins'] == after_port['physical_pins']
            user_changes.append({'before': before_port, 'after': after_port, 'serialized_physical_sink_unchanged': stationary})
        need(sorted([ [u['after']['cell'], u['after']['port'], u['after']['index']] for u in user_changes]) == sorted(native_identity(bc, u) for u in after_users[bit]), 'native selection misses complete user inventory')
        selections.append({'bit': bit, 'name': aliases[bit][0], 'aliases': aliases[bit],
                           'driver': physical_port(ac, drivers[bit][0]), 'serialized_driver': drivers[bit][0],
                           'before_users': users[bit], 'after_users': after_users[bit],
                           'user_transitions': user_changes, 'source_root': roots[0],
                           'canonical_tree_changed': bit in changed_bits,
                           'before_tree_sha256': digest(trees[0][bit]), 'after_tree_sha256': digest(trees[1][bit])})
    ownership = []
    for store in trees:
        wires, pips = {}, {}
        for bit, tree in store.items():
            for wire, (pip, strength) in (tree or {}).items():
                need(wire not in wires, 'wire shared by distinct complete net identities')
                wires[wire] = bit
                if pip:
                    need(pip not in pips, 'PIP shared by distinct complete net identities')
                    pips[pip] = bit
        ownership.append({'wires': len(wires), 'pips': len(pips), 'single_net_ownership': True})
    return {'status': 'pass', 'complete_cells': len(ac), 'complete_net_alias_records': len(a['netnames']),
            'complete_net_alias_classes': len(aliases), 'complete_public_ports': len(a['ports']),
            'settings_ports_module_attributes_LAB_state_equal': True, 'all_cell_types_BELs_and_other_attributes_equal': True,
            'all_outside_and_stationary_mate_cells_exact': True, 'complete_driver_graph_equal': True,
            'complete_users_exact_logged_transpositions': True, 'complete_alias_classes_equal': True,
            'complete_physical_ownership': {'before': ownership[0], 'after': ownership[1]},
            'accepted_cells': proofs, 'allowed_target_input_net_bits': sorted(allowed_nets),
            'input_bits_with_changed_physical_target_sinks': sorted(physical_changes),
            'changed_canonical_net_bits': sorted(changed_bits), 'every_raw_route_attribute_change': changes,
            'route_order_only_alias_changes': sum(not c['canonical_tree_changed'] for c in changes),
            'native_topology_selections': selections,
            'creator_before': left['creator'], 'creator_after': right['creator'],
            'limits': ['Every serialized cell, port, alias, driver, user, settings/LAB-state field and canonical route tuple is included.',
                       'Raw-net rows use PIN_SIG=0 and PIN_INV=3. Native input states must follow swapped nets; masks must be exactly transposed.',
                       'Native indexed user-store holes and native configuration muxes are not serialized; focused native tests cover them.',
                       'PIP strings establish exact ownership, not decoded electrical connectivity. Separate native topology readback must prove every selected tree and unchanged-sink path retention.',
                       'No native physical mask, setup/hold, clock or hardware signoff is inferred from this logical/serialized proof.']}


def main():
    paired_receipts()
    cases = ('cpu16', 'permutation4')
    logs = {name: (ROOT / ('route-' + name) / 'nextpnr.log').read_text() for name in cases}
    ledger = decisions(logs['permutation4'])
    ledger['preceding_repair_lines'] = {name: [line for line in text.splitlines() if 'Critical route ' in line or 'Critical LUT6 ' in line] for name, text in logs.items()}
    need(ledger['preceding_repair_lines']['cpu16'] == ledger['preceding_repair_lines']['permutation4'], 'preceding route/LUT6 repair decisions differ')
    need('Critical LUT permutation' not in logs['cpu16'], 'baseline unexpectedly ran permutation pass')
    left, right = [read(ROOT / ('route-' + name) / 'routed.json') for name in cases]
    result = prove(left, right, [t for t in ledger['all_trials'] if t['accepted']])
    graph_hashes = {name: sha(ROOT / ('route-' + name) / 'routed.json') for name in cases}
    result.update(checker_sha256=sha(__file__), support_sha256=sha(HERE / 'support.py'), graph_sha256=graph_hashes)
    write('decision-ledger.json', ledger)
    write('graph-proof.json', result)
    write('native-selection-specs.json', {'schema': 1, 'graph_proof_sha256': sha(HERE / 'graph-proof.json'),
          'graph_sha256': graph_hashes, 'selections': result['native_topology_selections'],
          'requirements': ['Native decode every selected source, complete users and every PIP source/destination in both graphs.',
                           'Require complete trees rooted at the identical source with no foreign owners, cycles, disconnected branches or missing sinks.',
                           'For each native sink whose wire vector is unchanged, require every original root-to-sink wire/PIP/strength tuple unchanged.',
                           'Do not infer timing, reroute, assign new pins or configure bitstream during readback.']})
    print(json.dumps({key: result[key] for key in ('status', 'complete_cells', 'complete_net_alias_records', 'changed_canonical_net_bits')}, sort_keys=True))


if __name__ == '__main__':
    main()
