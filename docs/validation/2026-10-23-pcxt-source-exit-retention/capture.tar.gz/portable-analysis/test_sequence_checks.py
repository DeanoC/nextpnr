#!/usr/bin/env python3
"""Exercise divergent ledgers without borrowing the option-off accepted prefix."""
import json
from prove_graph import validate_ledger
from support import ROOT,HERE,need,write,sha,reference_folder,reference_original

def main():
 reference=reference_folder('common')/'nextpnr.log'
 fixture=reference_folder('fixture')/'nextpnr.log'
 original=fixture.read_text().replace('tried=16/16 kept=2;', 'tried=16/32 kept=2;')
 prior=reference.read_text()
 a=validate_ledger(prior,original)
 old=a['all_trials'][0]['verbatim']
 new=old.replace('pins=D/E','pins=D/A').replace('native-arc-rank=', 'native-arc-rank=')
 divergent=original.replace(old,new)
 b=validate_ledger(prior,divergent)
 need(a['all_trials'][0]!=b['all_trials'][0], 'divergent trial fixture did not differ')
 need(len([t for t in a['all_trials'] if t['accepted']])==2 and len([t for t in b['all_trials'] if t['accepted']])==2,'own accepted inventory missing')
 rejected=[]
 def bad(name,base,selected):
  try:validate_ledger(base,selected)
  except (ValueError,KeyError,TypeError) as e:rejected.append({'case':name,'rejection':str(e)});return
  raise AssertionError('corruption accepted '+name)
 bad('prior CPU change',prior+'\nInfo: Critical LUT6 unexpected.',original)
 bad('reference already ran permutations',fixture.read_text(),original)
 bad('wrong bound',prior,original.replace('tried=16/32','tried=16/16'))
 bad('missing trial',prior,original.replace(a['all_trials'][0]['verbatim'],''))
 bad('wrong acceptance total',prior,original.replace('kept=2;','kept=3;'))
 bad('unknown permutation observation',prior,original+'\nInfo: Critical LUT permutation unexpected.')
 bad('duplicate summary',prior,original+'\n'+a['summary'])
 bad('truncated summary',prior,original.replace(a['summary'],''))
 write('sequence-checks-proof.json',{'passed':True,'positive_cases':2,'corruption_rejections':rejected,'test_sha256':sha(__file__),'checker_sha256':sha(HERE/'prove_graph.py'),'fixtures':{reference_original('common')+'/nextpnr.log':sha(reference),reference_original('fixture')+'/nextpnr.log':sha(fixture)},'scope':'Ledger isolation controls only; fresh source-exit timing and topology remain unmeasured.'})
 print(json.dumps({'passed':True,'rejections':len(rejected)}))
if __name__=='__main__':main()
