#!/usr/bin/env python3
"""Prove each divergent repair sequence against the complete CPU2 graph."""
import json
from permutation_graph_core import decisions, prove
from compare_timing import endpoint_guard, clock_guard
from support import HERE, ROOT, need, read, write, sha, paired_receipts, receipt, verify_recorded, reference_folder, reference_original


def validate_ledger(reference_log, log):
    ledger = decisions(log, 32)
    need(ledger['all_verbatim_lines'][-1] == ledger['summary'], 'summary not final')
    need('Critical LUT permutation' not in reference_log, 'common reference ran permutation pass')
    def preceding(text):
        return [line for line in text.splitlines() if 'Critical route ' in line or 'Critical LUT6 ' in line]
    need(preceding(reference_log) == preceding(log), 'preceding CPU repair differs')
    ledger['preceding_repair_lines'] = preceding(log)
    return ledger


def main():
    records = paired_receipts()
    common = reference_folder('common')
    baseline = receipt(common)
    for value in records.values():
        verify_recorded(reference_original('common') + '/receipt.json', value['immutable_evidence_sha256'][reference_original('common') + '/receipt.json'])
        need(value['inputs'] == baseline['inputs'], 'common-reference input identity differs')
        expected = baseline['nextpnr_command'][:]
        expected[0] = value['nextpnr_command'][0]
        expected += ['--critical-lut-permute-budget', '32', '--critical-unobserved-arith-outputs']
        actual = value['nextpnr_command'][:]
        if actual[-1] == '--critical-lut-permute-retain-source-exits':
            actual.pop()
        need(actual == expected, 'common-reference recipe differs')
    original = read(common / 'routed.json')
    endpoints = read(common / 'endpoints.json')
    timing = read(common / 'timing.json')
    log = (common / 'nextpnr.log').read_text()
    results = {}
    for case in ['default', 'retain']:
        folder = ROOT / ('route-' + case)
        ledger = validate_ledger(log, (folder / 'nextpnr.log').read_text())
        accepted = [t for t in ledger['all_trials'] if t['accepted']]
        proof = prove(original, read(folder / 'routed.json'), accepted)
        proof.update(graph_sha256={'cpu2': sha(common / 'routed.json'), case: sha(folder / 'routed.json')})
        guards = {'endpoints': endpoint_guard(endpoints, read(folder / 'endpoints.json')),
                  'clocks': clock_guard(timing, read(folder / 'timing.json'))}
        write(case + '-decision-ledger.json', ledger)
        write(case + '-graph-proof.json', proof)
        write(case + '-common-timing-guards.json', guards)
        write(case + '-native-selection-specs.json', {
            'schema': 1, 'graph_proof_sha256': sha(HERE / (case + '-graph-proof.json')),
            'graph_sha256': proof['graph_sha256'], 'selections': proof['native_topology_selections'],
            'requirements': [
                'Decode every selected complete source tree and every stationary sink path/strength.',
                'Retained source-exit provenance is live per-trial; do not infer baseline ownership for a shared input net changed by earlier accepted trials.',
                'Exact configuration and per-trial stub ownership remain guarded in-process; this readback does not rerun STA or configure an RBF.']})
        need(guards['endpoints']['nonregression_and_inventory_pass'] and guards['clocks']['pass'],
             case + ' regressed versus common CPU2 baseline; complete differences retained')
        results[case] = {key: proof[key] for key in ['status', 'complete_cells', 'complete_net_alias_records', 'changed_canonical_net_bits']}
    write('graph-proof-summary.json', {'results': results, 'checker_sha256': sha(__file__),
          'common_receipt_sha256': sha(common / 'receipt.json'),
          'graph_core_sha256': sha(HERE / 'permutation_graph_core.py'),
          'native_port_resolver_sha256': sha(HERE / 'native_port_identity.py'),
          'scope': 'Each complete graph is proved separately from common CPU2. Option-off accepted trials are not applied again to option-on.'})
    print(json.dumps(results, sort_keys=True))


if __name__ == '__main__':
    main()
