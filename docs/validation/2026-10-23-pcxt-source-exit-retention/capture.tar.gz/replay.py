#!/usr/bin/env python3
"""Offline complete evidence replay with explicit path-only checker-copy provenance."""
from pathlib import Path
from decimal import Decimal
import argparse,contextlib,hashlib,importlib,io,json,os,subprocess,sys,tempfile
R=Path(__file__).resolve().parent;A=R/'portable-analysis';ORIGINAL=R/'final-analysis';sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
def main(prepare=False):
 assert support.archive_mode() is not None and support.ROOT==R
 final=read(R/'final-validation.json');commit=read(R/'committed-source-verification.json');assert commit['commit']=='1ba2e289f5bf4e584a8539f185d6f15383650c26' and commit['source_files']==final['source_files'] and commit['final_validation_sha256']==sha(R/'final-validation.json')
 assert len(final['files'])==191 and len(final['source_files'])==30
 for p,h in final['files'].items():assert sha(R/p)==h,p
 for p,h in final['source_files'].items():assert sha(R/'complete-source'/p)==h,p
 prior=read(R/'references/cap32-evidence/final-validation.json');assert len(prior['source_files'])==29
 for p,h in prior['source_files'].items():assert sha(R/'references/prior-source'/p)==h,p
 identity=read(R/'source-validation/final-host/source-identity.json');assert len(identity['files'])==8 and identity['base_commit']=='134b858165a4dd0c00c8b5d5371fbf90fdac63a3'
 for p,v in identity['files'].items():
  assert sha(R/'source-validation/final-host/source'/p)==v['sha256']==final['source_files'][p]
  if not v.get('new_file'):assert sha(R/'source-validation/final-host/before'/p)==v['before_sha256']==sha(R/'references/prior-source'/p)
 control=read(R/'control-proof.json');assert control['default_zero_raw_bytes_equal']
 for case in ('default','zero'):
  p=R/('prepare-'+case);q=R/'references/prior-prepare';a=(q/'placed.json').read_bytes();b=(p/'placed.json').read_bytes();x=json.loads(a);y=json.loads(b);ca=json.dumps(x.pop('creator')).encode();cb=json.dumps(y.pop('creator')).encode()
  assert x==y and a.count(ca)==1 and a.replace(ca,cb,1)==b and (p/'predicted-timing.json').read_bytes()==(q/'predicted-timing.json').read_bytes()
  assert read(p/'receipt.json')['reference_receipt_sha256']==sha(q/'receipt.json')
  for n,h in read(p/'receipt.json')['artifacts'].items():assert sha(p/n)==h
 assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
 summary=read(R/'source-validation/validation.json');assert summary['pass'] and summary['sources_and_binaries_unchanged'] and len(summary['results'])==3
 for name,count in [('source-exit-native',12),('permutation-native',45),('permutation-cli',8)]:
  v=read(R/'source-validation'/(name+'.receipt.json'));assert v['pass'] and v['returncode']==0 and v['expected_count']==v['observed_count']==count and v in summary['results'] and v['log_sha256']==sha(R/'source-validation'/(name+'.log'))
 native=R/'native-topology';build=read(native/'build-receipt.json');compat=read(native/'architecture-compatibility.json')
 assert build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9' and compat['passed'] and compat['route_compiler_commit']==commit['commit']
 for n,k in [('tree-reader.cc','helper_source_sha256'),('frozen-manifest.json','frozen_manifest_sha256'),('build-commands.json','build_commands_sha256'),('build.log','build_log_sha256')]:assert sha(native/n)==build[k]
 assert len(read(native/'frozen-manifest.json')['files'])==401
 for p,v in compat['changed_snapshotted_source_files'].items():assert sha(R/'references/reader-source'/p)==v['old_sha256'] and sha(R/'complete-source'/p)==v['new_sha256']
 for name in ('architecture-compatibility.json','prepare.py','independent-reader-review.json'):
  retained={'architecture-compatibility.json':'prior-cap32-compatibility.json','prepare.py':'prior-cap32-prepare.py','independent-reader-review.json':'prior-cap32-reader-review.json'}[name]
  assert sha(native/retained)==sha(R/'references/cap32-native'/name)
 parent=R/'references/prior-source';current=R/'complete-source'
 line=b'    bool critical_lut_permute_retain_source_exits = false; // Preserve only original protected-LAB source exits.\n';a=(current/'mistral/arch.h').read_bytes();assert a.count(line)==1 and a.replace(line,b'')==(parent/'mistral/arch.h').read_bytes()
 suffix=b'const std::function<void(unsigned)> &stage = {}, bool keep_source_exits = false);';a=(current/'mistral/analogue_repair.h').read_bytes();assert a.count(suffix)==1 and a.replace(suffix,b'const std::function<void(unsigned)> &stage = {});')==(parent/'mistral/analogue_repair.h').read_bytes()
 a=(current/'mistral/CMakeLists.txt').read_bytes();token=b'tests/source_exit_retention_backend.cc ';assert a.count(token)==1 and a.replace(token,b'')==(parent/'mistral/CMakeLists.txt').read_bytes()
 # Never execute omitted native binaries. Complete original native output receipts are bound.
 for case in ('default','retain'):
  d=native/'paired-readback'/case;receipt=read(d/'receipt.json');assert receipt['passed'] and receipt['native_execution_needed'] and len(receipt['records'])==2
  assert receipt['helper_binary_sha256']==build['helper_binary_sha256'] and receipt['architecture_compatibility_sha256']==sha(native/'architecture-compatibility.json')
  for v in receipt['records']:
   for suffix,key in (('-selection.json','selection_sha256'),('-topology.json','output_sha256'),('.log','log_sha256')):assert sha(d/(v['case']+suffix))==v[key]
 account=read(R/'accounting.json');journal=R/'accounting-52/continued-runs.jsonl';records=[json.loads(s) for s in journal.read_text().splitlines()];prior_journal=R/'references/accounting-50/continued-runs.jsonl'
 assert len(records)==52 and len({x['case'] for x in records})==52 and sha(journal)==account['journal_sha256'] and journal.read_bytes().startswith(prior_journal.read_bytes())
 assert Decimal(account['pre_journal_charge_seconds'])+sum(Decimal(v['charged_seconds_decimal']) for v in records)==Decimal(account['cumulative_charge_seconds'])
 accounting_review=read(ORIGINAL/'independent-review/accounting-review.json');assert accounting_review['passed'] and accounting_review['journal_sha256']==sha(journal) and accounting_review['committed_readme_sha256']==sha(R/'accounting-52/README.md')
 assert accounting_review['fes_commit']==read(R/'accounting-52/source.json')['commit']=='826dbbe1c5b671f0c9facbdddb6692d1d4242bc4'
 for case in ('default','retain'):
  rows=[v for v in records if v['case']=='out/cga-source-exit-retention-20261023/route-'+case];assert len(rows)==1 and rows[0]['receipt_sha256']==sha(R/f'route-{case}/receipt.json') and rows[0]['receipt']==read(R/f'route-{case}/receipt.json')
 # Only three explicit archive-copy path edits; all other checker bytes remain exact.
 adapter=read(R/'portable-path-adapter.json');assert set(adapter['files'])=={'prove_graph.py','test_sequence_checks.py','verify_topology.py'} and adapter['patch_sha256']==sha(R/'portable-path-adapter.patch')
 for p in ORIGINAL.glob('*.py'):
  q=A/p.name
  if p.name in adapter['files']:
   v=adapter['files'][p.name];assert sha(p)==v['original_sha256'] and sha(q)==v['adapted_sha256'];text=p.read_text()
   for replacement in v['exact_replacements']:
    assert text.count(replacement['before'])==1;text=text.replace(replacement['before'],replacement['after'],1)
   assert text==q.read_text()
  else:assert p.read_bytes()==q.read_bytes()
 # Allow only hashes of the declared adapted script to differ in proof outputs.
 provenance={'graph-proof-summary.json':{'checker_sha256':'prove_graph.py'},'sequence-checks-proof.json':{'checker_sha256':'prove_graph.py','test_sha256':'test_sequence_checks.py'},
             'default-topology-proof.json':{'checker_sha256':'verify_topology.py'},'retain-topology-proof.json':{'checker_sha256':'verify_topology.py'}}
 checks=[]
 def compare_write(name,value):
  expected=read(ORIGINAL/name)
  for field,script in provenance.get(name,{}).items():assert expected[field]==sha(ORIGINAL/script);expected[field]=sha(A/script)
  assert encoded(value)==encoded(expected),name+' substantive output differs'
  if prepare:(A/name).write_bytes(encoded(value))
  else:assert (A/name).read_bytes()==encoded(value),name+' adapted replay differs'
  checks.append({'proof':name,'original_sha256':sha(ORIGINAL/name),'adapted_sha256':sha(A/name),'only_declared_digest_provenance_differs':list(provenance.get(name,{}))})
 with contextlib.redirect_stdout(io.StringIO()):
  for name in ('prove_graph','test_sequence_checks','test_native_port_identity','verify_topology'):
   module=importlib.import_module(name);module.write=compare_write;module.main()
  module=importlib.import_module('compare_timing')
  with tempfile.TemporaryDirectory(prefix='pcxt-exit-proof-') as scratch:
   module.R=Path(scratch);module.main();assert (module.R/'route-comparison.json').read_bytes()==(ORIGINAL/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
 checks.append({'proof':'route-comparison.json','original_sha256':sha(ORIGINAL/'route-comparison.json'),'adapted_sha256':sha(A/'route-comparison.json'),'only_declared_digest_provenance_differs':[]})
 # Replay the independent full-checker review on the adapted copies, transparently
 # retaining changed script/output hashes rather than claiming original review bytes.
 proc=subprocess.run([sys.executable,str(A/'independent-review/review.py')],cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True)
 assert proc.returncode==0,proc.stdout+proc.stderr
 old=read(ORIGINAL/'independent-review/review.json');new=read(A/'independent-review/review.json')
 old_inputs=old.pop('inputs');new_inputs=new.pop('inputs');assert old_inputs.keys()==new_inputs.keys()
 for name in old_inputs:assert old_inputs[name]==sha(ORIGINAL/name) and new_inputs[name]==sha(A/name)
 old_checks=old.pop('exact_replays');new_checks=new.pop('exact_replays');assert len(old_checks)==len(new_checks)==14
 for x,y in zip(old_checks,new_checks):assert x['proof']==y['proof'] and x['exact_replay']==y['exact_replay'] is True and x['sha256']==sha(ORIGINAL/x['proof']) and y['sha256']==sha(A/y['proof'])
 assert old==new,'independent review substantive results differ'
 t=read(A/'route-comparison.json');assert len(t['every_endpoint_row'])==17199 and t['native_margin_delta_counts']=={'setup':{'unchanged':17194},'hold':{'unchanged':17194}}
 assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal'] and t['default_vs_prior_fixed_invariance_pass']
 for name in ('routed.json','diagnostic.rbf','endpoints.json','timing.json'):assert (R/'route-default'/name).read_bytes()==(R/'route-retain'/name).read_bytes()
 for case in ('default','retain'):
  g=read(A/(case+'-graph-proof.json'));n=read(A/(case+'-topology-proof.json'));assert g['complete_cells']==12397 and g['complete_net_alias_records']==15546 and g['changed_canonical_net_bits']==[54479,54480,57715,57717]
  assert n['passed'] and n['selected_nets']==10 and n['stationary_users']==18 and n['retained_original_wire_tuples']==65
  for cell in g['accepted_cells']:assert len(cell['all_raw_net_rows'])==1<<cell['width'] and all(x['before_output']==x['after_output'] for x in cell['all_raw_net_rows'])
 result={'passed':True,'source_files':30,'host_admission_files':191,'native_snapshot_manifest_members':401,'proof_replays':checks,
 'original_independent_review_sha256':sha(ORIGINAL/'independent-review/review.json'),'adapted_independent_review_sha256':sha(A/'independent-review/review.json'),
 'complete_endpoint_rows':17199,'native_margin_delta_counts':t['native_margin_delta_counts'],'all_four_pair_artifacts_byte_equal':True,
 'both_native_comparisons':{'selected_nets_each':10,'stationary_users_each':18,'retained_wire_tuples_each':65},'accounting':{'records':52,'pair_charge_seconds':'2603.1843361197972','cumulative_charge_seconds':account['cumulative_charge_seconds']},
 'charged_route_seconds':0,'scope':'Offline source/host receipt and complete saved graph/truth/native-tree/timing replay. Original live proof bytes remain immutable; separate portable copies differ only in declared path lookup/script-digest provenance. No host test, native helper/reader, GPU route, rejected-state STA or RBF electrical/hardware execution.'}
 print(encoded(result).decode(),end='')
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');main(parser.parse_args().prepare)
