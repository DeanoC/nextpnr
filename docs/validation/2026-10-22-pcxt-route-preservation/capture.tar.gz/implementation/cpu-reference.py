from pathlib import Path
import json,subprocess,time,hashlib,os
root=Path('/tmp/pcxt-route-preserve-cpu-20261022');root.mkdir(exist_ok=False)
old=json.loads(Path('/tmp/pcxt-replicate-leased-20261022/baseline/receipt.json').read_text())
cmd=old['command'];cmd[0]='/tmp/pcxt-route-preserve-20261022/nextpnr-mistral'
cmd+=['--gpu-cpu','--critical-route-budget','8']
env=dict(os.environ);env.pop('NEXTPNR_REQUIRE_GPU',None)
r={'command':cmd,'evidence':'CPU-reference diagnostic only','timeout':600,'binary_sha256':hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()}
start=time.monotonic()
try:
 with (root/'nextpnr.log').open('w') as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 r['returncode']=p.returncode
except subprocess.TimeoutExpired:r['timeout_expired']=True
r['charged_seconds']=time.monotonic()-start
r['artifacts']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.json')}
(root/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(r.get('returncode'),r['charged_seconds'])
