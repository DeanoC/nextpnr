import json,re,sys,hashlib
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads((p/'baseline/routed.json').read_text());b=json.loads((p/'candidate/routed.json').read_text());x=a['modules']['top'];y=b['modules']['top'];mapping={}
assert x['netnames'].keys()==y['netnames'].keys()
for name,net in x['netnames'].items():
 other=y['netnames'][name];assert len(net['bits'])==len(other['bits'])
 for bit,dest in zip(net['bits'],other['bits']):
  if isinstance(bit,int):
   if bit in mapping:assert mapping[bit]==dest
   mapping[bit]=dest
  else:assert bit==dest
assert len(set(mapping.values()))==len(mapping)
def bits(v):return [mapping[n] if isinstance(n,int) else n for n in v]
for net in x['netnames'].values():net['bits']=bits(net['bits'])
for cell in x['cells'].values():cell['connections']={k:bits(v) for k,v in cell['connections'].items()}
for port in x['ports'].values():port['bits']=bits(port['bits'])
accepted=set(re.findall(r'Critical route trial \d+: net (.*?) variant \d+ accepted=1\.',(p/'candidate/nextpnr.log').read_text()))
changed=[]
for n,net in x['netnames'].items():
 if net!=y['netnames'][n]:
  assert n in accepted,n
  changed.append(n)
  old=net['attributes'];new=y['netnames'][n]['attributes']
  assert 'ROUTING' in old and 'ROUTING' in new
  old['ROUTING']=new['ROUTING']
assert a==b,'Change outside accepted net routing (after bit renumbering)'
r={'original_cells':len(x['cells']),'original_nets':len(x['netnames']),'changed_routes':changed,'accepted_nets':sorted(accepted),'all_other_graph_content_identical':True,'mapped_bits':len(mapping)}
(p/'preservation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
