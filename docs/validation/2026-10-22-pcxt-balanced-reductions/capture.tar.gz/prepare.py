#!/usr/bin/env python3
"""Prepare same-binary unpacked exports; never pack, place, route or program hardware."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
base=Path(__file__).resolve().parent
fes=base.parents[1]
binary=Path('/home/deano/harnesses/pcxt-compiler-repair/build-candidate/nextpnr-mistral')
def sha(path):
 with path.open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()
source=fes/'out/fresh-placement-20261022/inputs/synth.json'
roots={name:tree['raw']['root'] for name,tree in json.loads((base/'whole-reductions.json').read_text())['trees'].items()}
inputs=base/'inputs'
if sys.argv[1]=='freeze-inputs':
 inputs.mkdir(exist_ok=True)
 sources={'synth.json':source,'constraints.qsf':Path('/tmp/pcxt-replicate-leased-20261022/inputs/constraints.qsf'),
          'clocks.sdc':Path('/tmp/pcxt-replicate-leased-20261022/inputs/clocks.sdc')}
 for name,path in sources.items():
  destination=inputs/name
  if destination.exists():assert sha(destination)==sha(path)
  else:shutil.copyfile(path,destination)
 receipt={'binary':str(binary),'binary_sha256':sha(binary),'inputs':{name:{'source':str(path),'sha256':sha(path)} for name,path in sources.items()},
          'roots':roots,'evidence':'unpacked structural diagnostic only'}
 (inputs/'manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt,indent=2));sys.exit(0)
manifest=json.loads((inputs/'manifest.json').read_text())
mode=sys.argv[1]; selected={'baseline':[],'overflow17':[roots['overflow17']],
                           'both':[roots['overflow17'],roots['last_result16']]}[mode]
folder=base/('prepare-'+mode);folder.mkdir(exist_ok=True)
assert not (folder/'export.json').exists(),'refusing to overwrite prior export'
assert sha(binary)==manifest['binary_sha256'],'binary changed since input freeze'
for name,info in manifest['inputs'].items():assert sha(inputs/name)==info['sha256']
command=[str(binary),'--device','5CSEBA6U23I7','--json',str(inputs/'synth.json'),
         '--qsf',str(inputs/'constraints.qsf'),'--sdc',str(inputs/'clocks.sdc'),
         '--seed','1','--freq','100.0','--router','gpu','--placer-heap-timingweight','2000',
         '--placer-heap-critexp','5','--no-pack','--no-place','--no-route','--write',str(folder/'export.json')]
for root in selected:command+=['--balance-reduction-root',root]
start=time.monotonic()
with (folder/'prepare.log').open('w') as log:result=subprocess.run(command,cwd=folder,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':command,'cwd':str(folder),'binary_sha256':manifest['binary_sha256'],
         'inputs':manifest['inputs'],'selected_roots':selected,'returncode':result.returncode,
         'elapsed_seconds':time.monotonic()-start,'binary_unchanged':sha(binary)==manifest['binary_sha256'],
         'evidence':'unpacked diagnostic export; no pack/place/route or physical qualification'}
if (folder/'export.json').exists():receipt['export_sha256']=sha(folder/'export.json')
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2));assert result.returncode==0 and receipt['binary_unchanged']
