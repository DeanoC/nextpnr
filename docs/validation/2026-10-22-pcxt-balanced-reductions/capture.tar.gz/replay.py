from pathlib import Path
import hashlib,json,os,subprocess,time,concurrent.futures
root=Path(__file__).resolve().parent
old=json.loads((root.parent/'fresh-placement-20261022/baseline/receipt.json').read_text())
roots=json.loads((root/'whole-reductions.json').read_text())['trees']
wrapper=str(root.parents[1]/'scripts/gpu-run')
def run(label,selected):
 cmd=old['nextpnr_command'][:];cmd[0]=str(root/'nextpnr-mistral')
 for option,name in [('--json','synth.json'),('--qsf','constraints.qsf'),('--sdc','clocks.sdc')]:cmd[cmd.index(option)+1]=str(root/'inputs'/name)
 for key in selected:cmd+=['--balance-reduction-root',roots[key]['raw']['root']]
 command=[wrapper,'--phase-lease','--owner','pcxt-timing','--label','pcxt-balanced-'+label,'--',*cmd]
 p=root/('route-'+label);p.mkdir(exist_ok=False)
 env=dict(os.environ);env['NEXTPNR_REQUIRE_GPU']='1'
 receipt={'command':command,'nextpnr_command':cmd,'selected_roots':selected,'evidence':'leased GPU fresh pack/place/route host diagnostic; not acceptance','limit':'native bounded router iterations; no external GPU-job termination','binary_sha256':hashlib.file_digest(open(cmd[0],'rb'),'sha256').hexdigest()}
 start=time.monotonic()
 with (p/'nextpnr.log').open('w') as log:receipt['returncode']=subprocess.run(command,cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 receipt['charged_seconds']=time.monotonic()-start
 receipt['artifacts']={f.name:hashlib.file_digest(f.open('rb'),'sha256').hexdigest() for f in p.iterdir() if f.suffix in ['.json','.rbf']}
 (p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,receipt['returncode'],receipt['charged_seconds'],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,label,selected) for label,selected in [('baseline',[]),('both',['overflow17','last_result16']),('overflow17',['overflow17'])]]
 for f in futures:f.result()
