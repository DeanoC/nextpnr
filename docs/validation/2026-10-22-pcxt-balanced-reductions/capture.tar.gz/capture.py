from pathlib import Path
import hashlib,json,tarfile,gzip,io,sys
source=Path(sys.argv[1]);dest=Path(sys.argv[2]);dest.parent.mkdir(parents=True,exist_ok=True)
files=[p for p in sorted(source.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p != source/'manifest.json' and p.name not in {'nextpnr-mistral','nextpnr-mistral-test','native-m10k-sites-probe','capture.tar.gz','archive-readback.json'}]
manifest={str(p.relative_to(source)):{'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'size':p.stat().st_size} for p in files}
data=(json.dumps(manifest,indent=2)+'\n').encode();(source/'manifest.json').write_bytes(data)
with dest.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w|') as tf:
 for p in files:
  info=tf.gettarinfo(str(p),arcname=str(p.relative_to(source)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with p.open('rb') as src:tf.addfile(info,src)
 info=tarfile.TarInfo('manifest.json');info.size=len(data);info.mtime=0;tf.addfile(info,io.BytesIO(data))
with tarfile.open(dest,'r:gz') as tf:
 assert set(tf.getnames())==set(manifest)|{'manifest.json'}
 for name,expected in manifest.items():
  got=tf.extractfile(name).read();assert len(got)==expected['size'] and hashlib.sha256(got).hexdigest()==expected['sha256'],name
print(json.dumps({'archive':str(dest),'sha256':hashlib.file_digest(dest.open('rb'),'sha256').hexdigest(),'verified_members':len(manifest)+1,'bytes':dest.stat().st_size},indent=2))
