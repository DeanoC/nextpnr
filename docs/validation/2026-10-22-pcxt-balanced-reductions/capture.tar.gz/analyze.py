#!/usr/bin/env python3
"""Summarize complete seed-1 routes without changing acceptance predicates."""
from pathlib import Path
from collections import Counter,defaultdict
from decimal import Decimal
import hashlib,json
base=Path(__file__).resolve().parent
modes=('baseline','overflow17','both')
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def group(name):
 if name.startswith('system.machine.cpu.'):return 'CPU'
 if '.cga.' in name or name.startswith('system.machine.isa.rgbi_'):return 'CGA'
 if '.mda.' in name:return 'MDA'
 return 'other'
def row_key(endpoint,row):return (endpoint,tuple(row['launch']),tuple(row['capture']))
def rows(snapshot):
 result={}
 for endpoint,values in snapshot['endpoints'].items():
  for row in values:
   key=row_key(endpoint,row);assert key not in result
   result[key]=row
 return result
reports={};snapshots={};allrows={};receipts={};routed={};result={'runs':{}}
for mode in modes:
 folder=base/('route-'+mode)
 receipt=json.loads((folder/'receipt.json').read_text());receipts[mode]=receipt
 for filename,expected in receipt['artifacts'].items():assert sha(folder/filename)==expected,(mode,filename)
 timing=json.loads((folder/'timing.json').read_text());snapshot=json.loads((folder/'endpoints.json').read_text())
 module=json.loads((folder/'routed.json').read_text())['modules']['top'];routed[mode]=module
 assert timing['timing_summary']['final_analogue_model'] and snapshot['final_analogue']
 reports[mode]=timing;snapshots[mode]=snapshot;allrows[mode]=rows(snapshot)
 pairs=defaultdict(list);groups=defaultdict(list)
 for key,row in allrows[mode].items():
  pairs[(key[1],key[2])].append((key[0],row))
  if key[1]==('clocks[0]',0) and key[2]==('clocks[0]',0):groups[group(json.loads(key[0])[0])].append((key[0],row))
 pair_summary=[]
 for (launch,capture),values in sorted(pairs.items()):
  pair_summary.append({'launch':launch,'capture':capture,'rows':len(values),
   'setup_wns_ps':min((r['setup'] for ep,r in values if r['setup_timed']),default=None),
   'related_hold_wns_ps':min((r['hold'] for ep,r in values if r['hold_related']),default=None),
   'setup_failures':sum(r['setup_timed'] and r['setup']<0 for ep,r in values),
   'related_hold_failures':sum(r['hold_related'] and r['hold']<0 for ep,r in values)})
 group_summary={}
 for name,values in sorted(groups.items()):
  timed=sorted((r['setup'],ep) for ep,r in values if r['setup_timed'])
  group_summary[name]={'rows':len(values),'wns_ps':timed[0][0],
                       'setup_failures':sum(slack<0 for slack,ep in timed),'worst':[{'setup_ps':slack,'endpoint':json.loads(ep)} for slack,ep in timed[:5]]}
 worst={}
 for label in ('CPU','CGA','MDA','other','system'):
  candidates=[]
  for path in timing['critical_paths']:
   if path['from']!='posedge clocks[0]' or path['to']!='posedge clocks[0]' or not path['path']:continue
   endpoint=path['path'][-1]['to']
   if label!='system' and group(endpoint['cell'])!=label:continue
   slack=round((path['max_delay']-sum(s['delay'] for s in path['path']))*1000)
   candidates.append((slack,endpoint['cell'],path))
  if not candidates:continue
  slack,cell,path=min(candidates,key=lambda x:(x[0],x[1]));sums=defaultdict(float)
  for segment in path['path']:sums[segment['type']]+=segment['delay']
  worst[label]={'setup_ps':slack,'endpoint':path['path'][-1]['to'],
               'launch':next((s['from'] for s in path['path'] if s['type']=='clk-to-q'),None),
               'segment_totals_ns':dict(sums),'path':path}
 assert worst['system']['setup_ps']==min(v['wns_ps'] for v in group_summary.values())
 assert worst['CPU']['setup_ps']==group_summary['CPU']['wns_ps']
 (folder/'analyzed-worst-paths.json').write_text(json.dumps(worst,indent=2)+'\n')
 counts=Counter(c['type'] for c in module['cells'].values())
 result['runs'][mode]={'returncode':receipt['returncode'],'charged_seconds':receipt['charged_seconds'],
  'binary_sha256':receipt['binary_sha256'],'artifact_hashes':receipt['artifacts'],
  'clock_summary_ps':{clock:{'setup':round(values['setup_wns_ns']*1000),'hold':round(values['hold_wns_ns']*1000)} for clock,values in timing['timing_summary']['clocks'].items()},
  'clock_pairs':pair_summary,'system_domain_groups':group_summary,
  'endpoint_identities':len(snapshot['endpoints']),'endpoint_rows':len(allrows[mode]),
  'setup_timed_rows':sum(r['setup_timed'] for r in allrows[mode].values()),
  'setup_failing_rows':sum(r['setup_timed'] and r['setup']<0 for r in allrows[mode].values()),
  'related_hold_failing_rows':sum(r['hold_related'] and r['hold']<0 for r in allrows[mode].values()),
  'schema':snapshot['schema'],'complete':snapshot['complete'],'unsupported_count':len(snapshot['unsupported']),
  'static_endpoint_count':len(snapshot['static_endpoints']),'physical_obligations':snapshot['physical_obligations'],
  'routed_cell_count':len(module['cells']),'routed_named_net_count':len(module['netnames']),
  'routed_buffer_count':counts['MISTRAL_BUF'],'cell_types':dict(counts),
  'worst_paths':{label:{k:v for k,v in entry.items() if k!='path'} for label,entry in worst.items()}}
# Paired complete endpoint identities, constraints and all setup/hold margins.
result['comparisons']={}
for mode in modes[1:]:
 old,new=allrows['baseline'],allrows[mode];assert set(old)==set(new)
 for key in old:
  for field in ('setup_timed','hold_related','setup_window'):assert old[key][field]==new[key][field]
 metadata=('clocks','forwarded_clocks','io_constraints','output_contracts','physical_obligations',
           'primitive_clocks','registered_contracts','reset_contracts','unregistered_contracts','unsupported')
 for field in metadata:assert snapshots['baseline'][field]==snapshots[mode][field],(mode,field)
 physical_metadata={}
 for field in ('constant_outputs','static_endpoints','unsupported_details'):
  before,after=snapshots['baseline'][field],snapshots[mode][field]
  assert set(before)==set(after),(mode,field,'identities')
  physical_metadata[field]={'identities_equal':True,'count':len(before),
                            'changed_records':sum(before[key]!=after[key] for key in before),
                            'complete_records_equal':before==after}
 margins={}
 for field,flag in [('setup','setup_timed'),('hold','hold_related')]:
  delta=[new[key][field]-old[key][field] for key in old if old[key][flag]]
  margins[field]={'compared':len(delta),'improved':sum(x>0 for x in delta),'regressed':sum(x<0 for x in delta),
                  'unchanged':sum(x==0 for x in delta),'worst_regression_ps':min(delta),'best_improvement_ps':max(delta)}
 a,b=routed['baseline'],routed[mode];an=set(a['cells']);bn=set(b['cells'])
 removed=an-bn;added=bn-an
 assert all(a['cells'][n]['type']=='MISTRAL_BUF' for n in removed)
 assert all(b['cells'][n]['type']=='MISTRAL_BUF' for n in added)
 nonbuf={n for n,c in a['cells'].items() if c['type']!='MISTRAL_BUF'}
 assert nonbuf=={n for n,c in b['cells'].items() if c['type']!='MISTRAL_BUF'}
 changed_parameters=[];changed_logical_pins=[];physical_pin_differences=0;placement_differences=0
 for name in sorted(nonbuf):
  left,right=a['cells'][name],b['cells'][name]
  if left['type']!=right['type'] or left['parameters']!=right['parameters']:changed_parameters.append(name)
  placement_differences+=left['attributes'].get('NEXTPNR_BEL')!=right['attributes'].get('NEXTPNR_BEL')
  lp=json.loads(bytes.fromhex(left['attributes']['FES_PINMAP_V1']).decode())['pins']
  rp=json.loads(bytes.fromhex(right['attributes']['FES_PINMAP_V1']).decode())['pins']
  if {p:v[0] for p,v in lp.items()}!={p:v[0] for p,v in rp.items()}:changed_logical_pins.append(name)
  physical_pin_differences+=sum(pin in rp and value[1:]!=rp[pin][1:] for pin,value in lp.items())
 proof=json.loads((base/('proof-'+mode+'.json')).read_text())
 selected_cells={cell for root in proof['roots'].values() if root['selected'] for cell in root['cells']}
 assert set(changed_parameters)<=selected_cells and set(changed_logical_pins)<=selected_cells
 result['comparisons'][mode]={'complete_timed_endpoint_identity_and_clock_constraint_sets_match':True,'endpoint_margins':margins,
  'static_constant_and_unsupported_metadata':physical_metadata,
  'routed_inventory':{'common_nonbuffer_cells':len(nonbuf),'removed_buffers':len(removed),'added_buffers':len(added),
   'nonbuffer_placement_differences':placement_differences,'common_nonbuffer_physical_pin_differences':physical_pin_differences,
   'changed_nonbuffer_functions':changed_parameters,'changed_nonbuffer_logical_pin_sets_or_polarities':changed_logical_pins},
  'qualification':'rejected diagnostic: setup failures, per-endpoint margin regressions, changed physical proof records and incomplete physical coverage remain'}
# Exact disabled compatibility against the original placed and fresh raw 692 routes.
references={'original_692_placed':base.parent/'reassociate-20261022/baseline',
            'fresh_692_raw':base.parent/'fresh-placement-20261022/baseline'}
result['baseline_byte_comparisons']={}
for label,folder in references.items():
 result['baseline_byte_comparisons'][label]={}
 for filename in ('diagnostic.rbf','timing.json','endpoints.json','routed.json'):
  reference=sha(folder/filename);current=sha(base/'route-baseline'/filename)
  result['baseline_byte_comparisons'][label][filename]={'reference_sha256':reference,'current_sha256':current,'identical':reference==current}
 # Preserve small exact reference provenance, not an unbound path-only assertion.
 (base/('reference-'+label+'-receipt.json')).write_text((folder/'receipt.json').read_text())
prior=Decimal('9940.813688035588');charge=sum(Decimal(str(receipts[m]['charged_seconds'])) for m in modes)
result['accounting']={'prior_cumulative_seconds':str(prior),'three_route_seconds':str(charge),
                      'cumulative_seconds':str(prior+charge),'total_budget_cap':None,
                      'scope':'only these three completed routes; later seed/trace runs excluded'}
result['final_routed_proof']={'status':'not yet a complete final-graph equivalence proof',
 'established':'same complete nonbuffer cell identities; only selected function and logical-pin-set changes; exact full endpoint identities and constraints; exhaustive full-graph unpacked proofs',
 'remaining':'different route-through buffer inventories require a complete per-artifact helper/alias/driver/consumer ledger, source ancestry and polarity proof; physical placement/pin changes and RBF encoding are separate',
 'forbidden_shortcut':'do not intersect routed inventories, collapse helpers by name alone, or call unpacked proof final physical signoff'}
result['evidence']='host-only final-route diagnostic, not timing closure or hardware/producer acceptance'
(base/'route-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'runs':{m:{k:v for k,v in run.items() if k in ('clock_summary_ps','setup_failing_rows','system_domain_groups')} for m,run in result['runs'].items()},
                  'comparisons':result['comparisons'],'accounting':result['accounting'],
                  'baseline_byte_comparisons':result['baseline_byte_comparisons']},indent=2))
