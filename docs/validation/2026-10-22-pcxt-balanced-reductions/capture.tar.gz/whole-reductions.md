# Whole-reduction follow-up

The DX and last-result failures come from two independent private conjunction
trees. Both are present in the raw synthesis capture, so a fresh paired
pack/place/route can exercise whole-tree balancing without relying on a placed
reload. Each tree currently has a three-LUT longest branch and can become
three product leaves plus a three-input root, retaining its four cell objects,
root output, external consumers and literal user slots.

| Tree | Exact function | Existing shape | Proposed shape |
| --- | --- | --- | --- |
| overflow17 | `~(|DX[15:0]) & ~AX[15]` | ALUT6 → ALUT5 → ALUT5, with a second ALUT4 branch | 6+6+5 leaves → AND3 |
| last_result16 | `~(|eu_alu_last_result[15:0])` | ALUT4 → ALUT6 → ALUT5, with a second ALUT4 branch | 6+6+4 leaves → AND3 |

Raw roots:

```text
system.machine.cpu.cpu.u_eu_core.eu_overflow_override_MISTRAL_FF_Q_SCLR_MISTRAL_ALUT5_Q_D_MISTRAL_ALUT2_A_Q_MISTRAL_ALUT4_Q_1_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_C_Q_MISTRAL_ALUT5_Q
system.machine.cpu.cpu.u_eu_core.idiv_opcode_MISTRAL_ALUT4_A_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT5_Q
```

The original first-factor producer is inside `last_result16`; its consumer is
exactly that tree's root. Its immediate downstream ALUT5 has four true LUT rows,
so the conjunction ends there. Do not absorb that general Boolean function or
the shared downstream `idiv_opcode` result. The overflow root similarly stops
before `idiv_opcode_MISTRAL_ALUT4_A_D_MISTRAL_ALUT5_Q_1`.

`whole-reductions.json` records every node, primitive mask, logical input driver,
external root consumer, physical placement in the first-factor checkpoint and
raw register-bus mapping. `audit-whole-reductions.py` independently evaluated
131,072 assignments for the overflow root and 65,536 for the last-result root,
on **both** raw synthesis and first-factor placed checkpoints. Both root
functions agree under canonical named FF-Q identities; the two cell sets are
disjoint. This proves the selected functions, not a new compiler artifact or
timing closure.

Static input checks found ordinary LUT2..6 cells with exact LUT parameters,
no protected selected cells/nets, distinct register-Q literals, private Q nets
with one internal user and no top-level exposure, and no observed clock-pin
consumers. Full native Context eligibility remains mandatory when the CLI loads
the actual QSF/SDC. The audit deliberately does not forge placement, clocks or
contracts.

The old compiler already accepts the 16-literal class. Its four-cell rule
rejects the 17-literal overflow class. The prepared generic extension accepts
13–18 literals with deterministic leaf widths `6+5+2` for 13, then `6+6+2`
through `6+6+6` for 14–18. It retains the original sixteen-literal `6+6+4`
partition and all other guards. The separate placed-reduction path remains
restricted to its prior three-/seven-cell classes.

Recommended next diagnostics are a fresh same-binary raw baseline, overflow17
alone, and both roots through repeated `--balance-reduction-root` options.
Compare full final routed setup/hold and endpoint identities/margins; a shorter
logic graph is not evidence that physical routing improved. Retain the first
factor route separately as the current best diagnostic. The existing partial
schema-7 endpoint coverage and physical obligations remain qualification gates.

Source identities:

- raw `candidate/synth.json`: `b4c44b2b66faaf8dd1019c6d8de119c55eecb49856158019ac8899a869de028b`
- first-factor placed: `622a9403f5232e05420e2f4cffa62267a02e4b51d2d45504963b7d8a44f43bd9`
