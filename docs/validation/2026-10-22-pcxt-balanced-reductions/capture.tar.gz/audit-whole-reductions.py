#!/usr/bin/env python3
"""Read-only exact-tree audit. Does not produce a compiler netlist or timing acceptance."""
import hashlib,json,tarfile
from pathlib import Path
base=Path(__file__).resolve().parent
fes=base.parents[1]
archive=fes/'sources/misteross/docs/validation/2026-10-22-pcxt-pad-pipeline/capture.tar.gz'
with tarfile.open(archive) as tar:raw_bytes=tar.extractfile('candidate/synth.json').read()
placed_bytes=(base/'transformed-placed.json').read_bytes()
raw=json.loads(raw_bytes)['modules']['top'];placed=json.loads(placed_bytes)['modules']['top']
prefix='system.machine.cpu.cpu.u_eu_core.'
roots={
 'overflow17':prefix+'eu_overflow_override_MISTRAL_FF_Q_SCLR_MISTRAL_ALUT5_Q_D_MISTRAL_ALUT2_A_Q_MISTRAL_ALUT4_Q_1_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_C_Q_MISTRAL_ALUT5_Q',
 'last_result16':prefix+'idiv_opcode_MISTRAL_ALUT4_A_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT5_Q',
}
def audit(module,root):
 cells=module['cells']; drivers={};users={};aliases={};topbits=set()
 for name,net in module['netnames'].items():
  for index,bit in enumerate(net['bits']):aliases.setdefault(bit,[]).append((name,index,net.get('attributes',{})))
 for port in module['ports'].values():topbits.update(port['bits'])
 for name,cell in cells.items():
  for port,bits in cell['connections'].items():
   for bit in bits:
    if cell['port_directions'][port]=='output':
     assert bit not in drivers
     drivers[bit]=(name,port)
    else:users.setdefault(bit,[]).append((name,port))
 nodes={};literals={};guards=[]
 def walk(bit,required):
  d=drivers.get(bit);cell=cells.get(d[0],{}) if d else {}
  if cell.get('type') not in ['MISTRAL_ALUT'+str(w) for w in range(2,7)]:
   assert bit not in literals,('repeated literal',bit)
   assert d and cell['type']=='MISTRAL_FF' and d[1]=='Q'
   literals[bit]=required;return
  assert d[0] not in nodes,('cycle/reconvergence',d)
  w=int(cell['type'][-1]); mask=int(cell['parameters']['LUT'],2)
  assert set(cell['parameters'])=={'LUT'} and len(cell['parameters']['LUT'])==(1<<w)
  matches=[r for r in range(1<<w) if bool((mask>>r)&1)==required]
  assert len(matches)==1,(d,matches)
  logical={p:0 for p in 'ABCDEF'[:w]}
  if 'FES_PINMAP_V1' in cell.get('attributes',{}):
   pm=json.loads(bytes.fromhex(cell['attributes']['FES_PINMAP_V1']).decode())['pins']
   assert all(pm[p][0]==0 for p in logical),pm # actual selected trees have no inverted pins
  nodes[d[0]]={'type':cell['type'],'lut':hex(mask),'required_output':required,
               'inputs':{},'output_users':users.get(bit,[]),'output_top_level':bit in topbits,
               'bel':cell.get('attributes',{}).get('NEXTPNR_BEL')}
  assert not any(k in cell.get('attributes',{}) for k in ['keep','dont_touch'])
  if d[0]!=root:
   assert len(users.get(bit,[]))==1 and bit not in topbits
  for i,pin in enumerate('ABCDEF'[:w]):
   incoming=cell['connections'][pin][0]
   assert isinstance(incoming,int)
   assert not any(any(k in attrs for k in ['keep','dont_touch']) for n,j,attrs in aliases.get(incoming,[]))
   assert not any(port in ['CLK','INCLK','REFCLK'] for name,port in users.get(incoming,[]))
   nodes[d[0]]['inputs'][pin]=drivers[incoming]
   walk(incoming,bool((matches[0]>>i)&1))
 walk(cells[root]['connections']['Q'][0],True)
 for name,node in nodes.items():
  if name!=root:assert all(user in nodes for user,p in node['output_users'])
 canon={drivers[bit]:req for bit,req in literals.items()}
 bits=sorted(literals,key=lambda b:drivers[b]);positions={b:i for i,b in enumerate(bits)}
 def evaluate(bit,row):
  if bit in positions:return bool((row>>positions[bit])&1)
  name,port=drivers[bit];cell=cells[name];w=int(cell['type'][-1]);r=0
  for i,pin in enumerate('ABCDEF'[:w]):r|=int(evaluate(cell['connections'][pin][0],row))<<i
  return bool((int(cell['parameters']['LUT'],2)>>r)&1)
 required=sum(int(literals[b])<<i for i,b in enumerate(bits));count=1<<len(bits)
 for row in range(count):assert evaluate(cells[root]['connections']['Q'][0],row)==(row==required)
 buses={}
 for b in bits:
  buses[str(drivers[b])]=[(n,i) for n,i,a in aliases.get(b,[]) if n in [prefix+'eu_register_dx',prefix+'eu_register_ax',prefix+'eu_alu_last_result']]
 return {'root':root,'cell_count':len(nodes),'literal_count':len(bits),'nodes':nodes,
         'literals':[{'driver':driver,'required':req,'bus':buses[str(driver)]} for driver,req in sorted(canon.items())],
         'exhaustive_assignments':count,'required_row':required,
         'raw_structure_guards':'pass: ordinary LUT2..6; exact LUT shape; distinct FF-Q literals; single-use private Q; no protected cells/nets or top-level private Q; no observed CLK/INCLK/REFCLK consumers',
         'native_context_guard':'not invoked in this audit; full CLI validation remains mandatory'}
result={'evidence':'read-only structure and exhaustive logical proof; no route or timing acceptance',
        'source':{'archive':str(archive),'member':'candidate/synth.json','synth_sha256':hashlib.sha256(raw_bytes).hexdigest(),
                  'first_factor_placed_sha256':hashlib.sha256(placed_bytes).hexdigest()},'trees':{}}
for label,root in roots.items():
 a=audit(raw,root);b=audit(placed,root)
 assert {(tuple(x['driver']),x['required']) for x in a['literals']}=={(tuple(x['driver']),x['required']) for x in b['literals']}
 assert set(a['nodes'])==set(b['nodes'])
 result['trees'][label]={'raw':a,'first_factor_placed':b,'identical_root_function':True,
                       'proposed_leaf_widths':[6,6,5] if label=='overflow17' else [6,6,4]}
assert set(result['trees']['overflow17']['raw']['nodes']).isdisjoint(result['trees']['last_result16']['raw']['nodes'])
result['independent_cell_sets']=True
(base/'whole-reductions.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({label:{'root':root,'cells':result['trees'][label]['raw']['cell_count'],
                        'literals':result['trees'][label]['raw']['literal_count'],
                        'assignments_each':result['trees'][label]['raw']['exhaustive_assignments']} for label,root in roots.items()},indent=2))
