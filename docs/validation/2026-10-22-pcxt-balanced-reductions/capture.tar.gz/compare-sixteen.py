import importlib.util,sys,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
source=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr/mistral/tests/reduction_balance_cli.py')
old=root.parent/'reassociate-20261022/nextpnr-mistral';new=Path('/home/deano/harnesses/pcxt-compiler-repair/build-candidate/nextpnr-mistral')
sys.argv=['comparison',str(old)]
spec=importlib.util.spec_from_file_location('cli',source);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
result={'fixture':'existing sixteen-literal design() unchanged by extension','binary_hashes':{name:hashlib.file_digest(binary.open('rb'),'sha256').hexdigest() for name,binary in [('old',old),('new',new)]},'comparisons':{}}
for label,selected in [('disabled',None),('enabled','root')]:
 values=[]
 for name,binary in [('old',old),('new',new)]:
  mod.BINARY=str(binary);code,log,out=mod.ReductionBalanceCliTest().run_design(root=selected)
  assert code==0,log
  (root/f'sixteen-{label}-{name}.json').write_text(json.dumps(out,indent=2)+'\n');(root/f'sixteen-{label}-{name}.log').write_text(log)
  values.append(out['modules'])
 assert values[0]==values[1],label
 result['comparisons'][label]={'complete_exported_modules_equal':True}
(root/'sixteen-compatibility.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
