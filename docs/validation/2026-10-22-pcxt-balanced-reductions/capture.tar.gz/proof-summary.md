# Unpacked reduction export proofs

Three exports were produced from the same raw synthesis, QSF/SDC and compiler
binary, with `--no-pack --no-place --no-route`. The selected roots were accepted
by native Context guards. These are structural diagnostics; neither placement,
routing, timing acceptance nor hardware operation occurred.

| Variant | Changed cells | Preserved outside cells | Exhaustive root assignments |
| --- | ---: | ---: | ---: |
| Overflow only | 4 | 31,388 | 131,072 overflow + 65,536 last-result |
| Both roots | 8 | 31,384 | 131,072 overflow + 65,536 last-result |

Every candidate retains all 31,392 cell identities and 34,471 canonical net
identities/aliases. All output drivers, 19 top ports, cell metadata outside the
selected logic, net metadata, settings and module attributes agree with the
same-binary unmodified export. Private intermediate outputs have one internal
user and no top-level exposure. Root outputs and their external consumers remain
unchanged. Each root is independently checked against both its original truth
table and its expected all-zero conjunction.

`prepare.py` and `prepare-*/receipt.json` retain exact commands, return codes,
input hashes and binary identity. `proof.py` uses no compiler rewrite helper;
`proof-overflow17.json` and `proof-both.json` record full proof results. The parent
will route raw synthesis with direct opt-in flags; these exports are the proof
artifacts, not a replacement placement recipe.

Binary SHA256: `6834b09bc3ccc63105d3027db0c0415a6dc080cc923645126c3a0fca4ec65fde`.

- baseline export: `a926b9c80a1a8edb4137d500d75beef4c08a67db26f25705de6ae75b44b4d4cf`
- overflow17 export: `9ad8d6bcf98b8bea502f82d5266ecc8c1bf8490c625f7eda6f10d6d3165a0d99`
- both export: `8426c88da15c6af8ee04a66559e123f4dfbadca4d028b3701411cf3bd8b98fe3`
