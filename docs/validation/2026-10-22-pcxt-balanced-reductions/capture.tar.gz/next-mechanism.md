# Next bounded compiler diagnostic

The both-root seed-1 route has moved the worst CPU endpoint to ALU operand
selection and the output register. Its 11.126 ns path contains 7.653 ns routing,
2.891 ns combinational logic, 0.731 ns clock-to-Q, +0.047 ns skew and the native
-0.196 ns setup term. It is not a pure reduction and has no multiplication.

The reported sequence is:

1. `eu_add_select0_MISTRAL_FF_Q_5`, (13,37), fanout 16: 2.081 ns to the first ALUT5.
2. First operand-select ALUT5, (9,37): 0.478 ns logic and 0.877 ns to its sole ALUT5 consumer.
3. Second ALUT5, (8,36): 0.476 ns logic and **2.310 ns** to its sole arithmetic-A consumer at (9,35).
4. Arithmetic A-to-CO and subsequent carry/sum: 1.082 + 0.035 + 0.368 ns, with zero reported dedicated carry routing delay.
5. ALU output ALUT5: 0.227 ns logic, then a 1.806 ns route to `data_bus_word_out_MISTRAL_FF_Q_12` at (18,38), fanout 16 on the ALU output.

Exact long names, ports, coordinates and segments are retained in
`route-both/analyzed-worst-paths.json` under `CPU`. The two operand ALUT5s have
nine distinct external signals, so simple composition into one LUT6 does not
fit that cut. The two selected reduction roots are absent from this particular
path. Other CPU endpoints still fail, so this is a next diagnostic target, not
proof that one repaired edge closes the CPU.

The existing `--remap-lut-driver-critical REPORT` discovery accepts reported
ordinary-LUT Q to arithmetic A/B/C/D0/D1 edges. Its source check does not require
more than one output consumer. The 2.310 ns edge therefore matches discovery's
type/port shape; actual native eligibility, protected LABs, ordinary-net checks,
input arrivals, every affected endpoint clock pair and candidate site legality
must still pass. It preserves original arithmetic placement/carry links and
checks the following carry cell's shared-input cache. The documented bounds are
16 edges, 24 shortlisted sites and 16 native probes per edge, with a 250 ps
predicted improvement requirement. No listing has yet run for this capture.

Use a fresh same-recipe placement with both reductions and the matching routed
report before listing. The current pass rejects routed designs and validates
reported identities/locations. Do not remove routing fields from a final JSON,
feed it a different seed/profile, or bypass qualification. An accepted local
estimate still needs full final routing, all timing/coverage guards and complete
proof accounting.

The current LUT-pair placement pass discovers only the final two LUTs feeding a
register, so it does not directly target this internal pair before arithmetic.
If the driver-copy pass cannot qualify a useful candidate, a bounded move of the
existing sole-consumer LUT toward fixed arithmetic is a smaller proposed
extension than broad remapping: no new function, register or load is needed.
It would need the existing exact snapshot/rollback, pin/ALM legality, arithmetic
cache, clock and full affected-endpoint guards. Copying adds source-input loads
and retains the unused original driver, which may matter for this sole-consumer
case. No implementation is proposed without the listing rejection evidence.

More than 10,300 original cells move between the three fresh placements. The
short geometric separation but long 2.310 ns routed operand edge suggests an
estimate/pin/route interaction worth tracing through placement stages; the
report alone does not identify which stage caused it. The separate placer trace
and seed comparisons should decide that before a new global objective changes.
CGA's independent M10K-to-pixel path remains the both-root system limit and
requires its own placement/mapping investigation. No clock is reduced and no
DSP substitution follows from this path.
