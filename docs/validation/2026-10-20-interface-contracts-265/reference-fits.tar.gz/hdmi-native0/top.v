module top(input FPGA_CLK1_50, output HDMI_TX_CLK, output reg alive);
wire clk;
altclkctrl #(.clock_type("Global Clock"), .intended_device_family("Cyclone V")) clock_buffer
 (.inclk({3'b000,FPGA_CLK1_50}), .clkselect(2'b00), .ena(1'b1), .outclk(clk));
assign HDMI_TX_CLK = clk;
always @(posedge clk) alive <= ~alive;
endmodule
