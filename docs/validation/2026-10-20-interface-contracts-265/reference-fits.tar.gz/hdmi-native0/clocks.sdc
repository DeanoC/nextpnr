create_clock -period 20 -name source [get_ports FPGA_CLK1_50]
create_generated_clock -name forwarded -source [get_ports FPGA_CLK1_50] -divide_by 1 [get_ports HDMI_TX_CLK]
set_output_delay -clock source -min 0 [get_ports alive]
set_output_delay -clock source -max 1 [get_ports alive]
