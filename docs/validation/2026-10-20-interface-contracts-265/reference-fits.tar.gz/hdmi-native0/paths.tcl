package require ::quartus::project
package require ::quartus::sta
project_open top
create_timing_netlist
read_sdc
foreach corner [get_available_operating_conditions] {
    set_operating_conditions $corner
    update_timing_netlist
    file mkdir $corner
    foreach edge {rise fall} {
        puts [report_path -from [get_ports FPGA_CLK1_50] -${edge}_to [get_ports HDMI_TX_CLK] -npaths 10 -show_routing -file $corner/$edge-late.rpt]
        puts [report_path -min_path -from [get_ports FPGA_CLK1_50] -${edge}_to [get_ports HDMI_TX_CLK] -npaths 10 -show_routing -file $corner/$edge-early.rpt]
    }
    report_clocks -file $corner/clocks.rpt
}
project_close
