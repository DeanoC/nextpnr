#!/usr/bin/env python3
from pathlib import Path
import copy,importlib.util,json
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('copy_proof',root/'prove-copy.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
lib=checker.lib;read=lib.read;sha=lib.digest;require=lib.require
manifest=read(root/'inputs/manifest.json');binary=Path(manifest['binary']);require(sha(binary)==manifest['binary_sha256'],'binary differs')
baseline=read(root/'baseline/placed.json');selection_by_id={v['candidate']:v for v in read(root/'analysis.json')['candidates']};bridges=[];copies=[];tests=[]
reference=root.parent/'reduction-balanced-20261022/route-both'
def normalized(command):
 command=command[:]
 for option in ('--rbf','--routed-endpoints'):
  if option in command:i=command.index(option);del command[i:i+2]
 if '--no-route' in command:command.remove('--no-route')
 for option in ('--json','--qsf','--sdc','--remap-lut-driver-critical'):
  if option in command:i=command.index(option)+1;command[i]='sha256:'+sha(Path(command[i]))
 for option in ('--write','--report'):
  if option in command:command[command.index(option)+1]='<output>'
 return command
for mode,prepared_path,route in [('baseline',root/'baseline/placed.json',reference),('0',root/'prepare-0/placed.json',root/'route-0'),('2',root/'prepare-2/placed.json',root/'route-2')]:
 receipt=read(route/'receipt.json');prep_receipt=read(prepared_path.parent/'receipt.json')
 require(receipt['binary_sha256']==manifest['binary_sha256'],'route compiler differs')
 for name,expected in receipt['artifacts'].items():require(sha(route/name)==expected,'route artifact hash differs: '+name)
 require(normalized(receipt['nextpnr_command'])==normalized(prep_receipt['command']),'fresh reconstruction recipe differs')
 require(read(route/'timing.json')['timing_summary']['final_analogue_model'] is True,'not final analogue')
 pd,rd=read(prepared_path),read(route/'routed.json');bridge=lib.prepared_bridge(pd,rd);bridge.update(mode=mode,prepared_sha256=sha(prepared_path),routed_sha256=sha(route/'routed.json'));bridges.append(bridge)
 if mode=='baseline':continue
 selection=selection_by_id[int(mode)];proof=checker.prove(baseline,pd,selection);proof.update(candidate=int(mode),prepared_sha256=sha(prepared_path));copies.append(proof)
 clone=proof['clone'];net=proof['private_output_net'];sink=proof['sink'];port=proof['sink_port']
 def reject(label,mutate):
  changed=copy.deepcopy(pd);mutate(changed['modules']['top'])
  try:checker.prove(baseline,changed,selection)
  except (ValueError,AssertionError,KeyError) as error:tests.append({'candidate':int(mode),'case':label,'rejected':True,'reason':str(error)})
  else:raise AssertionError('negative copy mutation accepted: '+label)
 def truth(m):
  c=m['cells'][clone];s=c['parameters']['LUT'];c['parameters']['LUT']=('1' if s[0]=='0' else '0')+s[1:]
 def invert(m):
  c=m['cells'][clone];p=lib.unpack(c['attributes']['FES_PINMAP_V1']);p['pins']['A'][0]=3;c['attributes']['FES_PINMAP_V1']=lib.pack(p)
 reject('copied LUT truth changed',truth);reject('copied input polarity changed',invert)
 reject('private copy output given extra alias',lambda m:m['netnames'].update({'proof_mutation_alias':copy.deepcopy(m['netnames'][net])}))
 reject('copy output externally observed',lambda m:m['ports'].update({'proof_mutation_port':{'direction':'output','bits':m['netnames'][net]['bits'][:]}}))
 reject('selected consumer bypasses copy',lambda m:m['cells'][sink]['connections'].update({port:m['cells'][proof['source']]['connections']['Q'][:]}))
 protected=proof['protected_original_cells_unchanged'];require(protected,'no protected original test owner')
 reject('protected original attribute changed',lambda m:m['cells'][protected[0]]['attributes'].update(dont_touch='proofmutation'))
 helpers=bridge['route_generated_buffers_proved'];require(helpers,'missing helpers')
 changed=copy.deepcopy(rd);helper=changed['modules']['top']['cells'][helpers[0]['cell']];pins=lib.unpack(helper['attributes']['FES_PINMAP_V1']);pins['pins']['A'][0]=3;helper['attributes']['FES_PINMAP_V1']=lib.pack(pins)
 try:lib.prepared_bridge(pd,changed)
 except (ValueError,AssertionError,KeyError) as error:tests.append({'candidate':int(mode),'case':'routed helper inversion','rejected':True,'reason':str(error)})
 else:raise AssertionError('negative route helper inversion accepted')
result={'status':'pass','evidence':'complete copied-function and original graph preservation plus exhaustive per-helper final routed bridges; no electrical/RBF/LAB encoding, timing acceptance or hardware proof','binary_sha256':manifest['binary_sha256'],'checker_sha256':sha(Path(__file__)),'copy_checker_sha256':sha(root/'prove-copy.py'),'route_support_sha256':sha(root/'proof-routed-support.py'),'fresh_placement_recipes_match_their_full_routes':True,'copy_proofs':copies,'routed_bridges':bridges,'negative_mutations':tests,'limits':['No graph intersection or assumed matching route-helper inventory is used; each full artifact is checked against its own complete prepared graph.','Every route-only helper must have the exact transparent function, pin polarity, private alias, FF consumer and physical-half relationship.','All original logical pin states, clock settings, functions, connected bits, aliases, top ports and nonphysical metadata are checked; physical pin maps may be reassigned by routing.','Electrical routing, serialized LAB state and RBF encoding remain outside this logical proof; final endpoint and board/clock qualification remain independent.']}
(root/'proof-routed.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'pass','helpers_per_artifact':[len(x['route_generated_buffers_proved']) for x in bridges],'original_cells_per_artifact':[x['prepared_cell_count'] for x in bridges],'physical_pinmap_changes':[x['physical_pinmap_change_count'] for x in bridges],'negative_mutations_rejected':len(tests),'protected_original_cells':len(copies[0]['protected_original_cells_unchanged'])},indent=2))
