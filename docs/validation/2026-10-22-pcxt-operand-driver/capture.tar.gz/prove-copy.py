#!/usr/bin/env python3
"""Exhaustive copied-LUT proof with a complete graph/alias/metadata ledger."""
from pathlib import Path
import collections,copy,importlib.util,itertools,json,sys
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('route_support',root/'proof-routed-support.py');lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
require=lib.require

def prove(before_doc,after_doc,selection):
 require(set(before_doc)==set(after_doc)=={'creator','modules'} and before_doc['creator']==after_doc['creator'],'document schema/creator differs')
 require(set(before_doc['modules'])==set(after_doc['modules'])=={'top'},'module identity differs')
 a,b=before_doc['modules']['top'],after_doc['modules']['top'];source,sink,pin=[selection[k] for k in ('source','sink','port')]
 require(set(a)==set(b)=={'settings','attributes','ports','cells','netnames'},'module schema differs')
 clone=source+'$lut_driver_copy$'+sink+'$'+pin;newnet=clone+'$Q'
 require(set(b['cells'])==set(a['cells'])|{clone} and clone not in a['cells'],'exact copy cell inventory differs')
 require(set(b['netnames'])==set(a['netnames'])|{newnet} and newnet not in a['netnames'],'exact new output alias inventory differs')
 mapping={};reverse={}
 for n,x in a['netnames'].items():
  y=b['netnames'][n];require(set(x)==set(y),'net schema differs');require({k:v for k,v in x.items() if k!='bits'}=={k:v for k,v in y.items() if k!='bits'},'net metadata changed: '+n)
  require(len(x['bits'])==len(y['bits']),'net width differs')
  for old,new in zip(x['bits'],y['bits']):
   require(type(old)==type(new),'signal classification differs')
   if type(old)==int:
    require(mapping.get(old,new)==new and reverse.get(new,old)==old,'alias split/merge');mapping[old]=new;reverse[new]=old
   else:require(old==new,'constant changed')
 def conn(c,side):
  return {p:[reverse[v] if side and type(v)==int else v for v in bits] for p,bits in c['connections'].items()}
 require(a['settings']==b['settings'] and a['attributes']==b['attributes'],'settings/clock or module attrs changed')
 require(set(a['ports'])==set(b['ports']),'top ports differ')
 for p,x in a['ports'].items():
  y=b['ports'][p];require(x['direction']==y['direction'] and x['bits']==[reverse[v] if type(v)==int else v for v in y['bits']],'top port changes')
 c=b['cells'][clone];src=a['cells'][source];width=int(src['type'][-1]);require(src['type']==f'MISTRAL_ALUT{width}' and 2<=width<=6,'unsupported source primitive')
 require(set(c)==set(src) and set(c['connections'])==set(c['port_directions']),'clone cell schema differs')
 require(c['type']==src['type'] and c['parameters']==src['parameters'] and c['port_directions']==src['port_directions'],'clone function/schema differs')
 require(set(c['attributes'])=={'BEL_STRENGTH','NEXTPNR_BEL','FES_PINMAP_V1'},'clone has unaccounted attributes')
 require(c['hide_name']==0 and c['attributes']['NEXTPNR_BEL']==selection['bel'] and int(c['attributes']['BEL_STRENGTH'],2)==1,'clone placement differs')
 pins_a=lib.pinmap(src,source);pins_c=lib.pinmap(c,clone);require({p:v[0] for p,v in pins_a.items()}=={p:v[0] for p,v in pins_c.items()},'clone logical polarity differs')
 output=c['connections']['Q'];require(len(output)==1 and type(output[0])==int and output[0] not in reverse,'copy output is not fresh private signal')
 out=output[0];old=a['cells'][source]['connections']['Q'];require(len(old)==1 and a['cells'][sink]['connections'][pin]==old,'original edge differs')
 net=b['netnames'][newnet];require(net['bits']==output and set(net)=={'hide_name','bits','attributes'} and net['hide_name']==0 and net['attributes']=={'ROUTING':' '},'new net metadata differs')
 uses=[(n,p,cell['port_directions'][p]) for n,cell in b['cells'].items() for p,bits in cell['connections'].items() for bit in bits if bit==out]
 require(sorted(uses)==sorted([(clone,'Q','output'),(sink,pin,'input')]),'private copy output has other driver/user')
 require(all(out not in p['bits'] for p in b['ports'].values()),'copy output externally observable')
 for p in 'ABCDEF'[:width]:
  require(c['connections'][p]==[mapping[x] if type(x)==int else x for x in src['connections'][p]],'copy input identity differs')
 changed=copy.deepcopy(b['cells'][sink]);require(changed['connections'][pin]==output,'wrong selected consumer edge');changed['connections'][pin]=[mapping[old[0]]]
 protected=[]
 for n,x in a['cells'].items():
  y=changed if n==sink else b['cells'][n]
  require(set(x)==set(y),'cell schema differs: '+n)
  for k in x:
   if k!='connections':require(x[k]==y[k],'original '+k+' differs: '+n)
  require(conn(x,False)==conn(y,True),'outside connectivity differs: '+n)
  if any(k in x['attributes'] for k in ('keep','dont_touch','BEL','FES_SLOT')):protected.append(n)
 require(source not in protected and sink not in protected,'selected cell protected')
 for bits in itertools.product((0,1),repeat=width):
  values=[]
  for cell,pins in ((src,pins_a),(c,pins_c)):
   row=0
   for i,p in enumerate('ABCDEF'[:width]):
    state=pins[p][0];require(state in range(4),'invalid state');v=1 if state==2 else 0 if state==1 else bits[i]^(state==3);row|=int(v)<<i
   values.append((int(cell['parameters']['LUT'],2)>>row)&1)
  require(values[0]==values[1],'copy truth differs')
 return {'source':source,'sink':sink,'sink_port':pin,'clone':clone,'private_output_net':newnet,'exhaustive_rows':1<<width,'complete_original_cells_unchanged_except_one_proven_consumer_connection':len(a['cells']),'complete_original_named_aliases_preserved':len(a['netnames']),'all_original_metadata_physical_logical_pins_placements_clocks_and_settings_preserved':True,'protected_original_cells_unchanged':protected,'new_private_output_exact_single_consumer':True,'truth_equivalent':True}

if __name__=='__main__':
 selection=next(v for v in lib.read(root/'analysis.json')['candidates'] if v['candidate']==int(sys.argv[1]));folder=root/('prepare-'+sys.argv[1]);before=root/'baseline/placed.json';after=folder/'placed.json';result=prove(lib.read(before),lib.read(after),selection)
 result.update(before_sha256=lib.digest(before),after_sha256=lib.digest(after),checker_sha256=lib.digest(Path(__file__)),evidence='complete prepared graph and copied function proof; no routed timing or hardware acceptance')
 (folder/'proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='protected_original_cells_unchanged'},indent=2))
