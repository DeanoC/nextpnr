from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time

root=Path(__file__).resolve().parent
task=root.parents[1]
reference=root.parent/'reduction-balanced-20261022'
parent=json.loads((reference/'route-both/receipt.json').read_text())
guidance=root/'baseline/predicted-timing.json'
def run(index):
    command=parent['nextpnr_command'][:]
    for flag,name in [('--json','synth.json'),('--qsf','constraints.qsf'),('--sdc','clocks.sdc')]:
        command[command.index(flag)+1]=str(root/'inputs'/name)
    command+=['--remap-lut-driver-critical',str(guidance),'--remap-lut-driver-candidate',str(index)]
    wrapped=[str(task/'scripts/gpu-run'),'--phase-lease','--owner','pcxt-timing',
             '--label',f'pcxt-native-driver-{index}','--',*command]
    directory=root/f'route-{index}';directory.mkdir(exist_ok=False)
    receipt={'command':wrapped,'nextpnr_command':command,'candidate':index,
             'binary_sha256':parent['binary_sha256'],
             'guidance_sha256':hashlib.file_digest(guidance.open('rb'),'sha256').hexdigest(),
             'evidence':'leased GPU fresh pack/place/route host diagnostic; native qualified driver copy; not acceptance',
             'limit':'native bounded router iterations; no external GPU-job termination'}
    assert hashlib.file_digest(open(command[0],'rb'),'sha256').hexdigest()==receipt['binary_sha256']
    env=dict(os.environ);env['NEXTPNR_REQUIRE_GPU']='1';start=time.monotonic()
    with (directory/'nextpnr.log').open('w') as log:
        receipt['returncode']=subprocess.run(wrapped,cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    receipt['charged_seconds']=time.monotonic()-start
    receipt['artifacts']={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in directory.iterdir() if p.suffix in ['.json','.rbf']}
    (directory/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(index,receipt['returncode'],receipt['charged_seconds'],flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures=[pool.submit(run,index) for index in [0,2]]
    for future in futures:future.result()
