from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def prepare(index):
 receipt=json.loads((root/f'route-{index}/receipt.json').read_text());command=receipt['nextpnr_command'][:]
 for option in ('--rbf','--routed-endpoints'):
  i=command.index(option);del command[i:i+2]
 for option,value in (('--write','placed.json'),('--report','predicted-timing.json')):command[command.index(option)+1]=value
 command+=['--no-route'];dest=root/f'prepare-{index}';dest.mkdir(exist_ok=False)
 assert sha(command[0])==receipt['binary_sha256'];assert sha(command[command.index('--remap-lut-driver-critical')+1])==receipt['guidance_sha256']
 start=time.monotonic()
 with (dest/'nextpnr.log').open('w') as f:code=subprocess.run(command,cwd=dest,stdout=f,stderr=subprocess.STDOUT).returncode
 r={'command':command,'cwd':str(dest),'returncode':code,'elapsed_seconds':time.monotonic()-start,'route_charge_seconds':0,'binary_sha256':sha(command[0]),'guidance_sha256':receipt['guidance_sha256'],'evidence':'CPU-only fresh candidate placement reconstruction; no routing','artifacts':{name:sha(dest/name) for name in ('placed.json','predicted-timing.json') if (dest/name).exists()}}
 (dest/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(index,code,r['elapsed_seconds'],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for future in [pool.submit(prepare,index) for index in (0,2)]:future.result()
