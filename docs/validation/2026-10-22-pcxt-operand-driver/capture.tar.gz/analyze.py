#!/usr/bin/env python3
from pathlib import Path
import collections, hashlib, json, re
base=Path(__file__).resolve().parent
reference=base.parent/'reduction-balanced-20261022'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=read(base/'baseline/placed.json')['modules']['top']; r=read(reference/'route-both/routed.json')['modules']['top']
t=read(base/'baseline/predicted-timing.json'); p=read(reference/'route-both/analyzed-worst-paths.json')['CPU']
target=next(s for s in p['path']['path'] if s['type']=='routing' and 2.30<s['delay']<2.32)
key=lambda e:(e['from']['cell'],e['to']['cell'],e['to']['port'])
tk=key(target)
aliases=collections.defaultdict(list);users=collections.defaultdict(list);drivers=collections.defaultdict(list)
for n,v in a['netnames'].items():
 for bit in v['bits']:aliases[bit].append(n)
for n,c in a['cells'].items():
 for port,bits in c['connections'].items():
  for bit in bits:(drivers if c['port_directions'][port]=='output' else users)[bit].append([n,port])
def cell(n):
 c=a['cells'][n];return {'name':n,'cell':c,'logical_pin_map':json.loads(bytes.fromhex(c['attributes']['FES_PINMAP_V1'])) if 'FES_PINMAP_V1' in c['attributes'] else None,'nets':{port:[{'bit':bit,'aliases':sorted(aliases[bit]),'drivers':drivers[bit],'users':users[bit],'metadata':{name:a['netnames'][name] for name in aliases[bit]}} for bit in bits] for port,bits in c['connections'].items()}}
seen={}; violated=0; target_appearances=0
for path in t['critical_paths']:
 ss=path['path'];target_appearances+=sum(key(s)==tk for s in ss if s['type']=='routing')
 if ss[-1]['type']!='setup' or ss[-1]['to']['port'] not in ('ENA','DATAIN'):continue
 excess=sum(s['delay'] for s in ss)-path['max_delay']
 if excess<=0:continue
 violated+=1; edges=[s for s in ss if s['type']=='routing']
 for i,e in enumerate(edges):
  src,sink=a['cells'][e['from']['cell']],a['cells'][e['to']['cell']]
  if e['from']['port']!='Q' or src['type'] not in [f'MISTRAL_ALUT{k}' for k in range(2,7)] or sink['type']!='MISTRAL_ALUT_ARITH' or e['to']['port'] not in ('A','B','C','D0','D1'):continue
  k=key(e); old=seen.get(k,(excess,len(edges)-i));seen[k]=(max(excess,old[0]),min(len(edges)-i,old[1]))
rank=sorted(seen,key=lambda k:(-seen[k][0],seen[k][1],*k)); log=(base/'list-placed/nextpnr.log').read_text();candidates=[];trials=[];domains=[];rejections=[]
for line in log.splitlines():
 m=re.search(r'copy candidate (\d+): source=(\S+) sink=(\S+) bel=(\S+) gain=(-?\d+)ps',line)
 if m:
  i,src,sink,bel,gain=m.groups();dest,port=sink.rsplit('.',1)
  candidates.append({'candidate':int(i),'source':src,'sink':dest,'port':port,'bel':bel,'predicted_gain_ps':int(gain),'source_before':cell(src),'sink_before':cell(dest)})
 m=re.search(r'copy trial source=(\S+) sink=(\S+) bel=(\S+) gain=(-?\d+)ps improve=(\d) endpoints=(\d) clocks=(\d) hold=(\d)',line)
 if m:
  src,sink,bel,gain,improve,endpoints,clocks,hold=m.groups();trials.append(dict(source=src,sink=sink,bel=bel,predicted_gain_ps=int(gain),improve=bool(int(improve)),endpoints=bool(int(endpoints)),clocks=bool(int(clocks)),hold=bool(int(hold))))
 if 'copy domains ' in line:domains.append(line)
 if 'copy rejection ' in line:rejections.append(line)
checks={name:sha(base/'baseline'/name)==sha(base/'list-placed'/name) for name in ('placed.json','predicted-timing.json')};assert all(checks.values())
originals={n for n,c in a['cells'].items() if c['type']!='MISTRAL_BUF'};assert originals<r['cells'].keys()
placement_changes=[n for n in originals if a['cells'][n]['attributes'].get('NEXTPNR_BEL')!=r['cells'][n]['attributes'].get('NEXTPNR_BEL')]
clock_settings={k:v for k,v in a['settings'].items() if k.startswith(('timing/','sdc/')) or k=='target_freq'}
result={'evidence':'CPU-only fresh same-input same-binary placement and bounded native listing; no full route or hardware','source_identity':read(base/'inputs/manifest.json')['source_identity'],'target':{'routed_edge':target,'source':cell(tk[0]),'sink':cell(tk[1]),'placed_report_appearances':target_appearances,'native_eligibility':'NOT TESTED: final report rejected as stale; matching placed native report does not select this edge'},'routed_guidance':{'returncode':read(base/'list-routed/receipt.json')['returncode'],'error':'Stale remap report cell.','no_candidate_or_export':not (base/'list-routed/placed.json').exists()},'placed_discovery':{'relevant_violated_paths':violated,'eligible_shape_count':len(rank),'ordered_edges':[{'source':k[0],'sink':k[1],'port':k[2],'excess_ns':seen[k][0],'distance':seen[k][1]} for k in rank]},'candidates':candidates,'native_trials':trials,'native_domains':domains,'native_rejections':rejections,'rollback':{'byte_identical_artifacts':checks,'full_module_equal':a==read(base/'list-placed/placed.json')['modules']['top'],'counts':{k:len(a[k]) for k in ('cells','netnames','ports')},'includes':'all functions, params, attrs, physical/logical pins, complete nets and aliases, top ports, placements, clocks and settings'},'placement_reference':{'original_nonbuffer_cells':len(originals),'changed_original_bels_vs_final_routed':placement_changes},'clock_settings':clock_settings,'receipts':{mode:read(base/mode/'receipt.json') for mode in ('baseline','list-routed','list-placed')}}
(base/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'qualified':len(candidates),'trials':len(trials),'rollback':result['rollback'],'target_appearances':target_appearances,'original_placement_changes':len(placement_changes),'candidates':[{k:v for k,v in c.items() if k not in ('source_before','sink_before')} for c in candidates]},indent=2))
