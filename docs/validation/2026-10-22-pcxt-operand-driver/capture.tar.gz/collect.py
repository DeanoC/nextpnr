from pathlib import Path
import hashlib,json,shutil,subprocess
capture=Path(__file__).resolve().parent;source=capture.parent;copied={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def retain(src,name):
 dst=capture/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():assert sha(dst)==sha(src)
 else:shutil.copyfile(src,dst)
 copied[str(dst.relative_to(capture))]={'source':str(src),'sha256':sha(dst),'size':dst.stat().st_size}
for src in sorted(source.rglob('*')):
 if not src.is_file() or capture in src.parents or '__pycache__' in src.parts or src.name.startswith('nextpnr-mistral'):continue
 rel=src.relative_to(source)
 if rel==Path('README.md'):rel=Path('listing-README.md')
 retain(src,rel)
reference=source.parent/'reduction-balanced-20261022/route-both'
for name in ('routed.json','diagnostic.rbf','timing.json','endpoints.json','receipt.json','nextpnr.log'):retain(reference/name,Path('references/fresh-both-root-baseline')/name)
identity=json.loads((source/'inputs/manifest.json').read_text())['source_identity'];repo=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
files=['mistral/lut_driver_copy.cc','mistral/lut_driver_copy.h','mistral/remap_report.h','mistral/enable_replication_policy.h','mistral/main.cc','mistral/arch.cc']
for name in files:
 data=subprocess.check_output(['git','show',identity['commit']+':'+name],cwd=repo);dst=capture/'sources'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
 copied[str(dst.relative_to(capture))]={'source':'git:'+identity['commit']+':'+name,'sha256':sha(dst),'size':dst.stat().st_size}
(capture/'collection.json').write_text(json.dumps({'scope':'native driver 0/2 listing, fresh preparation, final graph/function/endpoint proofs and full routes; no AX15 or spreader routes','source_identity':identity,'files':copied},indent=2)+'\n')
print(json.dumps({'files':len(copied),'bytes':sum(x['size'] for x in copied.values())},indent=2))
