from pathlib import Path
from collections import defaultdict
from decimal import Decimal
import hashlib,json

root=Path(__file__).resolve().parent
def sha(path):
    return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
def rows(snapshot):
    result={}
    for endpoint,values in snapshot['endpoints'].items():
        for row in values:
            key=(endpoint,tuple(row['launch']),tuple(row['capture']))
            assert key not in result;result[key]=row
    return result
all_rows={};snapshots={};result={'runs':{},'comparisons':{}}
charge=Decimal(0)
for seed in [1]:
    for mode in ['baseline','0','2']:
        name=f'route-{mode}';directory=(root.parent/'reduction-balanced-20261022/route-both') if mode=='baseline' else root/name
        receipt=json.loads((directory/'receipt.json').read_text())
        for filename,expected in receipt['artifacts'].items():assert sha(directory/filename)==expected
        timing=json.loads((directory/'timing.json').read_text())
        snapshot=json.loads((directory/'endpoints.json').read_text());snapshots[name]=snapshot
        assert timing['timing_summary']['final_analogue_model'] and snapshot['final_analogue']
        r=rows(snapshot);all_rows[name]=r;groups=defaultdict(list)
        for key,row in r.items():groups[(key[1],key[2])].append(row)
        pairs=[]
        for (launch,capture),values in sorted(groups.items()):
            pairs.append({'launch':launch,'capture':capture,'rows':len(values),
                'setup_wns_ps':min((v['setup'] for v in values if v['setup_timed']),default=None),
                'related_hold_wns_ps':min((v['hold'] for v in values if v['hold_related']),default=None),
                'setup_failures':sum(v['setup_timed'] and v['setup']<0 for v in values),
                'related_hold_failures':sum(v['hold_related'] and v['hold']<0 for v in values)})
        if mode!='baseline':charge+=Decimal(str(receipt['charged_seconds']))
        result['runs'][name]={'returncode':receipt['returncode'],'charged_seconds':receipt['charged_seconds'],
            'artifact_hashes':receipt['artifacts'],'binary_sha256':receipt['binary_sha256'],
            'clock_summary':timing['timing_summary']['clocks'],'clock_pairs':pairs,
            'endpoint_rows':len(r),'endpoint_identities':len(snapshot['endpoints']),
            'setup_failures':sum(v['setup_timed'] and v['setup']<0 for v in r.values()),
            'related_hold_failures':sum(v['hold_related'] and v['hold']<0 for v in r.values()),
            'schema':snapshot['schema'],'complete':snapshot['complete'],
            'unsupported_count':len(snapshot['unsupported']),'primitive_clocks':snapshot['primitive_clocks'],
            'physical_obligations':snapshot['physical_obligations']}
    base='route-baseline'
    for mode in ['0','2']:
        name=f'route-{mode}';a,b=all_rows[base],all_rows[name]
        assert set(a)==set(b)
        for key in a:
            for field in ['setup_timed','hold_related','setup_window']:assert a[key][field]==b[key][field]
        for field in ['clocks','forwarded_clocks','io_constraints','output_contracts','physical_obligations',
                      'primitive_clocks','registered_contracts','reset_contracts','unregistered_contracts','unsupported']:
            assert snapshots[base][field]==snapshots[name][field],(name,field)
        metadata={}
        for field in ['constant_outputs','static_endpoints','unsupported_details']:
            before,after=snapshots[base][field],snapshots[name][field]
            assert set(before)==set(after)
            metadata[field]={'identities_equal':True,'changed_records':sum(before[k]!=after[k] for k in before),
                             'complete_records_equal':before==after}
        margins={}
        for field,flag in [('setup','setup_timed'),('hold','hold_related')]:
            delta=[b[k][field]-a[k][field] for k in a if a[k][flag]]
            margins[field]={'improved':sum(v>0 for v in delta),'regressed':sum(v<0 for v in delta),
                            'unchanged':sum(v==0 for v in delta),'worst_regression_ps':min(delta),
                            'best_improvement_ps':max(delta)}
        result['comparisons'][name]={'timed_endpoint_identities_and_clock_constraints_equal':True,
                                    'margins':margins,'physical_metadata':metadata,
                                    'qualification':'fails setup and has incomplete physical coverage'}
result['accounting']={'two_existing_driver_route_seconds':str(charge),'total_cap':None,'excluded':'the prior both-root baseline is a reused reference; AX15/spreader/other route charges excluded; no additional full routes'}
result['evidence']='host-only full final-route native comparison; logical function/graph proof retained in proof-routed.json; no electrical RBF encoding or hardware acceptance'
result['worst_paths']={}
for mode in ('baseline','0','2'):
    directory=(root.parent/'reduction-balanced-20261022/route-both') if mode=='baseline' else root/('route-'+mode)
    timing=json.loads((directory/'timing.json').read_text());groups={}
    for p in timing['critical_paths']:
        if p['from']!=p['to'] or p['to']!='posedge clocks[0]':continue
        endpoint=p['path'][-1]['to']['cell'];group='CPU' if endpoint.startswith('system.machine.cpu.') else 'other'
        margin=p['max_delay']-sum(s['delay'] for s in p['path'])
        if group not in groups or margin<groups[group]['setup_ns']:
            totals=defaultdict(float)
            for segment in p['path']:totals[segment['type']]+=segment['delay']
            groups[group]={'setup_ns':margin,'path':p,'segment_totals_ns':dict(totals)}
    result['worst_paths'][mode]=groups
result['graph_proof_sha256']=sha(root/'proof-routed.json') if (root/'proof-routed.json').exists() else None
(root/'route-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'accounting':result['accounting'],'runs':{name:{k:v for k,v in run.items() if k in ('clock_pairs','setup_failures','related_hold_failures','unsupported_count')} for name,run in result['runs'].items()},'comparisons':result['comparisons'],'cpu_wns_ns':{name:v['CPU']['setup_ns'] for name,v in result['worst_paths'].items()}},indent=2))
listing=json.loads((root/'analysis.json').read_text());selections={c['candidate']:c for c in listing['candidates']}
reference=root.parent/'reduction-balanced-20261022/route-both'
base_graph=json.loads((reference/'routed.json').read_text())['modules']['top'];helper_base={n for n,c in base_graph['cells'].items() if c['type']=='MISTRAL_BUF'}
result['selected_edge_report_observations']={};result['routed_inventories']={}
for candidate in (0,2):
    chosen=selections[candidate];clone=chosen['source']+'$lut_driver_copy$'+chosen['sink']+'$'+chosen['port'];observations=[]
    for label,directory,source in [('baseline',reference,chosen['source']),('candidate',root/('route-'+str(candidate)),clone)]:
        timing=json.loads((directory/'timing.json').read_text());values={s['delay'] for p in timing['critical_paths'] for s in p['path'] if s['type']=='routing' and s['from']['cell']==source and s['to']['cell']==chosen['sink'] and s['to']['port']==chosen['port']}
        observations.append({'artifact':label,'reported_route_edge_delays_ns':sorted(values),'present_in_retained_critical_paths':bool(values)})
    result['selected_edge_report_observations'][str(candidate)]=observations
    graph=json.loads((root/('route-'+str(candidate))/'routed.json').read_text())['modules']['top'];helpers={n for n,c in graph['cells'].items() if c['type']=='MISTRAL_BUF'}
    result['routed_inventories'][str(candidate)]={'cells':len(graph['cells']),'net_names':len(graph['netnames']),'route_helpers':len(helpers),'helper_identities_equal_reference':helpers==helper_base,'missing_reference_helper_identities':sorted(helper_base-helpers),'additional_helper_identities':sorted(helpers-helper_base)}
result['reference_routed_inventory']={'cells':len(base_graph['cells']),'net_names':len(base_graph['netnames']),'route_helpers':len(helper_base)}
(root/'route-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
