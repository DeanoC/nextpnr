# Operand-driver placement diagnostic, 2026-10-22

The existing default-off driver-copy pass offers four guarded candidates for two other CPU adder inputs, but does not yet test the sole-consumer connection that takes 2.310 ns on the seed-1 both-reduction route. No compiler source changed; no route or hardware ran.

`inputs/manifest.json` freezes raw synthesis, QSF, SDC and routed guidance. `run.py` and each receipt retain the exact commands and cbb compiler binary hash. All runs use the seed-1 both-root recipe and `--no-route`, fresh ordinary pack/place. The native CLI forbids using saved placement with `--no-pack`/`--no-place` for this pass. The inherited `--router gpu` setting never executes the router in these runs.

## Findings

* `baseline` completes fresh placement. All 10,448 original non-buffer cell BELs match the final seed-1 both-reduction route, including the target outer ALUT5 at `MISTRAL_MCOMB.8.36.12` and arithmetic sink at `MISTRAL_COMB.9.35.25.A`.
* `list-routed` fails closed with `Stale remap report cell.` (return 125), before candidate discovery. Routing inserted helper cells absent at placement; the validator checks every relevant violated path. No path was filtered, helper removed, or guidance rewritten.
* `list-placed` accepts the complete matching native predicted timing report. It discovers five edges from 856 violated FF data/enable paths, performs 38 bounded native trials, and lists four qualified candidates. The routed 2.310 ns edge has **zero appearances** in this placed report, so its candidate eligibility and benefit remain untested. The same output endpoint has a different predicted worst path.
* Every byte of the listing's `placed.json` and `predicted-timing.json` equals its baseline. This retains all 10,448 cells, 13,597 net names/aliases, 19 top ports, parameters, logical/physical pin maps, placement, settings and clock identity after the trials.

| Candidate | Source LUT | Copy BEL | Predicted gain | Affected native endpoint/clock pairs |
| --- | --- | --- | --- | --- |
| 0 | CPU ALUT3, exact name in analysis.json | MISTRAL_MCOMB.6.35.18 | 314 ps | 180 |
| 1 | same ALUT3 | MISTRAL_MCOMB.6.35.19 | 314 ps | 180 |
| 2 | CPU ALUT5, exact name in analysis.json | MISTRAL_MCOMB.6.35.18 | 390 ps | 261 |
| 3 | same ALUT5 | MISTRAL_MCOMB.6.35.19 | 390 ps | 261 |

All four pass the existing improvement, affected endpoint, native clock and hold predicates. These numbers are placement estimates. To test one, rerun the exact `list-placed/receipt.json` command with `--remap-lut-driver-candidate N`, retaining the same guidance and binary; a later full route remains required. Candidate numbers depend on this exact recipe and guidance. No candidate has been applied here.

## Target and proof boundary

`analysis.json` records the actual routed target edge, complete source/sink cells, physical/logical pin map, every connected net's metadata, aliases, drivers and users, and the complete clock settings. The source is ALUT5 with LUT `0x8fffffff`, weak BEL ownership and one output user. Its five inputs and its output retain scalar raw-net identities; target source and sink have no keep/dont_touch attributes. A single-consumer output is allowed by discovery. These are static observations, not a native eligibility result: all cone timing, protection, successor/cache and placement guards must still execute for the target.

The pass requires an ordinary unrouted graph and validates the whole supplied violated-path report before mutation. It rejects protected cells/nets and protected source/destination LABs, uses isolated legal ALMs, preserves original owners, accounts for the copied driver's added input loads and the arithmetic carry successor, checks every affected endpoint and real clock pair, and restores probes exactly. There is no basis to bypass these predicates because the intended target did not appear in the placed report.

The useful compiler follow-up is a generic, explicitly selected source/sink diagnostic that runs those same native guards without treating a routed report as a current placed path, or a separately proven native projection of every route helper onto the original placed graph. The former is the smaller experiment. Simply dropping stale paths would conceal the target rather than qualify it. A sole-consumer move could avoid extra loads, but would require its own exact placement/cache rollback tests and full routed comparison.

`analyze.py` regenerates all comparisons and parses the complete trial ledger into `analysis.json`. The three CPU-only diagnostics consumed 169.99530051555485 seconds in total; they add **zero full-route charge**. No physical acceptance or timing-closure claim is made.
