import json
from pathlib import Path
p=Path('/home/deano/harnesses/worktrees/fes/silver-delta/out/dev/pcxt-board/out/native-feedback-20261022')
def inventory(name):
    e=json.loads((p/name/'endpoints.json').read_text())
    rows={}
    for endpoint,group in e['endpoints'].items():
        for r in group:
            key=(endpoint,tuple(r['launch']),tuple(r['capture']))
            assert key not in rows
            rows[key]=r
    return e,rows
a,ar=inventory('baseline');b,br=inventory('candidate')
assert ar.keys()==br.keys(),'endpoint identity mismatch; do not compare intersections'
result={'diagnostic_only':True,'complete':[a['complete'],b['complete']],'unsupported':[len(a['unsupported']),len(b['unsupported'])],'matched_rows':len(ar),'unchanged_clocks':a['clocks']==b['clocks'],'unchanged_io_constraints':a['io_constraints']==b['io_constraints']}
for field,flag in [('setup','setup_timed'),('hold','hold_related')]:
    changes=[]
    for key,x in ar.items():
        y=br[key]
        assert x[flag]==y[flag]
        if x[flag]:
            changes.append({'endpoint':json.loads(key[0]),'launch':key[1],'capture':key[2],'before_ps':x[field],'after_ps':y[field],'delta_ps':y[field]-x[field]})
    result[field]={'timed_rows':len(changes),'regressions':sum(x['delta_ps']<0 for x in changes),'improvements':sum(x['delta_ps']>0 for x in changes),'new_failures':sum(x['before_ps']>=0 and x['after_ps']<0 for x in changes),'resolved_failures':sum(x['before_ps']<0 and x['after_ps']>=0 for x in changes),'worst_regressions':sorted(changes,key=lambda x:x['delta_ps'])[:10],'best_improvements':sorted(changes,key=lambda x:-x['delta_ps'])[:10]}
(p/'endpoint-deltas.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:{a:b for a,b in v.items() if a not in ('worst_regressions','best_improvements')} if isinstance(v,dict) else v for k,v in result.items()},indent=2))
