#!/usr/bin/env python3
"""Frozen original PC/XT seed-1 HeAP matrix; native bounds and shared phase leases."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
from datetime import datetime,timezone
import hashlib,json,os,subprocess,time
R=Path(__file__).resolve().parent;TASK=R.parents[1];H=R.parent/'hard-block-windows-20261022';B=H/'route-windows-correct-overflow';MATRIX=[(300,2),(300,5),(1000,2),(1000,5),(2000,2)]
BIN='e1a121d0de5e496afd96328ed435e77c0b78f913fcfd3768283c01b12313deac';SYNTH='b4c44b2b66faaf8dd1019c6d8de119c55eecb49856158019ac8899a869de028b';COMMIT='a361eac060ebc25f9f70ef3bbc126814069d346b'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def now():return datetime.now(timezone.utc).isoformat()
def verify(b):
 assert b['binary_sha256']==BIN and sha(b['nextpnr_command'][0])==BIN
 assert b['source_identity']['result_commit']==COMMIT
 assert b['inputs']['--json']['sha256']==SYNTH
 for v in b['inputs'].values():assert sha(v['path'])==v['sha256']
 for n,h in b['source_identity']['source_files'].items():assert sha(H/'sources'/n)==h
 for n,h in b['artifacts'].items():assert sha(B/n)==h
 c=b['nextpnr_command'];assert c[c.index('--seed')+1]=='1' and c[c.index('--freq')+1]=='100.0'
 assert c[c.index('--placer-heap-timingweight')+1]=='2000' and c[c.index('--placer-heap-critexp')+1]=='5'
 assert '--placer-heap-hard-block-windows' in c and '--placer-heap-correct-spread' in c and c.count('--balance-reduction-root')==1
 assert '--arrival-pin-assignment' not in c and not any('newcost' in x or 'half-budget' in x for x in c)
def summarize(d):
 if not (d/'endpoints.json').exists():return {'complete_artifact':False}
 s=read(d/'endpoints.json');cohorts={};allrows=[]
 for ident,rows in s['endpoints'].items():
  for v in rows:
   allrows.append(v);key=json.dumps([v['launch'],v['capture']]);cohorts.setdefault(key,[]).append((json.loads(ident)[0],v))
 def metrics(rows):
  rows=list(rows);result={'rows':len(rows)}
  for name,flag in [('setup','setup_timed'),('hold','hold_related')]:
   vals=[v[name] for v in rows if v[flag]];result[name+'_wns_ps']=min(vals,default=None);result[name+'_failures']=sum(v<0 for v in vals)
  return result
 return {'complete_artifact':True,'schema':s['schema'],'complete':s['complete'],'final_analogue':s['final_analogue'],'unsupported':len(s['unsupported']),**metrics(allrows),'clock_pairs':[{'pair':json.loads(k),**metrics(v for _,v in rows),'cpu':metrics(v for n,v in rows if n.startswith('system.machine.cpu.'))} for k,rows in sorted(cohorts.items())]}
def status(d,name):
 with (d/name).open('w') as f:subprocess.run([str(TASK/'scripts/gpu-status')],cwd=TASK,stdout=f,stderr=subprocess.STDOUT,check=False)
def run(pair):
 w,c=pair;b=read(R/'reference-receipt.json');verify(b);cmd=b['nextpnr_command'][:];cmd[cmd.index('--placer-heap-timingweight')+1]=str(w);cmd[cmd.index('--placer-heap-critexp')+1]=str(c)
 expected=b['nextpnr_command'][:]
 for f in ('--placer-heap-timingweight','--placer-heap-critexp'):expected[expected.index(f)+1]=cmd[cmd.index(f)+1]
 assert expected==cmd
 d=R/f'w{w}-c{c}';d.mkdir(exist_ok=False)
 wrapped=[str(TASK/'scripts/gpu-run'),'--phase-lease','--owner','pcxt-timing','--label',f'pcxt-hard-block-w{w}-c{c}','--',*cmd]
 rec={'command':wrapped,'nextpnr_command':cmd,'seed':1,'weight':w,'criticality_exponent':c,'reference_receipt_sha256':sha(B/'receipt.json'),'source_identity':b['source_identity'],'binary_sha256':BIN,'inputs':b['inputs'],'changed_recipe':{'--placer-heap-timingweight':['2000',str(w)],'--placer-heap-critexp':['5',str(c)]},'env':{'NEXTPNR_REQUIRE_GPU':'1','GPU_LEASE_MAX_PER_OWNER':'2'},'limit':'native router iterations, no external timeout or GPU-job termination','route_cap':None,'evidence':'frozen-raw seed-1 diagnostic; no production/seal/hardware acceptance','start_utc':now()}
 status(d,'gpu-before.log');write(d/'launch.json',rec);print(json.dumps({'event':'start','weight':w,'critexp':c,'utc':rec['start_utc']}),flush=True)
 t=time.monotonic()
 try:
  with (d/'nextpnr.log').open('w') as log:rec['returncode']=subprocess.run(wrapped,cwd=d,env=dict(os.environ,**rec['env']),stdout=log,stderr=subprocess.STDOUT).returncode
 except BaseException as e:rec['exception']=repr(e);rec['returncode']=None
 rec['charged_seconds']=time.monotonic()-t;rec['end_utc']=now();status(d,'gpu-after.log')
 try:verify(b);rec['immutable_source_inputs_verified_after']=True
 except BaseException as e:rec['immutable_source_inputs_verified_after']=False;rec['verification_error']=repr(e)
 rec['artifacts']={p.name:sha(p) for p in sorted(d.iterdir()) if p.is_file() and p.name!='receipt.json'}
 write(d/'receipt.json',rec)
 try:summary=summarize(d)
 except BaseException as e:summary={'analysis_error':repr(e)}
 write(d/'summary.json',summary);print(json.dumps({'event':'finish','weight':w,'critexp':c,'returncode':rec['returncode'],'charged_seconds':rec['charged_seconds'],'summary':summary}),flush=True)
 return rec

def gate():
 p=R/'parallel-gate.json'
 if not p.exists():return False
 g=read(p);rec=read(g['receipt']);assert sha(g['receipt'])==g['sha256'] and 'returncode' in rec and 'charged_seconds' in rec
 return True

def main():
 b=read(B/'receipt.json');verify(b);assert not (R/'reference-receipt.json').exists();write(R/'reference-receipt.json',b)
 write(R/'plan.json',{'matrix':[{'weight':w,'critexp':c} for w,c in MATRIX],'reference':{'weight':2000,'critexp':5,'path':str(B),'receipt_sha256':sha(B/'receipt.json'),'rerun':False},'seed':1,'binary_sha256':BIN,'raw_synth_sha256':SYNTH,'compiler_commit':COMMIT,'concurrency':'one job until parent-confirmed ROM completion receipt, then at most two matrix jobs','no_new_seeds':True,'no_overall_route_cap':True,'script_sha256':sha(__file__)})
 pending=MATRIX[:];active={};done=[]
 with ThreadPoolExecutor(max_workers=2) as pool:
  while pending or active:
   limit=2 if gate() else 1
   while pending and len(active)<limit:
    pair=pending.pop(0);active[pool.submit(run,pair)]=pair
   completed,_=wait(active,timeout=5,return_when=FIRST_COMPLETED)
   for f in completed:
    pair=active.pop(f)
    try:done.append(f.result())
    except BaseException as e:
     write(R/'controller-error.json',{'pair':pair,'error':repr(e),'utc':now()});raise
   write(R/'controller-status.json',{'active':list(active.values()),'pending':pending,'completed':[(x['weight'],x['criticality_exponent']) for x in done],'parallel_limit':limit,'updated_utc':now()})
 print(json.dumps({'event':'matrix_complete','runs':len(done),'charge_seconds':sum(x['charged_seconds'] for x in done)}),flush=True)
if __name__=='__main__':main()
