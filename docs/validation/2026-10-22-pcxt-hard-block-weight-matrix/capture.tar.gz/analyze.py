#!/usr/bin/env python3
"""Account for every completed matrix route and full native endpoint inventory."""
from pathlib import Path
from collections import defaultdict,Counter
from decimal import Decimal
import argparse,hashlib,json,re
R=Path(__file__).resolve().parent;BASE=R/'reference-baseline' if (R/'reference-baseline').exists() else R.parent/'hard-block-windows-20261022/route-windows-correct-overflow';CASES=[(300,2),(300,5),(1000,2),(1000,5),(2000,2)]
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def rows(s):
 out={}
 for ident,vs in s['endpoints'].items():
  assert len(json.loads(ident))==2
  for v in vs:
   key=(ident,tuple(v['launch']),tuple(v['capture']));assert key not in out;out[key]=v
 return out

def metrics(vs):
 vs=list(vs);result={'rows':len(vs)}
 for m,f in [('setup','setup_timed'),('hold','hold_related')]:
  vals=[v[m] for v in vs if v[f]];result[m+'_wns_ps']=min(vals,default=None);result[m+'_failures']=sum(v<0 for v in vals);result[m+'_timed_rows']=len(vals)
 return result

def load(folder):
 rec=read(folder/'receipt.json')
 for n,h in rec['artifacts'].items():assert sha(folder/n)==h,(folder,n)
 for x in rec['inputs'].values():assert sha(R/'inputs'/Path(x['path']).name if args.archive_mode else Path(x['path']))==x['sha256']
 if args.archive_mode:assert rec['binary_sha256']=='e1a121d0de5e496afd96328ed435e77c0b78f913fcfd3768283c01b12313deac'
 else:assert sha(Path(rec['nextpnr_command'][0]))==rec['binary_sha256']
 names=('routed.json','timing.json','endpoints.json','diagnostic.rbf','nextpnr.log');assert all((folder/n).is_file() for n in names)
 s=read(folder/'endpoints.json');t=read(folder/'timing.json');assert s['final_analogue'] and t['timing_summary']['final_analogue_model'];rr=rows(s)
 pairs=defaultdict(list)
 for k,v in rr.items():pairs[k[1:]].append((k[0],v))
 log=(folder/'nextpnr.log').read_text();backend=[l.strip() for l in log.splitlines() if any(w in l for w in ('GPU router using device','backend hip:','backend cuda:','acquired GPU','phase lease','waited','waiting for'))]
 clocks=[]
 for k,vals in sorted(pairs.items()):clocks.append({'launch':k[0],'capture':k[1],**metrics(v for _,v in vals),'cpu_destinations':metrics(v for n,v in vals if json.loads(n)[0].startswith('system.machine.cpu.'))})
 return rec,s,rr,{'returncode':rec['returncode'],'charged_seconds':str(rec['charged_seconds']),'receipt_sha256':sha(folder/'receipt.json'),'artifacts':{n:sha(folder/n) for n in names},'schema':s['schema'],'complete':s['complete'],'final_analogue':s['final_analogue'],'unsupported_count':len(s['unsupported']),**metrics(rr.values()),'clock_pairs':clocks,'native_timing_clocks':t['timing_summary']['clocks'],'fmax':t['fmax'],'GPU_backend_log_records':backend}

def compare(bs,br,s,rr):
 old,new=set(br),set(rr);inventory={'equal':old==new,'removed':[list(k) for k in sorted(old-new)],'added':[list(k) for k in sorted(new-old)]}
 if old!=new:return {'endpoint_inventory':inventory,'acceptance':False,'reason':'full inventories differ; no common-only subset used'}
 windowdiff=[];deltas=[];delta_counts={m:Counter() for m in ('setup','hold')};negative={m:[] for m in ('setup','hold')}
 for k,x in sorted(br.items()):
  y=rr[k];static=lambda v:{p:z for p,z in v.items() if p not in ('setup','hold','min_path','max_path')}
  if static(x)!=static(y):windowdiff.append({'key':k,'baseline':static(x),'candidate':static(y)})
  row={'identity':json.loads(k[0]),'launch':k[1],'capture':k[2],'baseline':x,'candidate':y,'delta_ps':{m:(y[m]-x[m] if x[m] is not None and y[m] is not None else None) for m in ('setup','hold','min_path','max_path')}};deltas.append(row)
  for m,f in [('setup','setup_timed'),('hold','hold_related')]:
   if x[f] and y[f]:
    d=y[m]-x[m];delta_counts[m]['improved' if d>0 else 'regressed' if d<0 else 'unchanged']+=1
    if x[m]>=0 and y[m]<0:negative[m].append(row)
 contracts={k:{'equal':bs[k]==s[k],'baseline':bs[k],'candidate':s[k]} for k in bs if k!='endpoints'}
 for k,v in contracts.items():
  if isinstance(v['baseline'],dict) and isinstance(v['candidate'],dict):
   old,new=v['baseline'],v['candidate'];v['complete_record_identity_equal']=set(old)==set(new);v['removed_records']=sorted(set(old)-set(new));v['added_records']=sorted(set(new)-set(old));v['changed_record_identities']=[n for n in old if n in new and old[n]!=new[n]]
 return {'endpoint_inventory':inventory,'windows_flags_equal':not windowdiff,'windows_flags_differences':windowdiff,'complete_snapshot_metadata':contracts,'margin_delta_counts':delta_counts,'newly_failing_rows':negative,'every_endpoint_delta':deltas,'acceptance':False,'limits':'Timing/coverage diagnostic only; no physical acceptance. Every endpoint row and metadata record retained, not an intersection.'}

parser=argparse.ArgumentParser();parser.add_argument('--require-complete',action='store_true');parser.add_argument('--archive-mode',action='store_true',help='verify included input bytes and recorded binary identity; executable is not embedded');args=parser.parse_args()
brec,bs,br,baseline=load(BASE);runs={};charge=Decimal(0);pending=[];allcomparisons={}
for w,c in CASES:
 name=f'w{w}-c{c}';d=R/name
 if not (d/'receipt.json').exists():pending.append(name);continue
 rec,s,rr,summary=load(d);assert rec['binary_sha256']==brec['binary_sha256'];assert rec['inputs']==brec['inputs'];assert rec['source_identity']==brec['source_identity'];assert rec['immutable_source_inputs_verified_after'];assert rec['seed']==1
 expected=brec['nextpnr_command'][:]
 expected[expected.index('--placer-heap-timingweight')+1]=str(w);expected[expected.index('--placer-heap-critexp')+1]=str(c);assert expected==rec['nextpnr_command']
 comp=compare(bs,br,s,rr);(d/'complete-comparison.json').write_text(json.dumps(comp,indent=2)+'\n');summary.update(weight=w,criticality_exponent=c,full_identity_inventory_equal=comp['endpoint_inventory']['equal'],windows_flags_equal=comp.get('windows_flags_equal',False),metadata_equal={k:v['equal'] for k,v in comp.get('complete_snapshot_metadata',{}).items()},comparison_sha256=sha(d/'complete-comparison.json'));runs[name]=summary;charge+=Decimal(str(rec['charged_seconds']))
if args.require_complete:assert not pending,pending
wrapper=read(R/'launcher-sandbox-denied/failure-note.json')
result={'reference':baseline,'runs':runs,'pending':pending,'accounting':{'full_route_count':len(runs),'new_full_route_seconds':str(charge),'reference_already_charged':True,'wrapper_only_failures':wrapper,'no_overall_route_cap':True},'evidence':'Complete frozen-original seed-1 HeAP matrix; only weight/critexp vary. Not a sealed producer or physical qualification.'}
(R/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
compact={n:{k:v for k,v in x.items() if k in ('weight','criticality_exponent','returncode','setup_failures','setup_wns_ps','hold_failures','hold_wns_ps','complete','unsupported_count','full_identity_inventory_equal','windows_flags_equal','charged_seconds','clock_pairs')} for n,x in runs.items()};print(json.dumps({'runs':compact,'pending':pending,'accounting':result['accounting']},indent=2))
