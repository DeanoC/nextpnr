#!/usr/bin/env python3
"""Freeze the requested five routes and original reference, without tool binaries."""
from pathlib import Path
import hashlib,json,shutil
R=Path(__file__).resolve().parent;H=R.parent/'hard-block-windows-20261022';B=H/'route-windows-correct-overflow';D=R/'capture-source';copies={}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def cp(src,name):
 dst=D/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert sha(src)==sha(dst);copies[str(name)]={'source':str(src),'sha256':sha(dst),'size':dst.stat().st_size}
a=json.loads((R/'analysis.json').read_text());assert not a['pending'] and len(a['runs'])==5
status=json.loads((R/'controller-status.json').read_text());assert not status['active'] and not status['pending'] and len(status['completed'])==5
D.mkdir(exist_ok=False)
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in ('.py','.md','.json','.jsonl','.log'):cp(p,Path(p.name))
for name in a['runs']:
 rec=json.loads((R/name/'receipt.json').read_text())
 for n,h in rec['artifacts'].items():assert sha(R/name/n)==h
 for p in sorted((R/name).iterdir()):
  if p.is_file():cp(p,p.relative_to(R))
for p in sorted((R/'launcher-sandbox-denied').rglob('*')):
 if p.is_file():cp(p,p.relative_to(R))
for p in sorted(B.iterdir()):
 if p.is_file():cp(p,Path('reference-baseline')/p.name)
rec=json.loads((R/'reference-receipt.json').read_text());assert sha(rec['nextpnr_command'][0])==rec['binary_sha256']
for info in rec['inputs'].values():
 p=Path(info['path']);assert sha(p)==info['sha256'];cp(p,Path('inputs')/p.name)
for n,h in rec['source_identity']['source_files'].items():
 p=H/'sources'/n;assert sha(p)==h;cp(p,Path('compiler-source/sources')/n)
for n in ('source-identity.json','hard-block-source.diff','hard-block-build-frozen.log','hard-block-native-frozen.log','hard-block-ctest.log'):cp(H/n,Path('compiler-source')/n)
gate=json.loads((R/'parallel-gate.json').read_text());assert sha(gate['receipt'])==gate['sha256'];cp(Path(gate['receipt']),Path('gate-completion-receipt.json'))
cp(Path('/tmp/pcxt-capture.py'),Path('capture.py'))
(D/'collection.json').write_text(json.dumps({'files':len(copies),'copies':copies,'scope':'Five original-source HeAP parameter routes and their full reference; all artifacts and native row ledgers, queue-inclusive charges, separately classified wrapper failures, frozen source/input bindings. No added seeds, source change, hardware or timing qualification.'},indent=2)+'\n');print('collected',len(copies),'files')
