#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;SOURCE=R.parent/'add-op0-20261022';D=R/'capture-source';D.mkdir(exist_ok=False);copies={}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def cp(src,name):
 dst=D/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert sha(src)==sha(dst);copies[str(name)]={'source':str(src),'sha256':sha(dst),'size':dst.stat().st_size}
for src in sorted(R.iterdir()):
 if src.is_file() and src.suffix in ('.py','.md','.json','.log'):cp(src,Path(src.name))
for mode in ('baseline','candidate'):
 for src in sorted((SOURCE/('route-balanced-'+mode)).iterdir()):
  if src.is_file():cp(src,Path('routes')/mode/src.name)
 for src in sorted((R/('prepare-route-'+mode)).iterdir()):
  if src.is_file():cp(src,src.relative_to(R))
for mode in ('control','balanced'):
 for src in sorted((R/('native-baseline-'+mode)).iterdir()):
  if src.is_file():cp(src,src.relative_to(R))
cp(SOURCE/'route-balanced.py',Path('route-balanced.py'))
for name in ('add-op0-committed-test-changed.log','add-op0-committed-check.log'):cp(R.parent/name,Path('validation')/name)
cp(Path('/tmp/pcxt-capture.py'),Path('capture.py'))
(D/'collection.json').write_text(json.dumps({'files':len(copies),'copies':copies,'scope':'Only complete balanced ADD routes, CPU-only reconstruction/native rewrite proofs and final committed-source check logs. Prior source capture reused by references.json; later arrival-pin/same-edge experiments excluded.'},indent=2)+'\n');print('collected',len(copies),'files')
