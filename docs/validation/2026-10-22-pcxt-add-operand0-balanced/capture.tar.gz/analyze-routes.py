#!/usr/bin/env python3
from pathlib import Path
from collections import defaultdict,Counter
from decimal import Decimal
import json,hashlib
R=Path(__file__).resolve().parent;SOURCE=R.parent/'add-op0-20261022'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
result={'runs':{},'comparison':{},'evidence':'Final analogue native routed diagnostics; both complete endpoint artifacts retained. Resynthesis changes endpoint identities; no common-only endpoint subset stands in for qualification.'};snaps={};rows={};charge=Decimal(0)
for mode in ('baseline','candidate'):
 d=(R/'routes'/mode) if (R/'routes'/mode).exists() else SOURCE/('route-balanced-'+mode);rec=read(d/'receipt.json');t=read(d/'timing.json');s=read(d/'endpoints.json');snaps[mode]=s
 for n,h in rec['artifacts'].items():assert sha(d/n)==h,(mode,n)
 for filename,v in rec['inputs'].items():assert sha(SOURCE/mode/'synthesis'/filename)==v['sha256']
 assert sha(SOURCE/mode/'receipt.json')==rec['synthesis_receipt_sha256']
 assert sha(SOURCE/'comparison.json')==rec['comparison_sha256']
 assert t['timing_summary']['final_analogue_model'] and s['final_analogue']
 rr={};group=defaultdict(list)
 for key,vs in s['endpoints'].items():
  for v in vs:
   k=(key,tuple(v['launch']),tuple(v['capture']));assert k not in rr;rr[k]=v;group[k[1:]].append((key,v))
 rows[mode]=rr;pairs=[]
 for (launch,capture),vs in sorted(group.items()):
  cpu=[v for k,v in vs if json.loads(k)[0].startswith('system.machine.cpu.')]
  pairs.append({'launch':launch,'capture':capture,'rows':len(vs),'setup_wns_ps':min((v['setup'] for k,v in vs if v['setup_timed']),default=None),'hold_wns_ps':min((v['hold'] for k,v in vs if v['hold_related']),default=None),'setup_failures':sum(v['setup_timed'] and v['setup']<0 for k,v in vs),'hold_failures':sum(v['hold_related'] and v['hold']<0 for k,v in vs),'cpu_destination_rows':len(cpu),'cpu_destination_setup_wns_ps':min((v['setup'] for v in cpu if v['setup_timed']),default=None)})
 worst={}
 for p in t['critical_paths']:
  if not p['path']:continue
  endpoint=p['path'][-1]['to']['cell'];key=' -> '.join((p['from'],p['to']))+(' CPU' if endpoint.startswith('system.machine.cpu.') else ' other');slack=p['max_delay']-sum(x['delay'] for x in p['path'])
  if key not in worst or slack<worst[key]['setup_ns']:
   totals=defaultdict(float)
   for x in p['path']:totals[x['type']]+=x['delay']
   worst[key]={'setup_ns':slack,'path':p,'segment_totals_ns':dict(totals)}
 g=read(d/'routed.json')['modules']['top'];charge+=Decimal(str(rec['charged_seconds']))
 result['runs'][mode]={'returncode':rec['returncode'],'charged_seconds':rec['charged_seconds'],'artifact_hashes':rec['artifacts'],'fes_commit':rec['fes_commit'],'compiler_sha256':rec['compiler']['binary_sha256'],'clocks':t['timing_summary']['clocks'],'clock_pairs':pairs,'endpoint_rows':len(rr),'endpoint_identities':len(s['endpoints']),'schema':s['schema'],'complete':s['complete'],'unsupported_count':len(s['unsupported']),'setup_failures':sum(v['setup_timed'] and v['setup']<0 for v in rr.values()),'hold_failures':sum(v['hold_related'] and v['hold']<0 for v in rr.values()),'primitive_clocks':s['primitive_clocks'],'physical_obligations':s['physical_obligations'],'routed_graph_counts':{'cells':len(g['cells']),'nets':len(g['netnames']),'ports':len(g['ports']),'types':dict(Counter(c['type'] for c in g['cells'].values()))},'worst_reported_paths':worst}
a,b=snaps['baseline'],snaps['candidate'];ra,rb=rows['baseline'],rows['candidate'];result['comparison']['endpoint_key_inventory']={'removed':sorted(set(ra)-set(rb)),'added':sorted(set(rb)-set(ra)),'retained':len(set(ra)&set(rb)),'interpretation':'Lists describe resynthesis identities; common generated cell names are not presumed equivalent state or used for a timing acceptance delta.'}
result['comparison']['contract_metadata']={k:{'equal':a[k]==b[k],'baseline':a[k],'candidate':b[k]} for k in ['clocks','forwarded_clocks','io_constraints','output_contracts','physical_obligations','primitive_clocks','registered_contracts','reset_contracts','unregistered_contracts','unsupported']}
result['comparison']['metadata_inventory']={k:{'before_count':len(a[k]),'after_count':len(b[k]),'complete_records_equal':a[k]==b[k],'removed_keys':sorted(set(a[k])-set(b[k])),'added_keys':sorted(set(b[k])-set(a[k]))} for k in ['constant_outputs','static_endpoints','unsupported_details']}
result['accounting']={'two_existing_balanced_add_route_seconds':str(charge),'total_cap':None,'excluded':'Synthesis and CPU-only reconstruction are not full-route charges; all previous and subsequent balanced/other routes excluded.'}
result['conclusion']='Both runs fail setup and endpoint coverage. Balanced ADD operand0 candidate worsens system, CPU and microcode path margins for this seed/recipe; it is not a timing winner. Hold has no negative related rows. Host diagnostic only; no full-board sequential, electrical/RBF or hardware acceptance.'
(R/'route-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'accounting':result['accounting'],'runs':{m:{k:v for k,v in r.items() if k in ['clock_pairs','endpoint_rows','endpoint_identities','setup_failures','hold_failures','unsupported_count','complete']} for m,r in result['runs'].items()},'endpoint_delta_counts':{k:len(v) if isinstance(v,list) else v for k,v in result['comparison']['endpoint_key_inventory'].items()},'contracts_equal':{k:v['equal'] for k,v in result['comparison']['contract_metadata'].items()}},indent=2))
