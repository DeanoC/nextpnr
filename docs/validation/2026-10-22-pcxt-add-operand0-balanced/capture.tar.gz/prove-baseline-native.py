#!/usr/bin/env python3
"""Independent exported-graph and exhaustive root proof; no compiler implementation helpers."""
from pathlib import Path
from collections import defaultdict
import hashlib,json,sys
base=Path(__file__).resolve().parent;SOURCE=base.parent/'add-op0-20261022'
mode='overflow17'
paths=[base/'native-baseline-control/export.json',base/'native-baseline-balanced/export.json']
documents=[json.loads(p.read_text()) for p in paths]
assert set(documents[0])==set(documents[1])=={'creator','modules'}
assert documents[0]['creator']==documents[1]['creator']
assert set(documents[0]['modules'])==set(documents[1]['modules'])=={'top'}
modules=[d['modules']['top'] for d in documents]
reference=json.loads((base/'native-baseline-control/receipt.json').read_text()); selected=json.loads((base/'native-baseline-balanced/receipt.json').read_text()); manifest={'binary_sha256':reference['binary_sha256'],'inputs':reference['inputs'],'roots':{'overflow17':selected['selected_roots'][0]}}
receipts=[json.loads((path.parent/'receipt.json').read_text()) for path in paths]
for receipt in receipts:
 assert receipt['returncode']==0 and receipt['binary_unchanged']
 assert receipt['binary_sha256']==manifest['binary_sha256']
 assert receipt['inputs']==manifest['inputs']
assert not receipts[0]['selected_roots']
selected=set(receipts[1]['selected_roots']); roots=manifest['roots']
assert selected==({roots['overflow17']} if mode=='overflow17' else set(roots.values()))
def sha(path):
 with path.open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()
for path,receipt in zip(paths,receipts):assert sha(path)==receipt['export_sha256']
for filename,entry in manifest['inputs'].items():assert sha(SOURCE/'baseline/synthesis'/filename)==entry['sha256']
# Net numbers are serialization-local. A complete alias partition binds identity.
aliases=[]
for module in modules:
 groups=defaultdict(list)
 for name,net in module['netnames'].items():
  for i,bit in enumerate(net['bits']):
   if isinstance(bit,int):groups[bit].append((name,i))
 aliases.append({bit:tuple(sorted(names)) for bit,names in groups.items()})
assert set(aliases[0].values())==set(aliases[1].values()),'alias partitions changed'
def canonical(bit,index):return aliases[index][bit] if isinstance(bit,int) else bit
connections=[];drivers=[];users=[];public=[]
for index,module in enumerate(modules):
 connection={name:{port:tuple(canonical(bit,index) for bit in bits) for port,bits in cell['connections'].items()}
             for name,cell in module['cells'].items()}
 driver={};consumer=defaultdict(list)
 for name,cell in module['cells'].items():
  for port,signals in connection[name].items():
   for offset,signal in enumerate(signals):
    if cell['port_directions'][port]=='output':
     assert signal not in driver,('multiple drivers',name,port)
     driver[signal]=(name,port,offset)
    else:consumer[signal].append((name,port,offset))
 connections.append(connection);drivers.append(driver);users.append(consumer)
 public.append({canonical(bit,index) for port in module['ports'].values() for bit in port['bits']})
assert set(modules[0])==set(modules[1])
for key in set(modules[0])-{'cells','netnames','ports'}:assert modules[0][key]==modules[1][key],key
assert set(modules[0]['netnames'])==set(modules[1]['netnames'])
for name in modules[0]['netnames']:
 before,after=[module['netnames'][name] for module in modules]
 assert {k:v for k,v in before.items() if k!='bits'}=={k:v for k,v in after.items() if k!='bits'},('net metadata',name)
 assert tuple(canonical(bit,0) for bit in before['bits'])==tuple(canonical(bit,1) for bit in after['bits']),('net bits',name)
assert set(modules[0]['ports'])==set(modules[1]['ports'])
for name in modules[0]['ports']:
 before,after=[module['ports'][name] for module in modules]
 assert {k:v for k,v in before.items() if k!='bits'}=={k:v for k,v in after.items() if k!='bits'},('port metadata',name)
 assert tuple(canonical(bit,0) for bit in before['bits'])==tuple(canonical(bit,1) for bit in after['bits']),('port bits',name)

def cone(index,root):
 module=modules[index];seen=set();active=set();frontier=set();ordered=[]
 def descend(signal):
  assert signal in drivers[index],('undriven cone input',signal)
  name,port,offset=drivers[index][signal];cell=module['cells'][name]
  if cell['type'] not in ['MISTRAL_ALUT'+str(w) for w in range(2,7)]:
   assert cell['type']=='MISTRAL_FF' and port=='Q' and offset==0
   frontier.add(signal);return
  assert signal not in active,'cycle'
  assert name not in seen,'shared intermediate or repeated selected net'
  seen.add(name);active.add(signal)
  width=int(cell['type'][-1]);expected=set('ABCDEF'[:width])|{'Q'}
  assert port=='Q' and offset==0 and set(cell['connections'])==expected
  assert set(cell['parameters'])=={'LUT'}
  table=cell['parameters']['LUT'];assert len(table)==1<<width and set(table)<={'0','1'}
  assert all(len(bits)==1 for bits in cell['connections'].values())
  assert cell['port_directions']=={**{p:'input' for p in 'ABCDEF'[:width]},'Q':'output'}
  assert not any(p in cell.get('attributes',{}) for p in ('keep','dont_touch','NEXTPNR_BEL','FES_PINMAP_V1'))
  if name!=root:
   assert len(users[index][signal])==1 and signal not in public[index],('observable private output',name)
  for pin in 'ABCDEF'[:width]:descend(connections[index][name][pin][0])
  active.remove(signal);ordered.append(name)
 descend(connections[index][root]['Q'][0])
 assert len(seen)==4
 for name in seen-{root}:
  assert all(user[0] in seen for user in users[index][connections[index][name]['Q'][0]])
 return {'cells':seen,'frontier':frontier,'order':ordered}
cones={label:[cone(i,root) for i in range(2)] for label,root in roots.items()}
allowed=set()
for label,root in roots.items():
 before,after=cones[label]
 assert before['cells']==after['cells'] and before['frontier']==after['frontier']
 if root in selected:allowed.update(before['cells'])
assert len(allowed)==4*len(selected)
assert set(modules[0]['cells'])==set(modules[1]['cells'])
changed=[]
for name in modules[0]['cells']:
 before,after=[module['cells'][name] for module in modules]
 if name not in allowed:
  assert {k:v for k,v in before.items() if k!='connections'}=={k:v for k,v in after.items() if k!='connections'},('outside cell',name)
  assert connections[0][name]==connections[1][name],('outside connections',name)
 else:
  assert {k:v for k,v in before.items() if k not in ('type','parameters','port_directions','connections')}=={k:v for k,v in after.items() if k not in ('type','parameters','port_directions','connections')},('selected cell metadata',name)
  assert connections[0][name]['Q']==connections[1][name]['Q'],('selected output identity',name)
  if before!=after or connections[0][name]!=connections[1][name]:changed.append(name)
assert set(drivers[0])==set(drivers[1]) and drivers[0]==drivers[1],'driver identities changed'

proofs={}
for label,root in roots.items():
 frontier=sorted(cones[label][0]['frontier']);count=len(frontier)
 assert count==(17 if label=='overflow17' else 16)
 programs=[]
 for index in range(2):
  slots={signal:bit for bit,signal in enumerate(frontier)};program=[]
  for name in cones[label][index]['order']:
   cell=modules[index]['cells'][name];width=int(cell['type'][-1])
   program.append((int(cell['parameters']['LUT'],2),[slots[connections[index][name][pin][0]] for pin in 'ABCDEF'[:width]]))
   slots[connections[index][name]['Q'][0]]=count+len(program)-1
  assert cones[label][index]['order'][-1]==root
  programs.append(program)
 true_assignments=0
 for assignment in range(1<<count):
  outputs=[]
  for program in programs:
   values=[bool((assignment>>bit)&1) for bit in range(count)]
   for mask,inputs in program:
    row=sum(int(values[source])<<pin for pin,source in enumerate(inputs))
    values.append(bool((mask>>row)&1))
   outputs.append(values[-1])
  assert outputs[0]==outputs[1],(label,assignment)
  # Separately bind the actual all-zero conjunction, not just paired equality.
  assert outputs[0]==(assignment==0),(label,'unexpected original function',assignment)
  true_assignments+=int(outputs[0])
 proofs[label]={'root':root,'selected':root in selected,'cells':sorted(cones[label][0]['cells']),
                'literal_count':count,'assignments':1<<count,'equivalent':True,'true_assignments':true_assignments,
                'function':'all canonical FF-Q literals zero','private_outputs_single_internal_user':True,
                'root_output_and_external_consumers_preserved':True,
                'before_types':{name:modules[0]['cells'][name]['type'] for name in sorted(cones[label][0]['cells'])},
                'after_types':{name:modules[1]['cells'][name]['type'] for name in sorted(cones[label][1]['cells'])}}
result={'baseline':str(paths[0]),'candidate':str(paths[1]),'baseline_sha256':sha(paths[0]),'candidate_sha256':sha(paths[1]),
        'binary_sha256':manifest['binary_sha256'],'source_synth_sha256':manifest['inputs']['synth.json']['sha256'],
        'selected_roots':sorted(selected),'cell_count':len(modules[0]['cells']),'outside_cells_exactly_preserved':len(modules[0]['cells'])-len(allowed),
        'net_alias_count':len(modules[0]['netnames']),'net_identity_count':len(aliases[0]),'top_port_count':len(modules[0]['ports']),
        'changed_cells':sorted(changed),'no_cells_or_nets_added_or_retired':True,'all_output_driver_identities_unchanged':True,
        'complete_alias_partition_net_metadata_top_ports_settings_attributes_unchanged':True,
        'outside_cell_functions_connections_attributes_and_polarities_unchanged':True,
        'roots':proofs,'evidence':'independent exhaustive root truth plus complete exported-graph identity proof; no timing or hardware acceptance'}
(base/'baseline-native-proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ('roots','changed_cells')},indent=2))
