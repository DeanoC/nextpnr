#!/usr/bin/env python3
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;SOURCE=R.parent/'add-op0-20261022'
def read(p):return json.loads(p.read_text())
raw=read(SOURCE/'baseline/synthesis/synth.json')['modules']['top'];native=read(R/'native-baseline-control/export.json')['modules']['top'];proof=read(R/'baseline-native-proof.json');root=proof['selected_roots'][0];nodes=proof['roots']['overflow17']['cells'];assert len(nodes)==4
old=read(SOURCE/'overflow-audit.json');assert root==old['root'] and set(nodes)==set(old['runs']['baseline']['four_cells'])
driver={b:(n,p,i) for n,c in raw['cells'].items() for p,bs in c['connections'].items() if c['port_directions'][p]=='output' for i,b in enumerate(bs) if isinstance(b,int)}
P='system.machine.cpu.cpu.u_eu_core.';leaves=[(P+'eu_register_dx',i,b) for i,b in enumerate(raw['netnames'][P+'eu_register_dx']['bits'])]+[(P+'eu_register_ax',15,raw['netnames'][P+'eu_register_ax']['bits'][15])];ids={driver[b] for _,_,b in leaves};assert len(ids)==17
inputs=set()
for n in nodes:
 a,b=raw['cells'][n],native['cells'][n]
 for k in ('type','parameters','port_directions'):assert a[k]==b[k]
 for p,bs in a['connections'].items():
  assert len(bs)==1;owner,pin,i=driver[bs[0]];assert b['connections'][p]==[native['cells'][owner]['connections'][pin][i]]
  if owner not in nodes:assert raw['cells'][owner]['type']=='MISTRAL_FF';inputs.add((owner,pin,i))
assert inputs==ids
result={'root':root,'four_actual_raw_cell_masks_types_directions_connections_equal_native_control':True,'literal_bindings':[{'rtl_alias':[n,i],'driver':driver[b]} for n,i,b in leaves],'native_rewrite_proof_sha256':hashlib.sha256((R/'baseline-native-proof.json').read_bytes()).hexdigest(),'prior_raw_literal_audit_sha256':hashlib.sha256((SOURCE/'overflow-audit.json').read_bytes()).hexdigest(),'raw_synth_sha256':hashlib.sha256((SOURCE/'baseline/synthesis/synth.json').read_bytes()).hexdigest(),'evidence':'Exact emitted native root frontier is actual DX[15:0]/AX[15], bound by raw driver identities; complete native rewrite proof is separate.'}
(R/'baseline-overflow-binding.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: four raw/native LUTs, exact 17 DX/AX FF-Q leaves')
