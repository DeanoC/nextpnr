#!/usr/bin/env python3
from pathlib import Path
import json,hashlib
from collections import defaultdict
R=Path(__file__).resolve().parent;SOURCE=R.parent/'add-op0-20261022'
def read(p):return json.loads(p.read_text())
def rows(s):
 r={}
 for n,vs in s['endpoints'].items():
  for v in vs:k=(n,tuple(v['launch']),tuple(v['capture']));assert k not in r;r[k]=v
 return r
def norm(cmd):
 c=cmd[:]
 if '--balance-reduction-root' in c:i=c.index('--balance-reduction-root');del c[i:i+2]
 return c
result={}
for mode in ('baseline','candidate'):
 dirs=[SOURCE/('route-'+mode),(R/'routes'/mode) if (R/'routes'/mode).exists() else SOURCE/('route-balanced-'+mode)];receipts=[read(d/'receipt.json') for d in dirs];assert norm(receipts[0]['nextpnr_command'])==norm(receipts[1]['nextpnr_command']);assert receipts[0]['inputs']==receipts[1]['inputs'];assert receipts[0]['compiler']==receipts[1]['compiler']
 snapshots=[read(d/'endpoints.json') for d in dirs];a,b=[rows(s) for s in snapshots];assert set(a)==set(b)
 for k in a:
  for f in ('setup_timed','hold_related','setup_window'):assert a[k][f]==b[k][f],(mode,k,f)
 fields=('clocks','forwarded_clocks','io_constraints','output_contracts','physical_obligations','primitive_clocks','registered_contracts','reset_contracts','unregistered_contracts','unsupported')
 assert all(snapshots[0][f]==snapshots[1][f] for f in fields)
 margins={}
 for f,flag in [('setup','setup_timed'),('hold','hold_related')]:
  delta=[b[k][f]-a[k][f] for k in a if a[k][flag]];margins[f]={'rows':len(delta),'improved':sum(x>0 for x in delta),'regressed':sum(x<0 for x in delta),'unchanged':sum(x==0 for x in delta),'worst_delta_ps':min(delta),'best_delta_ps':max(delta),'before_failures':sum(a[k][flag] and a[k][f]<0 for k in a),'after_failures':sum(b[k][flag] and b[k][f]<0 for k in b)}
 result[mode]={'same_raw_input_binary_recipe_except_explicit_root':True,'all_endpoint_keys_and_launch_capture_windows_exact':True,'full_endpoint_rows':len(a),'contracts_and_unsupported_exact':True,'margins':margins,'complete':[s['complete'] for s in snapshots],'evidence':'Complete endpoint-set comparison within one committed source build. No cross-resynthesis common-only subset, no timing acceptance claim.'}
(R/'within-build-balancing-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
