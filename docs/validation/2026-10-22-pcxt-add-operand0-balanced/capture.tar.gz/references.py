#!/usr/bin/env python3
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;S=R.parent/'add-op0-20261022';prior=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr/docs/validation/2026-10-22-pcxt-add-operand0')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
expected='52004db16988c99fb4abc13e257126ae8049178a224a5210a9c7ae53cd51a4b7';assert sha(prior/'capture.tar.gz')==expected;manifest=json.loads((prior/'manifest.json').read_text());deps=['comparison.json','committed-source-review.json','source-change.patch','overflow-audit.json','overflow-native-proof.json','overflow-selection-proof.json','mapped-proof.json','selector-proof.json','cpu-generated-ff-proof.json']
for mode in ('baseline','candidate'):
 deps += [f'{mode}/{n}' for n in ('source.tar.gz','snapshot.json','inputs.json','receipt.json')]
 deps += [f'{mode}/synthesis/{n}' for n in ('synth.json','constraints.qsf','clocks.sdc')]
 deps += [f'route-{mode}/{n}' for n in ('receipt.json','endpoints.json','timing.json')]
records={}
for name in deps:
 assert name in manifest and sha(S/name)==manifest[name]['sha256'],name
 records[name]=manifest[name]
result={'prior_capture':str(prior/'capture.tar.gz'),'prior_capture_sha256':expected,'prior_manifest_sha256':sha(prior/'manifest.json'),'prior_capture_commit':'a63f27f1','metadata_followup_commit':'ffbc638c','required_sibling_directory':'add-op0-20261022','reused_members_verified':records,'scope':'Immutable prior source/inputs/raw semantic proofs and bare reference reports are intentionally reused; no unfinished balanced artifacts enter the prior archive.'}
(R/'references.json').write_text(json.dumps(result,indent=2)+'\n');print('verified dependencies',len(records))
