#!/usr/bin/env python3
"""Matched full-board routes with the independently proved overflow reductions."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent
TASK = ROOT.parent.parent
POLICY = ROOT.parent / 'hard-block-windows-20261022'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def run(mode):
    synthesis = ROOT / mode / 'synthesis'
    source_receipt = read(ROOT / mode / 'receipt.json')
    assert source_receipt['returncode'] == 0
    assert comparison['runs'][mode]['synth_sha256'] == sha(synthesis / 'synth.json')
    for name, digest in source_receipt['artifacts'].items():
        assert sha(synthesis / name) == digest, (mode, name)
    command = read(POLICY / 'prepare-windows-correct/receipt.json')['nextpnr_command'][:]
    command.remove('--no-route')
    command.remove('--debug-placer')
    for flag, name in (('--json', 'synth.json'), ('--qsf', 'constraints.qsf'),
                       ('--sdc', 'clocks.sdc')):
        command[command.index(flag) + 1] = str(synthesis / name)
    command[command.index('--write') + 1] = 'routed.json'
    command[command.index('--report') + 1] = 'timing.json'
    command += ['--rbf', 'diagnostic.rbf', '--compress-rbf',
                '--routed-endpoints', 'endpoints.json']
    assert sha(Path(command[0])) == compiler['binary_sha256']
    proof = read(ROOT / 'overflow-native-proof.json')
    audit = read(ROOT / 'overflow-audit.json')
    if mode == 'candidate':
        assert proof['source_synth_sha256'] == sha(synthesis / 'synth.json')
        assert proof['binary_sha256'] == compiler['binary_sha256']
        assert proof['no_cells_or_nets_added_or_retired']
        assert proof['outside_cell_functions_connections_attributes_and_polarities_unchanged']
        roots = proof['selected_roots']
    else:
        assert audit['runs']['baseline']['synth_sha256'] == sha(synthesis / 'synth.json')
        assert audit['runs']['baseline']['root_present']
        roots = [audit['root']]
    assert len(roots) == 1
    command += ['--balance-reduction-root', roots[0]]
    wrapped = [str(TASK / 'scripts/gpu-run'), '--phase-lease', '--owner',
               'pcxt-timing', '--label', 'pcxt-add-op0-balanced-' + mode, '--', *command]
    target = ROOT / ('route-balanced-' + mode)
    target.mkdir(exist_ok=False)
    receipt = {
        'command': wrapped, 'nextpnr_command': command,
        'fes_commit': source_receipt['commit'], 'compiler': compiler,
        'synthesis_receipt_sha256': sha(ROOT / mode / 'receipt.json'),
        'comparison_sha256': sha(ROOT / 'comparison.json'),
        'overflow_native_proof_sha256': sha(ROOT / 'overflow-native-proof.json'),
        'overflow_audit_sha256': sha(ROOT / 'overflow-audit.json'),
        'inputs': {name: {'path': str(synthesis / name), 'sha256': sha(synthesis / name)}
                   for name in ('synth.json', 'constraints.qsf', 'clocks.sdc')},
        'env': {'NEXTPNR_REQUIRE_GPU': '1', 'GPU_LEASE_MAX_PER_OWNER': '2'},
        'limit': 'native router iteration bound; no external GPU-job termination',
        'evidence': 'leased GPU fresh synthesis full route diagnostic; no seal or hardware acceptance',
    }
    start = time.monotonic()
    with (target / 'nextpnr.log').open('w') as log:
        receipt['returncode'] = subprocess.run(
            wrapped, cwd=target, env=dict(os.environ, **receipt['env']),
            stdout=log, stderr=subprocess.STDOUT).returncode
    receipt['charged_seconds'] = time.monotonic() - start
    for info in receipt['inputs'].values():
        assert sha(Path(info['path'])) == info['sha256']
    assert sha(Path(command[0])) == compiler['binary_sha256']
    receipt['artifacts'] = {path.name: sha(path) for path in sorted(target.iterdir())
                            if path.is_file()}
    (target / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(mode, receipt['returncode'], receipt['charged_seconds'], flush=True)


if __name__ == '__main__':
    compiler = read(POLICY / 'source-identity.json')
    comparison = read(ROOT / 'comparison.json')
    assert comparison['clock_primitive_types_parameters_equal']
    assert comparison['inputs']['all_yosys_and_assembler_linker_identities_equal']
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(run, ('baseline', 'candidate')))
