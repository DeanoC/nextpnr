from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parent
old=json.loads(Path('/tmp/pcxt-replicate-leased-20261022/baseline/receipt.json').read_text())
env=dict(os.environ);env.pop('NEXTPNR_REQUIRE_GPU',None)
for label,budget in [('baseline',0),('candidate',8)]:
 p=root/label;p.mkdir(exist_ok=False)
 cmd=list(old['command']);cmd[0]=str(root/'nextpnr-mistral');cmd+=['--gpu-cpu']
 if budget:cmd+=['--critical-move-route-budget',str(budget)]
 r={'command':cmd,'evidence':'CPU-reference diagnostic only','timeout':600,'binary_sha256':hashlib.file_digest(open(cmd[0],'rb'),'sha256').hexdigest()}
 start=time.monotonic()
 try:
  with (p/'nextpnr.log').open('w') as log:r['returncode']=subprocess.run(cmd,cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
 except subprocess.TimeoutExpired:r['timeout_expired']=True
 r['charged_seconds']=time.monotonic()-start
 r['artifacts']={f.name:hashlib.file_digest(f.open('rb'),'sha256').hexdigest() for f in p.iterdir() if f.suffix in ['.json','.rbf']}
 (p/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(label,r.get('returncode'),r['charged_seconds'],flush=True)
 if not all((p/n).exists() for n in ['routed.json','timing.json','endpoints.json','diagnostic.rbf']):break
