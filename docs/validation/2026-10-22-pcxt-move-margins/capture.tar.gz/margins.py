from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
text=(root/'candidate/nextpnr.log').read_text()
pattern=r'Critical move margin (\d+): (setup|hold) clock (.*?) before=([-\d.]+) ns after=([-\d.]+) ns delta=([-\d.]+) ns\.'
rows=[dict(trial=int(i),kind=k,clock=c,before_ns=float(a),after_ns=float(b),delta_ns=float(d)) for i,k,c,a,b,d in re.findall(pattern,text)]
assert len(rows)==32, len(rows)
baseline=json.loads((root/'baseline/timing.json').read_text())['timing_summary']['clocks']
for row in rows:
 assert abs(row['before_ns']-baseline[row['clock']][row['kind']+'_wns_ns'])<0.000001
assert len(re.findall(r'Critical move trial .*?accepted=0;',text))==8

for i in (1,3,5,7):
 group=[r for r in rows if r['trial']==i]
 assert len(group)==8 and len({(r['kind'],r['clock']) for r in group})==8
 assert all(abs(r['after_ns']-r['before_ns']-r['delta_ns'])<0.000002 for r in group)
result={'rows':rows,'regressions':[r for r in rows if r['delta_ns']<0],'improvements':[r for r in rows if r['delta_ns']>0]}
(root/'margins.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
