from pathlib import Path
import json,re,sys
p=Path(sys.argv[1]);a=json.loads((p/'baseline/routed.json').read_text());b=json.loads((p/'candidate/routed.json').read_text())
x=a['modules']['top'];y=b['modules']['top'];mapping={}
assert x['cells'].keys()==y['cells'].keys() and x['netnames'].keys()==y['netnames'].keys()
for name,net in x['netnames'].items():
 other=y['netnames'][name];assert len(net['bits'])==len(other['bits'])
 for old,new in zip(net['bits'],other['bits']):
  if isinstance(old,int):
   if old in mapping:assert mapping[old]==new
   mapping[old]=new
  else:assert old==new
assert len(mapping)==len(set(mapping.values()))
def bits(v):return [mapping[n] if isinstance(n,int) else n for n in v]
for n in x['netnames'].values():n['bits']=bits(n['bits'])
for c in x['cells'].values():c['connections']={k:bits(v) for k,v in c['connections'].items()}
for port in x['ports'].values():port['bits']=bits(port['bits'])
accepted=dict(re.findall(r'Critical move trial \d+: cell (.*?) target (.*?) accepted=1;', (p/'candidate/nextpnr.log').read_text()))
incident=set();moved=[]
for name,target in accepted.items():
 old=x['cells'][name];new=y['cells'][name]
 assert new['attributes']['NEXTPNR_BEL']==target
 assert old['attributes']['NEXTPNR_BEL']!=target
 old['attributes']['NEXTPNR_BEL']=target;moved.append(name)
 for v in old['connections'].values():incident.update(n for n in v if isinstance(n,int))
changed=[]
for name,net in x['netnames'].items():
 other=y['netnames'][name]
 if net!=other:
  assert set(net['bits']) & incident,name
  assert 'ROUTING' in net['attributes'] and 'ROUTING' in other['attributes']
  net['attributes']['ROUTING']=other['attributes']['ROUTING'];changed.append(name)
assert a==b,'Change outside declared placement and incident routing (after bit renumbering)'
r={'cells':len(x['cells']),'nets':len(x['netnames']),'moved_cells':moved,'changed_incident_routes':changed,'mapped_bits':len(mapping),'all_other_graph_content_identical':True}
(p/'preservation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
