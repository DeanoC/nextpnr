/*
 *  nextpnr -- Next Generation Place and Route
 *
 *  Copyright (C) 2026  Deano Calver
 *
 *  Permission to use, copy, modify, and/or distribute this software for any
 *  purpose with or without fee is hereby granted, provided that the above
 *  copyright notice and this permission notice appear in all copies.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
 *  IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef MISTRAL_DSP_H
#define MISTRAL_DSP_H

#include <array>

#include "nextpnr_namespaces.h"

NEXTPNR_NAMESPACE_BEGIN

struct MistralDspLane
{
    int a_group;
    int b_group;
    int result_offset;
};

// A 3-lane M9 tile uses separate 9-bit slices for each operand. In preadder
// mode the Y slices move to the documented AY groups and each lane gets a Z
// slice. The order is low lane to high lane.
constexpr std::array<int, 3> mistral_dsp_preadder_y_groups{{2, 3, 8}};
constexpr std::array<int, 3> mistral_dsp_preadder_z_groups{{4, 5, 10}};

// The M18X18P36 mode uses AX groups 0/1, AY groups 2/3, and the optional
// 36-bit addend on groups 8/9 (low half) and 6/7 (high half). Tracing
// Quartus 17.0.2's A*B+C input routes confirms this concatenation order.
constexpr std::array<int, 2> mistral_dsp_18x18_a_groups{{0, 1}};
constexpr std::array<int, 2> mistral_dsp_18x18_b_groups{{2, 3}};
constexpr std::array<int, 4> mistral_dsp_18x18_c_groups{{8, 9, 6, 7}};

// The native two-multiplier modes use AX/AY and BX/BY.  Groups are listed
// from least-significant slice to most-significant slice.  The nineteenth bit
// of each Y operand is on an otherwise unnamed GOUT endpoint; Mistral exposes
// those endpoints as UNK_IN until the DSP port names are reverse engineered.
constexpr std::array<int, 2> mistral_dsp_18x19_a_groups{{0, 1}};
constexpr std::array<int, 2> mistral_dsp_18x19_b_groups{{2, 3}};
constexpr std::array<int, 2> mistral_dsp_18x19_c_groups{{6, 7}};
constexpr std::array<int, 2> mistral_dsp_18x19_d_groups{{8, 9}};
constexpr int mistral_dsp_18x19_b_high_pi = 94; // upper DSP2 GOUT.30
constexpr int mistral_dsp_18x19_d_high_pi = 30; // lower DSP GOUT.30

// A 27x27 multiplier uses the same operand packing as the three 9x9 mode,
// with one 54-bit result. RESULT port 36 is the physical hole between the
// upper and lower 37-bit halves, so the last 18 logical bits start at 37.
constexpr std::array<int, 3> mistral_dsp_27x27_a_groups{{0, 6, 7}};
constexpr std::array<int, 3> mistral_dsp_27x27_b_groups{{2, 8, 9}};

constexpr int mistral_dsp_27x27_result_port(int bit)
{
    return bit < 36 ? bit : bit + 1;
}

// Quartus implements a signed 9x9 product on lane 0 by sign-extending each
// operand into the upper AX/AY slice (DATAIN groups 1 and 3) and setting all
// four signedness bits. The upper slices are free in every lane assignment of
// the three-lane mode, but lanes 1 and 2 have no spare slice, so a signed cell
// owns its block unless --mistral-dsp-signed-lanes is given.
constexpr int mistral_dsp_m9_a_ext_group = 1;
constexpr int mistral_dsp_m9_b_ext_group = 3;

// In M18X18P36 mode Quartus feeds a signed Y operand's nineteenth
// (sign-extension) bit to DATAIN group 5 bit 8 and sets BY_SIGNED.
constexpr int mistral_dsp_18x18_b_ext_group = 5;
constexpr int mistral_dsp_18x18_b_ext_bit = 8;

// Cyclone V three-multiplier mode packs three 9x9 products into the 27-bit
// A/B inputs and the low 54 logical result bits. The physical RESULT port has
// a one-bit hole at 36, so the third product starts at port 37. The order
// follows Mistral's documented AX/AY packing table: the low lane is the
// existing single-mode mapping and the two upper lanes use groups 6/8 and
// 7/9.
constexpr std::array<MistralDspLane, 3> mistral_dsp_lanes{{
        {0, 2, 0},
        {6, 8, 18},
        {7, 9, 37},
}};

NEXTPNR_NAMESPACE_END

#endif
