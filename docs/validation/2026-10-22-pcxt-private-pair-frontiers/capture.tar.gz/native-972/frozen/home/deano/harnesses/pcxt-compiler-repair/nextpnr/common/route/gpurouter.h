/*
 *  nextpnr -- Next Generation Place and Route
 *
 *  Copyright (C) 2026  Deano Calver
 *
 *  Permission to use, copy, modify, and/or distribute this software for any
 *  purpose with or without fee is hereby granted, provided that the above
 *  copyright notice and this permission notice appear in all copies.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 *  GPU-accelerated connection-based negotiated-congestion router.
 *  See docs/gpurouter.md for the design.
 */

#ifndef GPUROUTER_H
#define GPUROUTER_H

#include <memory>
#include <functional>
#include <string>
#include <vector>

#include "log.h"
#include "nextpnr.h"

NEXTPNR_NAMESPACE_BEGIN

// Internal cooperative cancellation. Candidate callers must restore their
// saved bindings; gpurouter returns false after unwinding its router state.
struct GpuRouterCancelled {};

// A required-GPU device selection or initialisation failure. Most router
// errors remain recoverable during analogue repair, but this one must escape
// so required mode cannot report success after restoring an earlier route.
struct GpuRequiredFailure : log_execution_error_exception
{
};

struct GpuRouterCfg
{
    GpuRouterCfg(Context *ctx);

    // Empty leaves ordinary routing unbounded. Checked on the calling thread
    // between batches/iterations, never while a backend launch is in flight.
    std::function<bool()> stop_requested;
    void check_stop() const
    {
        if (stop_requested && stop_requested())
            throw GpuRouterCancelled{};
    }

    // Whether the router1 legality check that ends the route reports a
    // missed clock constraint as an error. An architecture that signs off
    // with a later, different timing model turns it off, so a table-model
    // miss that its repair then closes does not fail the run.
    bool legality_timing_gate;

    // Padding added to net bounding boxes (tiles)
    int bb_margin_x, bb_margin_y;
    // Congestion cost schedule (same meaning as router2)
    float init_curr_cong_weight, hist_cong_weight, curr_cong_mult;
    // If the negotiated-congestion loop's overused-wire count sets no new
    // minimum for this many iterations, the present-congestion weight grows
    // congestion_stall_boost times faster until it does. A handful of nets
    // stuck swapping the same local wire (e.g. two cells placed with a
    // shared LAB-internal conflict) can otherwise cycle for a very long
    // time under the plain additive schedule. This only accelerates
    // convergence. In an attempt that began with frozen timing-repair arcs,
    // a small plateau at the boost ceiling is handed to the soft-reservation
    // escape. Initial routing retains its normal max_iter budget.
    int congestion_stall_iters;
    float congestion_stall_boost;
    // Ceiling on the compounded boost multiplier. A genuine hard conflict
    // (a net with no legal alternative route at all, e.g. it is competing
    // with a reserved/frozen wire) does not respond to any amount of
    // present-congestion cost, so letting the multiplier compound without
    // bound just produces absurd weights and log noise. Once the multiplier
    // is at this ceiling during a frozen timing-repair attempt, a handful
    // of still-overused wires are routed again with soft reservations
    // ignored; a plateau that still does not move ends that attempt.
    float congestion_stall_boost_max;
    // Weight of the A* estimate; > 1 trades optimality for speed
    float estimate_weight;
    // The same for the pure-delay searches of timing repair and candidate
    // generation, which are few and are what critical arcs end up with;
    // defaults to estimate_weight
    float repair_estimate_weight;
    // Bias towards the net centroid, as a fraction of the base cost
    float bias_cost_factor;
    // A sink may attach anywhere on the net's existing tree; the attach
    // point starts with cost crit * seed_delay_weight * upstream delay
    float seed_delay_weight, seed_delay_floor;
    // Lower bound of the criticality weight max(floor, 1 - crit^2) that
    // scales the congestion terms; router2 uses 0.05
    float crit_weight_floor;
    // 0: weight = 1 - crit^2 (router2); 1: weight = (1 - crit)^crit_exponent
    int crit_weight_mode;
    float crit_exponent;
    // Analogue-model approximations: ns added when branching off a tree
    // wire per branch it already drives, and ns added to every pip
    float load_penalty, pip_adder;
    // Iterations without fewer slack-failing arcs before timing-driven
    // rip-up (--tmg-ripup) gives up
    int tmg_ripup_patience;
    // After convergence, arcs with setup slack below repair_slack (ps) are
    // re-routed at pure delay and frozen, for up to repair_rounds rounds
    int repair_rounds;
    float repair_slack;
    // While nothing fails, arcs within repair_band (ps) of the worst slack
    // are still repaired, until the worst slack stops improving
    float repair_band;
    int repair_improve_rounds;
    // A repair that cannot find its minimum-delay route may displace frozen
    // arcs of other nets with at least repair_displace_margin (ps) more slack
    bool repair_displace;
    float repair_displace_margin;
    // Tiles added to the net box for a pure-delay search while setup slack is
    // still negative. The first search is the one that is kept when it finds
    // a route, so a failing arc has to see past the negotiation box. 0 keeps
    // that box. Growth is capped at the device size: the box is int16 and
    // already clamped to the grid, and a larger addend can overflow first.
    int repair_bb_expand;
    // When a later same-band repair is blocked by an already-frozen peer,
    // those nets are ripped together and re-routed at pure delay plus this
    // present-congestion weight so they share short wires instead of the
    // first freeze leaving the rest unroutable. 1.0 makes an occupied wire
    // cost 2x delay. 0 disables the peer-group pass.
    float repair_cong_weight;
    // Batches of at most this many nets run on the host backend (0 = never)
    int cpu_lane_nets;
    // Diagnostic: re-run every bounded pure-delay repair search as an exact
    // Dijkstra on the host and report how often and by how much the K-best
    // weighted-A* search misses the minimum-delay route
    bool repair_verify;
    int repair_verify_arcs; // searches to compare, first arc of a task each (the exact search is slow)
    // Candidate generation (GpuCandidateRouter): tiles added to the net's
    // bounding box, and whether the two primary variants may fall back to
    // the search without a box
    int candidate_margin;
    bool candidate_unbounded;
    // Frontier entries expanded per step in candidate searches (default
    // expand_k): they run one net at a time, so a larger step means fewer
    // sequential steps at some cost in path quality
    int candidate_expand_k;
    // Frontier entries expanded per parallel step: at least expand_k and at
    // least frontier_size / expand_div (expand_k = 1, expand_div = 0 is A*)
    int expand_k, expand_div;
    // Bounding-box-disjoint batches per iteration before nets are allowed
    // to be routed concurrently with overlapping boxes
    int max_batches;
    // Nets whose boxes overlap every one of those batches are routed in
    // chunks of at most this many (0: all in one batch). Every failing net
    // is ripped up before the first batch, so nets sharing a batch all see
    // the wire they fought over as free and take it together again.
    int overflow_chunk;
    // Maximum number of nets routed concurrently on the device; large_slots
    // 0 sizes the large lane from free device memory
    int small_slots, large_slots;
    // log2 of the per-net hash table size for the two lanes
    int small_bits, large_bits;
    // GPU device index, -1 selects automatically
    int device;
    // Use the sequential host reference backend instead of the GPU
    bool cpu_backend;
    // Fail instead of falling back to the sequential host backend.
    bool gpu_required;
    // Print per-iteration timing and backend statistics
    bool perf_profile;
    // Diagnostic: rewritten after every negotiation iteration with each
    // overused wire, its occupancy and, for heavily shared wires, some of
    // the nets on it. Empty disables it.
    std::string overuse_report;
    // Empty disables telemetry. The writer creates this path exclusively.
    std::string telemetry_path;
    // Original explicit or randomized command seed. This is kept separate
    // from the warmed/advanced RNG state serialized in the generic settings.
    std::string telemetry_seed;
    // Stop after this many iterations without convergence
    int max_iter;
    // Maximum re-routing attempts after architecture binding rejects a route.
    // Zero fails on the first rejection. Independent of the congestion budget.
    int arch_retry_limit;
};

// Returns true when the whole design routed (and, as with router2, after the
// result has been checked by router1).
bool gpurouter(Context *ctx, const GpuRouterCfg &cfg, bool consume_telemetry = true);

// Seconds the calling thread has waited for gpu-run phase lease grants
// (GPU_LEASE_FD, see docs/gpurouter.md). Wall-clock route budgets and timers
// kept on that thread leave this out; it is always 0 without a lease.
double gpurouter_lease_wait_seconds();

// An alternative routing tree for one net produced by GpuCandidateRouter:
// every wire the net uses with the pip that drives it (PipId() for the
// source and for wires bound without a pip).
struct GpuRouteTree
{
    std::vector<std::pair<WireId, PipId>> wires;
    int variant = 0;         // diversity rule that produced it (see candidates())
    delay_t route_delay = 0; // delay-table route delay of the re-routed sink
};

// Produces several materially different pure-delay routes for one sink of an
// already-routed net while every other net stays where the Arch has bound
// it, so that an architecture with a more accurate delay model than the
// per-pip table (Mistral's analogue model) can choose between them instead
// of accepting the single route the scalar search prefers. The routing graph
// is flattened from the current Arch bindings when the object is created;
// resync() reloads one net after the caller has rebound it.
class GpuCandidateRouter
{
  public:
    GpuCandidateRouter(Context *ctx, const GpuRouterCfg &cfg);
    ~GpuCandidateRouter();
    struct Sink
    {
        NetInfo *net;
        store_index<PortRef> user;
    };
    // reserve_whole_tree reserves two slots for whole-tree alternatives on
    // multi-sink nets; ordinary callers retain the original candidate order.
    // For each sink, up to `count` distinct trees that re-route it at pure
    // delay, in this order: 0 attaches anywhere on the existing tree (the
    // router's own choice), 1 routes from the source only, then ones
    // avoiding the multi-tile wires of every earlier candidate while that
    // still finds new routes, then one that avoids each multi-tile wire of
    // the route the arc has now, and, while still below `count`, for a net
    // with several sinks whole-tree candidates (variant 100: every sink
    // rebuilt, the failing one first; 101: a star, every sink from the
    // source). The sinks are searched
    // together, one variant per launch; a second sink of the same net gets
    // no candidates in this call. The route the net already has and repeats are left
    // out. The nets' routing in the Arch is left unchanged; candidates of
    // different nets may compete for the same free wire, which the caller
    // sees when it binds them.
    std::vector<std::vector<GpuRouteTree>> candidates(const std::vector<Sink> &sinks, int count, bool reserve_whole_tree = false);
    // The caller rebound `net` in the Arch; reload its tree from there.
    void resync(NetInfo *net);

  private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};

NEXTPNR_NAMESPACE_END

#endif // GPUROUTER_H
