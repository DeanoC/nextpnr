/*
 *  nextpnr -- Next Generation Place and Route
 *
 *  Copyright (C) 2021  gatecat <gatecat@ds0.me>
 *
 *  Permission to use, copy, modify, and/or distribute this software for any
 *  purpose with or without fee is hereby granted, provided that the above
 *  copyright notice and this permission notice appear in all copies.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */

#include <algorithm>
#include <atomic>
#include <fstream>
#include <iterator>
#include <limits>
#include <map>
#include <set>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include "json11.hpp"
#include "log.h"
#include "nextpnr.h"
#include "util.h"

using json11::Json;

NEXTPNR_NAMESPACE_BEGIN

namespace {

std::string fes_encode_snapshot(const Json &payload)
{
    std::string encoded;
    static const char hex[] = "0123456789abcdef";
    for (unsigned char ch : payload.dump()) {
        encoded += hex[ch >> 4];
        encoded += hex[ch & 15];
    }
    return encoded;
}

Json fes_decode_snapshot(const Property &saved, const char *description)
{
    if (!saved.is_string)
        log_error("Invalid frozen %s encoding.\n", description);
    const std::string encoded = saved.as_string();
    std::string decoded;
    if (encoded.size() % 2 != 0)
        log_error("Invalid frozen %s encoding.\n", description);
    auto nibble = [&](char ch) {
        if (ch >= '0' && ch <= '9')
            return ch - '0';
        if (ch >= 'a' && ch <= 'f')
            return ch - 'a' + 10;
        log_error("Invalid frozen %s encoding.\n", description);
    };
    for (size_t i = 0; i < encoded.size(); i += 2)
        decoded += char((nibble(encoded[i]) << 4) | nibble(encoded[i + 1]));
    std::string error;
    Json payload = Json::parse(decoded, error);
    if (!error.empty() || payload.dump() != decoded)
        log_error("Invalid frozen %s payload.\n", description);
    return payload;
}

bool fes_skip_cart_cell(IdString type)
{
    return type.in(id_MISTRAL_IB, id_MISTRAL_OB, id_MISTRAL_IO, id_MISTRAL_BUF, id_MISTRAL_CLKENA,
                   id_MISTRAL_CLKBUF, id_cyclonev_hps_interface_mpu_general_purpose,
                   id_cyclonev_hps_interface_peripheral_i2c);
}

NetInfo *find_named_net(Context *ctx, const std::string &name)
{
    IdString id = ctx->id(name);
    if (ctx->nets.count(id))
        return ctx->nets.at(id).get();
    if (ctx->net_aliases.count(id))
        return ctx->getNetByAlias(id);
    return nullptr;
}

// Yosys drops plug_addr[0:5] netnames once they alias gp_in[15:10].
NetInfo *find_plug_addr_bit(Context *ctx, int index)
{
    auto found = ctx->cells.find(ctx->id(stringf("plug_addr_ff_%d", index)));
    if (found != ctx->cells.end()) {
        NetInfo *q = found->second->getPort(id_Q);
        if (q != nullptr)
            return q;
    }
    return find_named_net(ctx, stringf("plug_addr[%d]", index));
}

NetInfo *shell_clock_net(Context *ctx)
{
    const IdString selection = ctx->id("fes/slot_clock");
    if (ctx->settings.count(selection)) {
        const std::string name = ctx->settings.at(selection).as_string();
        NetInfo *clock = find_named_net(ctx, name);
        if (clock == nullptr || clock->driver.cell == nullptr)
            log_error("FES slot clock '%s' is not a driven shell net.\n", name.c_str());
        if (ctx->fes_cell_is_slot(clock->driver.cell))
            log_error("FES slot clock '%s' is driven by the cart, not the shell.\n", name.c_str());
        return clock;
    }
    NetInfo *clock = nullptr;
    for (auto &item : ctx->cells) {
        CellInfo *ci = item.second.get();
        if (ci->type != id_MISTRAL_FF)
            continue;
        if (ctx->fes_cell_is_slot(ci))
            continue;
        NetInfo *clk = ci->getPort(id_CLK);
        if (clk != nullptr) {
            if (clock != nullptr && clock != clk)
                log_error("FES shell has multiple clocks; select the socket clock with --fes-slot-clock.\n");
            clock = clk;
        }
    }
    if (clock != nullptr)
        return clock;
    clock = find_named_net(ctx, "FPGA_CLK1_50");
    if (clock == nullptr || clock->driver.cell == nullptr)
        log_error("FES shell has no driven socket clock; use --fes-slot-clock.\n");
    return clock;
}

CellInfo *find_rdata_ff(Context *ctx, const std::string &port)
{
    std::string suffix;
    if (port == "plug_rdata")
        suffix = "0";
    else if (port.size() > 11 && port.compare(0, 11, "plug_rdata[") == 0)
        suffix = port.substr(11, port.size() - 12);
    else
        return nullptr;
    const std::string cell_name = "plug_rdata_ff_" + suffix;
    auto found = ctx->cells.find(ctx->id(cell_name));
    if (found == ctx->cells.end())
        return nullptr;
    return found->second.get();
}

Property fes_parse_property(const Json &val)
{
    if (val.is_number())
        return Property(val.int_value(), 32);
    return Property::from_string(val.string_value());
}

bool fes_json_const(const Json &bit, char &value)
{
    if (!bit.is_string())
        return false;
    const std::string &s = bit.string_value();
    if (s.size() != 1)
        return false;
    value = s[0];
    return value == '0' || value == '1' || value == 'x';
}

bool fes_json_signal(const Json &bit, int &id)
{
    if (bit.is_number()) {
        id = bit.int_value();
        return true;
    }
    return false;
}

void fes_unbind_port_wires(Context *ctx, CellInfo *cell, IdString port)
{
    if (cell == nullptr || cell->bel == BelId())
        return;
    NetInfo *net = cell->getPort(port);
    if (net == nullptr)
        return;
    std::vector<WireId> wires;
    auto add = [&](WireId w) {
        if (w != WireId() && ctx->getBoundWireNet(w) == net)
            wires.push_back(w);
    };
    if (cell->pin_data.count(port)) {
        for (IdString bp : cell->pin_data.at(port).bel_pins)
            add(ctx->getBelPinWire(cell->bel, bp));
    }
    add(ctx->getBelPinWire(cell->bel, port));
    for (WireId w : wires) {
        if (ctx->getBoundWireNet(w) == net) {
            if (ctx->fes_protected_routing.count(w))
                log_error("Cannot detach protected frozen CRAM wire %s from %s.%s.\n", ctx->nameOfWire(w),
                          ctx->nameOf(cell), port.c_str(ctx));
            ctx->unbindWire(w);
        }
    }
}

} // namespace

void Arch::fes_trim_net_orphans(NetInfo *net)
{
    Context *ctx = getCtx();
    if (net == nullptr || net->wires.empty())
        return;
    pool<WireId> used;
    // A mux outside the socket remains part of the physical shell even when
    // its last logical sink is detached. The snapshot includes its ancestors.
    for (const auto &wire : net->wires)
        if (fes_protected_routing.count(wire.first))
            used.insert(wire.first);
    if (!net->users.empty()) {
        WireId src = ctx->getNetinfoSourceWire(net);
        if (src != WireId())
            used.insert(src);
    }
    for (auto usr : net->users) {
        // Imported routed shells have physical BEL bindings before the
        // scaffold restores logical pin mappings. Inspect those bindings
        // directly; querying logical sink wires here can address a packed
        // port that no longer exists on the physical BEL.
        if (usr.cell == nullptr || usr.cell->bel == BelId())
            continue;
        for (IdString pin : ctx->getBelPins(usr.cell->bel)) {
            WireId cursor = ctx->getBelPinWire(usr.cell->bel, pin);
            if (cursor == WireId() || ctx->getBoundWireNet(cursor) != net)
                continue;
            int guard = 0;
            while (cursor != WireId() && net->wires.count(cursor) && guard++ < 100000) {
                used.insert(cursor);
                PipId pip = net->wires.at(cursor).pip;
                if (pip == PipId())
                    break;
                cursor = ctx->getPipSrcWire(pip);
            }
        }
    }
    std::vector<WireId> extra;
    for (auto &it : net->wires) {
        if (!used.count(it.first))
            extra.push_back(it.first);
    }
    for (WireId w : extra) {
        if (net->wires.count(w))
            ctx->unbindWire(w);
    }
}

namespace {

NetInfo *rdata_sink_net(Context *ctx, int index)
{
    CellInfo *ff = find_rdata_ff(ctx, stringf("plug_rdata[%d]", index));
    if (ff == nullptr)
        return find_named_net(ctx, stringf("plug_rdata_d[%d]", index));
    // Vacant DATAIN is packed onto $PACKER_GND_NET with every other const-0
    // pin. Unbind only this FF's sink wire, then detach; ripping the shared
    // net would make the cart M10K drive chip-wide GND (SCLR, HPS, ...).
    NetInfo *old = ff->getPort(id_DATAIN);
    fes_unbind_port_wires(ctx, ff, id_DATAIN);
    if (ff->getPort(id_DATAIN) != nullptr)
        ff->disconnectPort(id_DATAIN);
    ctx->fes_trim_net_orphans(old);
    IdString name = ctx->id(stringf("fes_rdata[%d]", index));
    int suffix = 0;
    while (ctx->nets.count(name))
        name = ctx->id(stringf("fes_rdata[%d]$%d", index, suffix++));
    NetInfo *sink = ctx->createNet(name);
    if (!ff->ports.count(id_DATAIN))
        ff->addInput(id_DATAIN);
    ff->pin_data[id_DATAIN].state = PIN_SIG;
    ff->connectPort(id_DATAIN, sink);
    return sink;
}

} // namespace

bool Arch::fes_cell_is_slot(const CellInfo *cell) const
{
    // Same test as fes_cell_slot_region without interning the region name:
    // the routing rules ask this for every pip they check.
    if (cell == nullptr)
        return false;
    auto found = cell->attrs.find(id_FES_SLOT);
    if (found == cell->attrs.end())
        return false;
    const Property &prop = found->second;
    return prop.is_string ? !prop.as_string().empty() : prop.as_bool();
}

void Arch::fes_rip_reserved_shell_pips()
{
    Context *ctx = getCtx();
    int ripped = 0;
    for (auto &item : ctx->nets) {
        NetInfo *net = item.second.get();
        if (fes_cell_is_slot(net->driver.cell))
            continue;
        std::vector<PipId> pips;
        for (auto &wire : net->wires) {
            if (wire.second.pip != PipId() && fes_pip_in_socket(wire.second.pip))
                pips.push_back(wire.second.pip);
        }
        for (PipId pip : pips) {
            ctx->unbindPip(pip);
            ++ripped;
        }
    }
    log_info("FES ripped %d reserved-tile pips from shell nets.\n", ripped);
}

void Arch::save_fes_pin_maps(bool save_lab_state)
{
    // Routing does not describe unused memory lanes or folded hard constants.
    // Preserve the complete physical mapping alongside the frozen netlist.
    for (auto &item : getCtx()->cells) {
        CellInfo *ci = item.second.get();
        if (ci->bel == BelId())
            continue;
        Json::object ports;
        for (const auto &pin : ci->pin_data) {
            Json::array data{int(pin.second.state)};
            for (IdString physical : pin.second.bel_pins)
                data.emplace_back(physical.str(getCtx()));
            ports[pin.first.str(getCtx())] = data;
        }
        // The generic JSON writer does not escape quotes in attributes.
        // Hex keeps this architecture-specific payload unambiguous there.
        Json payload = Json::object{{"count", int(ports.size())}, {"pins", ports}};
        ci->attrs[id("FES_PINMAP_V1")] = fes_encode_snapshot(payload);
    }
    // LAB state becomes a physical snapshot only after routing preparation.
    // A placed checkpoint needs pin states, not a routed scaffold snapshot.
    if (!save_lab_state)
        return;
    Json::array physical_labs;
    for (const auto &lab : labs) {
        Loc loc = getBelLocation(lab.alms[0].lut_bels[0]);
        Json::array state{int(lab.aclr_used[0]), int(lab.aclr_used[1])};
        for (const auto &alm : lab.alms) {
            for (int value : {int(alm.l6_mode), int(alm.carry_mode), alm.clk_ena_idx[0], alm.clk_ena_idx[1],
                              alm.aclr_idx[0], alm.aclr_idx[1]})
                state.emplace_back(value);
        }
        physical_labs.emplace_back(Json::array{loc.x, loc.y, int(lab.is_mlab), state});
    }
    getCtx()->attrs[id("FES_LABSTATE_V1")] =
            fes_encode_snapshot(Json::object{{"device", args.device}, {"labs", physical_labs}});
}

bool Arch::restore_cell_pin_map(CellInfo *ci)
{
    Context *ctx = getCtx();
    for (const auto &attr : ci->attrs) {
        const std::string key = attr.first.str(ctx);
        if (key.compare(0, 11, "FES_PINMAP_") == 0 && key != "FES_PINMAP_V1")
            log_error("Unsupported frozen pin-map version for %s.\n", ctx->nameOf(ci));
    }
    auto saved = ci->attrs.find(id("FES_PINMAP_V1"));
    if (saved != ci->attrs.end()) {
        Json payload = fes_decode_snapshot(saved->second, "pin-map");
        const Json &ports = payload["pins"];
        if (!payload.is_object() || payload.object_items().size() != 2 ||
            !ports.is_object() || !payload["count"].is_number() ||
            payload["count"].number_value() != double(ports.object_items().size()))
            log_error("Invalid frozen pin map for %s.\n", ctx->nameOf(ci));
        for (const auto &port : ci->ports) {
            if (port.second.net != nullptr && !ports.object_items().count(port.first.str(ctx)))
                log_error("Incomplete frozen pin map for %s.%s.\n", ctx->nameOf(ci), port.first.c_str(ctx));
        }
        ci->pin_data.clear();
        for (const auto &entry : ports.object_items()) {
            const auto &data = entry.second.array_items();
            if (!entry.second.is_array() || data.empty() || !data[0].is_number() ||
                data[0].number_value() != data[0].int_value() || data[0].int_value() < PIN_SIG ||
                data[0].int_value() > PIN_INV)
                log_error("Invalid frozen pin state for %s.%s.\n", ctx->nameOf(ci), entry.first.c_str());
            auto &pin = ci->pin_data[id(entry.first)];
            pin.state = CellPinState(data[0].int_value());
            std::set<IdString> seen;
            for (size_t i = 1; i < data.size(); ++i) {
                if (!data[i].is_string() || !bel_data(ci->bel).pins.count(id(data[i].string_value())))
                    log_error("Invalid frozen physical pin for %s.%s.\n", ctx->nameOf(ci), entry.first.c_str());
                auto logical = ci->ports.find(id(entry.first));
                PortType direction = getBelPinType(ci->bel, id(data[i].string_value()));
                if (logical != ci->ports.end() && direction != PORT_INOUT && direction != logical->second.type)
                    log_error("Wrong frozen pin direction for %s.%s.\n", ctx->nameOf(ci), entry.first.c_str());
                if (!seen.insert(id(data[i].string_value())).second)
                    log_error("Duplicate frozen physical pin for %s.%s.\n", ctx->nameOf(ci), entry.first.c_str());
                pin.bel_pins.push_back(id(data[i].string_value()));
            }
            auto logical = ci->ports.find(id(entry.first));
            if (logical != ci->ports.end() && logical->second.net != nullptr && pin.bel_pins.empty() &&
                logical->second.net->driver.cell != nullptr && (pin.state == PIN_SIG || pin.state == PIN_INV))
                log_error("Empty frozen signal pin map for %s.%s.\n", ctx->nameOf(ci), entry.first.c_str());
        }
        return true;
    }
    return false;
}

void Arch::restore_placed_pin_maps()
{
    // Placed JSON has no routed scaffold to lock, but its packer-folded
    // constants and input inversions are still part of the logical design.
    // Legacy checkpoints omit the snapshot on every placed cell and stay
    // readable with a warning. A snapshot on only some placed cells leaves
    // the rest on JSON defaults, which can drop folded constants or inversions.
    Context *ctx = getCtx();
    int annotated = 0;
    int missing = 0;
    CellInfo *first_missing = nullptr;
    for (auto &entry : ctx->cells) {
        CellInfo *ci = entry.second.get();
        if (ci->bel == BelId())
            continue;
        if (restore_cell_pin_map(ci)) {
            ++annotated;
            continue;
        }
        if (first_missing == nullptr)
            first_missing = ci;
        ++missing;
    }
    if (annotated == 0) {
        log_warning("Placed checkpoint has no pin-state snapshot; regenerate it from synthesis JSON to preserve "
                    "folded constants and inversions.\n");
        return;
    }
    if (missing != 0)
        log_error("Placed checkpoint is only partially annotated: %s has no FES_PINMAP_V1 (%d placed %s missing). "
                  "Regenerate it from synthesis JSON so every placed cell carries the pin-state snapshot.\n",
                  ctx->nameOf(first_missing), missing, missing == 1 ? "cell" : "cells");
    assignArchInfo();
}

void Arch::lock_fes_scaffold()
{
    Context *ctx = getCtx();
    for (const auto &attr : ctx->attrs) {
        const std::string key = attr.first.str(ctx);
        if (key.compare(0, 13, "FES_LABSTATE_") == 0 && key != "FES_LABSTATE_V1")
            log_error("Unsupported frozen LAB-state version.\n");
    }
    auto lab_snapshot = ctx->attrs.find(id("FES_LABSTATE_V1"));
    if (lab_snapshot == ctx->attrs.end())
        log_error("Missing frozen LAB state; rebuild the shell with physical snapshot metadata.\n");
    Json lab_payload = fes_decode_snapshot(lab_snapshot->second, "LAB state");
    if (!lab_payload.is_object() || lab_payload.object_items().size() != 2 ||
        !lab_payload["device"].is_string() || lab_payload["device"].string_value() != args.device ||
        !lab_payload["labs"].is_array() || lab_payload["labs"].array_items().size() != labs.size())
        log_error("Invalid frozen LAB-state device or geometry.\n");
    for (size_t index = 0; index < labs.size(); ++index) {
        auto &lab = labs[index];
        const auto &entry = lab_payload["labs"][index];
        Loc loc = getBelLocation(lab.alms[0].lut_bels[0]);
        if (!entry.is_array() || entry.array_items().size() != 4 || entry[0].number_value() != loc.x ||
            entry[1].number_value() != loc.y || entry[2].number_value() != int(lab.is_mlab) ||
            !entry[0].is_number() || !entry[1].is_number() || !entry[2].is_number() ||
            !entry[3].is_array() || entry[3].array_items().size() != 62)
            log_error("Invalid frozen LAB-state geometry at index %zu.\n", index);
        const auto &state = entry[3].array_items();
        for (size_t offset = 0; offset < state.size(); ++offset) {
            const int max_value = offset >= 2 && ((offset - 2) % 6 == 2 || (offset - 2) % 6 == 3) ? 2 : 1;
            if (!state[offset].is_number() || state[offset].number_value() != state[offset].int_value() ||
                state[offset].int_value() < 0 || state[offset].int_value() > max_value)
                log_error("Invalid frozen LAB-state field at index %zu.%zu.\n", index, offset);
        }
        lab.aclr_used = {bool(state[0].int_value()), bool(state[1].int_value())};
        for (size_t alm_index = 0; alm_index < 10; ++alm_index) {
            auto &alm = lab.alms[alm_index];
            size_t start = 2 + 6 * alm_index;
            alm.l6_mode = state[start].int_value();
            alm.carry_mode = state[start + 1].int_value();
            alm.clk_ena_idx = {state[start + 2].int_value(), state[start + 3].int_value()};
            alm.aclr_idx = {state[start + 4].int_value(), state[start + 5].int_value()};
        }
    }
    // Rip is optional; mixed USER/WEAK trees make GPU router1 check abort.
    // fes_rip_reserved_shell_pips();
    if (fes_has_reserved_rect) {
        int m10ks = 0;
        for (BelId bel : getBels()) {
            if (getBelType(bel) != id_MISTRAL_M10K || !fes_bel_region.count(bel))
                continue;
            if (m10ks < 16)
                log_info("FES reserved M10K %s (region '%s')\n", getBelName(bel).str(getCtx()).c_str(),
                         fes_bel_region.at(bel).c_str(getCtx()));
            ++m10ks;
        }
        log_info("FES reserved M10K count %d\n", m10ks);
    }
    log_info("FES locking scaffold routing...\n");
    int locked_cells = 0;
    for (auto &item : ctx->cells) {
        CellInfo *ci = item.second.get();
        if (ci->bel == BelId() || fes_cell_is_slot(ci))
            continue;
        ci->belStrength = STRENGTH_LOCKED;
        fes_frozen_cells.emplace(ci, ci->bel);
        ++locked_cells;
        if (!restore_cell_pin_map(ci))
            log_error("Missing frozen pin map for %s; rebuild the shell with physical snapshot metadata.\n",
                      ctx->nameOf(ci));
    }
    // Control inversion and LUT annotations were initially derived before
    // restoring folded state. Recompute them without default pin remapping.
    std::vector<BelId> restored;
    for (auto &item : ctx->cells) {
        CellInfo *ci = item.second.get();
        if (ci->bel == BelId() || fes_cell_is_slot(ci))
            continue;
        if (is_comb_cell(ci->type) || ci->type.in(id_MISTRAL_MLAB, id_MISTRAL_BUF))
            assign_comb_info(ci);
        else if (ci->type == id_MISTRAL_FF)
            assign_ff_info(ci);
        restored.push_back(ci->bel);
    }
    for (BelId bel : restored)
        update_bel(bel);
    // Scaffold cells are STRENGTH_LOCKED, and lab_pre_route does not rewrite
    // those LABs. --no-route never calls lab_pre_route either. A V1 snapshot
    // from before open flops were parked keeps its stale ACLR index until
    // this park.
    int parked = 0;
    for (uint32_t lab = 0; lab < labs.size(); ++lab)
        parked += park_open_aclr(lab);
    if (parked != 0) {
        log_info("FES parked %d open flip-flop halves on an unused LAB clear.\n", parked);
        save_fes_pin_maps();
    }
    int locked = 0;
    for (auto &item : ctx->nets) {
        NetInfo *net = item.second.get();
        if (net->wires.empty() || fes_cell_is_slot(net->driver.cell))
            continue;
        ctx->lockNetRouting(item.first);
        ++locked;
    }
    fes_lock_protected_routing();
    log_info("FES scaffold locked %d cells and routing on %d nets.\n", locked_cells, locked);
}

bool Arch::fes_net_touches_slot(const NetInfo *net) const
{
    if (net == nullptr)
        return false;
    if (fes_cell_is_slot(net->driver.cell))
        return true;
    for (auto &user : net->users) {
        if (fes_cell_is_slot(user.cell))
            return true;
    }
    return false;
}

bool Arch::fes_pip_in_socket(PipId pip) const
{
    if (!fes_has_reserved_rect)
        return false;
    Loc loc = getPipLocation(pip);
    for (const auto &rect : fes_reserved_rects) {
        if (loc.x >= rect.x0 && loc.x <= rect.x1 && loc.y >= rect.y0 && loc.y <= rect.y1)
            return true;
    }
    return false;
}

void Arch::note_fes_cram_region(const std::string &spec)
{
#ifndef MISTRAL_ROUTING_MUX_CRAM_BITS
    log_error("Physical CRAM routing fence requires Mistral routing-mux coordinates.\n");
#else
    int x0, y0, x1, y1;
    char extra;
    if (sscanf(spec.c_str(), "%d,%d,%d,%d%c", &x0, &y0, &x1, &y1, &extra) != 4 || x0 < 0 || y0 < 0 ||
        x1 <= x0 || y1 <= y0 || uint32_t(x1) > cyclonev->get_cram_sx() || uint32_t(y1) > cyclonev->get_cram_sy())
        log_error("Invalid FES CRAM region; expected half-open x0,y0,x1,y1.\n");
    fes_cram_region = {x0, y0, x1, y1};
    fes_has_cram_region = true;
    std::vector<std::pair<uint32_t, uint32_t>> bits;
    for (uint32_t ri = 0; ri < cyclonev->rnode_index_count(); ri++) {
        const auto *ro = cyclonev->ri2ro(ri);
        if (ro == nullptr)
            continue;
        const auto node = ro->rc();
        if (!cyclonev->rnode_mux_cram_bits(node, bits))
            log_error("Missing routing mux physical coordinates.\n");
        bool inside = true;
        for (const auto &bit : bits) {
            if (bit.first < uint32_t(x0) || bit.first >= uint32_t(x1) || bit.second < uint32_t(y0) ||
                bit.second >= uint32_t(y1)) {
                inside = false;
                break;
            }
        }
        if (inside)
            fes_cram_allowed_muxes.insert(node);
    }
    // Snapshot before cart merge can detach any original return-path stubs.
    // Exact old selections remain legal; a different source at an outside mux
    // is forbidden even for a mixed shell/cart constant net.
    for (const auto &item : getCtx()->nets) {
        const NetInfo *net = item.second.get();
        for (const auto &wire : net->wires) {
            PipId pip = wire.second.pip;
            if (pip == PipId())
                continue;
            fes_frozen_pips.insert(pip);
            if (WireId(pip.src).is_nextpnr_created() || WireId(pip.dst).is_nextpnr_created() ||
                fes_cram_allowed_muxes.count(pip.dst))
                continue;
            WireId cursor = wire.first;
            while (!fes_protected_routing.count(cursor)) {
                auto upstream = net->wires.find(cursor);
                if (upstream == net->wires.end())
                    log_error("Incomplete frozen CRAM route at wire %s on net %s.\n",
                              getCtx()->nameOfWire(cursor), getCtx()->nameOf(net));
                PipId parent = upstream->second.pip;
                fes_protected_routing[cursor] = std::make_pair(parent, item.first);
                if (parent == PipId())
                    break;
                cursor = getPipSrcWire(parent);
            }
        }
    }
    log_info("FES physical CRAM fence admits %zu muxes and preserves %zu frozen pips.\n",
             fes_cram_allowed_muxes.size(), fes_frozen_pips.size());
#endif
}

void Arch::fes_lock_protected_routing()
{
    fes_validate_cram_routing();
    for (const auto &entry : fes_protected_routing)
        getCtx()->nets.at(entry.second.second)->wires.at(entry.first).strength = STRENGTH_LOCKED;
}

void Arch::fes_validate_cram_routing() const
{
    for (const auto &entry : fes_protected_routing) {
        const NetInfo *net = getBoundWireNet(entry.first);
        if (net == nullptr || net->name != entry.second.second || !net->wires.count(entry.first) ||
            net->wires.at(entry.first).pip != entry.second.first)
            log_error("Missing or changed frozen CRAM route at wire %s on net %s.\n",
                      getCtx()->nameOfWire(entry.first), entry.second.second.c_str(getCtx()));
    }
    for (const auto &item : getCtx()->nets)
        for (const auto &wire : item.second->wires)
            if (wire.second.pip != PipId() && !fes_pip_preserves_cram(wire.second.pip))
                log_error("Routed pip %s violates frozen CRAM region.\n",
                          getPipName(wire.second.pip).str(getCtx()).c_str());
}

bool Arch::fes_pip_preserves_cram(PipId pip) const
{
    // Synthetic BEL edges are not routing muxes: write_routing skips them.
    // Their cell/control configuration is governed by frozen physical state
    // and the placement fence, and the producer checks the final CRAM bytes.
    return !fes_has_cram_region || WireId(pip.src).is_nextpnr_created() || WireId(pip.dst).is_nextpnr_created() ||
           fes_frozen_pips.count(pip) || fes_cram_allowed_muxes.count(pip.dst);
}

void Arch::fes_check_boundary_connectivity() const
{
    if (!fes_has_cram_region)
        return;
    const Context *ctx = getCtx();
    // A necessary connectivity check, not a routing or timing guarantee.
    // Ignore all movable routing so another cart net cannot cause a false
    // rejection. Only immutable ownership/selections and architecture rules
    // prune this graph. Run after LAB pin mapping and global routing.
    std::vector<const NetInfo *> boundary_nets;
    for (const auto &item : ctx->nets) {
        const NetInfo *net = item.second.get();
        if (net->is_global || net->driver.cell == nullptr || fes_cell_is_slot(net->driver.cell) ||
            net->driver.cell->belStrength < STRENGTH_LOCKED || !fes_net_touches_slot(net))
            continue;
        boundary_nets.push_back(net);
    }
    std::sort(boundary_nets.begin(), boundary_nets.end(), [&](const NetInfo *a, const NetInfo *b) {
        return a->name.str(ctx) < b->name.str(ctx);
    });
    for (const NetInfo *net : boundary_nets) {
        WireId source = ctx->getNetinfoSourceWire(net);
        if (source == WireId())
            continue;
        pool<WireId> pending;
        for (const auto &user : net->users)
            if (fes_cell_is_slot(user.cell))
                for (WireId sink : ctx->getNetinfoSinkWires(net, user))
                    if (sink != WireId())
                        pending.insert(sink);
        if (pending.empty())
            continue;
        pool<WireId> seen;
        std::vector<WireId> queue{source};
        seen.insert(source);
        pending.erase(source);
        std::set<std::string> blockers;
        size_t fence_blocks = 0;
        for (size_t head = 0; head < queue.size() && !pending.empty(); ++head) {
            for (PipId pip : getPipsDownhill(queue[head])) {
                WireId dst = getPipDstWire(pip);
                if (!pip_allowed_for_net(pip, net)) {
                    if (!fes_pip_preserves_cram(pip))
                        ++fence_blocks;
                    continue;
                }
                const NetInfo *owner = getBoundWireNet(dst);
                if (owner != nullptr) {
                    const auto &binding = owner->wires.at(dst);
                    if (binding.strength >= STRENGTH_LOCKED && (owner != net || binding.pip != pip)) {
                        if (owner != net)
                            blockers.insert(owner->name.str(ctx));
                        continue;
                    }
                }
                if (!seen.insert(dst).second)
                    continue;
                pending.erase(dst);
                queue.push_back(dst);
            }
        }
        if (pending.empty())
            continue;
        std::vector<std::string> sinks;
        for (WireId sink : pending)
            sinks.push_back(getWireName(sink).str(ctx));
        std::sort(sinks.begin(), sinks.end());
        log_nonfatal_error("FES boundary net '%s' from %s cannot reach %s with frozen routing and CRAM fence "
                           "%d,%d,%d,%d (%zu reachable wires, %zu fence-blocked pips).\n",
                           net->name.c_str(ctx), getWireName(source).str(ctx).c_str(), sinks.front().c_str(),
                           fes_cram_region[0], fes_cram_region[1], fes_cram_region[2], fes_cram_region[3],
                           seen.size(), fence_blocks);
        for (const auto &owner : blockers)
            log_info("FES boundary exit blocked by frozen net '%s'.\n", owner.c_str());
        log_error("FES frozen boundary cannot reach placed cart sinks; choose reachable cart placement or rebuild "
                  "the shell with usable boundary routes inside the CRAM fence.\n");
    }
}

bool Arch::fes_pip_in_plug_halo(PipId pip) const
{
    if (!fes_has_reserved_rect)
        return false;
    Loc loc = getPipLocation(pip);
    for (const auto &rect : fes_reserved_rects) {
        if (loc.x >= rect.x0 - 6 && loc.x <= rect.x1 + 6 && loc.y >= rect.y0 - 6 && loc.y <= rect.y1 + 6)
            return true;
    }
    return false;
}

bool Arch::fes_pip_hits_bound_shell_pin(PipId pip) const
{
    auto hits_shell_pin = [&](WireId wire) {
        auto found = wires.find(wire);
        if (found == wires.end())
            return false;
        for (auto &pin : found->second.bel_pins) {
            CellInfo *bound = getBoundBelCell(pin.bel);
            if (bound != nullptr && !fes_cell_is_slot(bound))
                return true;
        }
        return false;
    };
    return hits_shell_pin(WireId(pip.src)) || hits_shell_pin(WireId(pip.dst));
}

namespace {

// A placed non-slot cell on this net. Shared by the binding check and
// netHaloShellTiles so the search exception is the same set of tiles.
bool shell_cell_tile(const Arch *arch, const CellInfo *cell, int &x, int &y)
{
    if (cell == nullptr || arch->fes_cell_is_slot(cell) || cell->bel == BelId())
        return false;
    Loc bel = arch->getBelLocation(cell->bel);
    x = bel.x;
    y = bel.y;
    return true;
}

} // namespace

bool Arch::fes_pip_reaches_net_shell_tile(PipId pip, const NetInfo *net) const
{
    if (net == nullptr)
        return false;
    if (fes_pip_hits_bound_shell_pin(pip))
        return true;
    Loc loc = getPipLocation(pip);
    auto on_tile = [&](const CellInfo *cell) {
        int x, y;
        return shell_cell_tile(this, cell, x, y) && x == loc.x && y == loc.y;
    };
    if (on_tile(net->driver.cell))
        return true;
    for (auto &user : net->users) {
        if (on_tile(user.cell))
            return true;
    }
    return false;
}

// Whether `wire` has fewer than two ways out for `net`. The search follows
// pips the architecture allows that net (CRAM fence, plug halo) and skips
// wires that frozen scaffold routing holds; movable routing is ignored. A
// pin another net holds above placer strength is narrow before the search:
// the cart net cannot bind that wire, however large the component beyond
// it is. The net's own binding is not a block. A wire escapes once its
// component outgrows a few tiles or, searching backward from a sink,
// reaches the net's own frozen route. It is narrow when it never escapes,
// or when one wire on its way out is a cut: every route of the net through
// `wire` then needs that one wire.
bool Arch::fes_search_pin_narrow(WireId wire, const NetInfo *net, bool forward) const
{
    const size_t limit = 2048;
    const NetInfo *start_owner = getBoundWireNet(wire);
    if (start_owner != nullptr && start_owner != net && start_owner->wires.at(wire).strength > STRENGTH_PLACER)
        return true;
    // Breadth-first search that skips `cut`; on escape, `exit_path` holds
    // the wires from `wire` (exclusive) to the escape point.
    auto escapes = [&](WireId cut, std::vector<WireId> *exit_path) {
        dict<WireId, WireId> parent;
        parent[wire] = WireId();
        std::vector<WireId> queue{wire};
        WireId escape;
        for (size_t head = 0; head < queue.size() && escape == WireId(); ++head) {
            auto visit = [&](PipId pip, WireId next) {
                if (escape != WireId() || next == cut || pip_rejection_reason(pip, net) != nullptr)
                    return;
                const NetInfo *owner = getBoundWireNet(next);
                if (owner != nullptr && owner != net && owner->wires.at(next).strength > STRENGTH_PLACER)
                    return;
                if (!parent.emplace(next, queue[head]).second)
                    return;
                queue.push_back(next);
                if (queue.size() > limit || (!forward && owner == net))
                    escape = next;
            };
            if (forward) {
                for (PipId pip : getPipsDownhill(queue[head]))
                    visit(pip, getPipDstWire(pip));
            } else {
                for (PipId pip : getPipsUphill(queue[head]))
                    visit(pip, getPipSrcWire(pip));
            }
        }
        if (escape == WireId())
            return false;
        if (exit_path)
            for (WireId w = escape; w != wire; w = parent.at(w))
                exit_path->insert(exit_path->begin(), w);
        return true;
    };
    // Only a routing wire that other tiles can drive (or, searching
    // backward, load) can be wanted by another net. A block's own output and
    // input wires are fed from one tile and are this pin's anyway.
    auto shared = [&](WireId w) {
        bool have = false;
        uint32_t x = 0, y = 0;
        auto other_tile = [&](WireId end) {
            if (!have) {
                have = true;
                x = end.node.x();
                y = end.node.y();
                return false;
            }
            return end.node.x() != x || end.node.y() != y;
        };
        if (forward) {
            for (PipId pip : getPipsUphill(w))
                if (other_tile(getPipSrcWire(pip)))
                    return true;
        } else {
            for (PipId pip : getPipsDownhill(w))
                if (other_tile(getPipDstWire(pip)))
                    return true;
        }
        return false;
    };
    std::vector<WireId> exit_path;
    bool narrow = !escapes(WireId(), &exit_path);
    // A cut close to the pin is what competes with the shell's exits.
    const size_t cut_depth = 4;
    for (size_t i = 0; !narrow && i < std::min(cut_depth, exit_path.size()); ++i)
        narrow = shared(exit_path[i]) && !escapes(exit_path[i], nullptr);
    return narrow;
}

namespace {

// The architecture rules see a net through whether a slot cell drives it,
// its shell cells (halo exceptions) and its own frozen route. Unrouted nets
// with the same answer to the first and no shell cell to the second search
// alike, so they share one cache entry per wire.
enum NarrowClass
{
    NARROW_OWN = 0,     // keyed by net name
    NARROW_CART = 1,    // slot driver, slot users only, unrouted
    NARROW_FROM_SHELL = 2 // shell driver, unrouted (halo rules do not apply)
};

NarrowClass narrow_class(const Arch *arch, const NetInfo *net)
{
    if (!net->wires.empty() || net->is_global)
        return NARROW_OWN;
    if (!arch->fes_cell_is_slot(net->driver.cell))
        return NARROW_FROM_SHELL;
    for (const auto &user : net->users)
        if (!arch->fes_cell_is_slot(user.cell))
            return NARROW_OWN;
    return NARROW_CART;
}

} // namespace

// fes_search_pin_narrow, cached. The caller holds fes_narrow_mutex.
bool Arch::fes_slot_pin_narrow(WireId wire, const NetInfo *net, bool forward) const
{
    const NarrowClass cls = narrow_class(this, net);
    auto key = std::make_pair(std::make_pair(wire, cls == NARROW_OWN ? net->name : IdString()),
                              int(forward) | (int(cls) << 1));
    auto cached = fes_narrow_cache.find(key);
    if (cached != fes_narrow_cache.end())
        return cached->second;
    bool narrow = fes_search_pin_narrow(wire, net, forward);
    fes_narrow_cache[key] = narrow;
    return narrow;
}

// Placement asks about the same slot pins over and over while moving cart
// cells. Answer the connections that share cache entries (see NarrowClass)
// of every slot cell, at every slot BEL of a type that cell fits, up front
// and on all cores. Nets with their own entry are searched on demand.
void Arch::fes_precompute_narrow_pins()
{
    if (!fes_fence_active || !fes_has_cram_region)
        return;
    struct Job
    {
        WireId wire;
        const NetInfo *net;
        bool forward;
        std::pair<std::pair<WireId, IdString>, int> key;
    };
    std::vector<Job> jobs;
    pool<std::pair<std::pair<WireId, IdString>, int>> seen;
    dict<IdString, std::vector<BelId>> bels_by_type;
    for (const auto &item : getCtx()->cells) {
        const CellInfo *cell = item.second.get();
        if (!fes_cell_is_slot(cell))
            continue;
        auto &bels = bels_by_type[cell->type];
        if (bels.empty())
            for (const auto &entry : fes_bel_region)
                if (isValidBelForCellType(cell->type, entry.first))
                    bels.push_back(entry.first);
        for (const auto &port : cell->ports) {
            const NetInfo *net = port.second.net;
            if (net == nullptr || net->is_global || net->driver.cell == nullptr || net->users.entries() == 0 ||
                port.second.type == PORT_INOUT)
                continue;
            auto pin_data = cell->pin_data.find(port.first);
            if (pin_data == cell->pin_data.end())
                continue;
            const bool forward = port.second.type == PORT_OUT;
            const NarrowClass cls = narrow_class(this, net);
            if (cls == NARROW_OWN)
                continue;
            for (BelId bel : bels) {
                if (!forward && bel_data(bel).type.in(id_MISTRAL_COMB, id_MISTRAL_MCOMB, id_MISTRAL_FF))
                    continue;
                for (IdString pin : pin_data->second.bel_pins) {
                    WireId wire = getBelPinWire(bel, pin);
                    if (wire == WireId())
                        continue;
                    auto key = std::make_pair(std::make_pair(wire, IdString()), int(forward) | (int(cls) << 1));
                    if (seen.insert(key).second)
                        jobs.push_back(Job{wire, net, forward, key});
                }
            }
        }
    }
    std::vector<uint8_t> narrow(jobs.size(), 0);
    std::atomic<size_t> next{0};
    auto work = [&]() {
        for (size_t i = next++; i < jobs.size(); i = next++)
            narrow[i] = fes_search_pin_narrow(jobs[i].wire, jobs[i].net, jobs[i].forward);
    };
    const int nthreads = std::max(1, std::min(int(std::thread::hardware_concurrency()), 32));
    std::vector<std::thread> threads;
    for (int t = 1; t < nthreads; ++t)
        threads.emplace_back(work);
    work();
    for (auto &thread : threads)
        thread.join();
    std::lock_guard<std::mutex> guard(fes_narrow_mutex);
    int count = 0;
    for (size_t i = 0; i < jobs.size(); ++i) {
        fes_narrow_cache[jobs[i].key] = narrow[i];
        count += narrow[i];
    }
    log_info("FES slot pins: %d of %zu candidate connections have no second way past frozen routing and the slot "
             "fences.\n",
             count, jobs.size());
}

// A narrow slot pin (see fes_slot_pin_narrow) reaches only a few tiles, or
// all of its routes share one wire. That wire may be one the shell's
// boundary nets have no slack to give up: a cart M10K output at the plug
// corner can need the one exit that the last plug address net also needs,
// and no router can then legalise the design. Keep slot cells off BELs where
// a connected pin is narrow. LAB inputs are assigned after placement, so
// only LAB outputs are checked.
bool Arch::fes_slot_pins_escape(BelId bel, const CellInfo *cell, bool explain_invalid) const
{
    if (!fes_fence_active || !fes_has_cram_region)
        return true;
    const bool lab = bel_data(bel).type.in(id_MISTRAL_COMB, id_MISTRAL_MCOMB, id_MISTRAL_FF);
    std::lock_guard<std::mutex> guard(fes_narrow_mutex);
    for (const auto &port : cell->ports) {
        const NetInfo *net = port.second.net;
        if (net == nullptr || net->is_global || net->driver.cell == nullptr || net->users.entries() == 0 ||
            port.second.type == PORT_INOUT || (lab && port.second.type == PORT_IN))
            continue;
        auto pin_data = cell->pin_data.find(port.first);
        if (pin_data == cell->pin_data.end())
            continue;
        for (IdString pin : pin_data->second.bel_pins) {
            WireId wire = getBelPinWire(bel, pin);
            if (wire == WireId() || !fes_slot_pin_narrow(wire, net, port.second.type == PORT_OUT))
                continue;
            if (explain_invalid)
                log_info("FES slot cell %s pin %s at %s has no second way past frozen routing and the slot "
                         "fences.\n",
                         nameOf(cell), port.first.c_str(getCtx()), getBelName(bel).str(getCtx()).c_str());
            return false;
        }
    }
    return true;
}

void Arch::netHaloShellTiles(const NetInfo *net, std::vector<std::pair<int, int>> &tiles) const
{
    tiles.clear();
    if (net == nullptr)
        return;
    auto add = [&](const CellInfo *cell) {
        int x, y;
        if (shell_cell_tile(this, cell, x, y))
            tiles.emplace_back(x, y);
    };
    add(net->driver.cell);
    for (auto &user : net->users)
        add(user.cell);
}

void Arch::merge_fes_cart(const std::string &filename, const std::string &region)
{
    Context *ctx = getCtx();
    // A run with no FES_RESERVED_RECT at all has no placement fencing to
    // validate against (matches the pre-multi-region behaviour); once any
    // region is declared, an unknown --fes-cart-region is a real mistake.
    if (fes_has_reserved_rect) {
        IdString region_id = id(region);
        auto absorbed = fes_region_absorbed_by.find(region_id);
        if (absorbed != fes_region_absorbed_by.end())
            log_error("FES cart region '%s' was absorbed into group '%s' by FES_RESERVED_RECT_GROUP and is no "
                      "longer independently available; merge '%s' against '%s' instead.\n",
                      region.c_str(), absorbed->second.c_str(ctx), filename.c_str(), absorbed->second.c_str(ctx));
        if (!fes_region_bels.count(region_id))
            log_error("FES cart region '%s' has no matching FES_RESERVED_RECT; declare it with FES_RESERVED_RECT "
                      "\"%s x0 y0 x1 y1\" before merging '%s'.\n",
                      region.c_str(), region.c_str(), filename.c_str());
    }
    fes_active_cart_region = region;
    log_info("FES parsing cart JSON '%s' into region '%s'...\n", filename.c_str(), region.c_str());
    std::ifstream in(filename);
    if (!in)
        log_error("Failed to open FES cart JSON '%s'.\n", filename.c_str());
    std::string json_str((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    std::string error;
    Json root = Json::parse(json_str, error);
    if (root.is_null())
        log_error("Loading FES cart JSON '%s' failed: %s.\n", filename.c_str(), error.c_str());
    Json modules = root["modules"];
    Json mod = modules["cart"];
    if (mod.is_null() && modules.is_object() && !modules.object_items().empty())
        mod = modules.object_items().begin()->second;
    if (mod.is_null())
        log_error("FES cart JSON '%s' has no cart module.\n", filename.c_str());

    std::map<int, std::pair<std::string, int>> top_bits;
    const Json &ports = mod["ports"];
    if (ports.is_object()) {
        for (const auto &item : ports.object_items()) {
            const auto &bits = item.second["bits"].array_items();
            for (int i = 0; i < int(bits.size()); i++) {
                int id;
                if (fes_json_signal(bits[i], id))
                    top_bits[id] = {item.first, i};
            }
        }
    }

    std::map<int, NetInfo *> bit_nets;
    auto intern_bit_net = [&](int id) -> NetInfo * {
        auto found = bit_nets.find(id);
        if (found != bit_nets.end())
            return found->second;
        NetInfo *net = ctx->createNet(ctx->id(stringf("fes_cart$bit%d", id)));
        bit_nets[id] = net;
        return net;
    };

    int mapped_ib = 0, missed_ib = 0, mapped_ob = 0;
    std::set<int> socket_clock_bits;
    const Json &cells = mod["cells"];
    if (cells.is_object()) {
        for (const auto &item : cells.object_items()) {
            const std::string type = item.second["type"].string_value();
            const Json &conns = item.second["connections"];
            if (type == "MISTRAL_IB") {
                const auto &pad = conns["PAD"].array_items();
                const auto &out = conns["O"].array_items();
                for (int i = 0; i < int(out.size()) && i < int(pad.size()); i++) {
                    int pad_id, out_id;
                    if (!fes_json_signal(pad[i], pad_id) || !fes_json_signal(out[i], out_id))
                        continue;
                    auto top = top_bits.find(pad_id);
                    if (top == top_bits.end())
                        continue;
                    NetInfo *shell = nullptr;
                    if (top->second.first == "FPGA_CLK1_50") {
                        shell = shell_clock_net(ctx);
                        socket_clock_bits.insert(out_id);
                    } else if (top->second.first == "plug_addr")
                        shell = find_plug_addr_bit(ctx, top->second.second);
                    if (shell != nullptr) {
                        bit_nets[out_id] = shell;
                        ++mapped_ib;
                    } else {
                        ++missed_ib;
                    }
                }
            } else if (type == "MISTRAL_OB") {
                const auto &in_bits = conns["I"].array_items();
                const auto &pad = conns["PAD"].array_items();
                for (int i = 0; i < int(in_bits.size()) && i < int(pad.size()); i++) {
                    int pad_id, in_id;
                    if (!fes_json_signal(pad[i], pad_id) || !fes_json_signal(in_bits[i], in_id))
                        continue;
                    auto top = top_bits.find(pad_id);
                    if (top == top_bits.end() || top->second.first != "plug_rdata")
                        continue;
                    NetInfo *sink = rdata_sink_net(ctx, top->second.second);
                    if (sink != nullptr) {
                        bit_nets[in_id] = sink;
                        ++mapped_ob;
                    } else {
                        ++missed_ib;
                    }
                }
            }
        }
    }

    // Synthesis may insert transparent clock buffers. Trace only those from
    // the declared cart clock input; a divider, gate or constant is a distinct
    // clock domain and must not be silently replaced by the shell clock.
    bool changed;
    do {
        changed = false;
        for (const auto &item : cells.object_items()) {
            const std::string type = item.second["type"].string_value();
            if (type != "MISTRAL_CLKBUF" && type != "MISTRAL_BUF")
                continue;
            const Json &conns = item.second["connections"];
            const auto &input = conns["A"].array_items();
            const auto &output = conns["Q"].array_items();
            int from, to;
            if (input.size() == 1 && output.size() == 1 && fes_json_signal(input[0], from) &&
                fes_json_signal(output[0], to) && socket_clock_bits.count(from))
                changed |= socket_clock_bits.insert(to).second;
        }
    } while (changed);
    // The skipped buffers' outputs are the socket clock too. Map every traced
    // bit onto the shell clock net, as for the input buffer above, so a clock
    // pin of any primitive (not only those the reconnect below knows) never
    // lands on a fresh cart net that nothing drives.
    if (NetInfo *shell_clock = shell_clock_net(ctx)) {
        for (int bit : socket_clock_bits)
            bit_nets[bit] = shell_clock;
    }

    int added = 0;
    std::vector<CellInfo *> merged_cells;
    if (cells.is_object()) {
        for (const auto &item : cells.object_items()) {
            const Json &src = item.second;
            const std::string type_name = src["type"].string_value();
            IdString type = ctx->id(type_name);
            if (fes_skip_cart_cell(type))
                continue;
            IdString dst_name = ctx->id(std::string("fes_cart$") + item.first);
            int suffix = 0;
            while (ctx->cells.count(dst_name))
                dst_name = ctx->id(stringf("fes_cart$%s$%d", item.first.c_str(), suffix++));
            CellInfo *dst = ctx->createCell(dst_name, type);
            merged_cells.push_back(dst);
            const Json &params = src["parameters"];
            if (params.is_object()) {
                for (const auto &param : params.object_items())
                    dst->params[ctx->id(param.first)] = fes_parse_property(param.second);
            }
            const Json &attrs = src["attributes"];
            if (attrs.is_object()) {
                for (const auto &attr : attrs.object_items()) {
                    if (attr.first == "NEXTPNR_BEL" || attr.first == "BEL_STRENGTH" || attr.first == "ROUTING")
                        continue;
                    dst->attrs[ctx->id(attr.first)] = fes_parse_property(attr.second);
                }
            }
            dst->attrs[id_FES_SLOT] = Property(region);

            const Json &dirs = src["port_directions"];
            const Json &conns = src["connections"];
            const std::vector<std::string> required_clocks =
                    type == id_MISTRAL_FF ? std::vector<std::string>{"CLK"}
                    : type == id_MISTRAL_M10K ? std::vector<std::string>{"CLK1"}
                    : type == id_MISTRAL_M10K_TDP ? std::vector<std::string>{"CLK1", "CLK2"}
                                                : std::vector<std::string>{};
            for (const auto &port : required_clocks)
                if (conns[port].array_items().size() != 1 || dirs[port].string_value() != "input")
                    log_error("FES cart '%s.%s' requires one declared socket clock input.\n",
                              item.first.c_str(), port.c_str());
            if (conns.is_object()) {
                for (const auto &conn : conns.object_items()) {
                    const auto &bits = conn.second.array_items();
                    const std::string dir = dirs[conn.first].string_value();
                    PortType ptype = PORT_IN;
                    if (dir == "output")
                        ptype = PORT_OUT;
                    else if (dir == "inout")
                        ptype = PORT_INOUT;
                    for (int i = 0; i < int(bits.size()); i++) {
                        const std::string pname =
                                bits.size() == 1 ? conn.first : stringf("%s[%d]", conn.first.c_str(), i);
                        IdString pid = ctx->id(pname);
                        if (ptype == PORT_OUT)
                            dst->addOutput(pid);
                        else if (ptype == PORT_INOUT)
                            dst->addInout(pid);
                        else
                            dst->addInput(pid);
                        char constant = 0;
                        int signal = 0;
                        const bool clock_port =
                                (type == id_MISTRAL_FF && pid == id_CLK) ||
                                (type.in(id_MISTRAL_M10K, id_MISTRAL_M10K_TDP) && pid.in(id_CLK1, id_CLK2));
                        if (clock_port &&
                            (!fes_json_signal(bits[i], signal) || !socket_clock_bits.count(signal)))
                            log_error("FES cart '%s.%s' does not use the declared socket clock; "
                                      "derived, gated and constant cart clocks are unsupported.\n",
                                      item.first.c_str(), pname.c_str());
                        if (fes_json_const(bits[i], constant)) {
                            if (ptype != PORT_IN)
                                log_error("FES cart cell '%s' has a constant output port.\n", item.first.c_str());
                            if (!ctx->nets.count(ctx->id("$PACKER_GND_NET")) ||
                                !ctx->nets.count(ctx->id("$PACKER_VCC_NET")))
                                log_error("FES cart merge requires a packed shell with constant nets.\n");
                            // Let the existing unbound packer choose the hard
                            // constant mux or a routed shell constant. Dropping
                            // this value would apply the pin's default instead.
                            dst->pin_data[pid].state = constant == '1' ? PIN_1 : PIN_0;
                            continue;
                        }
                        if (!fes_json_signal(bits[i], signal))
                            continue;
                        NetInfo *mapped = intern_bit_net(signal);
                        if (ptype == PORT_OUT && mapped->driver.cell != nullptr) {
                            CellInfo *old = mapped->driver.cell;
                            old->disconnectPort(mapped->driver.port);
                        }
                        dst->connectPort(pid, mapped);
                    }
                }
            }
            assign_default_pinmap(dst);
            ++added;
        }
    }
    NetInfo *clk = shell_clock_net(ctx);
    if (clk != nullptr) {
        for (auto &item : ctx->cells) {
            CellInfo *ci = item.second.get();
            if (!ci->type.in(id_MISTRAL_M10K, id_MISTRAL_M10K_TDP, id_MISTRAL_FF) || !fes_cell_is_slot(ci))
                continue;
            // FES sockets have one declared clock. Synthesis inserts clock
            // buffers which are removed at the cart boundary; reconnect all
            // supported sequential cells, including writable true-dual RAM.
            const std::vector<IdString> ports = ci->type == id_MISTRAL_FF
                                                      ? std::vector<IdString>{id_CLK}
                                                      : ci->type == id_MISTRAL_M10K_TDP
                                                                ? std::vector<IdString>{id_CLK1, id_CLK2}
                                                                : std::vector<IdString>{id_CLK1};
            for (IdString port : ports) {
                NetInfo *existing = ci->getPort(port);
                if (existing == clk)
                    continue;
                if (existing != nullptr)
                    ci->disconnectPort(port);
                if (!ci->ports.count(port))
                    ci->addInput(port);
                ci->pin_data[port].state = PIN_SIG;
                ci->connectPort(port, clk);
            }
        }
    }
    // Every connected input of a merged cell must have a driver: an unmapped
    // cart port, a skipped primitive or a missed clock pin would otherwise
    // leave it floating, which placement, routing and timing all accept.
    for (CellInfo *ci : merged_cells) {
        for (auto &port : ci->ports) {
            NetInfo *net = port.second.net;
            if (port.second.type != PORT_IN || net == nullptr || net->driver.cell != nullptr)
                continue;
            log_error("FES cart cell '%s' pin '%s' is on net '%s', which nothing drives; every cart input "
                      "must come from a socket port, the socket clock or another cart cell.\n",
                      ci->name.c_str(ctx), port.first.c_str(ctx), net->name.c_str(ctx));
        }
    }
    assignArchInfo();
    fes_fence_active = true;
    for (auto &item : ctx->cells) {
        CellInfo *ci = item.second.get();
        if (ci->type != id_MISTRAL_M10K || !fes_cell_is_slot(ci))
            continue;
        for (auto &port : ci->ports) {
            const std::string pname = port.first.c_str(ctx);
            if (pname.compare(0, 6, "B1ADDR") != 0 || port.second.net == nullptr)
                continue;
            log_info("FES %s.%s <= %s\n", ci->name.c_str(ctx), pname.c_str(),
                     port.second.net->name.c_str(ctx));
        }
    }
    log_info("FES cart merged %d cells from '%s' (ib=%d ob=%d missed=%d).\n", added, filename.c_str(),
             mapped_ib, mapped_ob, missed_ib);
}

void Arch::fes_constrain_slot_region()
{
    Context *ctx = getCtx();
    if (!fes_has_reserved_rect || fes_bel_region.empty())
        return;
    // Bucket every FES_SLOT cell by its declared region name. Two carts
    // merged onto two disjoint FES_RESERVED_RECT regions (for example a
    // cartridge slot and an expansion slot on the same shell) each get their
    // own Region and capacity report; fes_placement_allowed() is the hard
    // gate that keeps a region's cells off another region's BELs.
    dict<IdString, std::vector<CellInfo *>> by_region;
    for (auto &item : ctx->cells) {
        CellInfo *ci = item.second.get();
        if (ci->isPseudo())
            continue;
        IdString region_name = fes_cell_slot_region(ci);
        if (region_name != IdString())
            by_region[region_name].push_back(ci);
    }
    if (by_region.empty())
        return;
    // The placers only search near a cell's analytic or random location.
    // Without a Region they sample the whole chip, of which a socket is a
    // tiny fraction, so legalisation degenerates into chip-wide random
    // probing. fes_placement_allowed() remains the hard gate.
    for (auto &entry : by_region) {
        IdString region_name = entry.first;
        std::vector<CellInfo *> &slot_cells = entry.second;
        if (!fes_region_bels.count(region_name))
            log_error("FES cart cell(s) claim undeclared FES_SLOT region '%s'; declare it with FES_RESERVED_RECT "
                      "\"%s x0 y0 x1 y1\".\n",
                      region_name.c_str(ctx), region_name.c_str(ctx));
        IdString region_id = id("$FES_SLOT_" + region_name.str(ctx));
        if (!ctx->region.count(region_id)) {
            std::unique_ptr<Region> region(new Region());
            region->name = region_id;
            region->constr_bels = true;
            for (BelId bel : fes_region_bels.at(region_name))
                region->bels.insert(bel);
            ctx->region[region_id] = std::move(region);
        }
        Region *region = ctx->region.at(region_id).get();
        for (CellInfo *ci : slot_cells)
            ci->region = region;
        log_info("FES slot region '%s' constrains %zu cart cells to %zu reserved BELs.\n", region_name.c_str(ctx),
                 slot_cells.size(), fes_region_bels.at(region_name).size());
        fes_any_slot_region_active = true;
        fes_report_slot_capacity(region_name, slot_cells);
    }
    fes_precompute_narrow_pins();
}

// Static capacity check of the cart against the usable part of the reserved
// rectangle. Every bound here is necessary, not sufficient: a cart that
// passes may still fail detailed legalisation, but a cart that fails cannot
// be placed by any placer, so the run stops with the failing figure instead
// of legalising for minutes.
void Arch::fes_report_slot_capacity(IdString region_name, const std::vector<CellInfo *> &slot_cells) const
{
    const Context *ctx = getCtx();
    const auto &region_bels = fes_region_bels.at(region_name);
    // Usable LABs: reserved to this region, and not holding a frozen shell
    // cell. A LAB with any locked non-slot occupant is excluded wholesale by
    // fes_placement_allowed() because its control set is immutable.
    int usable_labs = 0, frozen_labs = 0;
    std::map<int, std::vector<int>> usable_rows;
    for (const auto &lab : labs) {
        BelId first = lab.alms[0].lut_bels[0];
        if (!region_bels.count(first))
            continue;
        bool frozen = false;
        for (const auto &alm : lab.alms) {
            for (BelId other : {alm.lut_bels[0], alm.lut_bels[1], alm.ff_bels[0], alm.ff_bels[1], alm.ff_bels[2],
                                alm.ff_bels[3]}) {
                const CellInfo *occupant = getBoundBelCell(other);
                if (occupant && !fes_cell_is_slot(occupant) && occupant->belStrength >= STRENGTH_LOCKED)
                    frozen = true;
            }
        }
        if (frozen) {
            ++frozen_labs;
            continue;
        }
        ++usable_labs;
        Loc loc = getBelLocation(first);
        usable_rows[loc.x].push_back(loc.y);
    }
    int max_run = 0;
    for (auto &column : usable_rows) {
        std::sort(column.second.begin(), column.second.end());
        int run = 0, prev = std::numeric_limits<int>::min();
        for (int y : column.second) {
            run = (y == prev + 1) ? run + 1 : 1;
            prev = y;
            max_run = std::max(max_run, run);
        }
    }
    // Other reserved BELs (M10K, DSP, ...) that are free or already hold a
    // slot cell of this same region.
    dict<IdString, int> other_bels;
    for (BelId bel : region_bels) {
        IdString type = getBelType(bel);
        if (type.in(id_MISTRAL_COMB, id_MISTRAL_MCOMB, id_MISTRAL_FF))
            continue;
        const CellInfo *occupant = getBoundBelCell(bel);
        if (occupant && fes_cell_slot_region(occupant) != region_name)
            continue;
        other_bels[getBelBucketForBel(bel)]++;
    }

    int comb_cells = 0, ff_cells = 0, chains = 0, chain_rows = 0, ff_fabric = 0;
    int lut_inputs = 0, pairable_luts = 0, sdata_inputs = 0;
    dict<IdString, int> other_cells;
    bool clock_global = true;
    // FF control-set lower bound. A LAB has one SCLR, one SLOAD, two ACLR and
    // three ENA selectors, but ENA, SCLR, ACLR and a non-global CLK share four
    // LAB DATAIN lines (lab.cc LabCtrlSetWorker), so a LAB with an SCLR keeps
    // only two ENA lines (one if its clock is not global).
    struct Group
    {
        int ffs = 0;
        std::set<const NetInfo *> enas;
    };
    std::map<const NetInfo *, Group> sclr_groups;
    for (CellInfo *ci : slot_cells) {
        BelBucketId bucket = getBelBucketForCellType(ci->type);
        if (bucket == id_MISTRAL_COMB || ci->type == id_MISTRAL_BUF) {
            ++comb_cells;
            // Same accounting as update_alm_input_count: used inputs less
            // those shared with the previous carry cell.
            lut_inputs += std::max(0, ci->combInfo.used_lut_input_count - ci->combInfo.chain_shared_input_count);
            if (ci->type != id_MISTRAL_ALUT_ARITH && ci->type != id_MISTRAL_MLAB)
                ++pairable_luts;
        } else if (bucket == id_MISTRAL_FF) {
            ++ff_cells;
            const auto &cs = ci->ffInfo.ctrlset;
            if (cs.clk.net != nullptr && !cs.clk.net->is_global)
                clock_global = false;
            Group &group = sclr_groups[cs.sclr.net];
            ++group.ffs;
            // An enable equal to the LAB's SCLR or (non-global) clock signal
            // shares that DATAIN line in LabCtrlSetWorker and costs no slot.
            const bool shares_sclr = cs.ena == cs.sclr;
            const bool shares_clk = cs.clk.net != nullptr && !cs.clk.net->is_global && cs.ena == cs.clk;
            if (cs.ena.net != nullptr && !shares_sclr && !shares_clk)
                group.enas.insert(cs.ena.net);
            // Needs a route-through LUT half or the E/F input unless it is
            // paired with the LUT that drives it (pair_unbound_lut_ffs).
            const NetInfo *datain = ci->getPort(id_DATAIN);
            const CellInfo *driver = datain ? datain->driver.cell : nullptr;
            bool paired = driver != nullptr && ci->cluster != ClusterId() && ci->cluster == driver->name;
            // A late, bound identity helper already accounts for this external
            // data input as a LUT input. Its parent FF needs no second fabric
            // input; the helper was inserted after clustering.
            if (!paired && driver != nullptr && driver->type == id_MISTRAL_BUF &&
                driver->name == idf("%s$ROUTETHRU", nameOf(ci)) && driver->getPort(id_Q) == datain &&
                fes_cell_slot_region(driver) == region_name && ci->bel != BelId() && driver->bel != BelId()) {
                const auto &ff_site = bel_data(ci->bel).lab_data;
                paired = labs.at(ff_site.lab).alms.at(ff_site.alm).lut_bels.at(ff_site.idx / 2) == driver->bel;
            }
            if (!paired)
                ++ff_fabric;
            if (ci->ffInfo.sdata)
                ++sdata_inputs;
        } else {
            other_cells[bucket]++;
        }
        // Every chain root, including a one-cell chain, is pinned to z=0 of
        // some LAB by constrain_carries and so consumes a LAB root.
        if (ci->type == id_MISTRAL_ALUT_ARITH && ci->cluster == ci->name) {
            ++chains;
            int rows = 1;
            for (const CellInfo *child : ci->constr_children)
                rows = std::max(rows, 1 - child->constr_y);
            chain_rows = std::max(chain_rows, rows);
        }
    }
    const int ena_with_sclr = clock_global ? 2 : 1;
    const int ena_without_sclr = clock_global ? 3 : 2;
    // FF BELs 1 and 3 of each ALM are rejected by is_alm_legal unless --mistral-ff4, so 20 (or 40) per LAB.
    // The SCLR-group LAB estimate has to use the same width: a legal group of 21–40 FFs fits one LAB with ff4.
    const int ffs_per_lab = lab_ff4 ? 40 : 20;
    int ctrl_labs = 0;
    for (const auto &group : sclr_groups) {
        const int slots = group.first != nullptr ? ena_with_sclr : ena_without_sclr;
        const int by_count = (group.second.ffs + ffs_per_lab - 1) / ffs_per_lab;
        const int by_ena = (int(group.second.enas.size()) + slots - 1) / slots;
        ctrl_labs += group.first != nullptr ? std::max(by_count, by_ena) : 0;
    }
    const int comb_bels = 20 * usable_labs, ff_bels = ffs_per_lab * usable_labs;
    // check_lab_input_count admits 42 unique ALM inputs per LAB. Two LUTs in
    // one ALM may share at most two inputs, so the best case shares two per
    // pair of non-arithmetic LUTs; unpaired FF data and SDATA add one each.
    const int min_lab_inputs = std::max(0, lut_inputs - 2 * (pairable_luts / 2)) + ff_fabric + sdata_inputs;
    const int input_labs = (min_lab_inputs + 41) / 42;
    log_info("FES slot capacity (region '%s'): %d usable LABs (%d frozen), longest vertical run %d.\n",
             region_name.c_str(ctx), usable_labs, frozen_labs, max_run);
    log_info("FES slot capacity: comb %d/%d, FF %d/%d (%d unpaired need a route-through or E/F input; %d free LUT "
             "halves), carry chains %d (longest %d LAB rows).\n",
             comb_cells, comb_bels, ff_cells, ff_bels, ff_fabric, comb_bels - comb_cells, chains, chain_rows);
    log_info("FES slot capacity: %zu FF control-set groups by SCLR need at least %d LABs (clock %s, %d ENA per SCLR "
             "LAB).\n",
             sclr_groups.size(), ctrl_labs, clock_global ? "global" : "not global", ena_with_sclr);
    log_info("FES slot capacity: LAB inputs need at least %d LABs at 42 unique inputs each (%d LUT inputs, best-case "
             "%d shared, %d FF fabric inputs).\n",
             input_labs, lut_inputs, 2 * (pairable_luts / 2), ff_fabric + sdata_inputs);
    for (const auto &item : other_cells)
        log_info("FES slot capacity: %s %d/%d.\n", item.first.c_str(ctx), item.second,
                 other_bels.count(item.first) ? other_bels.at(item.first) : 0);

    std::vector<std::string> failures;
    if (comb_cells > comb_bels)
        failures.push_back(stringf("%d combinational cells exceed %d usable COMB BELs", comb_cells, comb_bels));
    if (ff_cells > ff_bels)
        failures.push_back(stringf("%d flip-flops exceed %d usable FF BELs", ff_cells, ff_bels));
    if (ctrl_labs > usable_labs)
        failures.push_back(
                stringf("FF control sets need at least %d LABs but %d are usable", ctrl_labs, usable_labs));
    if (input_labs > usable_labs)
        failures.push_back(stringf("LAB input bandwidth needs at least %d LABs but %d are usable", input_labs,
                                   usable_labs));
    if (chains > usable_labs)
        failures.push_back(stringf("%d carry chains exceed %d usable LAB roots", chains, usable_labs));
    if (chain_rows > max_run)
        failures.push_back(stringf("a carry chain spans %d LAB rows but the longest usable column run is %d",
                                   chain_rows, max_run));
    for (const auto &item : other_cells) {
        const int avail = other_bels.count(item.first) ? other_bels.at(item.first) : 0;
        if (item.second > avail)
            failures.push_back(stringf("%d %s cells exceed %d reserved BELs", item.second, item.first.c_str(ctx),
                                       avail));
    }
    if (failures.empty())
        return;
    for (const auto &failure : failures)
        log_nonfatal_error("FES slot capacity (region '%s'): %s.\n", region_name.c_str(ctx), failure.c_str());
    log_error("FES cart does not fit region '%s'; enlarge its FES_RESERVED_RECT or reduce the cart.\n",
              region_name.c_str(ctx));
}

NEXTPNR_NAMESPACE_END
