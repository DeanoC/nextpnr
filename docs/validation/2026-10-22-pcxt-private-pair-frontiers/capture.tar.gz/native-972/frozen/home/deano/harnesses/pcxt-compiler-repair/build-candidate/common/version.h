#ifndef VERSION_H
#define VERSION_H

#define GIT_DESCRIBE_STR "nextpnr-0.11.1-638-g8987a69b"

#endif
