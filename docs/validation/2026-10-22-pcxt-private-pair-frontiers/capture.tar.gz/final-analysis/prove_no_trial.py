#!/usr/bin/env python3
"""Complete artifact identity proof for the recorded zero-trial private4 run."""
from support import ROOT, read, sha, need, paired_receipts, case_folder, write

def main():
    receipts=paired_receipts();a=case_folder('default');b=case_folder('private4')
    artifacts={n:{'matched_control_sha256':sha(a/n),'private4_sha256':sha(b/n),'byte_identical':(a/n).read_bytes()==(b/n).read_bytes()} for n in ('diagnostic.rbf','routed.json','timing.json','endpoints.json')}
    need(all(x['byte_identical'] for x in artifacts.values()),'no-trial route changed artifact bytes')
    lines=[x for x in (b/'nextpnr.log').read_text().splitlines() if 'Critical private pair' in x]
    need(len(lines)==7 and sum(x.startswith('Info: Critical private pair filter: producer=') for x in lines)==5,'decision inventory differs')
    need(lines[-2]=='Info: Critical private pair discovery: negative rows=13 paths=13 bounded producer witnesses=5 eligible groups=0; native path cap=16384, producer cap=64.','discovery differs')
    need(lines[-1]=='Info: Critical private pair: tried=0/4 kept=0; unchanged unsupported coverage is not qualification.','final decision differs')
    graph=read(a/'routed.json');need(set(graph)=={'creator','modules'} and len(graph['modules'])==1,'complete graph schema differs');m=next(iter(graph['modules'].values()))
    result={'status':'pass','scope':'Complete byte-identical no-trial route comparison; no private-pair timing benefit measured','complete_cells':len(m['cells']),'complete_alias_records':len(m['netnames']),'all_four_artifacts':artifacts,'decision_lines':lines,'tried':0,'kept':0,'full_graph_byte_identical':True,'new_route_charge_seconds':receipts['private4']['charged_seconds'],'already_charged_control_seconds':receipts['default']['charged_seconds'],'accounting':read(ROOT/'route-accounting.json')}
    write('no-trial-proof.json',result);print({'status':'pass','cells':len(m['cells']),'aliases':len(m['netnames']),'tried':0,'kept':0})
if __name__=='__main__':main()
