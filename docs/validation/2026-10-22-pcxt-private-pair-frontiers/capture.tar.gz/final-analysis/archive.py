#!/usr/bin/env python3
"""Capture no-trial route and frontier audits with an explicit immutable dependency."""
import gzip,hashlib,io,json,os,shutil,subprocess,sys,tarfile,tempfile
from pathlib import Path
from support import ROOT,HERE,need,read,sha,paired_receipts,reference_folder
CAPTURE=HERE/'capture';SOURCE=CAPTURE/'source'
CPU=ROOT.parent/'lut6-source-coverage-20261022/final-analysis/capture'
EXPECTED_CPU='2b2240ddd347411dc22a695cb5db0e53544b873e75183acf299ebc230101c8f1'
def main():
    need(not CAPTURE.exists(),'capture exists; never overwrite retained evidence')
    receipts=paired_receipts();need(read(HERE/'no-trial-proof.json')['status']=='pass','no-trial proof missing');need(read(HERE/'frontier-proof.json')['status']=='pass','frontier proof missing')
    need(sha(CPU/'capture.tar.gz')==EXPECTED_CPU,'CPU dependency archive identity differs')
    dep=read(CPU/'offline-readback.json');need(dep['status']=='pass' and dep['archive_sha256']==EXPECTED_CPU,'CPU dependency readback differs')
    oldmode=read(CPU/'source/archive-mode.json');recorded={p:{'retained_path':'dependency/cpu/'+v['retained_path'],'sha256':v['sha256']} for p,v in oldmode['recorded_files'].items()}
    SOURCE.mkdir(parents=True);omitted={};local_originals={}
    def retain(original,relative):
        original=Path(original);relative=Path(relative)
        need(original.is_file() and not original.is_symlink(),'not regular '+str(original));need(not relative.is_absolute() and '..' not in relative.parts,'unsafe relative path')
        digest=sha(original);target=SOURCE/relative;target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():need(sha(target)==digest,'retained collision')
        else:shutil.copyfile(original,target)
        if str(original) in recorded:need(recorded[str(original)]['sha256']==digest,'changed original identity')
        else:recorded[str(original)]={'retained_path':str(relative),'sha256':digest}
        local_originals[str(original)]=digest
    def omit(original,reason):
        original=Path(original);need(original.is_file() and not original.is_symlink(),'missing omitted payload')
        omitted[str(original)]={'sha256':sha(original),'size':original.stat().st_size,'reason':reason}
    def folder(original,relative):
        for p in sorted(Path(original).rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:retain(p,Path(relative)/p.relative_to(original))
    for p in sorted(ROOT.iterdir()):
        if p.is_file():retain(p,p.name)
    folder(ROOT/'route-private4','route-private4')
    for p in sorted(HERE.iterdir()):
        if p.is_file() and p.suffix in ('.py','.json','.md','.log'):retain(p,Path('final-analysis')/p.name)
    retain(HERE/'README.md','README.md')
    for name in ('mda','cga'):
        audit=ROOT.parent/(name+'-frontier-audit-20261022')
        for p in sorted(audit.iterdir()):
            if p.is_file():
                if p.name in ('native-probe','probe.o'):omit(p,'Recorded native structural helper/build object; omitted, never executed offline')
                else:retain(p,Path('audits')/name/p.name)
        analysis=read(audit/'analysis.json')
        for original,digest in analysis['inputs'].items():
            need(sha(original)==digest,'audit input changed')
            if original not in recorded:retain(original,Path('audit-inputs')/(digest+'-'+Path(original).name))
    native=ROOT.parent/'cga-native-pin-audit-20261022';frozen=read(native/'frozen-manifest.json')
    retain(native/'frozen-manifest.json','native-972/frozen-manifest.json')
    for item in frozen['files'].values():
        p=native/item['copy'];need(sha(p)==item['sha256'],'frozen native compile input changed')
        if p.suffix in ('.o','.a'):omit(p,'Frozen972 native link object/library; recorded identity only')
        else:retain(p,Path('native-972')/item['copy'])
    for value in receipts.values():
        for original,digest in value['immutable_evidence_sha256'].items():need(original in recorded and recorded[original]['sha256']==digest,'missing immutable route dependency '+original)
        for item in value['inputs'].values():need(item['path'] in recorded and recorded[item['path']]['sha256']==item['sha256'],'missing raw route input')
    mode={'scope':'Offline no-trial route and complete frontier verification; no original-path fallback or native execution',
          'excluded_binary':oldmode['excluded_binary'],'recorded_files':recorded,
          'cases':{'default':'dependency/cpu/route-default','private4':'route-private4'},
          'references':{'route':{'original_directory':str(reference_folder()),'retained_path':'dependency/cpu/references/prior13'}},
          'cpu_capture_dependency':{'archive_sha256':EXPECTED_CPU,'archive_bytes':dep['archive_bytes'],'manifest_sha256':dep['manifest_sha256'],'members':dep['verified_members_including_manifest'],'retained_directory':'dependency/cpu','provided_explicitly_to':'final-analysis/hydrate.py'},
          'native972_original_directory':str(native),'omitted_native_files':omitted,
          'omission_policy':'CPU capture is an explicit hash-bound external dependency, not duplicated. New native helper executables, build objects and frozen link objects/libraries are omitted with exact identities; all audit logs including initial build failure and frozen headers are retained.'}
    (SOURCE/'archive-mode.json').write_text(json.dumps(mode,indent=2,sort_keys=True)+'\n')
    files=[p for p in sorted(SOURCE.rglob('*')) if p.is_file()]
    manifest={str(p.relative_to(SOURCE)):{'sha256':sha(p),'size':p.stat().st_size} for p in files}
    payload=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();(SOURCE/'manifest.json').write_bytes(payload)
    archive=CAPTURE/'capture.tar.gz'
    with archive.open('wb') as stream,gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0,compresslevel=6) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tar:
        for p in files+[SOURCE/'manifest.json']:
            data=p.read_bytes();entry=tarfile.TarInfo(str(p.relative_to(SOURCE)));entry.size=len(data);entry.mode=0o644;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
    need(archive.stat().st_size<100_000_000,'archive exceeds100MB')
    extraction=Path(tempfile.mkdtemp(prefix='pcxt-private-frontier-offline-',dir='/tmp'))
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers();names=[m.name for m in members]
        need(len(names)==len(set(names)) and set(names)==set(manifest)|{'manifest.json'},'exact member inventory differs')
        for m in members:need(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts,'unsafe archive member')
        need(tar.extractfile('manifest.json').read()==payload,'embedded manifest differs')
        for name,info in manifest.items():
            data=tar.extractfile(name).read();need(len(data)==info['size'] and hashlib.sha256(data).hexdigest()==info['sha256'],'archive bytes differ '+name)
        tar.extractall(extraction,filter='data')
    need({str(p.relative_to(extraction)) for p in extraction.rglob('*') if p.is_file()}==set(manifest)|{'manifest.json'},'extraction file inventory differs')
    for name,info in manifest.items():need(sha(extraction/name)==info['sha256'],'extracted bytes differ')
    checks=[]
    commands=[('hydrate.py',[str(CPU/'capture.tar.gz')],[]),('prove_no_trial.py',[],['no-trial-proof.json']),('compare_timing.py',[],['route-comparison.json']),('verify_frontiers.py',[],['frontier-proof.json'])]
    for script,args,outputs in commands:
        expected={n:(extraction/'final-analysis'/n).read_bytes() for n in outputs}
        result=subprocess.run([sys.executable,str(extraction/'final-analysis'/script),*args],cwd='/tmp',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        (CAPTURE/('offline-'+script+'.log')).write_text(result.stdout);need(result.returncode==0,'offline failure '+script+'; retained '+str(extraction))
        for n,b in expected.items():need((extraction/'final-analysis'/n).read_bytes()==b,'proof bytes differ '+n)
        checks.append({'script':script,'returncode':0,'all_proof_bytes_identical':True,'outputs':outputs})
    for original,digest in local_originals.items():need(sha(original)==digest,'original evidence changed')
    for original,info in omitted.items():need(sha(original)==info['sha256'],'omitted native payload changed')
    need(sha(CPU/'capture.tar.gz')==EXPECTED_CPU,'dependency changed during capture')
    result={'status':'pass','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'verified_members_including_manifest':len(manifest)+1,'manifest_sha256':sha(SOURCE/'manifest.json'),'cpu_dependency':mode['cpu_capture_dependency'],'offline_extraction':str(extraction),'checks':checks,'explicit_omitted_native_payloads':len(omitted),'scope':'Exact complete no-trial route comparison and saved frontier/native-receipt verification; no compiler, device-model, timing rerun or hardware acceptance.'}
    (CAPTURE/'offline-readback.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
