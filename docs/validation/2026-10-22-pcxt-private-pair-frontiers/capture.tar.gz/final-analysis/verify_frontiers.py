#!/usr/bin/env python3
"""Reconstruct complete saved frontiers; verify recorded native metadata only."""
from collections import defaultdict
from pathlib import Path
from support import ROOT,HERE,need,read,sha,write,canonical,archive_mode,verify_recorded

def audit_dir(name):return ROOT/'audits'/name if archive_mode() else ROOT.parent/(name+'-frontier-audit-20261022')
def main():
    summaries={}
    frozen_dir=ROOT/'native-972' if archive_mode() else ROOT.parent/'cga-native-pin-audit-20261022'
    frozen=read(frozen_dir/'frozen-manifest.json');headers=0;objects=0
    for original,item in frozen['files'].items():
        path=frozen_dir/item['copy']
        if path.suffix in ('.o','.a'):
            objects+=1
            if archive_mode():
                key=str(Path(archive_mode()['native972_original_directory'])/item['copy'])
                record=archive_mode()['omitted_native_files'][key]
                need(record['sha256']==item['sha256'] and record['size']==item['bytes'],'omitted native object identity differs')
                continue
        else:headers+=1
        need(sha(path)==item['sha256'] and path.stat().st_size==item['bytes'],'native frozen compile surface differs')
    for name in ('mda','cga'):
        folder=audit_dir(name);analysis=read(folder/'analysis.json');receipt=read(folder/'native-receipt.json');native=read(folder/'native-result.json')
        need(sha(frozen_dir/'frozen-manifest.json')==receipt['frozen_manifest_sha256'],'frozen manifest binding differs')
        need({k:v for k,v in frozen.items() if k!='files'}==receipt['frozen_native_identity'],'native model identity differs')
        if archive_mode():
            helper=archive_mode()['omitted_native_files'][receipt['run_command'][0]]
            need(helper['sha256']==receipt['binary_sha256'],'omitted native helper identity differs')
        else:need(sha(folder/'native-probe')==receipt['binary_sha256'],'native helper identity differs')
        need(sha(folder/'analyze.py')==analysis['script_sha256'],'analysis script identity')
        need(sha(folder/'probe.cc')==receipt['source_sha256'] and sha(folder/'run-probe.py')==receipt['script_sha256'],'native probe source identity')
        need(sha(folder/'native-result.json')==receipt['result_sha256'],'native result identity')
        for path,digest in analysis['inputs'].items():verify_recorded(path,digest)
        graph=read(verify_recorded(receipt['input'],receipt['input_sha256']))
        endpoints=[verify_recorded(p,d) for p,d in analysis['inputs'].items() if p.endswith('/endpoints.json')];need(len(endpoints)==1,'endpoint input ambiguity');ledger=read(endpoints[0])
        need(len(graph['modules'])==1,'module count');m=next(iter(graph['modules'].values()));cells=m['cells'];users=defaultdict(list);drivers=defaultdict(list);aliases=defaultdict(list);public=defaultdict(list);alias_bits={}
        for n,v in m['netnames'].items():
            for lane,b in enumerate(v['bits']):aliases[b].append({'name':n,'lane':lane,'complete_net_record':v})
            if len(v['bits'])==1:alias_bits[n]=v['bits'][0]
        for n,v in m['ports'].items():
            for lane,b in enumerate(v['bits']):public[b].append({'name':n,'lane':lane,'complete_port_record':v})
        for n,c in cells.items():
            for p,bs in c['connections'].items():
                for lane,b in enumerate(bs):(drivers if c['port_directions'][p]=='output' else users)[b].append((n,p,lane))
        p,c=analysis['producer'],analysis['consumer']
        if name=='mda':
            need(cells[p]['type']=='MISTRAL_ALUT3' and cells[c]['type']=='MISTRAL_ALUT5','pair types');link=cells[p]['connections']['Q'][0];need(users[link]==[(c,next(pin for pin,bits in cells[c]['connections'].items() if bits==[link]),0)],'private pair link')
            roots={b for cell in (p,c) for pin,bs in cells[cell]['connections'].items() if cells[cell]['port_directions'][pin]=='input' for b in bs}-{link};need(len(roots)==7,'seven external signals');roots.add(cells[c]['connections']['Q'][0])
        else:roots={b for bs in cells[p]['connections'].values() for b in bs};need(p==c and len(roots)==4,'CGA root inventory')
        recorded={f['root']:f for f in analysis['frontiers']};need(set(recorded)==roots,'complete root inventory')
        native_roots={alias_bits[f['root']]:f for f in native['frontiers']};need(len(native_roots)==len(native['frontiers']) and set(native_roots)==roots,'native root inventory')
        union=set();empty=set()
        for root in sorted(roots):
            seen=set();visiting=set();captures=set();dead=[]
            def walk(bit,path):
                need(bit not in visiting,'cycle in saved graph')
                if bit in seen:return
                seen.add(bit);visiting.add(bit);need(len(seen)<=4096,'saved frontier bound')
                if not users[bit] or public[bit] or not drivers[bit]:
                    dead.append({'bit':bit,'path':path,'aliases':aliases[bit],'drivers':drivers[bit],'all_users':users[bit],'public_ports':public[bit],'driver_cells':{n:cells[n] for n,p,i in drivers[bit]}})
                    if not users[bit]:empty.add(bit)
                else:
                    for n,pin,lane in users[bit]:
                        cell=cells[n];step=path+[{'cell':n,'input':pin,'lane':lane}]
                        if cell['type'] in ('MISTRAL_ALUT2','MISTRAL_ALUT3','MISTRAL_ALUT4','MISTRAL_ALUT5','MISTRAL_ALUT6','MISTRAL_ALUT_ARITH','MISTRAL_BUF'):
                            for op,bs in cell['connections'].items():
                                if cell['port_directions'][op]=='output':
                                    for ol,ob in enumerate(bs):walk(ob,step+[{'cell':n,'output':op,'lane':ol}])
                        elif cell['type'] in ('MISTRAL_FF','MISTRAL_M10K'):captures.add((n,pin if len(cell['connections'][pin])==1 else pin+'['+str(lane)+']'))
                        else:raise ValueError('unsupported saved observer '+n)
                visiting.remove(bit)
            walk(root,[]);rows=[]
            for endpoint in sorted(captures):
                keys=[k for k in ledger['endpoints'] if read_identity(k)==list(endpoint)];need(len(keys)==1,'complete capture identity')
                rows.append({'endpoint':endpoint,'complete_native_saved_rows':ledger['endpoints'][keys[0]]})
            expected={'root':root,'aliases':aliases[root],'visited_nets':len(seen),'capture_count':len(captures),'captures':rows,'rejecting_structural_boundaries':dead,'unknown_observers':[],'cycles':[]}
            need(canonical(expected)==canonical(recorded[root]),'complete reconstructed frontier differs')
            nf=native_roots[root];actual={alias_bits[n['net']]:n for n in nf['nets']}
            need(len(actual)==len(nf['nets']) and set(actual)==seen,'native complete visited net inventory differs')
            need({tuple(x) for x in nf['native_capture_identities']}==captures,'native capture identities differ')
            boundaries={alias_bits[n['net']]:n for n in nf['rejecting_boundaries']};need(set(boundaries)=={x['bit'] for x in dead},'native boundaries differ')
            for bit,n in actual.items():
                need(len(drivers[bit])==1,'native driver ambiguity');driver,port,lane=drivers[bit][0];cell=cells[driver];nativeport=port if len(cell['connections'][port])==1 else port+'['+str(lane)+']'
                need(n['driver']==driver and n['driver_type']==cell['type'] and n['driver_port']==nativeport and n['driver_backreference'],'native exact driver differs')
                need(n['users']==len(users[bit]) and sorted(n['public_ports'])==sorted({p['name'] for p in public[bit]}),'native observer inventory differs')
                route_values={a['complete_net_record'].get('attributes',{}).get('ROUTING','') for a in aliases[bit]};need(len(route_values)==1,'routing aliases disagree')
                route=next(iter(route_values));need(isinstance(route,str),'nonstring route');route='' if route==' ' else route;need(not route or len(route.split(';'))%3==0,'malformed saved tree')
                need(n['route_wire_count']==(len(route.split(';'))//3 if route else 0),'native route wire count differs')
                if bit in boundaries:
                    need(n['driver_type']=='MISTRAL_ALUT_ARITH' and n['driver_port'] in ('SO','CO') and n['driver_timing_class']==5 and n['driver_clock_count']==0,'unmodeled unused leaf')
                    need(n['users']==0 and n['route_wire_count']==0 and not n['global'] and not n['clock_constraint'] and not n['public_ports'],'leaf is observed or routed')
            union.update(captures)
        need(sorted(empty)==analysis['empty_output_bits'] and canonical(sorted(union))==canonical(analysis['all_capture_identities']),'complete union differs')
        allrows=[r for e in union for k,rs in ledger['endpoints'].items() if read_identity(k)==list(e) for r in rs]
        need(all(r['setup_timed'] and r['hold_related'] for r in allrows),'unrelated or untimed captured rows')
        metrics={'count':len(allrows),'minimum_setup_ps':min(r['setup'] for r in allrows),'minimum_hold_ps':min(r['hold'] for r in allrows),'negative_setup_count':sum(r['setup']<0 for r in allrows)}
        need(metrics==analysis['capture_rows'],'capture metrics differ')
        summaries[name]={'complete_roots':len(roots),'complete_capture_identities':len(union),'unused_arithmetic_leaves':len(empty),'capture_rows':metrics,'analysis_sha256':sha(folder/'analysis.json'),'native_receipt_sha256':sha(folder/'native-receipt.json'),'native_result_sha256':sha(folder/'native-result.json')}
    result={'status':'pass','scope':'Complete offline saved graph frontier reconstruction and recorded native structural identity checks; no native execution, new STA, eligibility override or timing acceptance','audits':summaries,'native_frozen_headers':headers,'native_recorded_link_objects':objects,'native_manifest_sha256':sha(frozen_dir/'frozen-manifest.json'),'checker_sha256':sha(Path(__file__))}
    write('frontier-proof.json',result);print(canonical(result))
def read_identity(key):
    import json
    return json.loads(key)
if __name__=='__main__':main()
