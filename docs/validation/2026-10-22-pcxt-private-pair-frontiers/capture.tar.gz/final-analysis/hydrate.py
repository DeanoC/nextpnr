#!/usr/bin/env python3
"""Install the exact explicit CPU-capture dependency; no original-path fallback."""
import hashlib,json,sys,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent

def need(value,message):
    if not value: raise ValueError(message)
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def main():
    need(len(sys.argv)==2,'usage: hydrate.py /explicit/path/to/cpu-capture.tar.gz')
    dependency=json.loads((ROOT/'archive-mode.json').read_text())['cpu_capture_dependency']
    archive=Path(sys.argv[1]);need(sha(archive)==dependency['archive_sha256'],'wrong CPU capture dependency')
    relative=Path(dependency['retained_directory']);need(not relative.is_absolute() and '..' not in relative.parts,'unsafe dependency directory')
    dest=ROOT/relative
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers();names=[m.name for m in members]
        need(len(names)==len(set(names)),'duplicate dependency member')
        for m in members:
            p=Path(m.name);need(m.isfile() and not p.is_absolute() and '..' not in p.parts,'unsafe dependency member')
        payload=tar.extractfile('manifest.json').read();need(hashlib.sha256(payload).hexdigest()==dependency['manifest_sha256'],'dependency manifest identity differs')
        manifest=json.loads(payload);need(set(names)==set(manifest)|{'manifest.json'},'dependency exact member inventory differs')
        need(len(names)==dependency['members'],'dependency member count differs')
        for n,item in manifest.items():
            value=tar.extractfile(n).read();need(len(value)==item['size'] and hashlib.sha256(value).hexdigest()==item['sha256'],'dependency member differs: '+n)
        if not dest.exists():
            dest.mkdir(parents=True);tar.extractall(dest,filter='data')
    need({str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file()}==set(manifest)|{'manifest.json'},'installed dependency inventory differs')
    need(sha(dest/'manifest.json')==dependency['manifest_sha256'],'installed dependency manifest differs')
    for n,item in manifest.items():need(sha(dest/n)==item['sha256'] and (dest/n).stat().st_size==item['size'],'installed dependency member differs: '+n)
    print(json.dumps({'status':'pass','dependency_sha256':dependency['archive_sha256'],'members':len(manifest)+1},sort_keys=True))
if __name__=='__main__':main()
