#!/usr/bin/env python3
"""One fresh private-pair route, matched to the frozen same-binary default."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, subprocess, time
ROOT=Path(__file__).resolve().parent
CPU=ROOT.parent/'lut6-source-coverage-20261022'
TASK=ROOT.parent.parent

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def preflight():
 spec=importlib.util.spec_from_file_location('frozen_cpu_route',CPU/'route.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 command,inputs,committed,validation=m.preflight()
 control=read(CPU/'route-default/receipt.json')
 assert control['returncode'] in (0,1) and control['nextpnr_command']==command
 assert control['binary_sha256']==committed['binary_sha256'] and control['inputs']==inputs
 for n,h in control['artifacts'].items():assert sha(CPU/'route-default'/n)==h
 assert {'routed.json','diagnostic.rbf','timing.json','endpoints.json'}<=set(control['artifacts'])
 cli=read(ROOT/'cli.receipt.json');assert cli['returncode']==0 and cli['binary_sha256']==control['binary_sha256']
 assert sha(ROOT/'cli.log')==cli['log_sha256'] and sha(ROOT/'routed_private_pair_cli.py')==cli['test_script_sha256']
 assert 'Ran 6 tests in' in (ROOT/'cli.log').read_text() and (ROOT/'cli.log').read_text().rstrip().endswith('OK')
 prior=validation['prior_validation'];assert prior['private_pair_native_count']==77 and prior['private_pair_cli_count']==6 and prior['rerun_on_this_binary'] is False
 preserved=read(CPU/'retained-source-proof.json')['unchanged_source_files']
 for name in ['mistral/private_pair_decomposition.cc','mistral/private_pair_decomposition.h','mistral/private_pair_decomposition_native.h','mistral/tests/routed_private_pair_backend.cc','mistral/tests/routed_private_pair_cli.py']:
  assert preserved[name]==validation['source_files'][name]==sha(CPU/'complete-source'/name)
 assert not any('lut6-swap' in x or 'private-pair' in x or 'move-route' in x for x in command)
 return command+['--critical-private-pair-budget','4'],inputs,committed,validation,control,cli

def main(check):
 command,inputs,committed,validation,control,cli=preflight()
 if check:print('Frozen private4 preflight passed; no route launched.');return
 target=ROOT/'route-private4';target.mkdir(exist_ok=False)
 wrapped=[str(TASK/'scripts/gpu-run'),'--phase-lease','--owner','pcxt-timing','--label','pcxt-routed-private4','--',*command]
 env={'NEXTPNR_REQUIRE_GPU':'1','GPU_LEASE_MAX_PER_OWNER':'2'}
 immutable={str(p):sha(p) for p in [Path(__file__),ROOT/'cli.receipt.json',ROOT/'cli.log',ROOT/'routed_private_pair_cli.py',CPU/'source-identity.json',CPU/'final-validation.json',CPU/'committed-source-verification.json',CPU/'retained-source-proof.json',CPU/'route-default/receipt.json']}
 receipt={'command':wrapped,'nextpnr_command':command,'inputs':inputs,'binary_sha256':committed['binary_sha256'],'committed_source_verification':committed,'final_validation':validation,'cli_validation':cli,'matched_control':{'path':str(CPU/'route-default'),'receipt_sha256':sha(CPU/'route-default/receipt.json')},'immutable_evidence_sha256':immutable,'env':env,'recipe':'original raw synthesis seed1/native hard-block windows/correct spreading/overflow17/route32 plus private-pair4; LUT6 swap and move disabled','evidence':'fresh leased GPU host diagnostic; no production timing or hardware qualification','native_suite_provenance':'77 native private-pair tests retained at972 with exact unchanged implementation; six CLI tests rerun on this frozen binary'}
 t=time.monotonic()
 with (target/'nextpnr.log').open('w') as f:receipt['returncode']=subprocess.run(wrapped,cwd=target,env=dict(os.environ,**env),stdout=f,stderr=subprocess.STDOUT).returncode
 receipt['charged_seconds']=time.monotonic()-t
 for p,h in immutable.items():assert sha(p)==h
 for item in inputs.values():assert sha(item['path'])==item['sha256']
 assert sha(command[0])==receipt['binary_sha256']
 receipt['artifacts']={p.name:sha(p) for p in sorted(target.iterdir()) if p.is_file()}
 (target/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'returncode':receipt['returncode'],'charged_seconds':receipt['charged_seconds']}),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--check-only',action='store_true');main(p.parse_args().check_only)
