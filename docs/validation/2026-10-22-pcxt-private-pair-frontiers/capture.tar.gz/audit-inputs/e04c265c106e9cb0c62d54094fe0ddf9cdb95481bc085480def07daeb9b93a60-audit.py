#!/usr/bin/env python3
"""Read-only saved-graph audit of a prospective local MDA rewrite, not a native trial."""
from pathlib import Path
import collections, copy, hashlib, importlib.util, json, re, subprocess

R = Path(__file__).resolve().parent
OUT = R.parent
COMPILER = Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
PAIR_ROOT = OUT / 'private-pair-20261022'
REFERENCE = OUT / 'post-route-checkpoint-20261022/route-only'

def need(ok, text):
    if not ok:
        raise ValueError(text)

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

def write(path, obj):
    path.write_text(json.dumps(obj, sort_keys=True, indent=2) + '\n')

def main():
    proof_path = PAIR_ROOT / 'analysis/prove.py'
    spec = importlib.util.spec_from_file_location('frozen_pair_proof', proof_path)
    proof = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(proof)
    P, C = proof.PRODUCER, proof.CONSUMER
    PAIR = {P, C}
    inputs = [REFERENCE / 'routed.json', REFERENCE / 'endpoints.json', REFERENCE / 'receipt.json',
              PAIR_ROOT / 'prepare-selected-0/placed.json', PAIR_ROOT / 'prepare-selected-0/receipt.json',
              PAIR_ROOT / 'analysis/logical-proof.json', proof_path]
    hashes = {str(path): sha(path) for path in inputs}
    for folder in [REFERENCE, PAIR_ROOT / 'prepare-selected-0']:
        receipt = read(folder / 'receipt.json')
        for name, digest in receipt['artifacts'].items():
            need(sha(folder / name) == digest, 'receipt artifact mismatch: ' + name)
    original = proof.read(REFERENCE / 'routed.json')
    selected = proof.read(PAIR_ROOT / 'prepare-selected-0/placed.json')
    a = original['modules']['top']
    b = selected['modules']['top']
    cells = a['cells']
    drivers, users = proof.edge_map(a)
    aliases = collections.defaultdict(list)
    candidate_aliases = collections.defaultdict(list)
    for module, target in [(a, aliases), (b, candidate_aliases)]:
        for name, net in sorted(module['netnames'].items()):
            for index, bit in enumerate(net['bits']):
                if type(bit) is int:
                    target[bit].append([name, index])
    pair_bits = {bit for name in PAIR for values in cells[name]['connections'].values() for bit in values}
    need(all(aliases[bit] == candidate_aliases[bit] for bit in pair_bits), 'pair source alias classes differ')
    proposed = copy.deepcopy(original)
    for name in PAIR:
        target = proposed['modules']['top']['cells'][name]
        source = b['cells'][name]
        need(cells[name]['attributes']['NEXTPNR_BEL'] == source['attributes']['NEXTPNR_BEL'], 'pair BEL changed')
        for field in ['parameters', 'connections']:
            target[field] = copy.deepcopy(source[field])
        target['attributes']['FES_PINMAP_V1'] = source['attributes']['FES_PINMAP_V1']
    proposed_cells = proposed['modules']['top']['cells']
    composed = proof.prove(original, proposed)
    composed['scope'] = 'Prospective saved-graph plan built on original best13 native maps. No Context mutation, route, or timing run.'
    write(R / 'prospective-full-graph-proof.json', composed)
    nd, nu = proof.edge_map(proposed['modules']['top'])
    need(drivers == nd, 'driver changed')

    def port_name(name, port, lane):
        pins = proof.pins(cells[name])
        if port in pins:
            need(lane == 0, 'ambiguous scalar pin')
            return port
        scalar = port + '[' + str(lane) + ']'
        need(scalar in pins, 'missing scalar physical pin')
        return scalar

    def endpoint(cell_map, use):
        name, port, lane = use
        cell = cell_map[name]
        scalar = port_name(name, port, lane)
        return {'cell': name, 'port': scalar, 'port_group': port, 'lane': lane,
                'type': cell['type'], 'BEL': cell['attributes'].get('NEXTPNR_BEL'),
                'pin_state_and_physical_pins': proof.pins(cell)[scalar]}

    def physical_key(ep):
        return ep['BEL'], tuple(ep['pin_state_and_physical_pins'][1:])

    def route_records(bit):
        found = []
        for name, lane in aliases[bit]:
            net = a['netnames'][name]
            route = net['attributes'].get('ROUTING')
            if route is None:
                continue
            need(len(net['bits']) == 1, 'non-scalar ROUTING attribute')
            parts = route.split(';')
            need(len(parts) % 3 == 0, 'malformed saved route')
            records = sorted([parts[i], parts[i + 1], int(parts[i + 2])] for i in range(0, len(parts), 3))
            need(len({row[0] for row in records}) == len(records), 'duplicate saved wire')
            found.append((name, route, records))
        need(found and all(row[2] == found[0][2] for row in found), 'missing/inconsistent aliased route')
        return {'all_route_attribute_aliases': [row[0] for row in found],
                'raw_route_sha256_by_alias': {row[0]: hashlib.sha256(row[1].encode()).hexdigest() for row in found},
                'complete_saved_wire_pip_strength_records': found[0][2],
                'saved_root_records': [row for row in found[0][2] if not row[1]]}

    link = cells[P]['connections']['Q'][0]
    output = cells[C]['connections']['Q'][0]
    frontier = sorted(pair_bits - {link, output})
    need(len(frontier) == 7, 'wrong frontier')
    nets = []
    physically_changed = []
    for bit in frontier + [link, output]:
        old_pair = [use for use in users[bit] if use[0] in PAIR]
        new_pair = [use for use in nu[bit] if use[0] in PAIR]
        stationary = [use for use in users[bit] if use[0] not in PAIR]
        need(stationary == [use for use in nu[bit] if use[0] not in PAIR], 'stationary users changed')
        changed = bool(old_pair) and physical_key(endpoint(cells, old_pair[0])) != physical_key(endpoint(proposed_cells, new_pair[0]))
        if changed:
            physically_changed.append(bit)
        nets.append({'bit': bit, 'aliases': aliases[bit], 'drivers': [endpoint(cells, use) for use in drivers[bit]],
                     'all_original_users': [endpoint(cells, use) for use in users[bit]],
                     'all_proposed_users': [endpoint(proposed_cells, use) for use in nu[bit]],
                     'pair_use_before': [endpoint(cells, use) for use in old_pair],
                     'pair_use_after': [endpoint(proposed_cells, use) for use in new_pair],
                     'stationary_users': [endpoint(cells, use) for use in stationary],
                     'changed_physical_pair_sink': changed, 'route': route_records(bit)})
    need(len(physically_changed) == 6, 'unexpected physical footprint')

    affected = {proof.alm(cells[name]) for name in PAIR}
    lab_snapshot = json.loads(bytes.fromhex(a['attributes']['FES_LABSTATE_V1']))
    occupants = []
    masks = []

    def physical_half(cell):
        mapping = proof.pins(cell)
        width = int(cell['type'].removeprefix('MISTRAL_ALUT'))
        half = int(cell['attributes']['NEXTPNR_BEL'].rsplit('.', 1)[1]) % 6
        need(half in [0, 1], 'wrong LUT half')
        positions = {'A': 0, 'B': 1, 'D' if half else 'C': 2, 'E1' if half else 'E0': 3, 'F1' if half else 'F0': 4}
        logical = int(cell['parameters']['LUT'], 2)
        table = []
        for address in range(32):
            row = 0
            for index in range(width):
                state, physical = mapping[chr(65 + index)]
                need(state in [0, 3] and physical in positions, 'unsupported physical LUT pin')
                row |= (((address >> positions[physical]) & 1) ^ int(state != 3)) << index
            table.append(1 ^ ((logical >> row) & 1))
        return half, sum(value << index for index, value in enumerate(table)), table

    for where in sorted(affected):
        names = sorted(name for name, cell in cells.items() if proof.alm(cell) == where)
        shared = []
        occupancy = []
        for name in names:
            old, new = cells[name], proposed_cells[name]
            is_lut = re.fullmatch(r'MISTRAL_ALUT[2-5]', old['type']) is not None
            record = {'cell': name, 'pair': name in PAIR, 'complete_original_cell': old,
                      'complete_proposed_cell': new, 'native_pinmap_before': proof.pins(old),
                      'planned_pinmap_after': proof.pins(new), 'same_complete_cell': old == new}
            if name not in PAIR:
                need(old == new, 'stationary occupant changed')
                need(proof.pins(old) == proof.pins(b['cells'][name]), 'preparation native stationary map differs')
            if is_lut:
                half, old_mask, old_table = physical_half(old)
                new_half, new_mask, new_table = physical_half(new)
                need(half == new_half, 'LUT half moved')
                record['derived_physical_half_mask'] = {'half': half, 'before_hex': f'{old_mask:08x}', 'after_hex': f'{new_mask:08x}',
                       'before_all32_bits': old_table, 'after_all32_bits': new_table}
                if name not in PAIR:
                    need(old_mask == new_mask, 'stationary mask changed')
                for port, bits in old['connections'].items():
                    if old['port_directions'][port] != 'input':
                        continue
                    occupancy.append({'cell': name, 'port': port, 'physical_before': proof.pins(old)[port][1:],
                                      'physical_after': proof.pins(new)[port][1:], 'net_before': bits[0],
                                      'net_after': new['connections'][port][0]})
            occupants.append(record)
        for phase in ['before', 'after']:
            positions = collections.defaultdict(list)
            for use in occupancy:
                for physical in use['physical_' + phase]:
                    positions[physical].append(use)
            for physical, uses in positions.items():
                need(len({use['net_' + phase] for use in uses}) == 1, 'shared physical pin net conflict')
                if len(uses) > 1:
                    shared.append({'phase': phase, 'physical_pin': physical, 'net': uses[0]['net_' + phase], 'uses': uses})
        snapshots = [entry for entry in lab_snapshot['labs'] if entry[:2] == list(where[:2])]
        need(len(snapshots) == 1 and snapshots[0][2] == 0, 'actual candidate requires regular LAB')
        state = snapshots[0][3]
        alm_state = state[2 + 6 * where[2]:2 + 6 * (where[2] + 1)]
        need(alm_state[:2] == [0, 0], 'LUT6 or carry mode')
        counts = {}
        for phase, cm in [('before', cells), ('after', proposed_cells)]:
            lut_sets = []
            ff_extra = []
            for name in names:
                cell = cm[name]
                if re.fullmatch(r'MISTRAL_ALUT[2-5]', cell['type']):
                    lut_sets.append(set(bit for port, values in cell['connections'].items() if cell['port_directions'][port] == 'input' for bit in values))
                elif cell['type'] == 'MISTRAL_FF':
                    need(not cell['connections']['SDATA'], 'unexpected stationary FF SDATA')
                    mate_half = (int(cell['attributes']['NEXTPNR_BEL'].rsplit('.', 1)[1]) % 6 - 2) // 2
                    mate = [cm[n] for n in names if cm[n]['type'].startswith('MISTRAL_ALUT') and int(cm[n]['attributes']['NEXTPNR_BEL'].rsplit('.', 1)[1]) % 6 == mate_half]
                    need(len(mate) == 1 and cell['connections']['DATAIN'] == mate[0]['connections']['Q'], 'FF DATAIN is not its stationary local LUT')
                    ff_extra.append(0)
            need(len(lut_sets) == 2, 'two LUT occupants expected')
            counts[phase] = sum(map(len, lut_sets)) - min(2, len(lut_sets[0] & lut_sets[1])) + sum(ff_extra)
        need(counts['before'] == counts['after'], 'unique input count changed')
        masks.append({'ALM': list(where), 'serialized_full_LAB_state': snapshots[0],
                      'serialized_this_ALM_modes_and_control_indices': alm_state,
                      'all_LUT_pin_net_occupancy': occupancy, 'shared_physical_pins': shared,
                      'expected_update_alm_input_count': counts})

    endpoints = proof.read(REFERENCE / 'endpoints.json')
    def downstream(start, cm, use_map):
        pending = [start]
        visited = set()
        combinational = set()
        captures = set()
        other = []
        public = []
        while pending:
            bit = pending.pop()
            if bit in visited:
                continue
            visited.add(bit)
            for name, port in a['ports'].items():
                if bit in port['bits']:
                    public.append([name, bit])
            for name, port, lane in use_map[bit]:
                cell = cm[name]
                scalar = port_name(name, port, lane)
                if re.fullmatch(r'MISTRAL_ALUT[2-6]', cell['type']) or cell['type'] in ['MISTRAL_ALUT_ARITH', 'MISTRAL_BUF']:
                    combinational.add(name)
                    for out, values in cell['connections'].items():
                        if cell['port_directions'][out] == 'output':
                            pending.extend(value for value in values if type(value) is int)
                elif cell['type'] in ['MISTRAL_FF', 'MISTRAL_M10K']:
                    captures.add((name, scalar))
                else:
                    other.append([name, scalar, cell['type']])
        rows = []
        for name, port in sorted(captures):
            keys = [key for key in endpoints['endpoints'] if json.loads(key) == [name, port]]
            need(len(keys) <= 1, 'duplicate endpoint identity')
            rows.append({'cell': name, 'port': port, 'type': cells[name]['type'],
                         'original_complete_native_endpoint_rows': endpoints['endpoints'].get(keys[0], []) if keys else [],
                         'native_row_present': bool(keys)})
        return {'start_bit': start, 'visited_nets': len(visited),
                'every_combinational_cell': sorted(combinational),
                'all_structural_capture_boundaries': rows, 'unsupported_structural_cells': other,
                'public_observers': public,
                'scope': 'Static saved-graph reachability and original captured endpoint rows only. Live clock hints, actual timing arcs and before/after eligibility remain untested.'}

    sources = ['mistral/private_pair_decomposition.cc', 'mistral/private_pair_decomposition.h',
               'mistral/private_pair_decomposition_native.h', 'mistral/routed_move.cc',
               'mistral/routed_lut6_swap.cc', 'mistral/routed_lut6_swap_policy.h',
               'mistral/analogue_repair.h', 'mistral/lab.cc', 'mistral/bitstream.cc',
               'mistral/fes_slot.cc', 'mistral/archdefs.h', 'mistral/arch.h', 'mistral/arch.cc',
               'mistral/critical_cohort.h', 'mistral/critical_cohort.cc']
    source_dir = R / 'source-observed'
    source_dir.mkdir(exist_ok=True)
    source_hashes = {}
    for name in sources:
        path = COMPILER / name
        before = sha(path)
        data = path.read_bytes()
        need(hashlib.sha256(data).hexdigest() == before == sha(path), 'source changed during snapshot')
        target = source_dir / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        source_hashes[name] = before
    identity = {'HEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=COMPILER, text=True).strip(),
                'observed_dirty_status': subprocess.check_output(['git', 'status', '--short'], cwd=COMPILER, text=True),
                'exact_files': source_hashes,
                'scope': 'Read-only source observation during frozen CPU LUT6 production tests; not attributed to original best13 binary.'}
    write(R / 'observed-source-identity.json', identity)
    cone_pairs = []
    capture_union = set()
    for bit in physically_changed + [output]:
        before = downstream(bit, cells, users)
        after = downstream(bit, proposed_cells, nu)
        left = {(row['cell'], row['port']) for row in before['all_structural_capture_boundaries']}
        right = {(row['cell'], row['port']) for row in after['all_structural_capture_boundaries']}
        capture_union |= left | right
        cone_pairs.append({'start_bit': bit, 'original': before, 'proposed': after,
                           'complete_capture_inventory_equal': left == right,
                           'removed_captures': sorted(left - right), 'added_captures': sorted(right - left)})
    source_names = sorted({use[0] for bit in frontier for use in drivers[bit]})
    source_cells = {name: {'complete_original_cell': cells[name],
                         'every_connected_pin_alias_class': {port: [aliases[bit] if type(bit) is int else bit for bit in values]
                            for port, values in cells[name]['connections'].items()}}
                    for name in source_names}
    result = {'status': 'saved_graph_plan_proved_native_trial_not_run', 'inputs_sha256': hashes,
              'checker_sha256': sha(Path(__file__)), 'selection': {'candidate_index': 0, 'definition': 2, 'bound': [3, 4, 5]},
              'pair': {'producer': P, 'consumer': C}, 'all_nine_net_boundaries': nets,
              'all_affected_ALM_occupants': occupants, 'ALM_native_snapshot_inventory': masks,
              'complete_frontier_nets': len(frontier), 'external_total_users': sum(len(users[bit]) for bit in frontier),
              'external_stationary_users': sum(sum(use[0] not in PAIR for use in users[bit]) for bit in frontier),
              'physically_changed_nets': physically_changed, 'physically_changed_net_total_users': sum(len(users[bit]) for bit in physically_changed),
              'physically_changed_net_stationary_users': sum(sum(use[0] not in PAIR for use in users[bit]) for bit in physically_changed),
              'complete_external_source_cells_and_clocks': source_cells,
              'downstream_static_coverage_inventories': cone_pairs,
              'all_downstream_capture_boundaries_union': sorted(capture_union),
              'physical_half_scope': 'Independent equations over all32 physical addresses per half from actual saved pin state, using observed native input/output inversion convention. Not a compute_lut_mask invocation, RBF decode, or native selector proof.',
              'route_scope': 'Complete serialized wire/pip/strength inventory retained; no new native topology interpretation or routing invocation.',
              'selector_limits': 'FES_LABSTATE_V1 retains aclr_used and per-ALM modes/control indices. It does not retain all sel_ef/ff_in/control wires, RBF selectors, native ArchCellInfo, or indexed user slots. A live transaction must snapshot and validate those separately.',
              'no_compiler_source_edit_build_route_or_hardware': True}
    for path in inputs:
        need(sha(path) == hashes[str(path)], 'input changed during audit')
    write(R / 'inventory.json', result)
    print(json.dumps({'status': result['status'], 'changed_physical_nets': len(physically_changed),
                      'stationary_users_on_changed_nets': result['physically_changed_net_stationary_users'],
                      'occupants': len(occupants), 'truth_rows': len(composed['all128_rows'])}, indent=2))

if __name__ == '__main__':
    main()
