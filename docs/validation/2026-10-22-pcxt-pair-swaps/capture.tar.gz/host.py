import pathlib,shutil,json,subprocess,time,hashlib
root=pathlib.Path('/tmp/pcxt-pair-final-20261022')
bin=root/'nextpnr-mistral'

source=pathlib.Path('/tmp/pcxt-cpu-locality-20261022')
shutil.copy2(source/'placed.json',root/'input.json')
shutil.copy2(source/'address-focus/guidance.json',root/'guidance.json')
args=json.loads((source/'host-command.json').read_text())
for key in ['--critical-cohort-budget','--critical-cohort-report']:
 i=args.index(key);del args[i:i+2]
args[0]=str(bin);args[args.index('--json')+1]=str(root/'input.json')
args+=['--no-pack','--no-place','--critical-cohort-report',str(root/'guidance.json')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,budget in [('baseline',0),('candidate',32)]:
 out=root/name;out.mkdir()
 cmd=args+['--critical-swap-budget',str(budget)]+(['--critical-swap-pairs'] if budget else [])
 if not budget:
  i=cmd.index('--critical-cohort-report');del cmd[i:i+2]
 record=dict(argv=cmd,hashes={p.name:sha(p) for p in [bin,root/'input.json',root/'guidance.json']},route_seconds=0,hardware=False)
 (out/'invocation.json').write_text(json.dumps(record,indent=2)+'\n')
 start=time.monotonic()
 try:
  with (out/'nextpnr.log').open('w') as f:r=subprocess.run(cmd,cwd=out,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  record['returncode']=r.returncode
 except subprocess.TimeoutExpired:record['timeout']=True
 record['elapsed_seconds']=time.monotonic()-start
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 print(name,json.dumps(record),flush=True)
 if record.get('returncode')!=0:break
