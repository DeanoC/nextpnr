from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parent
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def unique(xs):
 d={}
 for k,v in xs:
  assert k not in d,k
  d[k]=v
 return d
def read(p):return json.loads(p.read_text(),object_pairs_hook=unique)
m=read(R/'manifest.json')
for name,h in m.items():assert sha(R/name)==h,name
v=read(R/'final-validation.json');assert v['validation']['passed'] and v['enabled_lut6_route_admission'] is False
for name,h in v['files'].items():assert sha(R/name)==h,name
s=read(R/'source-identity.json');c=read(R/'source-commit-check.json')
assert s['source_files']==v['source_files']==c['source_files'] and c['all_recorded_source_bytes_match_commit']
assert c['commit']=='972d8ea681c66daeaa3a77749582d49dfc6d7cdc'
for name,h in s['source_files'].items():assert sha(R/'source-validation/source'/name)==h,name
for name,count in [('native-final.log',8),('lut6-native-final.log',33),('private-pair/native-final.log',77)]:
 text=(R/'source-validation'/name).read_text();assert re.search(r'\[  PASSED  \] '+str(count)+r' tests\.',text),name
assert '[  PASSED  ] 0 tests.' in (R/'source-validation/old-test.log').read_text()
assert '8 FAILED TESTS' in (R/'source-validation/old-test.log').read_text()
for name in ['lut6-cli-final.log','private-pair/cli-combined-final.log']:
 text=(R/'source-validation'/name).read_text();assert re.search(r'Ran 6 tests in .*\n\nOK\n',text),name
old=read(R/'source-validation/diagnosis/native-probe.json');new=read(R/'source-validation/fixed-probe.json')
assert new['placed']==old['placed']
assert new['after_lab_pre_route']==new['after_cache_refresh']==old['after_cache_refresh']
assert len(old['after_lab_pre_route']['all_ff_cache_mismatches'])==1949
for key in ['illegal_lab_count','illegal_alm_count','overfull_lab_count']:assert new['after_lab_pre_route'][key]==0
assert new['after_lab_pre_route']['all_ff_cache_mismatches']==[]
a,b,p=[read(R/name/'placed.json') for name in ['prepare-default','prepare-zero','prior461']]
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
assert a.keys()==b.keys()==p.keys() and set(a)=={'creator','modules'} and a['modules']==b['modules']==p['modules']
assert (R/'prepare-default/predicted-timing.json').read_bytes()==(R/'prepare-zero/predicted-timing.json').read_bytes()==(R/'prior461/predicted-timing.json').read_bytes()
print(json.dumps({'status':'pass','verified_members':len(m),'source_files':len(s['source_files']),'cache_old_failed':8,'cache_fixed_passed':8,'lut6_native_passed':33,'private_pair_native_passed':77,'cli_passed':[6,6],'full_board_cache_fix_exact':True,'controls_exact':True,'enabled_lut6_route_admission':False,'route_charge':0,'hardware':False},sort_keys=True))
