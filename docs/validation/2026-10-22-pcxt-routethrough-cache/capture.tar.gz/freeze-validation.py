#!/usr/bin/env python3
"""Freeze completed host checks; this script never launches a route."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
VALIDATION=ROOT/'source-validation'
PRIVATE=ROOT.parent/'routed-private-pair-20261022'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

identity=json.loads((ROOT/'source-identity.json').read_text())
build=json.loads((PRIVATE/'final-validation-build-identity.json').read_text())
completion=json.loads((PRIVATE/'final-validation.json').read_text())
assert completion['pass'] and completion['sources_and_binaries_unchanged']
assert completion['build_identity_sha256']==sha(PRIVATE/'final-validation-build-identity.json')
assert identity['binary_sha256']==build['binary_sha256']==sha(ROOT/'nextpnr-mistral')
for name,digest in identity['source_files'].items():
    assert digest==sha(VALIDATION/'source'/name),name
    committed_source=subprocess.check_output(['git','show','972d8ea681c66daeaa3a77749582d49dfc6d7cdc:'+name],cwd=REPO)
    assert hashlib.sha256(committed_source).hexdigest()==digest,name
for name,digest in build['source_files'].items():
    assert identity['source_files'][name]==digest,name

counts={}
for record in completion['results']:
    assert record['returncode']==0
    path=Path(record['log']);assert sha(path)==record['log_sha256']
    text=path.read_text()
    if record['name'].endswith('native'):
        count=int(re.search(r'\[==========\] (\d+) tests from .* ran\.',text).group(1))
        assert re.search(r'\[  PASSED  \] '+str(count)+r' tests\.',text)
        assert '[  FAILED  ]' not in text
    else:
        count=int(re.search(r'Ran (\d+) tests? in ',text).group(1))
        assert text.rstrip().endswith('OK')
    counts[record['name']]=count
assert counts=={'cache-native':8,'lut6-native':33,'lut6-cli':6,'private-pair-native':77,'private-pair-cli':6},counts
control=json.loads((ROOT/'control-proof.json').read_text())
assert control['default_zero_raw_bytes_equal']
for record in control['controls']:
    assert record['complete_modules_equal'] and record['all_bytes_except_creator_equal'] and record['predicted_timing_bytes_equal']
    receipt=json.loads((ROOT/('prepare-'+record['case'])/'receipt.json').read_text())
    assert receipt['returncode']==0 and receipt['charged_seconds']==0
    assert receipt['binary_sha256']==identity['binary_sha256']
    for name,digest in receipt['artifacts'].items():assert sha(ROOT/('prepare-'+record['case'])/name)==digest
probe=json.loads((VALIDATION/'fixed-probe-comparison.json').read_text())
assert probe['all_native_FF_data_caches_match_actual_ports']
assert probe['all_LAB_ALM_count_control_and_MLAB_group_predicates_pass']
assert probe['explicit_final_cache_refresh_has_no_observed_effect']
assert probe['fixed_native_result_sha256']==sha(VALIDATION/'fixed-probe.json')
assert probe['input_placed_sha256']==sha(ROOT/'prepare-default/placed.json')
for name in ['final-validation.json','final-validation-build-identity.json','native-final.log','native-final.receipt.json','cli-combined-final.log','cli-combined-final.receipt.json']:
    target=VALIDATION/'private-pair'/name;target.parent.mkdir(exist_ok=True)
    shutil.copyfile(PRIVATE/name,target)
files={}
for path in sorted(VALIDATION.rglob('*')):
    if not path.is_file() or path.suffix in {'.o','.a'} or path.name in {'old-route-through-cache-test','fixed-native-probe'} or 'gtest-include' in path.parts:
        continue
    files[str(path.relative_to(ROOT))]=sha(path)
for name in ['prepare-controls.py','prepare-controls.log','control-proof.json','source-identity.json','freeze-validation.py']:
    files[name]=sha(ROOT/name)
result={
    'scope':'Host-only native cache/rollback/physical-model checks and complete-design no-route controls; no full route or hardware acceptance',
    'binary_sha256':identity['binary_sha256'],'native_test_sha256':build['native_test_sha256'],
    'source_parent':identity['source_parent'],'source_files':identity['source_files'],
    'control_proof_sha256':sha(ROOT/'control-proof.json'),
    'enabled_lut6_route_admission':False,
    'enabled_lut6_route_admission_reason':'Separate existing upstream-origin coverage gap: a combinational input can mix a characterized launch with a missing-clock or ignored origin omitted by native domain propagation. Passing downstream coverage and unchanged global inventory do not establish complete upstream source coverage. A bounded explicit upstream guard and focused negative cases are required before enabling LUT6 repair.',
    'validation':{'passed':True,'cache_regression_count':counts['cache-native'],
                  'lut6_native_count':counts['lut6-native'],'lut6_cli_count':counts['lut6-cli'],
                  'private_pair_native_count':counts['private-pair-native'],
                  'private_pair_cli_count':counts['private-pair-cli'],
                  'old_cache_regression_expected_failures':8,'full_board_native_cache_and_legality_pass':True},
    'files':files,
}
(ROOT/'final-validation.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('final_validation_sha256',sha(ROOT/'final-validation.json'))
