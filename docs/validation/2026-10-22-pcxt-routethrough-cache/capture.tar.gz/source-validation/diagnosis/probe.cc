// Structural route-preparation replay only. No placement, routing or STA.
#include "nextpnr.h"
#include "json_frontend.h"
#include "json11.hpp"
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
USING_NEXTPNR_NAMESPACE
using J=json11::Json;
static std::string name(Context &c, const NetInfo *n) { return n ? n->name.str(&c) : std::string(); }
static J snapshot(Context &c, const std::set<uint32_t> &selected) {
    J::array rows,mismatches; int illegal=0, countbad=0, almbad=0;
    for(uint32_t lab=0;lab<c.labs.size();++lab) {
        auto &l=c.labs[lab]; auto loc=c.getBelLocation(l.alms[0].lut_bels[0]);
        J::array alms; bool legal=true; int total=0;
        bool count=c.check_lab_input_count(lab), mlab=c.check_mlab_groups(lab), controls=c.is_lab_ctrlset_legal(lab);
        if(!count)++countbad;
        for(uint8_t ai=0;ai<10;++ai) {
            auto &a=l.alms[ai]; bool alm=c.is_alm_legal(lab,ai); if(!alm)++almbad;
            J::array cells; total+=a.unique_input_count;
            for(auto bel:{a.lut_bels[0],a.lut_bels[1],a.ff_bels[0],a.ff_bels[1],a.ff_bels[2],a.ff_bels[3]}) {
                auto *cell=c.getBoundBelCell(bel);if(!cell)continue;
                bool valid=c.isBelLocationValid(bel,true);legal&=valid;
                J::object r{{"cell",cell->name.str(&c)},{"type",cell->type.str(&c)},
                            {"bel",c.getBelName(bel).str(&c)},{"strength",int(cell->belStrength)},
                            {"valid",valid}};
                if(cell->type==id_MISTRAL_FF) {
                    r["cached_datain"]=name(c,cell->ffInfo.datain);r["actual_datain"]=name(c,cell->getPort(id_DATAIN));
                    r["cached_sdata"]=name(c,cell->ffInfo.sdata);r["actual_sdata"]=name(c,cell->getPort(id_SDATA));
                    bool mismatch=cell->ffInfo.datain!=cell->getPort(id_DATAIN)||cell->ffInfo.sdata!=cell->getPort(id_SDATA);
                    r["data_cache_mismatch"]=mismatch;if(mismatch)mismatches.push_back(r);
                } else {
                    r["comb_out"]=name(c,cell->combInfo.comb_out);
                    r["used_lut_inputs"]=cell->combInfo.used_lut_input_count;
                    r["lut_bits"]=cell->combInfo.lut_bits_count;
                }
                cells.push_back(r);
            }
            alms.push_back(J::object{{"alm",int(ai)},{"unique_inputs",a.unique_input_count},
                           {"alm_legal",alm},{"cells",cells}});
        }
        if(!legal)++illegal;
        if(selected.count(lab))rows.push_back(J::object{{"lab",int(lab)},{"x",loc.x},{"y",loc.y},
            {"input_count",total},{"count_legal",count},{"controls_legal",controls},{"mlab_groups_legal",mlab},
            {"whole_lab_legal",legal},{"alms",alms}});
    }
    return J::object{{"selected_labs",rows},{"all_ff_cache_mismatches",mismatches},
                     {"illegal_lab_count",illegal},{"overfull_lab_count",countbad},{"illegal_alm_count",almbad}};
}
int main(int argc,char **argv) { try {
    if(argc!=3)throw std::runtime_error("probe placed.json report.json");
    ArchArgs args;args.device="5CSEBA6U23I7";Context c(args);std::ifstream in(argv[1]);
    if(!parse_json(in,argv[1],&c))throw std::runtime_error("parse failed");
    if(c.attrs.at(id_step).as_string()!="place")throw std::runtime_error("requires placed checkpoint");
    c.restore_placed_pin_maps();
    std::set<uint32_t> selected;
    for(const char *n:{"system.machine.cpu.cpu.u_eu_core.u_operand1_mux.lanes[10].combine",
                      "system.machine.cpu.cpu.u_eu_core.eu_alu_out_MISTRAL_ALUT6_Q",
                      "system.machine.cpu.cpu.u_eu_core.eu_alu_out_MISTRAL_ALUT6_Q_2"}) {
        auto *cell=c.cells.at(c.id(n)).get();selected.insert(c.bel_data(cell->bel).lab_data.lab);
    }
    auto before=snapshot(c,selected);
    c.lab_pre_route();
    auto after=snapshot(c,selected);
    // Diagnostic cache refresh only: no port, physical-pin, route, BEL or logical mutation.
    for(auto &entry:c.cells)if(entry.second->type==id_MISTRAL_FF)c.assign_ff_info(entry.second.get());
    for(uint32_t l=0;l<c.labs.size();++l)for(uint8_t a=0;a<10;++a)c.update_alm_input_count(l,a);
    auto refreshed=snapshot(c,selected);
    std::ofstream out(argv[2]);out<<J(J::object{{"scope","native structural replay; no routing or STA"},
        {"placed",before},{"after_lab_pre_route",after},{"after_cache_refresh",refreshed}}).dump()<<"\n";
    return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<"\n";return 1;} }
