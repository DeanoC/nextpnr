# Route-through FF cache diagnosis

The symmetric LUT6 pass reached the intended CPU lane-10 OR6 B/F pair but rejected it before a route trial because the original LAB failed native legality. A standalone structural replay identifies stale FF data caches after route-through insertion as the cause. This is host-only structural evidence, not a new full route, timing report, or physical acceptance.

The immutable `461ce654` default and swap16 artifacts remain unchanged. Both have thirteen setup failures, including the same seven CPU rows; the candidate did not attempt any swap. No conclusion about the timing benefit of a swap follows from that result.

## Native reproduction

`native-probe` loads the exact `461ce654` fresh prepared checkpoint, restores its placed pin states and architecture information, then calls native `lab_pre_route()` once. It does not place, route, configure a bitstream, or run STA. It records each native legality predicate and every FF DATAIN/SDATA cache mismatch. Finally it diagnostically refreshes FF architecture caches and recounts ALM inputs, without changing logical ports, BELs, physical pin mappings, or routes.

The helper links already frozen `692a1c37` objects, avoiding the shared compiler build. `source-equivalence.json` verifies byte equality through `461ce654` for complete `lab.cc`, `fes_slot.cc`, the architecture structures, JSON frontend and base context, plus `isBelLocationValid`, `update_bel`, `assignArchInfo` and `route`. This is a replay using identical relevant native implementation, not an assertion that the helper binary itself is the frozen route binary.

| Replay stage | FF cache mismatches | Illegal LABs | Illegal ALMs | Cached LAB count >42 |
| --- | ---: | ---: | ---: | ---: |
| Original placed checkpoint | 0 | 0 | 0 | 0 |
| After native route preparation | 1,949 | 309 | 411 | 188 |
| After FF cache refresh and recount | 0 | 0 | 0 | 0 |

The CPU OR6 LAB `(15,35)` starts with 42 inputs. Its five inserted BUF helpers leave five FF caches pointing to their old DATAIN nets. The cached input count therefore rises to 47. Every individual ALM, control-set and MLAB-group predicate still passes there; the LAB input-count predicate alone rejects the OR6 candidate. Refreshing the five stale FF caches and recounting restores 42 inputs and native legality.

The other filtered symmetric ALU cells reside in LABs `(10,31)` and `(10,34)`. Their counts become 44 and 45 respectively, versus 42 before insertion and after refresh. Both LABs also fail ALM legality at ALMs 0 and 3: the FF cache treats a newly helper-fed register as still needing an independent fabric DATAIN, although its local BUF already occupies the route-through site and the opposite LUT4/5 reserves the E/F alternative. The same cache correction resolves those predicates without changing the physical allocation.

`graph-correspondence.json` checks all 1,949 stale-cache rows against both original placed and final routed graphs. Every old cached net is the original FF DATAIN and final helper A; every actual DATAIN is the final helper Q; all FF and helper identities, FF BELs, BUF types and empty parameters match. The set equals the complete final `$ROUTETHRU` helper inventory. This binds the replay to the actual routed graph. Original in-memory caches are not serialized in the final JSON, so the replay does not claim to read the now-terminated route process's cache or reproduce its STA.

## Cause and narrow correction

`Arch::reassign_alm_inputs` in `mistral/lab.cc` disconnects/reconnects FF DATAIN, calls `assign_comb_info` on the new helper and binds it, but does not call `assign_ff_info` for the changed register. `bindBel` updates the ALM count using the stale `ffInfo.datain`. `is_alm_legal` uses the same stale pointer. Route preparation has no subsequent architecture refresh.

The narrow fix is to refresh the changed FF's architecture info after the connection rewrite and before helper binding recounts the ALM. This maintains the graph/cache invariant at its mutation site. It does not relax any legality or timing guard. A global post-route `assignArchInfo` is inappropriate: it also overwrites physical LUT pin maps with placement scaffolds.

The existing reload path calls `assignArchInfo`, which refreshes FF caches and recounts all ALMs. Thus this defect supplies a concrete mechanism for a fresh-route versus reload candidate-list discrepancy. Exact old move32 shortlist attribution remains to be verified; the current evidence does not equate its route outcome with a fresh run.

Validation for a production fix should cover both helper halves, ordinary LAB and MLAB tiles, opposite LUT4/5 companions, multiple helper FFs at the 42-input LAB boundary, repeated preparation, exact graph/cache consistency and unchanged physical pin maps/LAB selectors. Fresh default full-route controls are still needed to establish artifact/timing behavior, followed by a new opt-in trial using the same complete guard.

## Reproduction

From the PC/XT task directory:

```sh
python3 out/original-lab-legality-20261022/build-probe.py
out/original-lab-legality-20261022/native-probe \
  out/routed-lut6-swap-20261022/prepare-default/placed.json \
  out/original-lab-legality-20261022/native-probe.json
```

`build-probe.py` verifies every linked frozen object hash before compiling the standalone source. The original failed const-correctness compilation is retained separately. `manifest.json` binds the final helper, source comparison, native result, full graph correspondence, source and input artifacts.
