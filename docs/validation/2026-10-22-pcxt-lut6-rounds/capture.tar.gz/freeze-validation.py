#!/usr/bin/env python3
"""Freeze host admission for bounded fresh discovery; actual round behavior requires paired full routes."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
R=Path(__file__).resolve().parent;F=R/'source-validation';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');OLD=R.parent/'unobserved-arith-coverage-20261022'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
old=read(OLD/'final-validation.json');assert sha(OLD/'final-validation.json')=='b9c15eaddbf4fd3c9c21e8ecf7b80d82b5a816e6140968cdcbefc3c84bfbdc32'
source=read(R/'source-identity.json');build=read(F/'build-identity.json');assert source['base']=='186637013e17461a72cd1d2cd17ca5ef174ed06f'
assert build['source_identity_sha256']==sha(R/'source-identity.json')
assert sha(R/'nextpnr-mistral')==build['production_sha256']=='e1f208fc6aa72910b639f503c0b5fec5140c15e613c715f3e5476ab7c4d706b7'
sources=dict(old['source_files']);sources.update({p:v['sha256'] for p,v in source['files'].items()});assert len(sources)==29 and len(source['files'])==5
for p,h in sources.items():
 origin=R/'source'/p if p in source['files'] else OLD/'complete-source'/p
 assert sha(origin)==h and sha(S/p)==h
 dest=R/'complete-source'/p;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==h
 else:shutil.copy2(origin,dest)
unchanged={p:h for p,h in old['source_files'].items() if p not in source['files']}
for p,h in unchanged.items():assert hashlib.sha256(subprocess.check_output(['git','show',source['base']+':'+p],cwd=S)).hexdigest()==h
write(R/'retained-source-proof.json',{'earlier_commit':source['base'],'earlier_final_validation_sha256':sha(OLD/'final-validation.json'),'unchanged_source_files':unchanged,'scope':'Only current source6/native33/CLI9 reran; all other prior checks retain their original7faa or earlier provenance.'})
prefix=read(R/'unchanged-native-prefix.json');before=(F/'retained-before/mistral/routed_lut6_swap.cc').read_bytes();after=(R/'source/mistral/routed_lut6_swap.cc').read_bytes();marker=prefix['marker'].encode()
assert prefix['before_source_sha256']==hashlib.sha256(before).hexdigest()==old['source_files']['mistral/routed_lut6_swap.cc']
assert prefix['after_source_sha256']==hashlib.sha256(after).hexdigest()==sources['mistral/routed_lut6_swap.cc']
a=before[:before.index(marker)];b=after[:after.index(marker)];assert a==b and len(a)==prefix['complete_prefix_bytes'] and hashlib.sha256(a).hexdigest()==prefix['complete_prefix_sha256']
review=read(R/'draft/reassociate-review.json');assert not review['source_blocker_found'] and review['coverage_helpers_and_transaction_prefix_byte_identical']
assert review['source_identity_sha256']==sha(R/'draft/source-identity.json')
assert set(review['files'])==set(source['files'])
for p,v in review['files'].items():assert v['before']==old['source_files'][p] and v['after']==sources[p]
summary=read(F/'validation.json');assert summary['pass'] and summary['sources_and_binaries_unchanged'] and summary['build_identity_sha256']==sha(F/'build-identity.json')
counts={'source-coverage':6,'lut6-native':33,'lut6-cli':9};assert {x['name'] for x in summary['results']}==set(counts)
for name,n in counts.items():
 receipt=read(F/(name+'.receipt.json'));text=(F/(name+'.log')).read_text();assert receipt['returncode']==0 and receipt['pass'] and receipt['expected_count']==receipt['observed_count']==n and receipt['log_sha256']==sha(F/(name+'.log'))
 if name.endswith('-cli'):assert re.search(r'Ran '+str(n)+r' tests in',text) and re.search(r'\nOK\s*$',text)
 else:
  run=re.findall(r'^\[ RUN      \] (.+)$',text,re.M);ok=re.findall(r'^\[       OK \] (.+) \(\d+ ms\)$',text,re.M);assert len(run)==len(ok)==len(set(run))==n and run==ok
control=read(R/'control-proof.json');assert control['default_round1_raw_bytes_equal'] and sorted(x['case'] for x in control['controls'])==['default','round1']
prior=read(OLD/'prepare-default/receipt.json');old_bytes=(OLD/'prepare-default/placed.json').read_bytes()
for x in control['controls']:
 assert all(x[k] for k in ('complete_modules_equal','all_bytes_except_creator_equal','predicted_timing_bytes_equal'))
 folder=R/('prepare-'+x['case']);receipt=read(folder/'receipt.json');assert receipt['returncode']==0 and receipt['binary_sha256']==build['production_sha256'] and receipt['inputs']==prior['inputs']
 expected=prior['nextpnr_command'][:];expected[0]=receipt['nextpnr_command'][0]
 if x['case']=='round1':expected+=['--critical-lut6-swap-rounds','1']
 assert receipt['nextpnr_command']==expected and '--no-route' in expected and '--rbf' not in expected
 for p,h in receipt['artifacts'].items():assert sha(folder/p)==h
 new_bytes=(folder/'placed.json').read_bytes();old_doc=json.loads(old_bytes);new_doc=json.loads(new_bytes);old_creator=json.dumps(old_doc.pop('creator')).encode();new_creator=json.dumps(new_doc.pop('creator')).encode()
 assert old_doc==new_doc and old_bytes.count(old_creator)==1 and old_bytes.replace(old_creator,new_creator,1)==new_bytes
 assert (folder/'predicted-timing.json').read_bytes()==(OLD/'prepare-default/predicted-timing.json').read_bytes()
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-round1/placed.json').read_bytes()
files={}
for prefix in ('source','source-validation','complete-source','prepare-default','prepare-round1','draft'):
 for p in sorted((R/prefix).rglob('*')):
  if p.is_file() and p.name not in ('nextpnr-mistral','nextpnr-mistral-test'):
   files[str(p.relative_to(R))]=sha(p)
for name in ('source-identity.json','unchanged-native-prefix.json','prepare-controls.py','prepare-controls.log','control-proof.json','retained-source-proof.json','freeze-validation.py'):
 files[name]=sha(R/name)
final={'scope':'Host-only source/native/CLI and complete no-route control validation for bounded fresh LUT6 discovery. Actual additional-round behavior/gain and final complete timing require paired fresh full routes; no hardware acceptance.',
 'binary_sha256':build['production_sha256'],'native_test_sha256':build['native_test_sha256'],'source_parent':source['base'],'source_files':sources,
 'independent_source_review_passed':True,'control_proof_sha256':sha(R/'control-proof.json'),'enabled_lut6_route_admission':True,'enabled_lut6_rounds_route_admission':True,
 'validation':{'passed':True,'source_coverage_count':6,'lut6_native_count':33,'lut6_cli_count':9},
 'coverage_and_transaction_prefix_sha256':sha(R/'unchanged-native-prefix.json'),'source_review_sha256':sha(R/'draft/reassociate-review.json'),
 'analysis_parser_review':{'receipt_sha256':sha(F/'round-parser-review.json'),'scope':'Separate read-only future paired-route parser review; not a production native-test gate or actual route result.'},
 'retained_prior_validation':{'path':str(OLD/'final-validation.json'),'sha256':sha(OLD/'final-validation.json'),'unchanged_source_proof_sha256':sha(R/'retained-source-proof.json'),'rerun_claim':'Only current6/33/9 suites reran. Prior native board admission, private77/permutation45/unused12 and earlier cache gates retain original provenance; all native coverage and transaction helper bytes remain exact.'},'files':files}
assert not (R/'final-validation.json').exists();write(R/'final-validation.json',final);print(sha(R/'final-validation.json'))
