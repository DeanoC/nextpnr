#!/usr/bin/env python3
"""Portable complete graph/timing/tree replay, with no native execution/live paths."""
from pathlib import Path
from decimal import Decimal
import contextlib,hashlib,importlib,io,json,sys,tempfile
R=Path(__file__).resolve().parent;A=R/'final-analysis';sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
assert support.archive_mode() is not None and support.ROOT==R
final=read(R/'final-validation.json');commit=read(R/'committed-source-verification.json')
assert commit['commit']=='5d566b0d0b93cbcb3773e4a2bd6094bbccd80353' and commit['source_files']==final['source_files'] and commit['final_validation_sha256']==sha(R/'final-validation.json')
for n,h in final['files'].items():assert sha(R/n)==h,n
for n,h in final['source_files'].items():assert sha(R/'complete-source'/n)==h,n
assert len(final['files'])==70 and len(final['source_files'])==29
prior=read(R/'references/prior-evidence/final-validation.json')
for n,h in prior['source_files'].items():assert sha(R/'references/prior-source'/n)==h,n
assert prior['binary_sha256']=='7faa854df524d0dd3a69cf90622b589692d2db078c031a36ac2c7a5d0deadf12'
# Default and explicit one-round placement retain every byte, including original creator.
controls=read(R/'control-proof.json');assert controls['default_round1_raw_bytes_equal']
for case in ('default','round1'):
 p=R/('prepare-'+case);q=R/'references/prior-prepare'
 assert (p/'placed.json').read_bytes()==(q/'placed.json').read_bytes()
 assert (p/'predicted-timing.json').read_bytes()==(q/'predicted-timing.json').read_bytes()
 for n,h in read(p/'receipt.json')['artifacts'].items():assert sha(p/n)==h
native=R/'native-topology';build=read(native/'build-receipt.json');compat=read(native/'architecture-compatibility.json')
assert build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
for name,key in [('tree-reader.cc','helper_source_sha256'),('frozen-manifest.json','frozen_manifest_sha256'),('build-commands.json','build_commands_sha256'),('build.log','build_log_sha256')]:assert sha(native/name)==build[key]
assert len(read(native/'frozen-manifest.json')['files'])==401
assert compat['passed'] and compat['route_compiler_commit']==commit['commit'] and compat['reader_compiler_commit']=='186637013e17461a72cd1d2cd17ca5ef174ed06f'
assert compat['reader_binary_sha256']==build['helper_binary_sha256'] and compat['route_source_identity_sha256']==sha(R/'source-identity.json')
for n,v in compat['changed_snapshotted_source_files'].items():
 assert sha(R/'references/prior-source'/n)==v['old_sha256'] and sha(R/'complete-source'/n)==v['new_sha256']
old=(R/'references/prior-source/mistral/arch.h').read_bytes();new=(R/'complete-source/mistral/arch.h').read_bytes()
added=b'    '+compat['arch_header_change'].encode()+b'\n';assert new.count(added)==1 and new.replace(added,b'')==old
prefix=read(R/'unchanged-native-prefix.json')
assert sha(R/'unchanged-native-prefix.json')==compat['unchanged_native_prefix_sha256']
assert (R/'references/prior-source/mistral/routed_lut6_swap.cc').read_bytes()[:32984]==(R/'complete-source/mistral/routed_lut6_swap.cc').read_bytes()[:32984]
review=read(native/'independent-reader-review.json');assert review['passed'] and review['architecture_compatibility_sha256']==sha(native/'architecture-compatibility.json') and review['prepare_script_sha256']==sha(native/'prepare.py')
root=read(native/'root-readback/receipt.json');assert root['passed'] and root['helper_binary_sha256']==build['helper_binary_sha256'] and root['architecture_compatibility_sha256']==sha(native/'architecture-compatibility.json')
assert len(root['rows'])==2 and {v['case'] for v in root['rows']}=={'round1','round2'}
for row in root['rows']:
 case=row['case'];assert row['returncode']==0 and row['independent_native_output_byte_exact']
 assert sha(native/'root-readback'/(case+'-topology.json'))==row['output_sha256']==sha(native/'paired-readback'/(case+'-topology.json'))
 assert sha(native/'paired-readback'/(case+'-selection.json'))==row['selection_sha256']
accounting=read(R/'accounting-40/summary.json');journal=R/'accounting-40/continued-runs.jsonl';records=[json.loads(v) for v in journal.read_text().splitlines()]
assert sha(journal)==accounting['journal_sha256'] and len(records)==accounting['completed_subsequent_receipts']==40
assert len({v['case'] for v in records})==40
assert Decimal(accounting['pre_journal_charge_seconds'])+sum(Decimal(v['charged_seconds_decimal']) for v in records)==Decimal(accounting['cumulative_charge_seconds'])
for case in ['round1','round2']:
 rows=[v for v in records if v['case']=='out/lut6-rounds-20261022/route-'+case];assert len(rows)==1 and rows[0]['receipt_sha256']==sha(R/f'route-{case}/receipt.json')
checks=[]
def compare_write(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs';checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
with contextlib.redirect_stdout(io.StringIO()):
 for name in ['prove_graph','test_checks','verify_topology']:
  m=importlib.import_module(name);m.write=compare_write
  if name=='test_checks':m.ROOT=R/'references'/'fixture-context'
  m.main()
 m=importlib.import_module('native_selection');compare_write('native-selection-specs.json',m.build())
 c=importlib.import_module('compare_timing')
 with tempfile.TemporaryDirectory(prefix='pcxt-rounds-proof-') as scratch:
  c.R=Path(scratch);c.main();assert (c.R/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
 checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
graph=read(A/'graph-proof.json');timing=read(A/'route-comparison.json');topology=read(A/'topology-proof.json')
assert len(timing['every_endpoint_row'])==17199 and timing['native_margin_delta_counts']=={'setup':{'improved':16,'unchanged':17178},'hold':{'unchanged':17194}}
assert timing['endpoint_identity_inventory_equal'] and timing['all_row_domain_windows_and_flags_equal'] and timing['all_metadata_categories_equal']
assert len(graph['accepted_cells'])==1 and len(graph['accepted_cells'][0]['all64_rows'])==64
assert all(v['before_output']==v['after_output'] for v in graph['accepted_cells'][0]['all64_rows'])
assert topology['selected_nets']==7 and topology['stationary_users']==6 and topology['changed_physical_users']==2 and topology['retained_original_wire_tuples']==30
result={'passed':True,'source_commit':commit['commit'],'source_files':29,'host_admission_files':70,'native_snapshot_manifest_members':401,'exact_replays':checks,'complete_endpoint_rows':17199,'native_margin_delta_counts':timing['native_margin_delta_counts'],'all64_truth_rows_equal':True,'native_topology':{k:topology[k] for k in ('selected_nets','stationary_users','changed_physical_users','retained_original_wire_tuples')},'pair_route_charge_seconds_recorded_not_recharged':timing['pair_charge_seconds'],'charged_route_seconds':0,'historical_accounting_context':{'journal_records':40,'cumulative_charge_seconds':accounting['cumulative_charge_seconds'],'scope':'Journal arithmetic and these two receipt hashes checked; other historical routes are context only.'},'scope':'Offline replay of saved full graphs, final timing inventories and recorded native decoded trees. No native execution, GPU route, emitted-RBF mask proof, reload STA or hardware acceptance.'}
print(encoded(result).decode(),end='')
