#!/usr/bin/env python3
"""Capture the completed rounds pair; frozen git blobs, never live build sources."""
from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
C=Path(__file__).resolve().parent;A=C.parent;R=A.parent;P=C/'payload';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def copy(p,n=None):
 dest=P/(n or p.relative_to(R));dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==sha(p),str(dest)
 else:shutil.copy2(p,dest)
 return str(dest.relative_to(P))
assert not P.exists(),'fresh payload required';P.mkdir()
final=read(R/'final-validation.json');assert sha(R/'final-validation.json')=='9ac0361a7ea27b0c4eeabd10cdc409cb809816d05e677aef8b8bc614d526e9c5'
for n,h in final['files'].items():assert sha(R/n)==h;copy(R/n)
for n in ['final-validation.json','committed-source-verification.json','route.py','independent-source-review.json','independent-review-binding.json','verify-and-commit.py','record-runs.py','accounting-40.json','fes-check.log','fes-test-changed.log']:copy(R/n)
commit=read(R/'committed-source-verification.json');assert commit['commit']=='5d566b0d0b93cbcb3773e4a2bd6094bbccd80353'
assert commit['source_files']==final['source_files']
for n,h in final['source_files'].items():
 data=subprocess.check_output(['git','show',commit['commit']+':'+n],cwd=S)
 assert hashlib.sha256(data).hexdigest()==h==sha(P/'complete-source'/n)
for case in ['round1','round2']:
 receipt=read(R/f'route-{case}/receipt.json');assert receipt['binary_sha256']==final['binary_sha256']
 for n,h in receipt['artifacts'].items():assert sha(R/f'route-{case}'/n)==h;copy(R/f'route-{case}'/n)
 copy(R/f'route-{case}/receipt.json')
for p in sorted(A.rglob('*')):
 if p.is_file() and not {'capture','__pycache__'}&set(p.relative_to(A).parts):copy(p)
for p in sorted((R/'native-topology').rglob('*')):
 if p.is_file() and p.name!='tree-reader' and '__pycache__' not in p.parts:copy(p)
for p in sorted((R/'accounting-40').iterdir()):
 if p.is_file():copy(p)
summary=read(P/'accounting-40/summary.json');assert summary['fes_commit']=='785482cca21583ab4964056c8af2ce2ad3402d3b'
assert summary['journal_sha256']==sha(P/'accounting-40/continued-runs.jsonl')
omitted=[]
for p in [R/'nextpnr-mistral',R/'native-topology/tree-reader']:
 omitted.append({'original_path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'reason':'Executable omitted; offline proof replay uses exact recorded artifacts and decoded native trees.'})
write(P/'omitted-payloads.json',{'files':omitted,'native_snapshot_manifest':'native-topology/frozen-manifest.json','native_snapshot_payload':'All 401 frozen source/header/object snapshot members omitted; no offline native execution/rebuild is claimed.'})
# One exact completed archive supplies prior CPU16 control, source and native reader qualification.
dep=R.parent/'unobserved-arith-coverage-20261022/final-analysis-permutation4/capture/capture.tar.gz'
assert sha(dep)=='f5528953a89346e18cd10c1bc30afcf9e7d0b3f7da63d3628b04e8a7f5d6c855'
bindings=[]
with tarfile.open(dep) as t:
 data=t.extractfile('manifest.json').read();m=json.loads(data)
 spec={'archive_sha256':sha(dep),'bytes':dep.stat().st_size,'members':len(t.getmembers()),'manifest_sha256':hashlib.sha256(data).hexdigest(),'manifest_path':'dependencies/prior-manifest.json'}
 assert spec['members']==len(m)+1
 d=P/spec['manifest_path'];d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
 for member in sorted(m):
  target=None
  for prefix,destination in [('route-cpu16/','references/prior-cpu/'),('external-inputs/','external-inputs/'),('prepare-default/','references/prior-prepare/'),('complete-source/','references/prior-source/')]:
   if member.startswith(prefix):target=destination+member[len(prefix):]
  if member in ['final-validation.json','committed-source-verification.json','archive-mode.json','CAPTURE-README.md']:target='references/prior-evidence/'+member
  if member in ['references/prior-cpu/nextpnr.log','references/prior-cpu/routed.json']:target='references/lut6-source-coverage-20261022/route-swap16/'+Path(member).name
  if member.startswith('native-topology/') and ('/reader-validation' in member or '/reader32-validated/' in member or '/initial-build-failed-shadow/' in member):target='references/prior-evidence/'+member
  if target is not None:
   d=P/target;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(t.extractfile(member).read());assert sha(d)==m[member]['sha256']
   bindings.append({'dependency':'prior','member':member,'retained_path':target,'sha256':sha(d)})
 for member in ['native-topology/tree-reader.cc','native-topology/build-receipt.json','native-topology/build-commands.json','native-topology/build.log','native-topology/frozen-manifest.json','native-topology/committed-source-verification.json']:
  assert sha(P/member)==m[member]['sha256'];bindings.append({'dependency':'prior','member':member,'retained_path':member,'sha256':sha(P/member)})
recorded={};receipt=read(R/'route-round1/receipt.json')
for path,h in receipt['immutable_evidence_sha256'].items():
 original=Path(path);target=str(original.relative_to(R)) if original.is_relative_to(R) else 'references/prior-cpu/receipt.json'
 assert sha(P/target)==h;recorded[path]={'retained_path':target,'sha256':h}
for v in receipt['inputs'].values():
 target='external-inputs/'+v['sha256']+'-'+Path(v['path']).name
 assert sha(P/target)==v['sha256'];recorded[v['path']]={'retained_path':target,'sha256':v['sha256']}
prior=str(R.parent/'unobserved-arith-coverage-20261022/route-cpu16')
bindings.sort(key=lambda v:(v['dependency'],v['member'],v['retained_path']))
mode={'recorded_files':recorded,'excluded_binary':{'original_path':receipt['nextpnr_command'][0],'sha256':final['binary_sha256']},'references':{'route':{'original_directory':prior,'retained_path':'references/prior-cpu'}},'dependencies':{'prior':spec},'selected_dependency_members':bindings,'scope':'No live-path fallback. Complete prior archive hashes are verified. Its historical transitive dependency identities remain retained context; those older archives are not rerun or fetched.'}
write(P/'archive-mode.json',mode)
for n in ['prepare.py','replay.py','replay_review.py','verify_capture.py','build_archive.py','README.md']:copy(C/n,'CAPTURE-README.md' if n=='README.md' else n)
if (C/'initial-replay-error.log').exists():copy(C/'initial-replay-error.log','capture-initial-replay-error.log')
print(json.dumps({'files':len([p for p in P.rglob('*') if p.is_file()]),'source_files':len(final['source_files']),'dependencies':mode['dependencies']},indent=2,sort_keys=True))
