#!/usr/bin/env python3
"""Bind the unchanged review's historical parser fixture to retained archive bytes."""
from pathlib import Path
import importlib,json,runpy,sys
R=Path(__file__).resolve().parent;A=R/'final-analysis';sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support
assert support.archive_mode() is not None and support.ROOT==R
mode=support.archive_mode();target='references/lut6-source-coverage-20261022/route-swap16/'
for name in ('routed.json','nextpnr.log'):
 rows=[v for v in mode['selected_dependency_members'] if v['retained_path']==target+name]
 assert len(rows)==1 and rows[0]['member']=='references/prior-cpu/'+name
 assert support.sha(R/rows[0]['retained_path'])==rows[0]['sha256']
t=importlib.import_module('test_checks');t.ROOT=R/'references'/'fixture-context'
runpy.run_path(str(A/'independent-review/review.py'),run_name='__main__')
