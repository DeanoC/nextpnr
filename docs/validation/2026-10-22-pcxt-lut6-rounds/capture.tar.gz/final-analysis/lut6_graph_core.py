#!/usr/bin/env python3
"""Complete serialized graph proof for logged symmetric two-net LUT6 swaps."""
from collections import Counter, defaultdict
from copy import deepcopy
import argparse
import json
import re
from support import HERE, ROOT, need, read, unique, sha, digest, write, paired_receipts

PINS = 'ABCDEF'


def decisions(text):
    lines = [line for line in text.splitlines() if 'Critical LUT6 ' in line]
    trials, filters, discovery, summaries, coverage, other = [], [], [], [], [], []
    trial_re = re.compile(r'^Info: Critical LUT6 trial (\d+): cell=(.*?) pins=([A-F])/([A-F]) prior-path-slack=(-?\d+)ps native-pin-rank=(-?\d+)ps accepted=([01]); (.*)\.$')
    for line in lines:
        match = trial_re.fullmatch(line)
        if match:
            number, cell, first, second, slack, rank, accepted, reason = match.groups()
            trials.append({'number': int(number), 'cell': cell, 'first': first, 'second': second,
                           'prior_path_slack_ps': int(slack), 'native_pin_rank_ps': int(rank),
                           'accepted': bool(int(accepted)), 'reason': reason, 'verbatim': line})
        elif (match := re.fullmatch(r'Info: Critical LUT6 current coverage: cell=(.+): (.+)\.', line)):
            coverage.append({'cell': match[1], 'reason': match[2], 'verbatim': line})
        elif line.startswith('Info: Critical LUT6 filter:'):
            filters.append(line)
        elif line.startswith('Info: Critical LUT6 discovery:'):
            discovery.append(line)
        elif line.startswith('Info: Critical LUT6 swap:'):
            summaries.append(line)
        else:
            other.append(line)
    need(not other, 'unparsed LUT6 decision lines')
    need(len(summaries) == 1 and len(discovery) in (1, 2), 'missing/duplicate discovery or final decision')
    match = re.fullmatch(r'Info: Critical LUT6 swap: tried=(\d+)/(\d+) kept=(\d+) eligible=(\d+); unchanged unsupported coverage is not qualification\.', summaries[0])
    need(match is not None, 'unknown final decision syntax')
    tried, budget, kept, eligible = map(int, match.groups())
    need(budget == 16 and tried == len(trials) <= 16, 'trial count/budget mismatch')
    need(tried + len(coverage) <= eligible, 'coverage skips exceed eligible proposals')
    need([t['number'] for t in trials] == list(range(1, tried + 1)), 'trial numbering is incomplete')
    need(sum(t['accepted'] for t in trials) == kept, 'accepted count mismatch')
    need(all(t['prior_path_slack_ps'] < 0 for t in trials), 'trial lacks an actual negative path')
    discovery_re = re.compile(r'^Info: Critical LUT6 discovery: negative endpoint rows=(\d+) native failing path witnesses=(\d+) LUT6 arcs=(\d+) filtered pairs=(\d+) eligible pairs=(\d+) cells=(\d+)\.$')
    counts = [match for line in discovery if (match := discovery_re.fullmatch(line))]
    need(len(counts) == 1, 'missing/duplicate complete discovery counts')
    names = ('negative_endpoint_rows', 'native_failing_path_witnesses', 'LUT6_arcs', 'filtered_pairs', 'eligible_pairs', 'cells')
    counts = dict(zip(names, map(int, counts[0].groups())))
    need(counts['filtered_pairs'] == len(filters) and counts['eligible_pairs'] == eligible and tried <= eligible,
         'discovery/final/filter count mismatch')
    for line in discovery:
        need(discovery_re.fullmatch(line) is not None or line == 'Info: Critical LUT6 discovery: native path bound truncates at 16384 per clock pair.', 'unknown discovery syntax')
    return {'all_verbatim_lines': lines, 'all_trials': trials, 'all_filters': filters,
            'all_discovery_lines': discovery, 'all_current_coverage_skips': coverage, 'summary': summaries[0], 'tried': tried,
            'budget': budget, 'kept': kept, 'eligible': eligible, 'discovery_counts': counts,
            'all_trial_reason_counts': dict(sorted(Counter(t['reason'] for t in trials).items())),
            'path_discovery_bound_reached': len(discovery) == 2}


def pinmap(cell):
    raw = cell['attributes']['FES_PINMAP_V1']
    data = json.loads(bytes.fromhex(raw).decode(), object_pairs_hook=unique)
    need(set(data) == {'count', 'pins'} and data['count'] == len(data['pins']), 'invalid physical pin snapshot')
    return data['pins']


def graph_edges(module):
    users, drivers, aliases = defaultdict(list), defaultdict(list), defaultdict(list)
    for name, cell in sorted(module['cells'].items()):
        need(cell['connections'].keys() == cell['port_directions'].keys(), 'port direction inventory: ' + name)
        for pin, bits in sorted(cell['connections'].items()):
            direction = cell['port_directions'][pin]
            need(direction in ('input', 'output', 'inout'), 'unknown port direction')
            for index, bit in enumerate(bits):
                if type(bit) is int:
                    if direction in ('input', 'inout'):
                        users[bit].append([name, pin, index])
                    if direction in ('output', 'inout'):
                        drivers[bit].append([name, pin, index])
    public = set()
    for name, port in sorted(module['ports'].items()):
        public.update(bit for bit in port['bits'] if type(bit) is int)
    for name, net in sorted(module['netnames'].items()):
        need(len(net['bits']) == 1, 'expected serialized scalar net/alias: ' + name)
        bit = net['bits'][0]
        need(type(bit) is int, 'noninteger routed net identity')
        aliases[bit].append(name)
    return users, drivers, aliases, public


def route_tree(raw):
    if raw is None:
        return None
    need(isinstance(raw, str), 'nonstring route attribute')
    # Property's JSON string encoding represents the empty string as one space.
    if raw in ('', ' '):
        return {}
    parts = raw.split(';')
    need(len(parts) % 3 == 0, 'partial route triple')
    result, pips = {}, set()
    for i in range(0, len(parts), 3):
        wire, pip, strength = parts[i:i + 3]
        need(wire and wire not in result, 'duplicate/empty route wire')
        need(re.fullmatch(r'[0-6]', strength) is not None, 'invalid native route strength')
        need(not pip or pip not in pips, 'duplicate route pip')
        if pip:
            pips.add(pip)
        result[wire] = [pip, int(strength)]
    return result


def prove(left, right, accepted):
    need(left.keys() == right.keys(), 'top-level field inventory differs')
    need(set(left) == {'creator', 'modules'}, 'unexpected top-level schema')
    need(left['modules'].keys() == right['modules'].keys() and len(left['modules']) == 1, 'module identity differs')
    a, b = next(iter(left['modules'].values())), next(iter(right['modules'].values()))
    need(a.keys() == b.keys(), 'module field inventory differs')
    need({k: v for k, v in a.items() if k not in ('cells', 'netnames')} ==
         {k: v for k, v in b.items() if k not in ('cells', 'netnames')}, 'module settings/ports/LAB state differ')
    ac, bc = a['cells'], b['cells']
    need(ac.keys() == bc.keys(), 'complete cell inventory differs')
    need(a['netnames'].keys() == b['netnames'].keys(), 'complete net alias inventory differs')
    before_users, before_drivers, aliases, public = graph_edges(a)
    after_users, after_drivers, after_aliases, after_public = graph_edges(b)
    need(aliases == after_aliases and public == after_public, 'alias classes/public identities differ')
    need(before_drivers == after_drivers, 'complete driver inventory differs')
    accepted_by_cell = {}
    for trial in accepted:
        need(trial['accepted'] and trial['cell'] not in accepted_by_cell, 'duplicate/unaccepted cell selection')
        accepted_by_cell[trial['cell']] = trial
    actual_changes = {name for name in ac if ac[name] != bc[name]}
    need(actual_changes == set(accepted_by_cell), 'cell changes do not equal complete accepted inventory')
    allowed_nets, proofs = set(), []
    expected_users = deepcopy(before_users)
    for name in sorted(ac):
        old, new = ac[name], bc[name]
        if name not in accepted_by_cell:
            need(old == new, 'outside cell changed: ' + name)
            continue
        trial = accepted_by_cell[name]
        first, second = trial['first'], trial['second']
        need(first in PINS and second in PINS and first != second, 'invalid selected input pair')
        need(old.keys() == new.keys(), 'changed cell field inventory')
        need({k: v for k, v in old.items() if k != 'connections'} ==
             {k: v for k, v in new.items() if k != 'connections'}, 'function/type/BEL/physical map changed: ' + name)
        need(old['type'] == 'MISTRAL_ALUT6' and set(old['parameters']) == {'LUT'}, 'not exact LUT6')
        mask_text = old['parameters']['LUT']
        need(isinstance(mask_text, str) and re.fullmatch('[01]{64}', mask_text), 'undefined/malformed LUT6 mask')
        mask = int(mask_text, 2)
        need(set(old['connections']) == set(PINS + 'Q'), 'not exactly six inputs and output')
        need(old['port_directions'] == {**{p: 'input' for p in PINS}, 'Q': 'output'}, 'unexpected LUT6 directions')
        need(all(len(old['connections'][p]) == 1 and type(old['connections'][p][0]) is int for p in PINS + 'Q'), 'invalid scalar LUT6 net')
        original = [old['connections'][p][0] for p in PINS]
        need(len(set(original)) == 6 and old['connections']['Q'][0] not in original, 'constant/aliased/cyclic input')
        maps = pinmap(old)
        need(set(maps) == set(PINS + 'Q') and all(maps[p][0] == 0 and len(maps[p]) == 2 for p in PINS + 'Q'), 'non PIN_SIG physical map')
        need([maps[p][1] for p in 'ABCD'] == list('ABCD') and maps['E'][1] in ('E0', 'E1') and
             maps['F'][1] == 'F' + maps['E'][1][-1] and maps['Q'][1] == 'COMBOUT', 'not unchanged full LUT6 occupancy')
        expected = deepcopy(old['connections'])
        expected[first], expected[second] = expected[second], expected[first]
        need(new['connections'] == expected, 'not exactly selected transposition')
        for p, q in ((first, second), (second, first)):
            bit = old['connections'][p][0]
            need(bit not in public and before_users[bit] == [[name, p, 0]], 'swapped net is not private single-sink')
            need(len(before_drivers[bit]) == 1 and bit in aliases, 'missing/ambiguous net driver/aliases')
            need(after_users[bit] == [[name, q, 0]], 'changed net sink identity differs')
            expected_users[bit] = [[name, q, 0]]
            allowed_nets.add(bit)
        table = []
        for row in range(64):
            values = {bit: (row >> i) & 1 for i, bit in enumerate(original)}
            new_address = sum(values[new['connections'][pin][0]] << i for i, pin in enumerate(PINS))
            before, after = (mask >> row) & 1, (mask >> new_address) & 1
            need(before == after, 'actual six-net function changed')
            table.append({'input_assignment': row, 'before_mask_index': row, 'after_mask_index': new_address,
                          'before_output': before, 'after_output': after})
        proofs.append({'cell': name, 'pins': [first, second], 'BEL': old['attributes']['NEXTPNR_BEL'],
                       'mask': mask_text, 'physical_maps': maps, 'input_bits': original,
                       'all64_rows': table, 'driver_user_alias_boundary': [
                           {'bit': old['connections'][p][0], 'aliases': aliases[old['connections'][p][0]],
                            'drivers': before_drivers[old['connections'][p][0]],
                            'before_users': before_users[old['connections'][p][0]],
                            'after_users': after_users[old['connections'][p][0]]} for p in (first, second)]})
    need(expected_users == after_users, 'outside user graph changed')
    changes, changed_bits, all_trees = [], set(), [{}, {}]
    for alias in sorted(a['netnames']):
        old, new = a['netnames'][alias], b['netnames'][alias]
        need(old.keys() == new.keys() and old['bits'] == new['bits'], 'net identity/schema differs: ' + alias)
        bit = old['bits'][0]
        old_copy, new_copy = deepcopy(old), deepcopy(new)
        old_raw = old_copy['attributes'].pop('ROUTING', None)
        new_raw = new_copy['attributes'].pop('ROUTING', None)
        need(old_copy == new_copy, 'non-route net metadata differs: ' + alias)
        old_tree, new_tree = route_tree(old_raw), route_tree(new_raw)
        for store, tree in zip(all_trees, (old_tree, new_tree)):
            if bit in store:
                need(store[bit] == tree, 'aliases disagree on canonical physical route')
            else:
                store[bit] = tree
        changed = old_tree != new_tree
        if changed:
            need(bit in allowed_nets, 'outside canonical route changed: ' + alias)
            changed_bits.add(bit)
        if old_raw != new_raw:
            changes.append({'alias': alias, 'bit': bit, 'canonical_tree_changed': changed,
                            'before_tree': old_tree, 'after_tree': new_tree,
                            'before_raw_sha256': digest(old_raw), 'after_raw_sha256': digest(new_raw)})
    need(changed_bits == allowed_nets, 'accepted net lacks changed serialized physical route')
    for bit in allowed_nets:
        roots = []
        for store in all_trees:
            tree = store[bit]
            need(tree is not None and tree, 'missing accepted net route')
            need(all(data[1] <= 2 for data in tree.values()), 'selected route contains protected strength')
            roots.append({wire: data for wire, data in tree.items() if data[0] == ''})
        need(len(roots[0]) == 1 and roots[0] == roots[1], 'selected original source root/strength changed')
    ownership = []
    for store in all_trees:
        wire_owners, pip_owners = {}, {}
        for bit, tree in store.items():
            for wire, (pip, strength) in (tree or {}).items():
                need(wire not in wire_owners, 'physical wire shared between different complete net identities')
                wire_owners[wire] = bit
                if pip:
                    need(pip not in pip_owners, 'physical pip shared between different complete net identities')
                    pip_owners[pip] = bit
        ownership.append({'wires': len(wire_owners), 'pips': len(pip_owners), 'single_net_ownership': True})
    return {'status': 'pass', 'complete_cells': len(ac), 'complete_net_alias_records': len(a['netnames']),
            'complete_net_alias_classes': len(aliases), 'complete_public_ports': len(a['ports']),
            'all_settings_ports_module_attributes_LAB_state_equal': True,
            'all_cell_types_masks_BELs_pin_maps_and_other_attributes_equal': True,
            'complete_driver_graph_equal': True, 'complete_user_graph_exactly_selected_transpositions': True,
            'complete_alias_classes_equal': True, 'outside_canonical_route_trees_equal': True,
            'complete_physical_wire_and_pip_ownership': {'before': ownership[0], 'after': ownership[1]},
            'accepted_cells': proofs, 'changed_canonical_net_bits': sorted(changed_bits),
            'every_raw_route_attribute_change': changes,
            'route_order_only_alias_changes': sum(not c['canonical_tree_changed'] for c in changes),
            'creator_before': left['creator'], 'creator_after': right['creator'],
            'limits': ['Serialized physical maps/LAB state and complete canonical wire/pip/strength records are compared.',
                       'Native indexed user-store holes are not serialized; focused native transaction tests cover them.',
                       'Pip strings are treated as exact identities, not independently decoded electrical connectivity.',
                       'The all64-row proof is logical equivalence. Native RBF/mux tests and complete final STA are separate evidence; no hardware acceptance.']}


def main():
    paired_receipts()
    logs = {name: (ROOT / ('route-' + name) / 'nextpnr.log').read_text() for name in ('default', 'swap16')}
    ledger = decisions(logs['swap16'])
    ledger['preceding_route_repair_all_lines'] = {
        name: [line for line in text.splitlines() if 'Critical route ' in line] for name, text in logs.items()}
    ledger['preceding_route_repair_decisions_equal'] = ledger['preceding_route_repair_all_lines']['default'] == ledger['preceding_route_repair_all_lines']['swap16']
    need(ledger['preceding_route_repair_decisions_equal'], 'preceding original route-repair decisions differ')
    need(not any('Critical LUT6 ' in line for line in logs['default'].splitlines()),
         'default unexpectedly executed new pass')
    left, right = [read(ROOT / ('route-' + name) / 'routed.json') for name in ('default', 'swap16')]
    result = prove(left, right, [trial for trial in ledger['all_trials'] if trial['accepted']])
    result.update(checker_sha256=sha(__file__), support_sha256=sha(HERE / 'support.py'),
                  graph_sha256={name: sha(ROOT / ('route-' + name) / 'routed.json') for name in ('default', 'swap16')})
    write('decision-ledger.json', ledger)
    write('graph-proof.json', result)
    print(json.dumps({key: result[key] for key in ('status', 'complete_cells', 'complete_net_alias_records', 'changed_canonical_net_bits')}, sort_keys=True))


if __name__ == '__main__':
    main()
