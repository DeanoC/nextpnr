#!/usr/bin/env python3
"""Compare actual round1 and round2 final graphs, with complete decision ledger."""
import json,re
from lut6_graph_core import decisions,prove
from support import HERE,ROOT,need,read,write,sha,paired_receipts

def round_decisions(text):
 lines=[s for s in text.splitlines() if 'Critical LUT6 ' in s]
 starts=[];rounds=[];current=None;total=None;summary=None;tried=kept=eligible=0
 for line in lines:
  if m:=re.fullmatch(r'Info: Critical LUT6 round start: round=(\d+)/(\d+) tried=(\d+)/(\d+) kept=(\d+)\.',line):
   number,limit,t,b,k=map(int,m.groups())
   need(current is None and total is None and summary is None,'nested or late round start')
   need(limit==2 and b==16 and number==len(rounds)+1 and number<=2,'round/budget bound')
   need(t==tried and k==kept,'round start accounting differs')
   if rounds:need(rounds[-1]['kept']>0 and tried<16,'new round without previous gain or budget')
   current=[];starts.append(line)
  elif m:=re.fullmatch(r'Info: Critical LUT6 round complete: round=(\d+) tried=(\d+) kept=(\d+)\.',line):
   number,t,k=map(int,m.groups())
   need(current is not None and number==len(rounds)+1,'unmatched round completion')
   normalized=[]
   for entry in current:
    if match:=re.match(r'Info: Critical LUT6 trial (\d+):',entry):
     actual=int(match[1]);need(actual>tried,'trial numbering precedes round')
     entry=entry[:match.start(1)]+str(actual-tried)+entry[match.end(1):]
    normalized.append(entry)
   discovery=[x for x in current if x.startswith('Info: Critical LUT6 discovery: negative endpoint rows=')]
   need(len(discovery)==1,'missing/duplicate full discovery')
   match=re.search(r'eligible pairs=(\d+) cells=\d+\.$',discovery[0]);need(match is not None,'bad discovery count')
   count=int(match[1]);normalized.append(f'Info: Critical LUT6 swap: tried={t}/16 kept={k} eligible={count}; unchanged unsupported coverage is not qualification.')
   parsed=decisions('\n'.join(normalized))
   parsed['round']=number;parsed['global_trial_offset']=tried;parsed['all_original_round_lines']=current
   need(parsed['tried']==t and parsed['kept']==k,'round ledger mismatch')
   tried+=t;kept+=k;eligible+=count;rounds.append(parsed);current=None
  elif m:=re.fullmatch(r'Info: Critical LUT6 rounds: completed=(\d+)/(\d+) shared-trials=(\d+)/(\d+)\.',line):
   n,limit,t,b=map(int,m.groups())
   need(current is None and total is None and summary is None,'unexpected rounds summary')
   need(limit==2 and b==16 and n==len(rounds) and 1<=n<=2 and t==tried<=16,'total rounds/trials mismatch')
   need(n==2 or kept==0 or tried==16,'second round omitted despite retained gain and available budget')
   total=line
  elif m:=re.fullmatch(r'Info: Critical LUT6 swap: tried=(\d+)/(\d+) kept=(\d+) eligible=(\d+); unchanged unsupported coverage is not qualification\.',line):
   t,b,k,e=map(int,m.groups())
   need(current is None and total is not None and summary is None,'unexpected final summary')
   need((t,b,k,e)==(tried,16,kept,eligible),'final summary differs from complete round ledgers')
   summary=line
  else:
   need(current is not None,'unparsed or out-of-round decision line');current.append(line)
 need(current is None and total is not None and summary is not None,'incomplete round logs')
 return {'all_verbatim_lines':lines,'round_starts':starts,'rounds':rounds,'total_summary':total,'final_summary':summary,'tried':tried,'kept':kept,'eligible':eligible,'budget':16}

def paired_decisions(before,after):
 control=decisions(before);selected=round_decisions(after)
 need(selected['rounds'][0]['all_verbatim_lines']==control['all_verbatim_lines'],'first-round complete decisions differ')
 preceding={n:[x for x in t.splitlines() if 'Critical route ' in x] for n,t in [('round1',before),('round2',after)]}
 need(preceding['round1']==preceding['round2'],'preceding route repair differs')
 additional=[x for group in selected['rounds'][1:] for x in group['all_trials'] if x['accepted']]
 return {'control':control,'selected':selected,'preceding_route_repair_all_lines':preceding,'preceding_route_repair_decisions_equal':True,'first_round_complete_decisions_equal':True,'additional_accepted_trials':additional,'limits':['Matching first-round decision logs does not independently snapshot the intermediate route. Complete final graph/timing/native topology comparisons remain required.']}

def main():
 paired_receipts()
 logs={n:(ROOT/('route-'+n)/'nextpnr.log').read_text() for n in ('round1','round2')}
 ledger=paired_decisions(logs['round1'],logs['round2'])
 left,right=[read(ROOT/('route-'+n)/'routed.json') for n in ('round1','round2')]
 result=prove(left,right,ledger['additional_accepted_trials'])
 result.update(checker_sha256=sha(__file__),graph_core_sha256=sha(HERE/'lut6_graph_core.py'),support_sha256=sha(HERE/'support.py'),graph_sha256={n:sha(ROOT/('route-'+n)/'routed.json') for n in ('round1','round2')})
 write('decision-ledger.json',ledger);write('graph-proof.json',result)
 print(json.dumps({k:result[k] for k in ['status','complete_cells','complete_net_alias_records','changed_canonical_net_bits']},sort_keys=True))
if __name__=='__main__':main()
