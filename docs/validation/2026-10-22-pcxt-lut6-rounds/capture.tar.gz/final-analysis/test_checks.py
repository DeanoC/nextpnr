#!/usr/bin/env python3
"""Independent orchestration-log corruptions; existing full graph proof retained."""
from pathlib import Path
import json,re
from prove_graph import decisions,paired_decisions,round_decisions,prove
from support import ROOT,HERE,read,write,sha,need

def main():
 prior=ROOT.parent/'lut6-source-coverage-20261022/route-swap16'
 control=(prior/'nextpnr.log').read_text();old=decisions(control)
 body=[x for x in old['all_verbatim_lines'] if not x.startswith('Info: Critical LUT6 swap:')]
 t,k,e=old['tried'],old['kept'],old['eligible'];need((t,k,e)==(3,1,7),'test fixture changed')
 second=[]
 for line in body:
  if m:=re.match(r'Info: Critical LUT6 trial (\d+):',line):
   line=line[:m.start(1)]+str(int(m[1])+t)+line[m.end(1):]
   line=line.replace('accepted=1;','accepted=0;')
  second.append(line)
 preceding=[x for x in control.splitlines() if 'Critical route ' in x]
 selected='\n'.join(preceding+['Info: Critical LUT6 round start: round=1/2 tried=0/16 kept=0.']+body+[
  'Info: Critical LUT6 round complete: round=1 tried=3 kept=1.',
  'Info: Critical LUT6 round start: round=2/2 tried=3/16 kept=1.']+second+[
  'Info: Critical LUT6 round complete: round=2 tried=3 kept=0.',
  'Info: Critical LUT6 rounds: completed=2/2 shared-trials=6/16.',
  'Info: Critical LUT6 swap: tried=6/16 kept=1 eligible=14; unchanged unsupported coverage is not qualification.'])
 ledger=paired_decisions(control,selected);need(ledger['additional_accepted_trials']==[],'wrong accepted set')
 rejects=[]
 def bad(name,text):
  try:paired_decisions(control,text)
  except (ValueError,KeyError,TypeError) as exc:rejects.append({'case':name,'rejection':str(exc)});return
  raise AssertionError('corruption accepted: '+name)
 bad('missing first start',selected.replace('Info: Critical LUT6 round start: round=1/2 tried=0/16 kept=0.',''))
 bad('third round claimed',selected.replace('round=2/2','round=3/2'))
 bad('wrong budget',selected.replace('shared-trials=6/16','shared-trials=6/17'))
 bad('wrong second offset',selected.replace('round=2/2 tried=3/16','round=2/2 tried=2/16'))
 bad('wrong previous keep count',selected.replace('round=2/2 tried=3/16 kept=1','round=2/2 tried=3/16 kept=0'))
 bad('duplicate trial number',selected.replace('Critical LUT6 trial 4:','Critical LUT6 trial 3:'))
 bad('missing round completion',selected.replace('Info: Critical LUT6 round complete: round=2 tried=3 kept=0.',''))
 bad('wrong round trial count',selected.replace('round=2 tried=3 kept=0','round=2 tried=2 kept=0'))
 bad('wrong round keep count',selected.replace('round=2 tried=3 kept=0','round=2 tried=3 kept=1'))
 bad('wrong total trial count',selected.replace('shared-trials=6/16','shared-trials=5/16'))
 bad('wrong total rounds',selected.replace('completed=2/2','completed=1/2'))
 bad('wrong final total',selected.replace('swap: tried=6/16','swap: tried=5/16'))
 bad('wrong final eligibility',selected.replace('eligible=14;','eligible=13;'))
 bad('unknown decision line',selected+'\nInfo: Critical LUT6 surprise.')
 bad('duplicate final summary',selected+'\n'+selected.splitlines()[-1])
 bad('first-round decision changed',selected.replace('prior-path-slack=-173ps','prior-path-slack=-174ps',1))
 bad('preceding repair changed',selected+'\nInfo: Critical route unrecorded transformation.')
 omitted='\n'.join(selected.splitlines()[:selected.splitlines().index('Info: Critical LUT6 round start: round=2/2 tried=3/16 kept=1.')]+[
  'Info: Critical LUT6 rounds: completed=1/2 shared-trials=3/16.',
  'Info: Critical LUT6 swap: tried=3/16 kept=1 eligible=7; unchanged unsupported coverage is not qualification.'])
 bad('second round omitted despite gain/budget',omitted)
 graph=read(prior/'routed.json');full=prove(graph,graph,[])
 result={'passed':True,'synthetic_two_round_parser_pass':True,'complete_previous_final_graph_noop':{k:full[k] for k in ['status','complete_cells','complete_net_alias_records']},'corruption_rejections':rejects,'checker_sha256':sha(HERE/'prove_graph.py'),'graph_core_sha256':sha(HERE/'lut6_graph_core.py'),'test_sha256':sha(__file__),'limits':['Synthetic round logs test ledger interpretation only; actual second-round route decisions and timing are not inferred.']}
 write('checks-proof.json',result);print(json.dumps({'passed':True,'log_corruptions_rejected':len(rejects),'complete_graph_cells':full['complete_cells']}))
if __name__=='__main__':main()
