#!/usr/bin/env python3
"""Complete six-input and output frontier for each final accepted LUT6 transposition."""
from support import HERE,ROOT,need,read,sha,digest,write
from lut6_graph_core import graph_edges,pinmap,route_tree

def physical(cells,user):
 name,port,index=user;need(index==0,'nonscalar native port');c=cells[name];m=pinmap(c);need(port in m and len(m[port])>=2,'missing native pins')
 return {'cell':name,'port':port,'index':index,'BEL':c['attributes']['NEXTPNR_BEL'],'state':m[port][0],'physical_pins':m[port][1:]}

def build():
 p=read(HERE/'graph-proof.json');need(p['status']=='pass','graph proof failed');mods={}
 for case,h in p['graph_sha256'].items():
  need(sha(ROOT/f'route-{case}/routed.json')==h,'route hash differs');mods[case]=next(iter(read(ROOT/f'route-{case}/routed.json')['modules'].values()))
 need(set(mods)=={'round1','round2'},'case inventory')
 a,b=mods['round1'],mods['round2'];au,ad,aliases,public=graph_edges(a);bu,bd,ba,bp=graph_edges(b)
 need(aliases==ba and public==bp and ad==bd,'complete graph identities differ')
 trials={x['cell']:x for x in p['accepted_cells']};bits=set()
 for name in trials:
  cell=a['cells'][name];need(set(cell['connections'])==set('ABCDEFQ'),'target pins');bits.update(x[0] for x in cell['connections'].values())
 selections=[]
 for bit in sorted(bits):
  need(bit not in public and len(ad[bit])==1 and bit in aliases,'invalid selected driver/public identity');users=[];expected=[]
  for u in au[bit]:
   v=u[:]
   if u[0] in trials and u[1] in trials[u[0]]['pins']:
    pair=trials[u[0]]['pins'];v[1]=pair[1-pair.index(u[1])]
   expected.append(v);old,new=physical(a['cells'],u),physical(b['cells'],v)
   users.append({'before':old,'after':new,'serialized_physical_sink_unchanged':old['BEL']==new['BEL'] and old['physical_pins']==new['physical_pins']})
  need(sorted(expected)==sorted(bu[bit]),'complete user transitions differ')
  driver=physical(a['cells'],ad[bit][0]);need(driver==physical(b['cells'],bd[bit][0]),'driver changed')
  old=route_tree(a['netnames'][aliases[bit][0]]['attributes'].get('ROUTING'));new=route_tree(b['netnames'][aliases[bit][0]]['attributes'].get('ROUTING'))
  need(old and new,'empty selected tree');roots=[{w:x for w,x in t.items() if not x[0]} for t in [old,new]];need(len(roots[0])==1 and roots[0]==roots[1],'source roots changed')
  selections.append({'bit':bit,'name':aliases[bit][0],'aliases':aliases[bit],'driver':driver,'user_transitions':users,'source_root':roots[0],'before_tree_sha256':digest(old),'after_tree_sha256':digest(new)})
 return {'schema':1,'graph_proof_sha256':sha(HERE/'graph-proof.json'),'graph_sha256':p['graph_sha256'],'selection_builder_sha256':sha(__file__),'selections':selections,'scope':'Complete six target input nets and target output net, including every native driver/user and alias. Full outside-tree preservation remains in the complete graph proof.'}
if __name__=='__main__':write('native-selection-specs.json',build())
