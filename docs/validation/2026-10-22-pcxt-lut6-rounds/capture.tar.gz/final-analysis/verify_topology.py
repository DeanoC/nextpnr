#!/usr/bin/env python3
"""Offline verification of native decoded trees and stationary-sink preservation.

This replays recorded native wire/PIP identities. It never executes the omitted
native reader or claims that its result is a timing/physical-mask proof.
"""
from pathlib import Path
from collections import Counter
from support import HERE,ROOT,need,read,sha,digest,write
from lut6_graph_core import route_tree
from native_selection import build as build_selection


def validate(tree, selected, serialized, which):
    need(tree['bit']==selected['bit'] and tree['selected_alias']==selected['name'],'native selected identity differs')
    need(tree['complete_aliases']==selected['aliases'],'native complete aliases differ')
    need(tree['driver']['native_port']==selected['driver'],'native driver metadata differs')
    need(tree['driver']['cell']==selected['driver']['cell'] and tree['driver']['port']==selected['driver']['port'],'native driver identity differs')
    root=tree['driver']['source_wire'];wires=tree['complete_tree']
    need(wires and root in wires and len(wires)<=4096,'missing/oversize native tree')
    native_canonical={wire:[row['pip'] or '',row['strength']] for wire,row in wires.items()}
    need(native_canonical==serialized,'native tree does not decode complete serialized routing')
    need({wire:data for wire,data in serialized.items() if not data[0]}==selected['source_root'],'source root/strength differs')
    pips=set()
    for wire,row in wires.items():
        need(type(row['strength']) is int and 0<=row['strength']<=2,'native route has protected/invalid strength')
        if row['pip'] is None:
            need(wire==root and set(row)=={'pip','strength'},'additional native root')
        else:
            need(set(row)=={'pip','strength','source','destination'} and row['destination']==wire and row['source'] in wires,'bad native PIP endpoint')
            need(row['pip'] not in pips,'duplicate native PIP');pips.add(row['pip'])
        seen=set();cursor=wire
        while cursor!=root:
            need(cursor not in seen and cursor in wires and wires[cursor]['pip'] is not None,'native cycle/disconnected tree')
            seen.add(cursor);cursor=wires[cursor]['source']
    expected={(u[which]['cell'],u[which]['port']):u[which] for u in selected['user_transitions']}
    actual={}
    for user in tree['complete_users']:
        key=(user['cell'],user['port']);need(key not in actual,'duplicate native user');actual[key]=user
        need(key in expected and user['native_port']==expected[key],'unexpected native user/physical map')
        sinks=user['physical_sink_wires'];need(sinks and sinks==sorted(set(sinks)),'native sink vector missing/duplicate')
        need(set(user['paths_to_source'])==set(sinks),'native sink path inventory differs')
        for sink in sinks:
            need(sink in wires,'native sink absent from tree');path=[];cursor=sink
            while True:
                path.append(cursor)
                if cursor==root:break
                cursor=wires[cursor]['source']
            need(user['paths_to_source'][sink]==path,'recorded native source path differs from decoded PIPs')
    need(set(actual)==set(expected),'complete native user identities differ')
    need(all(tree[k] is True for k in ('all_native_sinks_reached','single_acyclic_source_root','foreign_ownership_absent')),'native readback failure flag')
    return actual


def main():
    H=ROOT/'native-topology';D=H/'paired-readback'
    proof=read(HERE/'graph-proof.json');spec=read(HERE/'native-selection-specs.json');receipt=read(D/'receipt.json')
    need(proof['status']=='pass' and receipt['passed'],'missing passed graph/readback')
    need(spec['graph_proof_sha256']==receipt['graph_proof_sha256']==sha(HERE/'graph-proof.json'),'graph proof identity mismatch')
    need(receipt['selection_specs_sha256']==sha(HERE/'native-selection-specs.json'),'native selection spec identity mismatch')
    need(spec==build_selection() and spec['graph_sha256']==proof['graph_sha256'],'selection graph identity mismatch')
    if not proof['accepted_cells']:
        need(not receipt['native_execution_needed'] and not spec['selections'] and not proof['changed_canonical_net_bits'],'invalid no-readback claim')
        write('topology-proof.json',{'passed':True,'native_readback_needed':False,'reason':'No accepted permutation or changed graph/tree','graph_proof_sha256':sha(HERE/'graph-proof.json'),'readback_receipt_sha256':sha(D/'receipt.json')});return
    need(receipt['native_execution_needed'] and len(receipt['records'])==2,'missing complete native executions')
    build=read(H/'build-receipt.json')
    compatibility=read(H/'architecture-compatibility.json')
    need(compatibility['passed'] and compatibility['reader_binary_sha256']==build['helper_binary_sha256'] and receipt['architecture_compatibility_sha256']==sha(H/'architecture-compatibility.json'),'native structural compatibility missing')
    need(sha(H/'build-receipt.json')==receipt['build_receipt_sha256'],'native build receipt differs')
    need(build['helper_source_sha256']==receipt['helper_source_sha256']==sha(H/'tree-reader.cc'),'reader source differs')
    need(build['helper_binary_sha256']==receipt['helper_binary_sha256'],'native executable identity differs')
    trees={};modules={}
    for record in receipt['records']:
        case=record['case'];need(case in ('round1','round2') and case not in trees and record['returncode']==0,'wrong/missing native case')
        need(sha(ROOT/f'route-{case}/routed.json')==record['input_sha256']==proof['graph_sha256'][case],'readback input differs')
        for suffix,key in (('-selection.json','selection_sha256'),('-topology.json','output_sha256'),('.log','log_sha256')):
            need(sha(D/(case+suffix))==record[key],'native readback artifact differs')
        output=read(D/(case+'-topology.json'));need(output['pass'],'native readback failed')
        trees[case]={t['bit']:t for t in output['trees']};need(len(trees[case])==len(output['trees']),'duplicate native net')
        modules[case]=next(iter(read(ROOT/f'route-{case}/routed.json')['modules'].values()))
    bits={s['bit'] for s in spec['selections']};need(set(trees)=={'round1','round2'},'case inventory differs')
    need(all(set(rows)==bits for rows in trees.values()),'complete selected native net inventory differs')
    records=[];retained_wires=set();stationary_users=0;changed_users=0
    for selected in spec['selections']:
        bit=selected['bit'];users={}
        for case,which in (('round1','before'),('round2','after')):
            aliases=selected['aliases'];module=modules[case]
            serialized=route_tree(module['netnames'][aliases[0]]['attributes'].get('ROUTING'))
            need(digest(serialized)==selected[which+'_tree_sha256'],'selected serialized tree digest differs')
            need(all(module['netnames'][a]['bits']==[bit] and route_tree(module['netnames'][a]['attributes'].get('ROUTING'))==serialized for a in aliases),'selected alias tree differs')
            users[which]=validate(trees[case][bit],selected,serialized,which)
        old=trees['round1'][bit]['complete_tree'];new=trees['round2'][bit]['complete_tree'];root=trees['round1'][bit]['driver']['source_wire']
        need(trees['round2'][bit]['driver']['source_wire']==root and old[root]==new[root],'native original root changed')
        stationary=[];changed=[];retained={root}
        for transition in selected['user_transitions']:
            before=users['before'][(transition['before']['cell'],transition['before']['port'])]
            after=users['after'][(transition['after']['cell'],transition['after']['port'])]
            same=before['physical_sink_wires']==after['physical_sink_wires']
            need(not transition['serialized_physical_sink_unchanged'] or same,'identical saved native pins decode to different sinks')
            if same:
                stationary_users+=1
                for sink in before['physical_sink_wires']:
                    path=before['paths_to_source'][sink]
                    need(after['paths_to_source'][sink]==path,'stationary source-to-sink path changed')
                    for wire in path:need(wire in new and old[wire]==new[wire],'stationary route tuple/strength changed')
                    retained.update(path)
                stationary.append({'before':transition['before'],'after':transition['after'],'sink_wires':before['physical_sink_wires']})
            else:
                changed_users+=1;changed.append({'before':transition['before'],'after':transition['after'],'before_sinks':before['physical_sink_wires'],'after_sinks':after['physical_sink_wires']})
        retained_wires.update((bit,wire) for wire in retained)
        records.append({'bit':bit,'aliases':selected['aliases'],'canonical_tree_changed':old!=new,'before_wire_count':len(old),'after_wire_count':len(new),
         'retained_original_wires':sorted(retained),'complete_stationary_users':stationary,'complete_changed_users':changed})
    write('topology-proof.json',{'passed':True,'native_readback_needed':True,'graph_proof_sha256':sha(HERE/'graph-proof.json'),
     'readback_receipt_sha256':sha(D/'receipt.json'),'checker_sha256':sha(__file__),'helper_source_sha256':build['helper_source_sha256'],
     'helper_binary_sha256':build['helper_binary_sha256'],'architecture_compatibility_sha256':sha(H/'architecture-compatibility.json'),'selected_nets':len(bits),'stationary_users':stationary_users,'changed_physical_users':changed_users,
     'retained_original_wire_tuples':len(retained_wires),'nets':records,
     'limits':['Offline replay of recorded native source/PIP/sink decoding, not a new native execution.',
               'No routing, physical mask/mux, STA or hardware qualification is inferred. Complete final timing/coverage proofs remain separate.']})
    print('PASS native complete trees and stationary paths:',len(bits),'nets,',stationary_users,'stationary users')


if __name__=='__main__':main()
