#!/usr/bin/env python3
"""One frozen source/native/CLI validation for bounded second-round discovery."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,re,subprocess,sys,time
HERE=Path(__file__).resolve().parent;EVIDENCE=HERE.parent
ROOT=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr');BUILD=ROOT.parent/'build-candidate'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
source=json.loads((EVIDENCE/'source-identity.json').read_text());identity=json.loads((HERE/'build-identity.json').read_text())
exe=BUILD/'nextpnr-mistral';test=BUILD/'nextpnr-mistral-test'
def unchanged():
 return (all(sha(ROOT/f)==r['sha256'] for f,r in source['files'].items()) and
 sha(exe)==identity['production_sha256'] and sha(test)==identity['native_test_sha256'] and
 sha(EVIDENCE/'nextpnr-mistral')==identity['production_sha256'])
assert unchanged()
def run(name,cmd,count,native):
 log=HERE/(name+'.log');assert not log.exists();t=time.monotonic()
 with log.open('w') as f:rc=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT).returncode
 matches=re.findall(r'\[  PASSED  \] (\d+) tests?\.' if native else r'Ran (\d+) tests? in',log.read_text())
 observed=int(matches[-1]) if matches else 0
 r={'name':name,'command':cmd,'cwd':str(ROOT),'returncode':rc,'elapsed_seconds':time.monotonic()-t,
 'log_sha256':sha(log),'expected_count':count,'observed_count':observed,'pass':rc==0 and observed==count}
 (HERE/(name+'.receipt.json')).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r),flush=True);return r
cases=[('source-coverage',[str(test),'--gtest_filter=RoutedLut6SourceCoverage.*'],6,True),
('lut6-native',[str(test),'--gtest_filter=RoutedLut6SwapCoverage.*:*RoutedLut6SwapBackend.*:*PrivatePairBackend.CompleteMultiCaptureCoverageRejectsHiddenUnsupportedAndPublicBranches*'],33,True),
('lut6-cli',[sys.executable,str(ROOT/'mistral/tests/routed_lut6_swap_cli.py'),str(exe),'-v'],9,False)]
with ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,*case) for case in cases];results=[f.result() for f in futures]
valid=unchanged();r={'build_identity_sha256':sha(HERE/'build-identity.json'),'results':results,
'sources_and_binaries_unchanged':valid,'pass':valid and all(x['pass'] for x in results)}
(HERE/'validation.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r),flush=True)
sys.exit(0 if r['pass'] else 1)
