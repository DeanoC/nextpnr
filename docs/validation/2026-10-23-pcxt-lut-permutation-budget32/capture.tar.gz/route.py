#!/usr/bin/env python3
"""Fresh budget16 control versus budget32, keeping original clocks and guards."""
from pathlib import Path
import argparse,concurrent.futures,hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parent;TASK=ROOT.parent.parent
REFERENCE=ROOT.parent/'cpu2-permutation16-20261022/route-combined16'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def preflight():
 base=json.loads((REFERENCE/'receipt.json').read_text());v=json.loads((ROOT/'final-validation.json').read_text());c=json.loads((ROOT/'committed-source-verification.json').read_text())
 assert c['all_recorded_source_bytes_match_commit'] is True and c['final_validation_sha256']==sha(ROOT/'final-validation.json')
 assert c['source_files']==v['source_files'] and c['binary_sha256']==v['binary_sha256']==sha(ROOT/'nextpnr-mistral')
 for p,h in v['files'].items():assert sha(ROOT/p)==h
 assert v['validation']['passed'] is True and v['independent_source_review_passed'] is True
 assert v['enabled_lut_permutation_route_admission'] is True and v['enabled_lut_permutation_budget32_route_admission'] is True
 assert v['validation']['lut_permutation_native_count']==45 and v['validation']['lut_permutation_cli_count']==6
 assert sha(ROOT/'control-proof.json')==v['control_proof_sha256']
 control=json.loads((ROOT/'control-proof.json').read_text());assert control['default_zero_raw_bytes_equal']
 for x in control['controls']:assert x['complete_modules_equal'] and x['all_bytes_except_creator_equal'] and x['predicted_timing_bytes_equal']
 command=base['nextpnr_command'][:];command[0]=str(ROOT/'nextpnr-mistral')
 for key,value in [('--seed','1'),('--freq','100.0'),('--critical-route-budget','32'),('--critical-lut6-swap-budget','16'),('--critical-lut-permute-budget','16'),('--critical-lut6-swap-rounds','2'),('--router','gpu')]:assert command[command.index(key)+1]==value
 assert command[-3:]==['--critical-lut-permute-budget','16','--critical-unobserved-arith-outputs']
 for flag in ['--rbf','--placer-heap-hard-block-windows','--placer-heap-correct-spread','--balance-reduction-root']:assert flag in command
 assert not any(x in command for x in ['--no-route','--no-pack','--no-place','--pack-only','--critical-private-pair-budget','--critical-move-route-budget'])
 for p in base['inputs'].values():assert sha(p['path'])==p['sha256']
 return command,base['inputs'],c,v

def run(case):
 command,inputs,committed,validation=preflight();assert case in ['budget16','budget32']
 if case=='budget32':command[command.index('--critical-lut-permute-budget')+1]='32'
 target=ROOT/('route-'+case);target.mkdir(exist_ok=False)
 wrapped=[str(TASK/'scripts/gpu-run'),'--phase-lease','--owner','pcxt-timing','--label','pcxt-permutation-'+case,'--',*command]
 env={'NEXTPNR_REQUIRE_GPU':'1','GPU_LEASE_MAX_PER_OWNER':'2'}
 immutable={str(p):sha(p) for p in [ROOT/'source-identity.json',ROOT/'final-validation.json',ROOT/'committed-source-verification.json',ROOT/'control-proof.json',ROOT/'independent-source-review.json',REFERENCE/'receipt.json',Path(__file__)]}
 receipt={'command':wrapped,'nextpnr_command':command,'binary_sha256':committed['binary_sha256'],'committed_source_verification':committed,'final_validation':validation,'immutable_evidence_sha256':immutable,'inputs':inputs,'env':env,'recipe':'Original raw synthesis seed1/native hard-block windows/correct spreading/overflow17/route32/LUT6swap16/rounds2/unused arithmetic leaves; permutation '+case,'limit':'Native bounded searches and explicit permutation trial bound; no external GPU-job termination','evidence':'Fresh leased GPU host diagnostic; no timing closure, seal or hardware acceptance'}
 start=time.monotonic()
 with (target/'nextpnr.log').open('w') as log:receipt['returncode']=subprocess.run(wrapped,cwd=target,env=dict(os.environ,**env),stdout=log,stderr=subprocess.STDOUT).returncode
 receipt['charged_seconds']=time.monotonic()-start
 for p in inputs.values():assert sha(p['path'])==p['sha256']
 for p,h in immutable.items():assert sha(p)==h
 assert sha(ROOT/'nextpnr-mistral')==receipt['binary_sha256']
 receipt['artifacts']={p.name:sha(p) for p in sorted(target.iterdir()) if p.is_file()}
 (target/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'case':case,'returncode':receipt['returncode'],'charged_seconds':receipt['charged_seconds']}),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--check-only',action='store_true');p.add_argument('--case',choices=['budget16','budget32'],action='append');args=p.parse_args();preflight()
 if args.check_only:print('Matched budget16/32 fresh-route preflight passed; no route launched.')
 else:
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,args.case or ['budget16','budget32']))
