#!/usr/bin/env python3
"""Freeze the complete cap32 no-gain pair using exact committed sources and dependencies."""
from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
C=Path(__file__).resolve().parent;A=C.parent;R=A.parent;P=C/'payload';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def copy(p,n=None):
 dest=P/(n or p.relative_to(R));dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==sha(p),str(dest)
 else:shutil.copy2(p,dest)
 return str(dest.relative_to(P))
assert not P.exists(),'fresh payload required';P.mkdir()
final=read(R/'final-validation.json');assert sha(R/'final-validation.json')=='b3c202d37aae84c678f84f221c170111fe8db9fef071ea0d55dc1be3ab1f3a6f'
assert len(final['files'])==87 and len(final['source_files'])==29
for n,h in final['files'].items():assert sha(R/n)==h;copy(R/n)
for n in ['final-validation.json','committed-source-verification.json','route.py','verify-and-commit.py','record-runs.py','accounting.json']:copy(R/n)
commit=read(R/'committed-source-verification.json');assert commit['commit']=='134b858165a4dd0c00c8b5d5371fbf90fdac63a3' and commit['source_files']==final['source_files']
for n,h in final['source_files'].items():
 data=subprocess.check_output(['git','show',commit['commit']+':'+n],cwd=S)
 assert hashlib.sha256(data).hexdigest()==h==sha(P/'complete-source'/n)
for case in ['budget16','budget32']:
 receipt=read(R/f'route-{case}/receipt.json');assert receipt['binary_sha256']==final['binary_sha256']
 for n,h in receipt['artifacts'].items():assert sha(R/f'route-{case}'/n)==h;copy(R/f'route-{case}'/n)
 copy(R/f'route-{case}/receipt.json')
for p in sorted(A.rglob('*')):
 if p.is_file() and not {'capture','__pycache__'}&set(p.relative_to(A).parts):copy(p)
for p in sorted((R/'native-topology').rglob('*')):
 if p.is_file() and p.name!='tree-reader' and '__pycache__' not in p.parts:copy(p)
for p in sorted((R/'accounting-50').iterdir()):
 if p.is_file():copy(p)
account=read(P/'accounting-50/source.json');assert account['commit']=='9caa2bd60e82dd41943b0df6c7c366d107d93ee2'
for n,h in account['files'].items():assert sha(P/'accounting-50'/n)==h
assert read(P/'accounting.json')['journal_sha256']==sha(P/'accounting-50/continued-runs.jsonl')
omitted=[]
for p in [R/'nextpnr-mistral',R/'native-topology/tree-reader']:
 omitted.append({'original_path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'reason':'Executable omitted; offline replay uses exact recorded artifacts.'})
write(P/'omitted-payloads.json',{'files':omitted,'native_snapshot_manifest':'native-topology/frozen-manifest.json','native_snapshot_payload':'All401 frozen source/header/object members omitted; no offline native execution or rebuild claimed.'})
paths={'node':R.parent/'private-pair-node-budget-20261022/final-analysis/capture/capture.tar.gz','combined':R.parent/'cpu2-permutation16-20261022/final-analysis/capture/capture.tar.gz'}
expected={'node':'26dea41e116f9ae89bba40c68e7caacaeb47f31a0c2673c8d7ce66371e1540d7','combined':'3333e2524c928aec6704c3fd8374b45208cc4964ff3598c5fdfac4604971d22b'}
bindings=[];dependencies={}
for kind,dep in paths.items():
 assert sha(dep)==expected[kind]
 with tarfile.open(dep) as t:
  data=t.extractfile('manifest.json').read();m=json.loads(data)
  spec={'archive_sha256':sha(dep),'bytes':dep.stat().st_size,'members':len(t.getmembers()),'manifest_sha256':hashlib.sha256(data).hexdigest(),'manifest_path':f'dependencies/{kind}-manifest.json'}
  assert spec['members']==len(m)+1;dependencies[kind]=spec
  d=P/spec['manifest_path'];d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
  def retain(member,target):
   d=P/target;d.parent.mkdir(parents=True,exist_ok=True);payload=t.extractfile(member).read()
   if d.exists():assert d.read_bytes()==payload
   else:d.write_bytes(payload)
   assert sha(d)==m[member]['sha256'];bindings.append({'dependency':kind,'member':member,'retained_path':target,'sha256':sha(d)})
  for member in sorted(m):
   target=None
   prefixes=[('prepare-default/','references/prior-prepare/'),('complete-source/','references/node-source/'),('references/prior-source/','references/prior-source/'),('references/budget-source/','references/combined-source/'),('external-inputs/','external-inputs/')] if kind=='node' else [('route-combined16/','references/prior-cpu/')]
   for prefix,destination in prefixes:
    if member.startswith(prefix):target=destination+member[len(prefix):]
   if member in ['final-validation.json','committed-source-verification.json','archive-mode.json','CAPTURE-README.md']:target=f'references/{kind}-evidence/'+member
   if target is not None:retain(member,target)
  if kind=='node':
   for member in ['native-topology/architecture-compatibility.json','native-topology/prepare.py']:
    retain(member,'references/node-native/'+Path(member).name)
  else:retain('route-combined16/nextpnr.log','references/cpu2-permutation16-20261022/route-combined16/nextpnr.log')
recorded={};receipt=read(R/'route-budget16/receipt.json')
for path,h in receipt['immutable_evidence_sha256'].items():
 original=Path(path);target=str(original.relative_to(R)) if original.is_relative_to(R) else 'references/prior-cpu/receipt.json'
 assert sha(P/target)==h;recorded[path]={'retained_path':target,'sha256':h}
for v in receipt['inputs'].values():
 target='external-inputs/'+v['sha256']+'-'+Path(v['path']).name
 assert sha(P/target)==v['sha256'];recorded[v['path']]={'retained_path':target,'sha256':v['sha256']}
bindings.sort(key=lambda v:(v['dependency'],v['member'],v['retained_path']))
mode={'recorded_files':recorded,'excluded_binary':{'original_path':receipt['nextpnr_command'][0],'sha256':final['binary_sha256']},'references':{'route':{'original_directory':str(R.parent/'cpu2-permutation16-20261022/route-combined16'),'retained_path':'references/prior-cpu'}},'dependencies':dependencies,'selected_dependency_members':bindings,'scope':'No live-path fallback. Both complete dependency archives are member-hash verified; their historical transitive identities remain context, not fetched or rerun.'}
write(P/'archive-mode.json',mode)
for n in ['prepare.py','replay.py','replay_review.py','verify_capture.py','build_archive.py','README.md']:copy(C/n,'CAPTURE-README.md' if n=='README.md' else n)
print(json.dumps({'files':len([p for p in P.rglob('*') if p.is_file()]),'source_files':len(final['source_files']),'dependencies':dependencies},indent=2,sort_keys=True))
