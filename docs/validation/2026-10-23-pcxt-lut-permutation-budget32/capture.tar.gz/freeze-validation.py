#!/usr/bin/env python3
"""Freeze host-only admission for the extended explicit permutation trial budget."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
R=Path(__file__).resolve().parent;F=R/'source-validation';OLD=R.parent/'private-pair-node-budget-20261022';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert sha(OLD/'final-validation.json')=='25760e7b9d05331625d63713db43092966e38360f65bacdf6d57b6be18475d6d'
old=read(OLD/'final-validation.json');source=read(R/'source-identity.json');build=read(F/'build-identity.json');review=read(R/'independent-source-review.json');proof=read(R/'unchanged-transaction-coverage-proof.json')
base=source['base_commit'];assert base=='f5c6b90df4b8a36a6a8f631998d52ef160c2044b' and len(source['files'])==4
assert build['source_identity_sha256']==sha(R/'source-identity.json')==review['source_identity_sha256']==proof['source_identity_sha256']
assert build['review_sha256']==sha(R/'independent-source-review.json') and build['unchanged_proof_sha256']==sha(R/'unchanged-transaction-coverage-proof.json')
assert review['passed'] and not review.get('blockers',[]) and review['source_files']==source['files']
assert sha(R/'source-identity.json')==review['source_identity_sha256']
assert sha(R/'nextpnr-mistral')==build['production_sha256']=='aba33a3cc6b3a322f98c22853efc0d1d9fe4d781707932c6249640cd5395662c'
assert build['native_test_sha256']==old['native_test_sha256']
audit=read(F/'native-link-audit/result.json')
assert audit['status']=='pass' and audit['source_identity_sha256']==sha(R/'source-identity.json')
assert audit['build_identity_sha256']==sha(F/'build-identity.json')
assert audit['test_object_recompiled_and_test_executable_relinked_in_current_log'] and audit['orchestration_symbol_absent_from_final_test'] and audit['transaction_symbol_present_in_final_test']
assert audit['native_test_bytes_equal_prior_node'] and audit['production_contains_new_native32_guard_text'] and audit['test_contains_neither_native16_nor32_guard_text']
assert audit['link_uses_rebuilt_object_and_LTO']
sources=dict(old['source_files']);sources.update({p:v['sha256'] for p,v in source['files'].items()});assert len(sources)==29
for p,h in sources.items():
 origin=R/'source'/p if p in source['files'] else OLD/'complete-source'/p
 assert sha(origin)==h==sha(S/p)
 prior=subprocess.check_output(['git','show',base+':'+p],cwd=S);prior_hash=hashlib.sha256(prior).hexdigest()
 if p in source['files']:assert prior_hash==source['files'][p]['before_sha256']==old['source_files'][p]==sha(R/'before'/p)
 else:assert prior_hash==h
 dest=R/'complete-source'/p;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==h
 else:shutil.copy2(origin,dest)
path='mistral/routed_lut_permutation.cc';before=(R/'before'/path).read_bytes();after=(R/'source'/path).read_bytes()
assert before.count(b'critical_lut_permute_budget>16')==before.count(b'budget 1..16.')==1
assert before.replace(b'critical_lut_permute_budget>16',b'critical_lut_permute_budget>32').replace(b'budget 1..16.',b'budget 1..32.')==after
assert before[:proof['complete_permutation_prefix_bytes']]==after[:proof['complete_permutation_prefix_bytes']]
assert hashlib.sha256(before[:proof['complete_permutation_prefix_bytes']]).hexdigest()==proof['complete_permutation_prefix_sha256']
for p,h in proof['unchanged_complete_source_files'].items():assert sources[p]==h
summary=read(F/'validation.json');assert summary['pass'] and summary['sources_and_binaries_unchanged'] and summary['build_identity_sha256']==sha(F/'build-identity.json')
counts={'permutation-native':45,'permutation-cli':6};assert {x['name'] for x in summary['results']}==set(counts)
for name,n in counts.items():
 v=read(F/(name+'.receipt.json'));text=(F/(name+'.log')).read_text();assert v['returncode']==0 and v['pass'] and v['expected_count']==v['observed_count']==n and v['log_sha256']==sha(F/(name+'.log'))
 assert next(x for x in summary['results'] if x['name']==name)==v
 if name.endswith('cli'):assert re.search(r'Ran '+str(n)+r' tests in',text) and re.search(r'\nOK\s*$',text)
 else:
  run=re.findall(r'^\[ RUN      \] (.+)$',text,re.M);ok=re.findall(r'^\[       OK \] (.+) \(\d+ ms\)$',text,re.M);assert len(run)==len(ok)==len(set(run))==n and run==ok
control=read(R/'control-proof.json');assert control['default_zero_raw_bytes_equal'] and sorted(x['case'] for x in control['controls'])==['default','zero']
assert control['script_sha256']==sha(R/'prepare-controls.py')
prior=read(OLD/'prepare-default/receipt.json');oldbytes=(OLD/'prepare-default/placed.json').read_bytes()
for x in control['controls']:
 assert all(x[k] for k in ('complete_modules_equal','all_bytes_except_creator_equal','predicted_timing_bytes_equal'))
 folder=R/('prepare-'+x['case']);v=read(folder/'receipt.json');assert v['returncode']==0 and v['binary_sha256']==build['production_sha256'] and v['inputs']==prior['inputs']
 expected=prior['nextpnr_command'][:];expected[0]=v['nextpnr_command'][0]
 if x['case']=='zero':expected+=['--critical-lut-permute-budget','0']
 assert v['nextpnr_command']==expected and '--no-route' in expected and '--rbf' not in expected
 for p,h in v['artifacts'].items():assert sha(folder/p)==h
 newbytes=(folder/'placed.json').read_bytes();a=json.loads(oldbytes);b=json.loads(newbytes);ca=json.dumps(a.pop('creator')).encode();cb=json.dumps(b.pop('creator')).encode()
 assert a==b and oldbytes.count(ca)==1 and oldbytes.replace(ca,cb,1)==newbytes
 assert (folder/'predicted-timing.json').read_bytes()==(OLD/'prepare-default/predicted-timing.json').read_bytes()
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
write(R/'retained-source-proof.json',{'earlier_commit':base,'earlier_final_validation_sha256':sha(OLD/'final-validation.json'),'unchanged_source_files':{p:h for p,h in old['source_files'].items() if p not in source['files']},'scope':'Only current45 native permutation and6 CLI tests reran; source6/nativeLUT6-33/CLI9, private81/CLI9, unused12 and cache evidence retain their earlier exact source/build provenance.'})
files={}
for prefix in ('source','before','source-validation','complete-source','prepare-default','prepare-zero'):
 for p in sorted((R/prefix).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:files[str(p.relative_to(R))]=sha(p)
for name in ('source-identity.json','independent-source-review.json','unchanged-transaction-coverage-proof.json','source.patch','prepare-controls.py','controls.log','initial-control-launch-error.log','control-proof.json','retained-source-proof.json','freeze-validation.py','initial-freeze-validation.py','initial-final-freeze.log'):files[name]=sha(R/name)
final={'scope':'Host-only admission for the existing ordinary-LUT permutation sequence with explicit budget0..32, default0 unchanged. Additional live trials require fresh full route and all unchanged native physical/timing/coverage guards; no gain or hardware acceptance asserted.',
'binary_sha256':build['production_sha256'],'native_test_sha256':build['native_test_sha256'],'source_parent':base,'source_files':sources,'files':files,
'independent_source_review_passed':True,'source_review_sha256':sha(R/'independent-source-review.json'),'control_proof_sha256':sha(R/'control-proof.json'),
'enabled_lut_permutation_route_admission':True,'enabled_lut_permutation_budget32_route_admission':True,
'validation':{'passed':True,'lut_permutation_native_count':45,'lut_permutation_cli_count':6},'native_execution_boundary':{'link_audit_sha256':sha(F/'native-link-audit/result.json'),'scope':'Native45 exercises unchanged transaction/coverage helpers. Rebuilt test drops unused orchestration under LTO; CLI6 checks admission. Enabled32-trial orchestration behavior requires the fresh route.'},'unchanged_transaction_coverage_proof_sha256':sha(R/'unchanged-transaction-coverage-proof.json'),
'retained_prior_validation':{'path':str(OLD/'final-validation.json'),'sha256':sha(OLD/'final-validation.json'),'unchanged_source_proof_sha256':sha(R/'retained-source-proof.json'),'scope':'Earlier passes keep original provenance; only45/6 rerun on this build. Full LUT6/private-pair/shared coverage source bytes are unchanged.'}}
assert not (R/'final-validation.json').exists();write(R/'final-validation.json',final);print(sha(R/'final-validation.json'))
