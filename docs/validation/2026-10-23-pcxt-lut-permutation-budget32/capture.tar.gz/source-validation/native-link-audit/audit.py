#!/usr/bin/env python3
"""Read-only evidence for a rebuilt LTO object with unused orchestration removed."""
from pathlib import Path
import gzip,hashlib,json,shutil,subprocess
HERE=Path(__file__).resolve().parent;OUT=HERE.parent.parent;BUILD=Path('/home/deano/harnesses/pcxt-compiler-repair/build-candidate')
sha=lambda b:hashlib.sha256(b).hexdigest()
def run(name,command):
 r=subprocess.run(command,cwd=BUILD,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert r.returncode==0,(command,r.stderr)
 for suffix,data in [('stdout',r.stdout),('stderr',r.stderr)]:
  (HERE/(name+'.'+suffix+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 records[name]={'command':command,'cwd':str(BUILD),'returncode':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)}
 return r.stdout.decode()
records={};files={}
obj=Path('mistral/CMakeFiles/nextpnr-mistral-test.dir/routed_lut_permutation.cc.o')
for name in [obj,Path('nextpnr-mistral-test'),Path('nextpnr-mistral'),Path('build.ninja'),Path('.ninja_log')]:
 f=BUILD/name;s=f.stat();files[str(name)]={'sha256':sha(f.read_bytes()),'size':s.st_size,'mtime_ns':s.st_mtime_ns}
for name in ['build.ninja','.ninja_log']:(HERE/(name.replace('.','_')+'.gz')).write_bytes(gzip.compress((BUILD/name).read_bytes(),mtime=0))
shutil.copyfile(BUILD/obj,HERE/'routed_lut_permutation.test-object.o')
object_symbols=run('object-symbols',['nm','-C',str(obj)])
test_symbols=run('test-symbols',['nm','-C','nextpnr-mistral-test'])
production_symbols=run('production-symbols',['nm','-C','nextpnr-mistral'])
compile_commands=run('object-build-commands',['ninja','-t','commands',str(obj)])
all_link_commands=run('test-build-commands',['ninja','-t','commands','nextpnr-mistral-test'])
link=all_link_commands.splitlines()[-1];(HERE/'test-link-command.txt').write_text(link+'\n')
log=(OUT/'source-validation/build.log').read_text()
assert 'Building CXX object '+str(obj) in log and 'Linking CXX executable nextpnr-mistral-test' in log
symbol='nextpnr_mistral::Arch::repair_critical_lut_permutations()';trial='nextpnr_mistral::critical_routed_lut_permutation_trial('
assert symbol in object_symbols and symbol not in test_symbols and trial in object_symbols and trial in test_symbols
assert '-flto=auto' in compile_commands and '-flto=auto' in link and str(obj) in link
production=(BUILD/'nextpnr-mistral').read_bytes();test=(BUILD/'nextpnr-mistral-test').read_bytes()
new=b'Critical LUT permutation requires an ordinary completed route and budget 1..32.\n';old=b'Critical LUT permutation requires an ordinary completed route and budget 1..16.\n'
assert new in production and old not in production and new not in test and old not in test
prior=OUT.parent/'private-pair-node-budget-20261022/source-validation/build-identity.json';identity=json.loads(prior.read_text());assert sha(test)==identity['native_test_sha256'] and sha(production)!=identity['production_sha256']
result={'status':'pass','source_identity_sha256':sha((OUT/'source-identity.json').read_bytes()),'build_log_sha256':sha((OUT/'source-validation/build.log').read_bytes()),'build_identity_sha256':sha((OUT/'source-validation/build-identity.json').read_bytes()),'prior_node_build_identity_sha256':sha(prior.read_bytes()),'files':files,'commands':records,'test_object_recompiled_and_test_executable_relinked_in_current_log':True,'orchestration_defined_in_rebuilt_LTO_object':True,'orchestration_symbol_absent_from_final_test':True,'transaction_symbol_present_in_final_test':True,'link_uses_rebuilt_object_and_LTO':True,'production_contains_new_native32_guard_text':True,'test_contains_neither_native16_nor32_guard_text':True,'native_test_bytes_equal_prior_node':True,'production_bytes_differ_from_prior_node':True,'symbol_lines':{'object':[l for l in object_symbols.splitlines() if symbol in l or trial in l],'test':[l for l in test_symbols.splitlines() if symbol in l or trial in l],'production':[l for l in production_symbols.splitlines() if symbol in l]},'conclusion':'The test object was rebuilt and linked; LTO eliminates unused orchestration while retaining the unchanged tested transaction. Identical test bytes do not establish execution of the widened native orchestration bound. Production CLI tests cover admission; enabled32 orchestration needs its fresh route.','limits':['This audit does not claim native45 invokes Arch::repair_critical_lut_permutations or exercises32 trials.','No source, shared build or routed artifacts were modified by this audit.']}
(HERE/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'pass','result_sha256':sha((HERE/'result.json').read_bytes()),'test_sha256':sha(test),'production_sha256':sha(production)}))
