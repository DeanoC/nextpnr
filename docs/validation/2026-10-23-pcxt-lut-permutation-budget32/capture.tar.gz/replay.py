#!/usr/bin/env python3
"""Portable complete cap32 graph/endpoint/no-change proof; no native execution."""
from pathlib import Path
from decimal import Decimal
import contextlib,hashlib,importlib,io,json,sys,tempfile
R=Path(__file__).resolve().parent;A=R/'final-analysis';sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
assert support.archive_mode() is not None and support.ROOT==R
final=read(R/'final-validation.json');commit=read(R/'committed-source-verification.json')
assert commit['commit']=='134b858165a4dd0c00c8b5d5371fbf90fdac63a3' and commit['source_files']==final['source_files'] and commit['final_validation_sha256']==sha(R/'final-validation.json')
for n,h in final['files'].items():assert sha(R/n)==h,n
for n,h in final['source_files'].items():assert sha(R/'complete-source'/n)==h,n
assert len(final['files'])==87 and len(final['source_files'])==29
for key in ('node','combined'):
 prior=read(R/f'references/{key}-evidence/final-validation.json')
 for n,h in prior['source_files'].items():assert sha(R/f'references/{key}-source'/n)==h,n
identity=read(R/'source-identity.json');assert identity['base_commit']=='f5c6b90df4b8a36a6a8f631998d52ef160c2044b'
for n,v in identity['files'].items():assert sha(R/'before'/n)==v['before_sha256']==sha(R/'references/node-source'/n) and sha(R/'source'/n)==v['sha256']
controls=read(R/'control-proof.json');assert controls['default_zero_raw_bytes_equal']
for case in ('default','zero'):
 p=R/('prepare-'+case);q=R/'references/prior-prepare';a=(q/'placed.json').read_bytes();b=(p/'placed.json').read_bytes();x=json.loads(a);y=json.loads(b)
 before=json.dumps(x.pop('creator')).encode();after=json.dumps(y.pop('creator')).encode()
 assert x==y and a.count(before)==1 and a.replace(before,after,1)==b
 assert (p/'predicted-timing.json').read_bytes()==(q/'predicted-timing.json').read_bytes()
 assert read(p/'receipt.json')['reference_receipt_sha256']==sha(q/'receipt.json')
 for n,h in read(p/'receipt.json')['artifacts'].items():assert sha(p/n)==h
assert (R/'prepare-default/placed.json').read_bytes()==(R/'prepare-zero/placed.json').read_bytes()
summary=read(R/'source-validation/validation.json');assert summary['pass']
for name,count in [('permutation-native',45),('permutation-cli',6)]:
 v=read(R/'source-validation'/(name+'.receipt.json'));assert v['pass'] and v['returncode']==0 and v['observed_count']==v['expected_count']==count
 assert v['log_sha256']==sha(R/'source-validation'/(name+'.log')) and v in summary['results']
native=R/'native-topology';build=read(native/'build-receipt.json');compat=read(native/'architecture-compatibility.json')
assert build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
for name,key in [('tree-reader.cc','helper_source_sha256'),('frozen-manifest.json','frozen_manifest_sha256'),('build-commands.json','build_commands_sha256'),('build.log','build_log_sha256')]:assert sha(native/name)==build[key]
assert len(read(native/'frozen-manifest.json')['files'])==401
assert compat['passed'] and compat['route_compiler_commit']==commit['commit'] and compat['reader_compiler_commit']=='186637013e17461a72cd1d2cd17ca5ef174ed06f'
assert compat['reader_binary_sha256']==build['helper_binary_sha256'] and compat['route_source_identity_sha256']==sha(R/'source-identity.json')
for n,v in compat['changed_snapshotted_source_files'].items():assert sha(R/'references/prior-source'/n)==v['old_sha256'] and sha(R/'complete-source'/n)==v['new_sha256']
assert sha(native/'prior-private-compatibility.json')==compat['prior_private_compatibility_sha256']==sha(R/'references/node-native/architecture-compatibility.json')
assert sha(native/'prior-private-prepare.py')==compat['prior_private_prepare_sha256']==sha(R/'references/node-native/prepare.py')
a=(R/'references/node-source/mistral/routed_lut_permutation.cc').read_bytes();b=(R/'complete-source/mistral/routed_lut_permutation.cc').read_bytes()
assert a.count(b'critical_lut_permute_budget>16')==a.count(b'budget 1..16.')==1
assert a.replace(b'critical_lut_permute_budget>16',b'critical_lut_permute_budget>32').replace(b'budget 1..16.',b'budget 1..32.')==b
prefix=compat['permutation_native_prefix_bytes'];assert a[:prefix]==b[:prefix] and hashlib.sha256(a[:prefix]).hexdigest()==compat['permutation_native_prefix_sha256']
nreceipt=read(native/'paired-readback/receipt.json');assert nreceipt['passed'] and not nreceipt['native_execution_needed']
origin=read(A/'indexed-port-resolution-origin.json');assert origin['frontend_sha256']==sha(A/'pinned-frontend_base.h') and origin['module_sha256']==sha(A/'native_port_identity.py')
accounting=read(R/'accounting.json');journal=R/'accounting-50/continued-runs.jsonl';records=[json.loads(v) for v in journal.read_text().splitlines()];asource=read(R/'accounting-50/source.json')
assert asource['commit']=='9caa2bd60e82dd41943b0df6c7c366d107d93ee2'
for n,h in asource['files'].items():assert sha(R/'accounting-50'/n)==h
assert sha(journal)==accounting['journal_sha256'] and len(records)==accounting['completed_subsequent_receipts']==50 and len({v['case'] for v in records})==50
assert Decimal(accounting['pre_journal_charge_seconds'])+sum(Decimal(v['charged_seconds_decimal']) for v in records)==Decimal(accounting['cumulative_charge_seconds'])
for case in ('budget16','budget32'):
 rows=[v for v in records if v['case']=='out/lut-permutation-budget32-20261023/route-'+case];assert len(rows)==1 and rows[0]['receipt_sha256']==sha(R/f'route-{case}/receipt.json')
checks=[]
def compare_write(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs';checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
with contextlib.redirect_stdout(io.StringIO()):
 for name in ('prove_graph','test_graph_checks','test_budget_checks','test_native_port_identity','verify_topology'):
  m=importlib.import_module(name);m.write=compare_write
  if name=='test_budget_checks':m.ROOT=R/'references'/'fixture-context'
  m.main()
 c=importlib.import_module('compare_timing')
 with tempfile.TemporaryDirectory(prefix='pcxt-cap32-proof-') as scratch:
  c.R=Path(scratch);c.main();assert (c.R/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
 checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
g=read(A/'graph-proof.json');t=read(A/'route-comparison.json');n=read(A/'topology-proof.json');d=read(A/'decision-ledger.json')
assert not g['accepted_cells'] and not g['changed_canonical_net_bits'] and g['route_order_only_alias_changes']==5
assert len(t['every_endpoint_row'])==17199 and t['native_margin_delta_counts']=={'setup':{'unchanged':17194},'hold':{'unchanged':17194}}
assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal'] and t['default_vs_prior_fixed_invariance_pass']
assert n['passed'] and not n['native_readback_needed']
assert d['control']['tried']==16 and d['selected']['tried']==23 and d['control']['kept']==d['selected']['kept']==2
assert d['preceding_repair_decisions_equal'] and d['first_sixteen_complete_decisions_equal'] and not d['additional_accepted_trials']
bytes_proof=read(A/'independent-review/artifact-bytes.json');assert bytes_proof['passed'] and len(bytes_proof['every_raw_route_difference'])==5
for name,row in bytes_proof['artifacts'].items():
 p=R/'route-budget16'/name;q=R/'route-budget32'/name
 assert sha(p)==row['before_sha256'] and sha(q)==row['after_sha256'] and (p.read_bytes()==q.read_bytes())==row['byte_equal']
 assert row['byte_equal']==(name!='routed.json')
result={'passed':True,'source_commit':commit['commit'],'source_files':29,'host_admission_files':87,'native_snapshot_manifest_members':401,'exact_replays':checks,'complete_endpoint_rows':17199,'native_margin_delta_counts':t['native_margin_delta_counts'],'additional_retained_permutations':0,'three_final_artifacts_byte_equal':True,'routed_json_order_only_changes':5,'native_readback_needed':False,'pair_route_charge_seconds_recorded_not_recharged':t['pair_charge_seconds'],'charged_route_seconds':0,'historical_accounting_context':{'journal_records':50,'cumulative_charge_seconds':accounting['cumulative_charge_seconds'],'scope':'Journal arithmetic and these two receipt hashes checked; other historical routes are context only.'},'scope':'Offline complete saved graph/timing/rollback proof. Native45/CLI6 retained receipts are not rerun; no native reader, GPU route, rejected-state STA, emitted-RBF electrical or hardware acceptance.'}
print(encoded(result).decode(),end='')
