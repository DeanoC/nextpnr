#!/usr/bin/env python3
import json,re
from prove_graph import decisions,paired_decisions
from support import ROOT,HERE,need,write,sha

def main():
 p=ROOT.parent/'cpu2-permutation16-20261022/route-combined16/nextpnr.log';control=p.read_text();old=decisions(control,16);need(old['tried']==16 and old['kept']==2,'fixture changed')
 previous=[x for x in control.splitlines() if 'Critical route ' in x or 'Critical LUT6 ' in x]
 extra=old['all_trials'][0]['verbatim'].replace('trial 1:','trial 17:').replace('pins=D/E','pins=D/A')
 selected='\n'.join(previous+old['all_verbatim_lines'][:-1]+[extra,'Info: Critical LUT permutation: tried=17/32 kept=2; unchanged unsupported coverage is not qualification.'])
 result=paired_decisions(control,selected);need(result['additional_accepted_trials']==[],'incorrect additional retention')
 rejected=[]
 def bad(name,text):
  try:paired_decisions(control,text)
  except (ValueError,KeyError,TypeError) as e:rejected.append({'case':name,'rejection':str(e)});return
  raise AssertionError('corruption accepted '+name)
 bad('wrong budget',selected.replace('tried=17/32','tried=17/33'))
 bad('wrong total',selected.replace('tried=17/32','tried=16/32'))
 bad('missing global trial',selected.replace('trial 17:','trial 18:'))
 bad('wrong accepted count',selected.replace('kept=2;','kept=0;'))
 bad('changed first-sixteen slack',selected.replace('prior-slack=-434ps','prior-slack=-433ps',1))
 bad('missing original final trial',selected.replace(old['all_trials'][15]['verbatim'],''))
 bad('changed prior repair',selected+'\nInfo: Critical route unexpected.')
 bad('unknown permutation line',selected+'\nInfo: Critical LUT permutation unexpected.')
 bad('duplicate summary',selected+'\n'+selected.splitlines()[-1])
 bad('retrial of retained target',selected.replace(extra,old['all_trials'][2]['verbatim'].replace('trial 3:','trial 17:').replace('accepted=1;','accepted=0;')))
 bad('negative path omitted',selected.replace(extra,extra.replace('prior-slack=-434ps','prior-slack=0ps')))
 bad('first-sixteen pair changed',selected.replace(old['all_trials'][0]['verbatim'],old['all_trials'][0]['verbatim'].replace('pins=D/E','pins=D/A')))
 bad('early candidate summary',selected.replace(extra+'\n'+selected.splitlines()[-1],selected.splitlines()[-1]+'\n'+extra))
 result={'passed':True,'positive_parser_cases':1,'corruption_rejections':rejected,'checker_sha256':sha(HERE/'prove_graph.py'),'graph_core_sha256':sha(HERE/'permutation_graph_core.py'),'test_sha256':sha(__file__),'fixture_log_sha256':sha(p),'scope':'Synthetic budget32 continuation ledger only; actual extra trials and timing remain unproven.'}
 write('budget-checks-proof.json',result);print(json.dumps({'passed':True,'rejections':len(rejected)}))
if __name__=='__main__':main()
