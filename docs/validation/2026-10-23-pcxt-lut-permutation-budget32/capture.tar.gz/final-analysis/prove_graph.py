#!/usr/bin/env python3
"""Complete final comparison after an identical first sixteen permutation trials."""
import json
from permutation_graph_core import decisions,prove,pinmap,transposed_mask,route_tree
from support import HERE,ROOT,need,read,write,sha,paired_receipts

def paired_decisions(left,right):
 before=decisions(left,16);after=decisions(right,32)
 need(after['all_verbatim_lines'][-1]==after['summary'],'candidate summary was not final')
 need(before['tried']==16,'control did not reach original bound; larger budget is not justified by this pair')
 prefix=before['all_verbatim_lines'][:-1];need(before['all_verbatim_lines'][-1]==before['summary'],'control summary was not final')
 need(after['all_verbatim_lines'][:len(prefix)]==prefix,'complete first-sixteen decisions differ')
 need(after['all_trials'][:16]==before['all_trials'],'first-sixteen parsed trials differ')
 previous={n:[line for line in text.splitlines() if 'Critical route ' in line or 'Critical LUT6 ' in line] for n,text in [('budget16',left),('budget32',right)]}
 need(previous['budget16']==previous['budget32'],'preceding route/LUT6 repair differs')
 accepted=[t for t in after['all_trials'][16:] if t['accepted']]
 return {'control':before,'selected':after,'first_sixteen_complete_decisions_equal':True,'preceding_repair_all_lines':previous,'preceding_repair_decisions_equal':True,'additional_accepted_trials':accepted,'limits':['Matching decision logs does not independently snapshot the intermediate route; complete final graph, timing and native topology checks remain required.']}

def main():
 paired_receipts();cases=('budget16','budget32')
 logs={n:(ROOT/('route-'+n)/'nextpnr.log').read_text() for n in cases};ledger=paired_decisions(logs['budget16'],logs['budget32'])
 left,right=[read(ROOT/('route-'+n)/'routed.json') for n in cases]
 result=prove(left,right,ledger['additional_accepted_trials']);hashes={n:sha(ROOT/('route-'+n)/'routed.json') for n in cases}
 result.update(native_port_resolver_sha256=sha(HERE/'native_port_identity.py'),checker_sha256=sha(__file__),graph_core_sha256=sha(HERE/'permutation_graph_core.py'),support_sha256=sha(HERE/'support.py'),graph_sha256=hashes)
 write('decision-ledger.json',ledger);write('graph-proof.json',result)
 write('native-selection-specs.json',{'schema':1,'graph_proof_sha256':sha(HERE/'graph-proof.json'),'graph_sha256':hashes,'selections':result['native_topology_selections'],'requirements':['Decode every selected complete native tree and all stationary sink paths/strengths using a separately frozen native reader; no allocation, configuration or timing reload.']})
 print(json.dumps({k:result[k] for k in ['status','complete_cells','complete_net_alias_records','changed_canonical_net_bits']},sort_keys=True))
if __name__=='__main__':main()
