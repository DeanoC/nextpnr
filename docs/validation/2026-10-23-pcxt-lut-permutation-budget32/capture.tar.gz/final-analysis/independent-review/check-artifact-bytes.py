#!/usr/bin/env python3
"""Independent exact four-artifact comparison, retaining every serialization difference."""
from pathlib import Path
import hashlib,json,re
H=Path(__file__).resolve().parent;R=H.parent.parent
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def text_sha(s):
 # The graph receipt hashes the canonical JSON string value, including quotes.
 return hashlib.sha256(json.dumps(s,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def tree(s):
 assert isinstance(s,str)
 if s in ('',' '):return {}
 fields=s.split(';');assert len(fields)%3==0
 rows={};pips=set()
 for i in range(0,len(fields),3):
  wire,pip,strength=fields[i:i+3]
  assert wire and wire not in rows and re.fullmatch('[0-6]',strength)
  assert not pip or pip not in pips
  if pip:pips.add(pip)
  rows[wire]=[pip,int(strength)]
 return rows
receipts={};artifacts={}
for case in ('budget16','budget32'):
 d=R/('route-'+case);v=read(d/'receipt.json');assert v['returncode'] in (0,1)
 assert set(v['artifacts'])=={'diagnostic.rbf','endpoints.json','nextpnr.log','routed.json','timing.json'}
 for p,h in v['artifacts'].items():assert sha(d/p)==h
 receipts[case]={'sha256':sha(d/'receipt.json'),'artifacts':v['artifacts']}
for p in ('diagnostic.rbf','endpoints.json','routed.json','timing.json'):
 a,b=(R/'route-budget16'/p),(R/'route-budget32'/p)
 artifacts[p]={'before_sha256':sha(a),'after_sha256':sha(b),'byte_equal':a.read_bytes()==b.read_bytes()}
assert all(artifacts[p]['byte_equal'] for p in ('diagnostic.rbf','endpoints.json','timing.json'))
assert not artifacts['routed.json']['byte_equal']
a=read(R/'route-budget16/routed.json');b=read(R/'route-budget32/routed.json')
assert set(a)==set(b)=={'creator','modules'} and a['creator']==b['creator']
assert set(a['modules'])==set(b['modules'])=={'top'}
aa=a['modules']['top']['netnames'];bb=b['modules']['top']['netnames'];assert set(aa)==set(bb)
changes=[]
for name in sorted(aa):
 old,new=aa[name]['attributes'].get('ROUTING'),bb[name]['attributes'].get('ROUTING')
 if old==new:continue
 x,y=tree(old),tree(new);assert x==y
 changes.append({'alias':name,'before_raw_sha256':text_sha(old),'after_raw_sha256':text_sha(new),'wire_pip_strengths':x})
 aa[name]['attributes']['ROUTING']=x;bb[name]['attributes']['ROUTING']=y
assert a==b
g=read(R/'final-analysis/graph-proof.json')
assert g['status']=='pass' and not g['changed_canonical_net_bits'] and len(changes)==g['route_order_only_alias_changes']==5
assert {x['alias'] for x in changes}=={x['alias'] for x in g['every_raw_route_attribute_change']}
for x in changes:
 y=next(y for y in g['every_raw_route_attribute_change'] if y['alias']==x['alias'])
 assert x['before_raw_sha256']==y['before_raw_sha256'] and x['after_raw_sha256']==y['after_raw_sha256']
 assert x['wire_pip_strengths']==y['before_tree']==y['after_tree'] and not y['canonical_tree_changed']
result={'passed':True,'script_sha256':sha(__file__),'receipts':receipts,'artifacts':artifacts,'graph_proof_sha256':sha(R/'final-analysis/graph-proof.json'),
 'all_json_equal_after_exact_route_order_normalization':True,'every_raw_route_difference':changes,
 'scope':'Three final artifacts are byte-exact. Routed JSON differs only in five route-string serialization orders; every wire/PIP/strength tuple and all remaining JSON are exact. No native execution, STA or new route.'}
(H/'artifact-bytes.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'passed':True,'receipt_sha256':sha(H/'artifact-bytes.json'),'serialization_only_route_attributes':len(changes)}))
