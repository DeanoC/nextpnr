#!/usr/bin/env python3
"""Independent complete final cap32 proof replay; only run after native readback."""
from pathlib import Path
import contextlib,hashlib,importlib,io,json,sys
HERE=Path(__file__).resolve().parent;A=HERE.parent;sys.path.insert(0,str(A));sys.dont_write_bytecode=True
import support

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def encoded(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
inputs={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*.py'))};checks=[]
def compare_write(name,value):
 assert encoded(value)==(A/name).read_bytes(),name+' replay differs';checks.append({'proof':name,'sha256':sha(A/name),'exact_replay':True})
log=io.StringIO()
with contextlib.redirect_stdout(log):
 g=importlib.import_module('prove_graph');g.write=compare_write;g.main()
 for name in ('test_graph_checks','test_budget_checks','test_native_port_identity'):
  c=importlib.import_module(name);c.write=compare_write;c.main()
 n=importlib.import_module('verify_topology');n.write=compare_write;n.main()
 t=importlib.import_module('compare_timing');t.R=HERE;t.main()
assert (HERE/'route-comparison.json').read_bytes()==(A/'route-comparison.json').read_bytes()
checks.append({'proof':'route-comparison.json','sha256':sha(A/'route-comparison.json'),'exact_replay':True})
assert inputs=={str(p.relative_to(A)):sha(p) for p in sorted(A.glob('*.py'))}
g=read(A/'graph-proof.json');t=read(A/'route-comparison.json');n=read(A/'topology-proof.json');d=read(A/'decision-ledger.json')
assert d['preceding_repair_decisions_equal'] and d['first_sixteen_complete_decisions_equal']
assert len(g['accepted_cells'])==len(d['additional_accepted_trials'])
for cell in g['accepted_cells']:
 rows=cell['all_raw_net_rows'];assert rows and len(rows) in (4,8,16,32) and all(x['before_output']==x['after_output'] for x in rows)
assert t['endpoint_identity_inventory_equal'] and t['all_row_domain_windows_and_flags_equal'] and t['all_metadata_categories_equal'] and len(t['every_endpoint_row'])==17199
assert t['independent_complete_clock_guard']['pass'] and t['independent_emitted_inventory_guard']['nonregression_and_inventory_pass'] and not t['independent_emitted_inventory_guard']['all_violations']
for k in ('setup','hold'):
 counts=t['native_margin_delta_counts'][k];assert sum(counts.values())==17194 and not counts.get('regressed',0)
assert t['default_vs_prior_fixed_invariance_pass']
assert all(x['unsupported_count']==105 and not x['complete'] and x['hold']['failures']==0 for x in t['runs'].values())
assert n['passed'] and n['native_readback_needed']==bool(g['accepted_cells'])
changed=[x for x in t['every_endpoint_row'] if x['margin_delta_ps']['setup'] or x['margin_delta_ps']['hold']]
result={'passed':True,'reviewer':'timing_strategy','review_script_sha256':sha(__file__),'inputs':inputs,'exact_replays':checks,'complete_endpoint_rows':17199,'native_margin_delta_counts':t['native_margin_delta_counts'],'setup_failure_counts':{k:v['setup']['failures'] for k,v in t['runs'].items()},'whole_system_setup_minimum_ps':{k:v['setup']['minimum_ps'] for k,v in t['runs'].items()},'changed_margin_rows':changed,'accepted_cells':[{'cell':v['cell'],'pins':v['pins'],'complete_truth_rows':len(v['all_raw_net_rows'])} for v in g['accepted_cells']],'changed_canonical_net_bits':g['changed_canonical_net_bits'],'native_topology':{k:v for k,v in n.items() if k in ('native_readback_needed','selected_nets','stationary_users','changed_physical_users','retained_original_wire_tuples')},'charged_route_seconds':0,'findings':['Complete graph, aliases, settings/LAB, physical ownership and final setup/hold/native clock inventories replay exactly. All native clock and endpoint margins are nonregressing, including initially positive margins.','The first sixteen complete decisions and all preceding route/LUT6 repair lines match exactly. Only logged later accepted transpositions explain changed logical pin assignments and canonical trees.','Every raw truth-table row of every accepted cell is checked. All observed stationary user paths and source-root strengths are covered by native structural readback when trees change; unchanged trees need no native execution.'],'limits':['Independent review of root-authored graph/timing checkers and exact offline replay. This agent authored the native-readback adaptation; its compatibility is separately independently reviewed.','Only the emitted final timing frame is replayed. No reload STA or new reference-free inventory is inferred; both live guard frames retain their frozen source/log evidence.','Unsupported105 and complete=false remain. No timing closure, hardware/electrical acceptance or emitted-RBF mask equivalence is claimed.']}
(HERE/'replay.log').write_text(log.getvalue());(HERE/'review.json').write_bytes(encoded(result));print(json.dumps({'passed':True,'review_sha256':sha(HERE/'review.json'),'exact_replays':len(checks)},sort_keys=True))
