#!/usr/bin/env python3
"""CPU-only complete-design default and explicit-zero byte controls."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import subprocess
import time

ROOT=Path(__file__).resolve().parent
REFERENCE=ROOT.parent/'private-pair-node-budget-20261022/prepare-default'

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def run(case):
    prior=json.loads((REFERENCE/'receipt.json').read_text())
    identity=json.loads((ROOT/'source-validation/build-identity.json').read_text())
    identity['binary_sha256']=identity['production_sha256']
    identity['source_files']=json.loads((ROOT/'source-identity.json').read_text())['files']
    command=prior['nextpnr_command'][:]
    command[0]=str(ROOT/'nextpnr-mistral')
    if case=='zero':command+=['--critical-lut-permute-budget','0']
    assert '--no-route' in command and '--rbf' not in command
    assert sha(command[0])==identity['binary_sha256']
    for item in prior['inputs'].values():assert sha(item['path'])==item['sha256']
    target=ROOT/('prepare-'+case);target.mkdir(exist_ok=False)
    receipt={'nextpnr_command':command,'source_identity':identity,'inputs':prior['inputs'],
             'binary_sha256':identity['binary_sha256'],'charged_seconds':0,
             'scope':'CPU-only fresh placement default control; no route or timing qualification',
             'reference_receipt_sha256':sha(REFERENCE/'receipt.json')}
    start=time.monotonic()
    with (target/'nextpnr.log').open('w') as log:
        receipt['returncode']=subprocess.run(command,cwd=target,stdout=log,stderr=subprocess.STDOUT).returncode
    receipt['elapsed_seconds']=time.monotonic()-start
    assert sha(command[0])==identity['binary_sha256']
    for item in prior['inputs'].values():assert sha(item['path'])==item['sha256']
    receipt['artifacts']={p.name:sha(p) for p in target.iterdir() if p.is_file()}
    (target/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(case,receipt['returncode'],receipt['elapsed_seconds'],flush=True)
    assert receipt['returncode']==0
    old_bytes=(REFERENCE/'placed.json').read_bytes();new_bytes=(target/'placed.json').read_bytes()
    old=json.loads(old_bytes);new=json.loads(new_bytes)
    assert old['modules']==new['modules']
    old_creator=json.dumps(old.pop('creator')).encode();new_creator=json.dumps(new.pop('creator')).encode()
    assert old==new and old_bytes.count(old_creator)==1
    assert old_bytes.replace(old_creator,new_creator,1)==new_bytes
    assert (REFERENCE/'predicted-timing.json').read_bytes()==(target/'predicted-timing.json').read_bytes()
    return {'case':case,'complete_modules_equal':True,'all_bytes_except_creator_equal':True,
            'predicted_timing_bytes_equal':True,'placed_sha256':sha(target/'placed.json')}

if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,['default','zero']))
    assert (ROOT/'prepare-default/placed.json').read_bytes()==(ROOT/'prepare-zero/placed.json').read_bytes()
    (ROOT/'control-proof.json').write_text(json.dumps({'controls':results,'default_zero_raw_bytes_equal':True,
        'script_sha256':sha(__file__),'scope':'Complete CPU placement control only'},indent=2)+'\n')
