#!/usr/bin/env python3
"""Native topology execution bound to the exact complete additional-budget permutation graph proof."""
from pathlib import Path
import hashlib,json,subprocess,time
H=Path(__file__).resolve().parent;E=H.parent;C=E/'final-analysis'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
proof=read(C/'graph-proof.json');spec=read(C/'native-selection-specs.json');build=read(H/'build-receipt.json')
assert proof['status']=='pass' and spec['graph_proof_sha256']==sha(C/'graph-proof.json')
assert spec['graph_sha256']==proof['graph_sha256']
compat=read(H/'architecture-compatibility.json');assert compat['passed'] and compat['reader_binary_sha256']==build['helper_binary_sha256'] and compat['route_compiler_commit']=='134b858165a4dd0c00c8b5d5371fbf90fdac63a3'
assert set(proof['graph_sha256'])=={'budget16','budget32'}
assert build['pass'] and sha(H/'tree-reader')==build['helper_binary_sha256'] and sha(H/'tree-reader.cc')==build['helper_source_sha256']
assert sha(H/'frozen-manifest.json')==build['frozen_manifest_sha256']
for case,want in proof['graph_sha256'].items():assert sha(E/f'route-{case}/routed.json')==want
D=H/'paired-readback';D.mkdir(exist_ok=True);records=[]
if not proof['accepted_cells']:
 assert not spec['selections'] and not proof['changed_canonical_net_bits']
 save(D/'receipt.json',{'passed':True,'native_execution_needed':False,'reason':'No logged accepted permutation or graph/route change',
  'graph_proof_sha256':sha(C/'graph-proof.json'),'selection_specs_sha256':sha(C/'native-selection-specs.json'),'charged_route_seconds':0})
 subprocess.run(['python3',str(C/'verify_topology.py')],check=True)
 print('No accepted permutation: native readback not needed.');raise SystemExit
for case,which in (('budget16','before'),('budget32','after')):
 nets=[]
 for net in spec['selections']:
  nets.append({'name':net['name'],'bit':net['bit'],'aliases':net['aliases'],'driver':net['driver'],
   'users':[u[which] for u in net['user_transitions']]})
 selection=D/(case+'-selection.json');save(selection,{'schema':2,'nets':nets,'graph_proof_sha256':sha(C/'graph-proof.json'),'graph_sha256':proof['graph_sha256'][case]})
 output=D/(case+'-topology.json');assert not output.exists()
 cmd=[str(H/'tree-reader'),str(E/f'route-{case}/routed.json'),str(selection),str(output)];start=time.monotonic()
 with (D/(case+'.log')).open('w') as log:rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 record={'case':case,'argv':cmd,'returncode':rc,'wall_seconds':time.monotonic()-start,'input_sha256':proof['graph_sha256'][case],
  'selection_sha256':sha(selection),'log_sha256':sha(D/(case+'.log')),'output_sha256':sha(output) if output.exists() else None}
 records.append(record);assert rc==0 and read(output)['pass']
for case,want in proof['graph_sha256'].items():assert sha(E/f'route-{case}/routed.json')==want
assert sha(H/'tree-reader')==build['helper_binary_sha256'] and sha(H/'tree-reader.cc')==build['helper_source_sha256']
save(D/'receipt.json',{'passed':True,'native_execution_needed':True,'records':records,'graph_proof_sha256':sha(C/'graph-proof.json'),
 'selection_specs_sha256':sha(C/'native-selection-specs.json'),'build_receipt_sha256':sha(H/'build-receipt.json'),
 'architecture_compatibility_sha256':sha(H/'architecture-compatibility.json'),'helper_binary_sha256':build['helper_binary_sha256'],'helper_source_sha256':build['helper_source_sha256'],'charged_route_seconds':0,
 'scope':'Native saved-tree topology readback only. No routing, pin allocation, configuration, STA or RBF generation.'})
subprocess.run(['python3',str(C/'verify_topology.py')],check=True)
