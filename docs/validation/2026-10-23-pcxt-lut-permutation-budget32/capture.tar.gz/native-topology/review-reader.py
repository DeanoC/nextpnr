#!/usr/bin/env python3
"""Read-only source compatibility replay; never runs the native reader."""
from pathlib import Path
from unittest.mock import patch
import contextlib,hashlib,io,json,runpy,subprocess
H=Path(__file__).resolve().parent
S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
replayed=[]
for script in [H.parent.parent/'private-pair-node-budget-20261022/native-topology/prepare.py',H/'prepare.py']:
 expected=script.parent/'architecture-compatibility.json'; original=expected.read_bytes(); writes=[]
 def capture(p,text,*args,**kwargs):
  assert Path(p).resolve()==expected.resolve(), str(p)
  data=text.encode(kwargs.get('encoding') or 'utf-8');assert data==original
  writes.append(sha(expected));return len(text)
 def no_copy(*args,**kwargs):raise AssertionError('Missing frozen preparation dependency: '+str(args))
 stdout=io.StringIO()
 with patch.object(Path,'write_text',capture),patch('shutil.copy2',no_copy),contextlib.redirect_stdout(stdout):runpy.run_path(str(script),run_name='__main__')
 assert len(writes)==1 and expected.read_bytes()==original
 replayed.append({'script':str(script),'sha256':sha(script),'output_sha256':sha(expected),'replayed_byte_exact_without_writes':True,'stdout':stdout.getvalue()})
q=read(H/'committed-source-verification.json');checked={}
for name,digest in q['source_files'].items():
 data=subprocess.check_output(['git','show',q['source_commit']+':'+name],cwd=S)
 assert hashlib.sha256(data).hexdigest()==digest;checked[name]=digest
build=read(H/'build-receipt.json')
for file,key in [('build-commands.json','build_commands_sha256'),('build.log','build_log_sha256'),('tree-reader.cc','helper_source_sha256'),('tree-reader','helper_binary_sha256'),('frozen-manifest.json','frozen_manifest_sha256')]:assert sha(H/file)==build[key]
compat=read(H/'architecture-compatibility.json');assert compat['passed']
receipt={'pass':True,'reviewer':'reassociate_integration','review_scope':'Independent source/compatibility review and exact read-only preparation replay; no native reader execution or actual final-route readback.', 'bindings':{name:sha(H/name) for name in ['prepare.py','architecture-compatibility.json','prior-private-prepare.py','prior-private-compatibility.json','tree-reader.cc','tree-reader','build-receipt.json','build-commands.json','build.log','frozen-manifest.json','committed-source-verification.json']},'replays':replayed,'old_committed_snapshot_git_blobs_independently_hashed':len(checked),'changed_snapshot_files':sorted(compat['changed_snapshotted_source_files']),'checks':{'all_old_source_hashes_match_exact_reader_commit':True,'both_compatibility_scripts_byte_exact_without_mutating_originals':True,'cap32_only_two_uncalled_bound_error_changes':True,'native_transaction_prefix_unchanged':True,'prior_private_node_proof_replayed':True,'helper_build_command_log_source_binary_manifest_hashes_match':True,'main_object_not_linked':True,'no_mixed_new_context_abi':True,'native_reader_scope_only_parse_restore_saved_maps_and_decode_source_sink_pips':True},'limits':['No fresh reader execution or final routed graph result is claimed.','The reader is internally consistent at its old source commit; changed orchestration and added Arch configuration fields are not executed or mixed with new objects.','Restoring serialized pin maps is required to decode saved physical ports; this does not allocate pins, configure a bitstream, run STA, place, or route.','Full native user, alias, sink reachability, ownership, strength, single-root and cycle checks apply only to the explicitly selected bounded saved net trees; whole graph equivalence remains a separate checker.']}
p=H/'independent-reader-review.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({'pass':True,'path':str(p),'sha256':sha(p),'source_count':len(checked)}))
