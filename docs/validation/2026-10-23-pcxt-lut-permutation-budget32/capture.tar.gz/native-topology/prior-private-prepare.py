#!/usr/bin/env python3
"""Qualify unchanged native JSON/tree decoder through the private-only node option."""
from pathlib import Path
import hashlib,json,shutil,subprocess
H=Path(__file__).resolve().parent;R=H.parent;B=R.parent/'lut-permutation-budget16-20261022';S=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def blob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=S)
def copy(p,n):
 d=H/n
 if d.exists():assert sha(d)==sha(p)
 else:shutil.copy2(p,d)
for n in ['tree-reader','tree-reader.cc','build-receipt.json','build-commands.json','build.log','frozen-manifest.json','committed-source-verification.json','lut6-prefix-proof.json']:
 copy(B/'native-topology'/n,n)
copy(B/'native-topology/architecture-compatibility.json','prior-budget-compatibility.json')
copy(B/'native-topology/independent-reader-review.json','prior-budget-reader-review.json')
copy(B/'unchanged-transaction-coverage-proof.json','prior-permutation-transaction-proof.json')
build=read(H/'build-receipt.json');assert sha(H/'tree-reader')==build['helper_binary_sha256']=='689dbb4b864082394a8e9233a31293630220715f276c884e08c76aa28c0370c9'
assert sha(H/'tree-reader.cc')==build['helper_source_sha256'] and sha(H/'frozen-manifest.json')==build['frozen_manifest_sha256']
old='186637013e17461a72cd1d2cd17ca5ef174ed06f';base='02ffa3aa6a74b71debbb23da24e5332b541cf742';new='f5c6b90df4b8a36a6a8f631998d52ef160c2044b'
q=read(H/'committed-source-verification.json');assert q['passed'] and q['source_commit']==old
prior=read(H/'prior-budget-compatibility.json');assert prior['passed'] and prior['route_compiler_commit']==base
identity=read(R/'source-identity.json');assert identity['base_commit']==base
committed=read(R/'committed-source-verification.json');assert committed['commit']==new
delta=set(subprocess.check_output(['git','diff','--name-only',base,new,'--','mistral','common','json','generic','3rdparty'],cwd=S,text=True).splitlines())
assert delta=={'mistral/arch.h','mistral/main.cc','mistral/private_pair_decomposition.cc','mistral/tests/routed_private_pair_backend.cc','mistral/tests/routed_private_pair_cli.py'}
same={};different={}
for n,h in q['source_files'].items():
 digest=hashlib.sha256(blob(new,n)).hexdigest();(same if digest==h else different)[n]={'old_sha256':h,'new_sha256':digest}
assert set(different)=={'mistral/arch.h','mistral/main.cc','mistral/routed_lut6_swap.cc','mistral/routed_lut_permutation.cc','mistral/private_pair_decomposition.cc'}
assert 'mistral/main.cc.o' not in (H/'build-commands.json').read_text()
for n in ('mistral/routed_lut6_swap.cc','mistral/routed_lut_permutation.cc'):assert blob(base,n)==blob(new,n)
added=b'    int critical_private_pair_route_nodes = 500000; // Explicit CLI only; shared across one trial\'s changed nets.\n'
assert blob(new,'mistral/arch.h').count(added)==1 and blob(new,'mistral/arch.h').replace(added,b'',1)==blob(base,'mistral/arch.h')
name='mistral/private_pair_decomposition.cc';a=blob(base,name);b=blob(new,name);assert a==blob(old,name)
extra=b'    if (critical_private_pair_route_nodes<1 || critical_private_pair_route_nodes>2000000)\n        log_error("Critical private pair local route node budget must be 1..2000000.\\n");\n    if (critical_private_pair_route_nodes!=500000)\n        log_info("Critical private pair local search node budget: %d per trial.\\n",critical_private_pair_route_nodes);\n'
assert b.count(extra)==1
normalized=b.replace(extra,b'').replace(b'visit_budget>2000000',b'visit_budget>500000').replace(b'local route node budget must be 1..2000000',b'local route node budget must be 1..500000').replace(b'choice.candidate,critical_private_pair_route_nodes,[&]()',b'choice.candidate,500000,[&]()')
assert normalized==a
for n,v in identity['files'].items():assert hashlib.sha256(blob(new,n)).hexdigest()==v['sha256']
value={'passed':True,'reader_compiler_commit':old,'route_compiler_commit':new,'reader_binary_sha256':sha(H/'tree-reader'),'reader_source_sha256':sha(H/'tree-reader.cc'),'reader_build_receipt_sha256':sha(H/'build-receipt.json'),'reader_frozen_manifest_sha256':sha(H/'frozen-manifest.json'),'route_source_identity_sha256':sha(R/'source-identity.json'),'prior_budget_compatibility_sha256':sha(H/'prior-budget-compatibility.json'),'prior_budget_reader_review_sha256':sha(H/'prior-budget-reader-review.json'),'unchanged_snapshotted_source_files':same,'changed_snapshotted_source_files':different,'production_delta_from_budget_commit':sorted(delta),'arch_header_addition':added.decode().strip(),'private_source_normalizes_exact_after_only_node_guard_config_log_call_changes':True,'scope':'Structural saved-JSON source/sink/PIP decoding only. Parser/model/physical decoding source remains exact. The old reader has its own consistent old Context ABI; new Arch integer is never accessed. Changed private trial/orchestration functions and CLI main are never called. No routing, pin allocation, configuration, STA or new-object ABI execution is authorized.'}
(H/'architecture-compatibility.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');print(sha(H/'architecture-compatibility.json'))
