#!/usr/bin/env python3
"""Read complete parent-produced final artifacts; never routes or builds."""
import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
route=ROOT/'route/routed.json';plan=ROOT/'plan.json';binary=ROOT/'native-routed-masks'
receipt=json.loads((ROOT/'route/receipt.json').read_text())
assert receipt['returncode'] in (0,1) and sha(route)==receipt['artifacts']['routed.json']
assert all(name in receipt['artifacts'] for name in ['routed.json','timing.json','endpoints.json','diagnostic.rbf'])
assert sha(ROOT/'candidate-placed.json')==receipt['input_sha256']
proof=ROOT/'route-native-mask-proof.json'
command=[str(binary),str(route),str(plan),str(proof)]
before=sha(route);start=time.monotonic()
with (ROOT/'route-native-mask.log').open('w') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
record={'command':command,'input_sha256':before,'plan_sha256':sha(plan),'binary_sha256':sha(binary),
        'verifier_source_sha256':sha(ROOT/'verify_routed_masks.cc'),'returncode':result.returncode,
        'elapsed_seconds':time.monotonic()-start,'input_unchanged':sha(route)==before}
assert record['input_unchanged']
if result.returncode==0:record['proof_sha256']=sha(proof)
(ROOT/'route-native-mask-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
assert result.returncode==0
with (ROOT/'proof-routed.log').open('w') as log:
    subprocess.run(['python3',str(ROOT/'prove-routed.py'),'--self-test'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('Final routed mask, complete graph and endpoint checks passed')
