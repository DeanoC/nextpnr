#!/usr/bin/env python3
"""Build this standalone diagnostic against frozen copies; never rebuild nextpnr."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess

root=Path(__file__).resolve().parent
source=root/'frozen-source'
build=root/'frozen-build'
manifest=json.loads((root/'frozen-object-manifest.json').read_text())
for item in manifest['objects']:
    assert hashlib.sha256(Path(item['copy']).read_bytes()).hexdigest()==item['sha256']
definitions=['ARCHNAME=mistral','ARCH_MISTRAL','NEXTPNR_NAMESPACE=nextpnr_mistral','NO_GUI','NO_PYTHON','NO_RUST',
             'NPNR_GPU_ROUTER_DEVICE=1','USE_PROF_API=1','__HIP_PLATFORM_AMD__=1']
includes=[root/'frozen-model-headers',source/'common/kernel',source/'mistral',build/'common',
          source/'frontend',source/'json',source/'rust',source/'3rdparty/json11',source/'common/place',
          source/'common/route',source/'3rdparty/oourafft',Path('/usr/include/eigen3'),Path('/opt/rocm/include')]
compile_command=['/usr/bin/c++','-std=c++17','-Wall','-Wextra','-Werror','-Wno-unused-parameter',
                 '-Wno-missing-field-initializers','-Wno-misleading-indentation','-O1','-g','-fPIC']
compile_command += ['-D'+d for d in definitions]
compile_command += [arg for p in includes for arg in ['-I',str(p)]]
compile_command += ['-c',str(root/'verify_routed_masks.cc'),'-o',str(root/'verify_routed_masks.o')]
original=shlex.split((root/'original-link-command.txt').read_text())
begin=original.index('/usr/bin/c++');original=original[begin:original.index('&&',begin)]
link=[];i=0
while i<len(original):
    a=original[i];i+=1
    if a.startswith('-Wl,--dependency-file=') or a=='-flto=auto':continue
    if a.endswith('/main.cc.o'):
        link.append(str(root/'verify_routed_masks.o'));continue
    if a=='-o':link.extend(['-o',str(root/'native-routed-masks')]);i+=1;continue
    if a.endswith(('.o','.a')) and not a.startswith('/'):
        a=str(build/a)
    link.append(a)
link.extend(['-flto=2'])
(root/'routed-verifier-build-commands.json').write_text(json.dumps({'compile':compile_command,'link':link},indent=2)+'\n')
with (root/'routed-verifier-build.log').open('wb') as log:
    subprocess.run(compile_command,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=root)
    subprocess.run(link,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=root)
print('helper_sha256',hashlib.sha256((root/'native-routed-masks').read_bytes()).hexdigest())
