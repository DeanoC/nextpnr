// Read-only interpretation of final routed saved maps. No placement, pin assignment or routing.
#include "nextpnr.h"
#include "json_frontend.h"
#include "json11.hpp"
#include <array>
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
USING_NEXTPNR_NAMESPACE
using J=json11::Json;
static void need(bool yes,const std::string &why){if(!yes)throw std::runtime_error(why);}
static J read(const char *path){std::ifstream f(path);need(bool(f),"Cannot read JSON");
    std::string text((std::istreambuf_iterator<char>(f)),{}),error;auto j=J::parse(text,error);need(error.empty(),error);return j;}
static J decoded(const Property &property){auto text=property.as_string();need(text.size()%2==0,"Invalid hex length");std::string out,error;
    auto digit=[](char ch)->int{if(ch>='0'&&ch<='9')return ch-'0';if(ch>='a'&&ch<='f')return ch-'a'+10;
        if(ch>='A'&&ch<='F')return ch-'A'+10;throw std::runtime_error("Invalid hex digit");};
    for(size_t i=0;i<text.size();i+=2)out.push_back(char(16*digit(text[i])+digit(text[i+1])));
    auto result=J::parse(out,error);need(error.empty(),error);return result;}
using Alm=std::pair<uint32_t,uint8_t>;
static Alm alm(Context &c,BelId b){const auto &d=c.bel_data(b).lab_data;return {d.lab,d.alm};}
struct Move{CellInfo *cell;BelId to;};
static int physical_bit(IdString pin)
{
    if(pin==id_A)return 0; if(pin==id_B)return 1; if(pin==id_C || pin==id_D)return 2;
    if(pin==id_E0 || pin==id_E1)return 3; if(pin==id_F0 || pin==id_F1)return 4;
    throw std::runtime_error("Unexpected L5 physical input");
}
static int prove_masks(Context &c,const std::vector<Move> &moves)
{
    int rows=0;
    for(const auto &m:moves) {
        if(m.cell->type!=id_MISTRAL_ALUT4)continue;
        auto a=alm(c,m.to); const auto &d=c.labs[a.first].alms[a.second];
        need(!c.labs[a.first].is_mlab && !d.l6_mode && !d.carry_mode,"Unexpected destination ALM mode");
        int half=d.lut_bels[1]==m.to; uint64_t physical=c.compute_lut_mask(a.first,a.second);
        uint64_t logical=m.cell->params.at(id_LUT).as_int64();
        std::array<IdString,4> ports{id_A,id_B,id_C,id_D};
        for(int raw=0;raw<16;raw++) {
            int forced_mask=0,forced_bits=0;
            for(int p=0;p<4;p++) {
                const auto &mapped=m.cell->pin_data.at(ports[p]);
                need(mapped.state==PIN_SIG && mapped.bel_pins.size()==1,"Invalid selected physical input mapping");
                auto bp=mapped.bel_pins[0]; need(c.bel_data(m.to).pins.count(bp),"Unknown destination pin");
                int bit=physical_bit(bp); need(!(forced_mask&(1<<bit)),"Distinct logical signals share physical pin");
                forced_mask|=1<<bit;
                // ALM truth-table inputs are active-low in the backend encoding.
                if(!(raw&(1<<p))) forced_bits|=1<<bit;
            }
            for(int vector=0;vector<32;vector++) if((vector&forced_mask)==forced_bits) {
                bool actual=!((physical>>(half*32+vector))&1),expected=(logical>>raw)&1;
                need(actual==expected,"Native physical LUT mask disagrees with unchanged logical truth table"); ++rows;
            }
        }
    }
    return rows;
}
int main(int argc,char **argv){try{
    need(argc==4,"Usage: native-routed-masks routed.json plan.json proof.json");
    ArchArgs args;args.device="5CSEBA6U23I7";Context c(args);std::ifstream input(argv[1]);
    need(parse_json(input,argv[1],&c),"Cannot parse routed checkpoint");
    need(c.attrs.at(id_step).as_string()=="route","Not a final routed checkpoint");
    need(!c.fes_any_slot_region_active && !c.fes_fence_active && !c.fes_has_reserved_rect,"Unexpected frozen region");
    c.restore_placed_pin_maps();
    auto snapshot=decoded(c.attrs.at(c.id("FES_LABSTATE_V1")));
    need(snapshot.object_items().size()==2 && snapshot["device"].string_value()==args.device &&
         snapshot["labs"].array_items().size()==c.labs.size(),"Routed LAB snapshot shape mismatch");
    for(size_t index=0;index<c.labs.size();index++){
        auto &lab=c.labs[index];auto entry=snapshot["labs"][index];auto loc=c.getBelLocation(lab.alms[0].lut_bels[0]);
        need(entry.array_items().size()==4 && entry[0].int_value()==loc.x && entry[1].int_value()==loc.y &&
             entry[2].int_value()==int(lab.is_mlab) && entry[3].array_items().size()==62,"Routed LAB geometry mismatch");
        auto state=entry[3].array_items();
        for(size_t k=0;k<state.size();k++){
            int limit=k>=2 && ((k-2)%6==2 || (k-2)%6==3)?2:1;
            need(state[k].is_number() && state[k].number_value()==state[k].int_value() &&
                 state[k].int_value()>=0 && state[k].int_value()<=limit,"Invalid routed LAB state field");
        }
        lab.aclr_used={bool(state[0].int_value()),bool(state[1].int_value())};
        for(size_t ai=0;ai<10;ai++){
            auto &a=lab.alms[ai];size_t k=2+6*ai;a.l6_mode=state[k].int_value();a.carry_mode=state[k+1].int_value();
            a.clk_ena_idx={state[k+2].int_value(),state[k+3].int_value()};a.aclr_idx={state[k+4].int_value(),state[k+5].int_value()};
        }
    }
    auto plan=read(argv[2]);need(plan["moves"].array_items().size()==18,"Need exact eighteen-cell plan");
    std::vector<Move> moves;std::set<CellInfo*> cells;std::set<BelId> bels;std::set<uint32_t> touched;
    std::set<NetInfo*> bank_bits;std::set<uint64_t> onehot;int rams=0,luts=0;
    for(const auto &entry:plan["moves"].array_items()){
        auto name=c.id(entry["cell"].string_value());need(c.cells.count(name),"Missing selected cell");auto *cell=c.cells.at(name).get();
        need(cells.insert(cell).second && cell->type.str(&c)==entry["type"].string_value(),"Duplicate or wrong selected cell");
        auto destination=c.getBelByNameStr(entry["new_bel"].string_value());
        need(destination!=BelId() && cell->bel==destination && bels.insert(destination).second,"Wrong or duplicate final BEL");
        need(c.restore_cell_pin_map(cell),"Missing selected saved map");J::object pins;
        for(const auto &pin:cell->pin_data){J::array values{int(pin.second.state)};
            for(auto physical:pin.second.bel_pins)values.emplace_back(physical.str(&c));pins[pin.first.str(&c)]=values;}
        need(decoded(cell->attrs.at(c.id("FES_PINMAP_V1")))==J(J::object{{"count",int(pins.size())},{"pins",pins}}),
             "Native restored map differs from final serialized map");
        moves.push_back({cell,destination});
        if(cell->type==id_MISTRAL_M10K){++rams;for(int i=0;i<2;i++){
            auto *n=cell->getPort(c.idf("B1DATA[%d]",i));need(n && n->driver.cell==cell && bank_bits.insert(n).second,"RAM output alias");}}
        else{need(cell->type==id_MISTRAL_ALUT4,"Unexpected primitive");++luts;
            auto from=c.getBelByNameStr(entry["old_bel"].string_value());need(from!=BelId(),"Original site missing");
            touched.insert(alm(c,from).first);touched.insert(alm(c,destination).first);
            need(cell->pin_data.at(id_Q).state==PIN_SIG,"Unexpected decoder output inversion");
            uint64_t mask=cell->params.at(id_LUT).as_int64();need(mask && !(mask&(mask-1)) && mask<=0x8000 && onehot.insert(mask).second,"Decoder masks changed");}
    }
    need(rams==2 && luts==16 && bank_bits.size()==4,"Wrong bank shape");
    for(const auto &m:moves)if(m.cell->type==id_MISTRAL_ALUT4){std::set<NetInfo*> inputs;
        for(auto pin:{id_A,id_B,id_C,id_D})inputs.insert(m.cell->getPort(pin));need(inputs==bank_bits,"Decoder inputs changed");}
    for(auto lab:touched)for(const auto &a:c.labs[lab].alms){
        for(auto bel:{a.lut_bels[0],a.lut_bels[1],a.ff_bels[0],a.ff_bels[1],a.ff_bels[2],a.ff_bels[3]})
            if(c.getBoundBelCell(bel))need(c.isBelLocationValid(bel,true),"Final touched LAB is illegal");}
    for(const auto &m:moves)need(c.isBelLocationValid(m.to,true),"Final selected BEL illegal");
    int rows=prove_masks(c,moves);need(rows==512,"Incomplete final mask proof");c.check();
    std::ofstream output(argv[3]);need(bool(output),"Cannot write proof");
    output<<J(J::object{{"kind","read-only final routed physical decoder-mask qualification; no electrical or RBF proof"},
       {"selected_cells",18},{"physical_truth_rows",rows},{"all_touched_labs_legal",true},
       {"saved_routed_lab_state_restored_without_locking",true},{"saved_physical_maps_restored_exactly",true},
       {"no_placement_pin_assignment_or_routing",true}}).dump()<<"\n";return 0;
}catch(const std::exception &error){std::cerr<<"REJECTED: "<<error.what()<<"\n";return 1;}}
