#!/usr/bin/env python3
"""Native fail-closed input-plan checks. Produces no checkpoint on rejection."""
import copy
import hashlib
import json
import subprocess
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
plan=json.loads((ROOT/'plan.json').read_text());source=Path(plan['source_path'])
assert hashlib.sha256(source.read_bytes()).hexdigest()==plan['source_sha256']
cells=json.loads(source.read_bytes())['modules']['top']['cells']
selected={m['cell'] for m in plan['moves']}
occupied=next(c['attributes']['NEXTPNR_BEL'] for n,c in cells.items() if n not in selected and c['type']=='MISTRAL_M10K')
kept_name,kept=next((n,c) for n,c in cells.items() if c['type']=='MISTRAL_FF' and 'keep' in c['attributes'])
cases={}
p=copy.deepcopy(plan);p['moves'][0]['new_bel']=occupied;cases['occupied_ram']=(p,'occupied by unselected')
p=copy.deepcopy(plan);p['moves'][1]['new_bel']=p['moves'][0]['new_bel'];cases['duplicate_destination']=(p,'Duplicate destination')
p=copy.deepcopy(plan);p['moves'][0]['new_bel']=kept['attributes']['NEXTPNR_BEL'];cases['wrong_bel_type']=(p,'Invalid destination BEL type')
p=copy.deepcopy(plan);p['moves'][0].update(cell=kept_name,type=kept['type'],old_bel=kept['attributes']['NEXTPNR_BEL']);cases['protected_ff']=(p,'protected or clustered')
results=[]
for name,(bad,reason) in cases.items():
    path=ROOT/('reject-'+name+'.json');path.write_text(json.dumps(bad,indent=2)+'\n')
    prefix=ROOT/('reject-'+name);proof=ROOT/('reject-'+name+'-proof.json')
    outputs=[Path(str(prefix)+suffix) for suffix in ['-baseline.json','-candidate.json']]+[proof]
    assert all(not f.exists() for f in outputs)
    command=[str(ROOT/'native-ram-decode'),'apply',str(source),str(path),str(prefix),str(proof)]
    started=time.monotonic();proc=subprocess.run(command,capture_output=True,text=True)
    (ROOT/('reject-'+name+'.log')).write_text(proc.stdout+proc.stderr)
    assert proc.returncode!=0 and reason in proc.stderr and all(not f.exists() for f in outputs)
    results.append({'name':name,'returncode':proc.returncode,'expected_reason':reason,'seconds':time.monotonic()-started,
       'no_checkpoint_or_proof_created':True,'stderr':proc.stderr.strip()})
(ROOT/'rejection-tests.json').write_text(json.dumps({'binary_sha256':hashlib.sha256((ROOT/'native-ram-decode').read_bytes()).hexdigest(),'cases':results},indent=2)+'\n')
print(json.dumps(results,indent=2))
