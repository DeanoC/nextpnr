#!/usr/bin/env python3
"""Transplant native-qualified placement attrs; preserve every other source byte."""
import hashlib
import json
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(path):return json.loads(path.read_bytes())
def require(condition,message):
    if not condition:raise ValueError(message)
def differences(a,b,path=()):
    if type(a)!=type(b):return [(path,a,b)]
    if isinstance(a,dict):
        require(list(a)==list(b),'Object member ordering or inventory changed at '+repr(path))
        return [d for k in a for d in differences(a[k],b[k],path+(k,))]
    if isinstance(a,list):
        require(len(a)==len(b),'Array length changed at '+repr(path))
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in differences(x,y,path+(i,))]
    return [] if a==b else [(path,a,b)]

def main():
    plan=load(ROOT/'plan.json');source=Path(plan['source_path']);raw=source.read_bytes()
    require(sha(raw)==plan['source_sha256'],'Source hash mismatch')
    original=json.loads(raw);baseline=load(ROOT/'placed-baseline.json');candidate=load(ROOT/'placed-candidate.json')
    original_cells=original['modules']['top']['cells'];a=baseline['modules']['top'];b=candidate['modules']['top']
    require(set(original_cells)==set(a['cells'])==set(b['cells']),'Cell inventory changed')
    require(a['settings']==b['settings'] and a['attributes']==b['attributes'] and a['ports']==b['ports'] and a['netnames']==b['netnames'],'Native transaction changed surrounding module')
    selected={m['cell']:m for m in plan['moves']};expected={}
    for name,cell in a['cells'].items():
        require(cell['attributes']==original_cells[name]['attributes'],'Native load changed source cell attrs')
        changed=differences(cell,b['cells'][name])
        if name not in selected:require(not changed,'Native transaction changed unselected cell')
        else:
            allowed={'NEXTPNR_BEL'} | ({'FES_PINMAP_V1'} if cell['type']=='MISTRAL_ALUT4' else set())
            require({d[0] for d in changed}=={('attributes',k) for k in allowed},'Unexpected selected-cell mutation')
            require(cell['attributes']['NEXTPNR_BEL']==selected[name]['old_bel'],'Old BEL mismatch')
            require(b['cells'][name]['attributes']['NEXTPNR_BEL']==selected[name]['new_bel'],'New BEL mismatch')
            old_pins=json.loads(bytes.fromhex(cell['attributes']['FES_PINMAP_V1']))
            new_pins=json.loads(bytes.fromhex(b['cells'][name]['attributes']['FES_PINMAP_V1']))
            require({p:v[0] for p,v in old_pins['pins'].items()}=={p:v[0] for p,v in new_pins['pins'].items()},'Logical pin states changed')
            for path,old,new in changed:expected[(name,path[-1])]=(old,new)
    require(len(expected)==34,'Expected exactly 18 BEL and 16 physical pin-map edits')
    # Decode each complete cell to find its exact byte span; never replace a pin-map token globally.
    text=raw.decode('utf-8');decoder=json.JSONDecoder();start=re.search(r'"cells"\s*:\s*\{',text).end();pos=start
    spans={}
    while True:
        while text[pos].isspace() or text[pos]==',':pos+=1
        if text[pos]=='}':break
        name,pos=decoder.raw_decode(text,pos)
        while text[pos].isspace():pos+=1
        require(text[pos]==':','Malformed cell object');pos+=1
        while text[pos].isspace():pos+=1
        cell_start=pos;value,pos=decoder.raw_decode(text,pos)
        require(value==original_cells[name],'Cell span does not match parsed original')
        spans[name]=(cell_start,pos)
    require(set(spans)==set(original_cells),'Cell byte-span inventory changed')
    edits=[]
    for (name,key),(old,new) in expected.items():
        lo,hi=spans[name];body=text[lo:hi]
        pattern=re.compile(r'"'+re.escape(key)+r'"\s*:\s*("(?:[^"\\]|\\.)*")')
        hits=list(pattern.finditer(body));require(len(hits)==1,'Nonunique cell attribute token')
        hit=hits[0];require(json.loads(hit.group(1))==old,'Old attribute token mismatch')
        edits.append((lo+hit.start(1),lo+hit.end(1),json.dumps(new,ensure_ascii=True),name,key))
    edits.sort();chunks=[];inverse=[];cursor=0;new_cursor=0
    for lo,hi,new,name,key in edits:
        require(lo>=cursor,'Overlapping edits');chunks.append(text[cursor:lo]);new_cursor+=lo-cursor
        chunks.append(new);inverse.append((new_cursor,new_cursor+len(new),text[lo:hi]));new_cursor+=len(new);cursor=hi
    chunks.append(text[cursor:]);result=''.join(chunks);restored=result
    for lo,hi,old in reversed(inverse):restored=restored[:lo]+old+restored[hi:]
    require(restored==text,'Exact inverse did not restore original bytes')
    after=json.loads(result);diff=differences(original,after)
    wanted={(('modules','top','cells',name,'attributes',key),old,new) for (name,key),(old,new) in expected.items()}
    require(set(diff)==wanted,'Final artifact changes something outside native-qualified attributes')
    output=ROOT/'candidate-placed.json';output.write_bytes(result.encode('utf-8'))
    proof={'kind':'Exact-source diagnostic checkpoint with native-qualified selected placement and pin maps; no route/timing/hardware acceptance',
      'source_path':str(source),'source_sha256':sha(raw),'candidate_path':str(output),'candidate_sha256':sha(output.read_bytes()),
      'source_bytes':len(raw),'candidate_bytes':output.stat().st_size,'attribute_edits':len(edits),
      'proof':{'exact_byte_inverse':True,'complete_ordered_logical_graph_preserved':True,
       'all_net_aliases_empty_ports_and_constant_connections_preserved':True,'all_unselected_cell_bytes_preserved':True,
       'all_ff_keep_carry_and_ram_initialisation_preserved':True,'all_logical_pin_states_preserved':True,
       'all_clocks_phases_timing_settings_preserved':True,'all_source_attributes_match_native_normalized_baseline':True},
      'native_normalization_note':'Native JSON frontend/writer drops 18 orphan iobuf aliases and empty ports on a normal load/write. This artifact retains all original source bytes except the 34 native-qualified attributes.',
      'evidence_sha256':{name:sha((ROOT/name).read_bytes()) for name in ['plan.json','native-proof.json','placed-baseline.json','placed-candidate.json','native_ram_decode.cc','native-ram-decode','finalize_checkpoint.py']},
      'all_differences':[{'path':path,'before':old,'after':new} for path,old,new in diff]}
    (ROOT/'checkpoint-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps({k:proof[k] for k in ['source_sha256','candidate_sha256','attribute_edits','source_bytes','candidate_bytes']},indent=2))
if __name__=='__main__':main()
