#!/usr/bin/env python3
"""One deterministic geometry plan from native-qualified free BELs. No mutation/routing."""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def xy(bel):
    return tuple(map(int, bel.split('.')[1:3]))

def predict(a,b):
    dx,dy=abs(a[0]-b[0]),abs(a[1]-b[1])
    return 650 + (250 if dy else 0) + 35*dx + 100*dy

def assignment(costs):
    n,m=len(costs),len(costs[0]); assert n<=m
    u,v,p,way=[0]*(n+1),[0]*(m+1),[0]*(m+1),[0]*(m+1)
    for i in range(1,n+1):
        p[0],j0=i,0; minv,used=[10**30]*(m+1),[False]*(m+1)
        while True:
            used[j0]=True; i0,delta,j1=p[j0],10**30,0
            for j in range(1,m+1):
                if not used[j]:
                    cur=costs[i0-1][j-1]-u[i0]-v[j]
                    if cur<minv[j]:minv[j],way[j]=cur,j0
                    if minv[j]<delta:delta,j1=minv[j],j
            for j in range(m+1):
                if used[j]:u[p[j]]+=delta;v[j]-=delta
                else:minv[j]-=delta
            j0=j1
            if p[j0]==0:break
        while True:
            j1=way[j0];p[j0],j0=p[j1],j1
            if j0==0:break
    result=[-1]*n
    for j in range(1,m+1):
        if p[j]:result[p[j]-1]=j-1
    assert len(set(result))==n and min(result)>=0
    return result

def main():
    plan=json.loads((ROOT/'identities.json').read_text())
    source=Path(plan['source_path']); assert digest(source)==plan['source_sha256']
    module=json.loads(source.read_bytes())['modules']['top'];cells=module['cells']
    sites=json.loads((ROOT/'native-sites-capacity.json').read_text())
    cone_path=ROOT.parent/'ram-all-20261022/east-decode-cone.json'
    cone=json.loads(cone_path.read_text());decoders={d['cell']:d for d in cone['decoders']}
    dests=['MISTRAL_M10K.14.39.0','MISTRAL_M10K.14.40.0']
    rams=[m for m in plan['moves'] if m['type']=='MISTRAL_M10K']
    for move,bel in zip(rams,dests):
        assert bel in sites['free_m10k'];move['new_bel']=bel
    luts=[m for m in plan['moves'] if m['type']=='MISTRAL_ALUT4']
    by_lab=collections.defaultdict(list)
    for site in sorted(sites['empty_ordinary_alms'],key=lambda s:(s['x'],s['y'],s['z'])):
        if site['baseline_lab_legal']:by_lab[site['lab']].append(site)
    options=[]
    for group in by_lab.values():
        # Native conservative LAB budget counts each selected four-input LUT.
        capacity=max(0,(42-group[0]['lab_input_count'])//4)
        options.extend(group[:capacity])
    options.sort(key=lambda s:(s['x'],s['y'],s['z']))
    # One LUT per wholly empty ALM avoids changing any existing LUT/FF pin mapping.
    # Each complete RAM->decoder->capture path is represented by its two estimated legs.
    def score(move,site):
        incoming=[predict(xy(bel),(site['x'],site['y'])) for bel in dests]
        outgoing=[predict((site['x'],site['y']),xy(u['bel'])) for u in decoders[move['cell']]['output_users']]
        return (max(incoming)+max(outgoing))*100000 + sum(incoming)*2+sum(outgoing)
    costs=[[score(move,site) for site in options] for move in luts]
    chosen=assignment(costs)
    for move,j in zip(luts,chosen):move['new_bel']=options[j]['bel']
    new_bels={m['cell']:m['new_bel'] for m in plan['moves']}
    plan.update({'kind':'bounded native two RAM and sixteen one-hot decoder placement experiment',
      'objective':'Fixed free M10K14,39/40; minimize sum of each decoder worst two-leg placement estimate, then edge sum; each decoder gets a distinct whole-empty ALM within native 42-input LAB capacity',
      'caveat':'Placement geometry estimate only, not route timing. Independent of the fourteen-RAM experiment; destination conflicts must be reassigned before combining.',
      'provenance':{str(p):digest(p) for p in [ROOT/'native-sites-capacity.json',cone_path,Path(__file__)]}})
    drivers={};users=collections.defaultdict(list);aliases=collections.defaultdict(list)
    for name,net in module['netnames'].items():
        for i,bit in enumerate(net['bits']):aliases[bit].append([name,i])
    for name,cell in cells.items():
        for port,bits in cell['connections'].items():
            for index,bit in enumerate(bits):
                item={'cell':name,'port':port,'bit_index':index,'type':cell['type'],
                      'old_bel':cell['attributes']['NEXTPNR_BEL'],
                      'new_bel':new_bels.get(name,cell['attributes']['NEXTPNR_BEL'])}
                if cell['port_directions'][port]=='output':assert bit not in drivers;drivers[bit]=item
                else:users[bit].append(item)
    incident=sorted({b for name in new_bels for bits in cells[name]['connections'].values() for b in bits},key=str)
    nets=[]
    for bit in incident:
        nets.append({'bit':bit,'aliases':aliases[bit],'driver':drivers.get(bit),'all_users':users[bit]})
    metrics=collections.defaultdict(list)
    for net in nets:
        driver=net['driver']
        if not driver:continue
        for user in net['all_users']:
            if user['cell'] not in new_bels and driver['cell'] not in new_bels:continue
            kind='other'
            if user['cell'] in new_bels and user['type']=='MISTRAL_M10K' and user['port']=='B1ADDR':kind='address'
            elif driver['cell'] in new_bels and driver['type']=='MISTRAL_M10K' and user['type']=='MISTRAL_ALUT4':kind='ram_to_decoder'
            elif driver['cell'] in new_bels and driver['type']=='MISTRAL_ALUT4':kind='decoder_to_capture'
            elif driver['cell'] in new_bels and driver['type']=='MISTRAL_M10K':kind='ram_to_direct_capture'
            old_a,old_b=xy(driver['old_bel']),xy(user['old_bel'])
            new_a,new_b=xy(driver['new_bel']),xy(user['new_bel'])
            metrics[kind].append({'driver':driver,'user':user,'old_estimate_ps':predict(old_a,old_b),
              'new_estimate_ps':predict(new_a,new_b),'old_manhattan':sum(abs(a-b) for a,b in zip(old_a,old_b)),
              'new_manhattan':sum(abs(a-b) for a,b in zip(new_a,new_b))})
    summary={}
    for kind,rows in metrics.items():
        summary[kind]={'edges':len(rows),'closer':sum(r['new_manhattan']<r['old_manhattan'] for r in rows),
          'farther':sum(r['new_manhattan']>r['old_manhattan'] for r in rows),
          **{key:sum(r[key] for r in rows) for key in ['old_manhattan','new_manhattan','old_estimate_ps','new_estimate_ps']},
          'old_max_estimate_ps':max(r['old_estimate_ps'] for r in rows),'new_max_estimate_ps':max(r['new_estimate_ps'] for r in rows)}
    paths=[]
    for move in luts:
        decoder=decoders[move['cell']]
        old_in=max(predict(xy(m['old_bel']),xy(move['old_bel'])) for m in rams)
        new_in=max(predict(xy(m['new_bel']),xy(move['new_bel'])) for m in rams)
        for user in decoder['output_users']:
            paths.append({'decoder':move['cell'],'capture':user['cell'],
              'old_two_leg_estimate_ps':old_in+predict(xy(move['old_bel']),xy(user['bel'])),
              'new_two_leg_estimate_ps':new_in+predict(xy(move['new_bel']),xy(user['bel']))})
    plan['geometry_summary']=summary
    plan['geometry_paths']={'paths':len(paths),'improved':sum(p['new_two_leg_estimate_ps']<p['old_two_leg_estimate_ps'] for p in paths),
       'worsened':sum(p['new_two_leg_estimate_ps']>p['old_two_leg_estimate_ps'] for p in paths),
       'old_worst_ps':max(p['old_two_leg_estimate_ps'] for p in paths),
       'new_worst_ps':max(p['new_two_leg_estimate_ps'] for p in paths)}
    (ROOT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    (ROOT/'geometry-and-fanouts.json').write_text(json.dumps({'incident_nets':nets,'edge_geometry':metrics,'return_path_geometry':paths},indent=2)+'\n')
    print(json.dumps({'summary':summary,'paths':plan['geometry_paths'],'moves':plan['moves']},indent=2))
if __name__=='__main__':main()
