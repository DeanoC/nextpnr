#!/usr/bin/env python3
"""Complete durable capture: selected inputs, final RBF/reports, sources and receipts."""
import hashlib,json,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
compact=json.loads((ROOT/'compact-evidence/artifact-manifest.json').read_text())
files={name:ROOT/name for name in compact['included']}
for name in ['candidate-placed.json','placed-baseline.json','placed-candidate.json',
             'route/diagnostic.rbf','route/routed.json','route/endpoints.json','route/timing.json',
             'route.py','package_complete.py']:
    assert name not in files;files[name]=ROOT/name
files['reference-baseline-receipt.json']=ROOT.parent/'reassociate-20261022/baseline/receipt.json'
files['inputs/constraints.qsf']=Path('/tmp/pcxt-replicate-leased-20261022/inputs/constraints.qsf')
files['inputs/clocks.sdc']=Path('/tmp/pcxt-replicate-leased-20261022/inputs/clocks.sdc')
assert all(path.is_file() for path in files.values())
manifest={'kind':'Complete PC/XT RAM-decoder diagnostic capture, including final route/RBF and reports',
 'route_charge_seconds':json.loads((ROOT/'route/receipt.json').read_text())['charged_seconds'],
 'ledger_scope':'This run only; parent owns cumulative accounting',
 'members':{name:{'source_path':str(path.resolve()),'sha256':sha(path),'bytes':path.stat().st_size} for name,path in sorted(files.items())},
 'excluded_large_build_inputs':'Frozen objects, compiler source archive, model headers and executables; their complete identities remain in frozen-object-manifest.json and build receipts',
 'shared_baseline':{'capture':'../2026-10-22-pcxt-reassociation/capture.tar.gz',
                    'sha256':'0511f300a4ece620dfb2323b3de7fc3d4f72e6787aae0da2b45b1fb4958f20cc',
                    'source_placed_sha256':'9241b02074cfee262c985c9ddde7e2c71f05bc654d35b989857a9a93ccc58878'},
 'timing_accepted':False,'hardware_evidence':'none'}
mf=ROOT/'complete-capture-manifest.json';mf.write_text(json.dumps(manifest,indent=2)+'\n')
files['manifest.json']=mf
archive=ROOT/'complete-capture.tar.gz';prefix='ram-decode-20261022/'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
    for name,path in sorted(files.items()):tar.add(path,arcname=prefix+name,recursive=False)
verified=[]
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(files)
    for member in tar.getmembers():
        name=member.name.removeprefix(prefix);assert name in files and member.isfile()
        data=tar.extractfile(member).read();digest=hashlib.sha256(data).hexdigest()
        assert digest==sha(files[name]) and len(data)==files[name].stat().st_size
        verified.append({'member':member.name,'sha256':digest,'bytes':len(data)})
record={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'verified_members':len(verified),
        'complete_candidate_and_final_route_rbf_reports_included':True,
        'all_members_read_back_and_sha256_verified':True,'members':verified}
(ROOT/'complete-capture-readback.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='members'},indent=2))
