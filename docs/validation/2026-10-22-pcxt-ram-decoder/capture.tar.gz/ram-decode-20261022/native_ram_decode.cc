// Isolated diagnostic executable. Never packs, places globally, routes or writes an RBF.
#include "nextpnr.h"
#include "json_frontend.h"
#include "jsonwrite.h"
#include "json11.hpp"
#include "log.h"
#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <stdexcept>

USING_NEXTPNR_NAMESPACE
using J = json11::Json;
using Alm = std::pair<uint32_t, uint8_t>;
static void need(bool yes, const std::string &why) { if (!yes) throw std::runtime_error(why); }
static std::string belname(Context &c, BelId b) { return b == BelId() ? "" : c.getBelName(b).str(&c); }
static J read(const std::string &path)
{
    std::ifstream f(path); need(bool(f), "Cannot read " + path);
    std::string text((std::istreambuf_iterator<char>(f)), {}), error;
    auto j = J::parse(text, error); need(error.empty(), error); return j;
}
static void write(const std::string &path, const std::string &text)
{
    std::ofstream f(path); need(bool(f), "Cannot write " + path); f << text; need(bool(f), "Write failed");
}
static std::string serialise(Context &c)
{
    std::ostringstream out; std::string name = "native-checkpoint";
    need(write_json_file(out, name, &c), "Checkpoint writer failed"); return out.str();
}
static Alm alm(Context &c, BelId b)
{
    const auto &d = c.bel_data(b).lab_data; return {d.lab, d.alm};
}
static std::array<BelId,6> members(Context &c, Alm a)
{
    const auto &d=c.labs.at(a.first).alms.at(a.second);
    return {d.lut_bels[0],d.lut_bels[1],d.ff_bels[0],d.ff_bels[1],d.ff_bels[2],d.ff_bels[3]};
}
static bool protected_cell(Context &c, CellInfo *cell)
{
    if (cell->belStrength>STRENGTH_WEAK || cell->cluster!=ClusterId() || !cell->constr_children.empty() ||
        cell->constr_x || cell->constr_y || cell->constr_z || cell->constr_abs_z || cell->region || cell->isPseudo()) return true;
    for (const auto &a:cell->attrs) {
        auto k=a.first.str(&c);
        if (k=="keep" || k=="dont_touch" || k=="BEL" || k=="LOC" || k=="FES_SLOT") return true;
    }
    return false;
}
static bool has_keep(Context &c, CellInfo *cell)
{
    for (const auto &a:cell->attrs) if (a.first.str(&c)=="keep") return true;
    return false;
}
struct Move { CellInfo *cell; BelId from, to; PlaceStrength strength; };
static std::vector<Move> identify(Context &c, const J &plan, bool require_destination)
{
    need(plan["moves"].is_array() && plan["moves"].array_items().size()==18, "Need exact 18-cell plan");
    std::vector<Move> result; std::set<CellInfo*> selected; std::vector<CellInfo*> rams,luts;
    for (const auto &entry:plan["moves"].array_items()) {
        CellInfo *cell=nullptr;
        for (const auto &item:c.cells) if (item.first.str(&c)==entry["cell"].string_value()) cell=item.second.get();
        need(cell && selected.insert(cell).second, "Missing or duplicate selected cell");
        need(cell->type.str(&c)==entry["type"].string_value(), "Selected cell type mismatch");
        need(belname(c,cell->bel)==entry["old_bel"].string_value(), "Selected cell source BEL mismatch");
        need(!protected_cell(c,cell), "Selected cell is protected or clustered");
        need(cell->type.in(id_MISTRAL_M10K,id_MISTRAL_ALUT4), "Only M10K/ALUT4 allowed");
        (cell->type==id_MISTRAL_M10K?rams:luts).push_back(cell);
        BelId to;
        if (require_destination) {
            to=c.getBelByNameStr(entry["new_bel"].string_value());
            need(to!=BelId() && c.isValidBelForCellType(cell->type,to), "Invalid destination BEL type");
            need(c.fes_placement_allowed(to,cell), "Destination violates placement region");
        }
        result.push_back({cell,cell->bel,to,cell->belStrength});
    }
    need(rams.size()==2 && luts.size()==16, "Need two RAMs and sixteen ALUT4s");
    std::set<NetInfo*> bank_outputs; std::set<uint64_t> masks;
    for (auto *ram:rams) {
        for (int i=0;i<2;i++) {
            auto *n=ram->getPort(c.idf("B1DATA[%d]",i)); need(n && n->driver.cell==ram,"Missing RAM output");
            need(bank_outputs.insert(n).second,"Aliased RAM output");
        }
        for (int i=0;i<12;i++) {
            auto *n=ram->getPort(c.idf("B1ADDR[%d]",i));
            need(n && n->driver.cell && n->driver.cell->type==id_MISTRAL_FF && has_keep(c,n->driver.cell),
                 "RAM address must retain kept FF launch");
        }
    }
    for (auto *lut:luts) {
        std::set<NetInfo*> inputs;
        for (auto pin:{id_A,id_B,id_C,id_D}) {
            auto *n=lut->getPort(pin); need(n && bank_outputs.count(n),"Decoder input outside selected RAM bank");
            need(lut->pin_data.at(pin).state==PIN_SIG,"Diagnostic requires uninverted decoder inputs");
            inputs.insert(n);
        }
        need(inputs==bank_outputs,"Decoder does not read all four distinct bank bits");
        auto mask=uint64_t(lut->params.at(id_LUT).as_int64());
        need(mask && !(mask&(mask-1)) && mask<=0x8000 && masks.insert(mask).second,"Not a complete unique one-hot bank");
        auto *q=lut->getPort(id_Q); need(q && q->users.entries()==2,"Decoder output fanout changed");
        for (const auto &u:q->users) need(u.cell && u.cell->type==id_MISTRAL_FF && u.port==id_DATAIN && has_keep(c,u.cell),
                                        "Decoder capture must retain kept FFs");
    }
    if (require_destination) {
        std::set<BelId> targets;
        for (const auto &m:result) {
            need(targets.insert(m.to).second,"Duplicate destination");
            auto *occupant=c.getBoundBelCell(m.to);
            need(!occupant || selected.count(occupant),"Destination is occupied by unselected cell");
            if (m.cell->type==id_MISTRAL_M10K) {
                need(!occupant,"RAM destination must be originally free"); continue;
            }
            need(c.getBelType(m.to)==id_MISTRAL_COMB,"Diagnostic destinations must be ordinary LAB LUTs");
            for (auto a:{alm(c,m.from),alm(c,m.to)}) for (auto b:members(c,a)) {
                auto *other=c.getBoundBelCell(b);
                need(!other || (selected.count(other) && other->type==id_MISTRAL_ALUT4),
                     "LUT source/destination ALM contains an unrelated cell or FF");
            }
        }
    }
    return result;
}
static J pin_snapshot(Context &c, const std::set<CellInfo*> &omit_physical={})
{
    J::object all;
    for (const auto &entry:c.cells) {
        auto *cell=entry.second.get(); J::object pins,ports;
        for (const auto &pin:cell->pin_data) {
            J::array value{int(pin.second.state)};
            if (!omit_physical.count(cell)) for (auto p:pin.second.bel_pins) value.emplace_back(p.str(&c));
            pins[pin.first.str(&c)]=value;
        }
        for (const auto &p:cell->ports) ports[p.first.str(&c)]=p.second.user_idx.idx();
        all[entry.first.str(&c)]=J::object{{"pins",pins},{"user_slots",ports}};
    }
    return all;
}
static bool same_labs(const std::vector<LABInfo> &a,const std::vector<LABInfo> &b)
{
    if(a.size()!=b.size()) return false;
    for(size_t i=0;i<a.size();i++) {
        const auto &x=a[i],&y=b[i];
        if(x.is_mlab!=y.is_mlab || x.clk_wires!=y.clk_wires || x.ena_wires!=y.ena_wires ||
           x.aclr_wires!=y.aclr_wires || x.sclr_wire!=y.sclr_wire || x.sload_wire!=y.sload_wire || x.aclr_used!=y.aclr_used) return false;
        for(int j=0;j<10;j++) {
            const auto &p=x.alms[j],&q=y.alms[j];
            if(p.comb_out!=q.comb_out || p.sel_clk!=q.sel_clk || p.sel_ena!=q.sel_ena || p.sel_aclr!=q.sel_aclr ||
               p.sel_ef!=q.sel_ef || p.ff_in!=q.ff_in || p.ff_out!=q.ff_out || p.lut_bels!=q.lut_bels || p.ff_bels!=q.ff_bels ||
               p.l6_mode!=q.l6_mode || p.carry_mode!=q.carry_mode || p.clk_ena_idx!=q.clk_ena_idx ||
               p.aclr_idx!=q.aclr_idx || p.unique_input_count!=q.unique_input_count) return false;
        }
    }
    return true;
}
static J bindings(Context &c)
{
    J::object all;
    for (const auto &e:c.cells) all[e.first.str(&c)]=J::array{belname(c,e.second->bel),int(e.second->belStrength)};
    return all;
}
static void legal(Context &c,const std::set<uint32_t> &labs,const std::vector<Move> &moves,bool check_pins=false)
{
    for(auto lab:labs) for(uint8_t a=0;a<10;a++) for(auto b:members(c,{lab,a}))
        if(c.getBoundBelCell(b) && !c.isBelLocationValid(b,true)) {
            int count=0;for(const auto &item:c.labs[lab].alms)count+=item.unique_input_count;
            need(false,"Touched LAB placement is illegal: "+belname(c,b)+" inputs="+std::to_string(count)+
                 " alm="+std::to_string(c.is_alm_legal(lab,a))+" ctrl="+std::to_string(c.is_lab_ctrlset_legal(lab))+
                 " mlab="+std::to_string(c.check_mlab_groups(lab)));
        }
    for(const auto &m:moves) {
        need(c.isBelLocationValid(m.to,true),"Destination is illegal");
        if(!check_pins)continue;
        for(const auto &pin:m.cell->pin_data) for(auto physical:pin.second.bel_pins) {
            need(c.bel_data(m.to).pins.count(physical),"Saved mapping names no destination physical pin");
            auto logical=m.cell->ports.find(pin.first);
            if(logical!=m.cell->ports.end()) {
                auto direction=c.getBelPinType(m.to,physical);
                need(direction==PORT_INOUT || direction==logical->second.type,"Destination pin direction mismatch");
            }
        }
    }
}
static int physical_bit(IdString pin)
{
    if(pin==id_A)return 0; if(pin==id_B)return 1; if(pin==id_C || pin==id_D)return 2;
    if(pin==id_E0 || pin==id_E1)return 3; if(pin==id_F0 || pin==id_F1)return 4;
    throw std::runtime_error("Unexpected L5 physical input");
}
static int prove_masks(Context &c,const std::vector<Move> &moves)
{
    int rows=0;
    for(const auto &m:moves) {
        if(m.cell->type!=id_MISTRAL_ALUT4)continue;
        auto a=alm(c,m.to); const auto &d=c.labs[a.first].alms[a.second];
        need(!c.labs[a.first].is_mlab && !d.l6_mode && !d.carry_mode,"Unexpected destination ALM mode");
        int half=d.lut_bels[1]==m.to; uint64_t physical=c.compute_lut_mask(a.first,a.second);
        uint64_t logical=m.cell->params.at(id_LUT).as_int64();
        std::array<IdString,4> ports{id_A,id_B,id_C,id_D};
        for(int raw=0;raw<16;raw++) {
            int forced_mask=0,forced_bits=0;
            for(int p=0;p<4;p++) {
                const auto &mapped=m.cell->pin_data.at(ports[p]);
                need(mapped.state==PIN_SIG && mapped.bel_pins.size()==1,"Invalid selected physical input mapping");
                auto bp=mapped.bel_pins[0]; need(c.bel_data(m.to).pins.count(bp),"Unknown destination pin");
                int bit=physical_bit(bp); need(!(forced_mask&(1<<bit)),"Distinct logical signals share physical pin");
                forced_mask|=1<<bit;
                // ALM truth-table inputs are active-low in the backend encoding.
                if(!(raw&(1<<p))) forced_bits|=1<<bit;
            }
            for(int vector=0;vector<32;vector++) if((vector&forced_mask)==forced_bits) {
                bool actual=!((physical>>(half*32+vector))&1),expected=(logical>>raw)&1;
                need(actual==expected,"Native physical LUT mask disagrees with unchanged logical truth table"); ++rows;
            }
        }
    }
    return rows;
}
struct Injected {};
struct Transaction {
    Context &c; const std::vector<Move>&moves; std::vector<LABInfo> labs;
    std::map<CellInfo*,ArchCellInfo> architecture; bool committed=false;
    Transaction(Context &c,const std::vector<Move>&m):c(c),moves(m),labs(c.labs)
    {for(auto &e:c.cells)architecture.emplace(e.second.get(),*static_cast<ArchCellInfo*>(e.second.get()));}
    ~Transaction() {
        if(committed)return;
        for(const auto &m:moves)if(m.cell->bel!=BelId())c.unbindBel(m.cell->bel);
        for(auto &e:architecture)*static_cast<ArchCellInfo*>(e.first)=std::move(e.second);
        for(const auto &m:moves)c.bindBel(m.from,m.cell,m.strength);
        c.labs=std::move(labs);
    }
};
static int trial(Context &c,const std::vector<Move>&moves,int inject,bool accept)
{
    std::set<Alm> alms;std::set<uint32_t> labs;std::set<CellInfo*> selected_luts;
    for(const auto &m:moves)if(m.cell->type==id_MISTRAL_ALUT4) {
        alms.insert(alm(c,m.from));alms.insert(alm(c,m.to));selected_luts.insert(m.cell);
    }
    for(auto a:alms)labs.insert(a.first);
    auto graph=serialise(c),pins=pin_snapshot(c,selected_luts).dump();
    auto prior_bindings=bindings(c).object_items();
    Transaction transaction(c,moves);
    auto point=[&](int stage){if(inject==stage)throw Injected{};};
    c.unbindBel(moves.front().cell->bel);point(1);
    for(size_t i=1;i<moves.size();i++)c.unbindBel(moves[i].cell->bel);point(2);
    for(size_t i=0;i<moves.size();i++) {c.bindBel(moves[i].to,moves[i].cell,moves[i].strength);if(i==8)point(3);}
    legal(c,labs,moves);
    for(auto a:alms)c.assign_alm_lut_inputs(a.first,a.second);
    point(4);legal(c,labs,moves,true);int rows=prove_masks(c,moves);point(5);
    need(serialise(c)==graph,"Logical graph, parameters, attributes, clock constraints or user ordering changed");
    need(pin_snapshot(c,selected_luts).dump()==pins,"Logical pin states or unrelated physical pin maps changed");
    auto now=bindings(c).object_items();
    for(const auto &m:moves) {prior_bindings.erase(c.nameOf(m.cell));now.erase(c.nameOf(m.cell));}
    need(J(now)==J(prior_bindings),"Unselected placement/strength changed");
    c.check();
    if(!accept)return rows;
    transaction.committed=true;return rows;
}
int main(int argc,char **argv)
{
    try {
        need(argc==5 || argc==6,"Usage: helper inventory input identities output | helper apply input plan output-prefix proof");
        std::string mode=argv[1];need(mode=="inventory" || mode=="apply" || mode=="verify","Unknown mode");
        ArchArgs args;args.device="5CSEBA6U23I7";Context c(args);
        std::ifstream input(argv[2]);need(parse_json(input,argv[2],&c),"Cannot parse checkpoint");
        need(c.attrs.count(id_step) && c.attrs.at(id_step).as_string()=="place","Requires placed checkpoint");
        need(!c.fes_any_slot_region_active && !c.fes_fence_active && !c.fes_has_reserved_rect &&
             c.fes_frozen_cells.empty() && c.fes_frozen_pips.empty(),"Frozen region/scaffold present");
        for(auto &e:c.attrs)need(e.first.str(&c).find("FES_LABSTATE")!=0,"Routed LAB snapshot present");
        for(auto &e:c.nets)need(e.second->wires.empty(),"Physical routing present");
        c.restore_placed_pin_maps(); auto plan=read(argv[3]);
        if(mode=="verify") {
            auto resolved=plan.object_items();auto entries=plan["moves"].array_items();
            for(auto &entry:entries) {
                auto object=entry.object_items();object["old_bel"]=entry["new_bel"];entry=object;
            }
            resolved["moves"]=entries;auto checked=identify(c,resolved,false);std::set<uint32_t> touched;
            for(auto &m:checked) {
                m.to=m.from;
                if(m.cell->type==id_MISTRAL_ALUT4) {
                    touched.insert(alm(c,m.to).first);
                    // restore_placed_pin_maps rebuilds COMB placement estimator scaffolds.
                    // Inspect the saved physical map separately, without assigning any pins.
                    need(c.restore_cell_pin_map(m.cell),"Selected saved physical pin map missing");
                    auto encoded=m.cell->attrs.at(c.id("FES_PINMAP_V1")).as_string();
                    need(encoded.size()%2==0,"Malformed saved-map hex");std::string decoded;
                    auto digit=[](char ch)->int {if(ch>='0'&&ch<='9')return ch-'0';if(ch>='a'&&ch<='f')return ch-'a'+10;
                        if(ch>='A'&&ch<='F')return ch-'A'+10;throw std::runtime_error("Invalid hex digit");};
                    for(size_t i=0;i<encoded.size();i+=2)decoded.push_back(char(16*digit(encoded[i])+digit(encoded[i+1])));
                    std::string error;auto expected=J::parse(decoded,error);need(error.empty(),"Malformed saved-map JSON");
                    J::object pins;
                    for(const auto &pin:m.cell->pin_data) {
                        J::array values{int(pin.second.state)};for(auto physical:pin.second.bel_pins)values.emplace_back(physical.str(&c));
                        pins[pin.first.str(&c)]=values;
                    }
                    need(expected==J(J::object{{"count",int(pins.size())},{"pins",pins}}),"Restored map differs from serialized map");
                }
            }
            for(const auto &entry:plan["moves"].array_items())if(entry["type"].string_value()=="MISTRAL_ALUT4") {
                auto source=c.getBelByNameStr(entry["old_bel"].string_value());need(source!=BelId(),"Original BEL vanished");
                touched.insert(alm(c,source).first);
            }
            legal(c,touched,checked,true);int rows=prove_masks(c,checked);c.check();
            write(argv[4],J(J::object{{"kind","read-only final checkpoint reload qualification"},
                {"physical_truth_rows",rows},{"full_touched_lab_legality",true},{"selected_cells",18},
                {"no_global_placement_pin_assignment_or_routing",true},{"selected_saved_maps_explicitly_restored_after_placement_scaffold",true}}).dump()+"\n");return 0;
        }
        auto moves=identify(c,plan,mode=="apply");
        if(mode=="inventory") {
            J::array rams,alms;
            for(auto b:c.getBels()) {
                auto at=c.getBelLocation(b);
                if(c.getBelType(b)==id_MISTRAL_M10K && c.checkBelAvail(b))rams.emplace_back(belname(c,b));
                if(c.getBelType(b)!=id_MISTRAL_COMB || at.z%6 || at.x<10 || at.x>32 || at.y<30 || at.y>45)continue;
                auto a=alm(c,b);bool empty=true;for(auto other:members(c,a))empty&=c.checkBelAvail(other);
                int input_count=0;bool baseline_legal=true;
                for(uint8_t ai=0;ai<10;ai++) {
                    input_count+=c.labs[a.first].alms[ai].unique_input_count;
                    for(auto occupied:members(c,{a.first,ai}))
                        if(c.getBoundBelCell(occupied))baseline_legal&=c.isBelLocationValid(occupied,false);
                }
                if(empty && c.isValidBelForCellType(id_MISTRAL_ALUT4,b))
                    alms.emplace_back(J::object{{"bel",belname(c,b)},{"x",at.x},{"y",at.y},{"z",at.z},
                                               {"lab",int(a.first)},{"alm",int(a.second)},{"lab_input_count",input_count},{"baseline_lab_legal",baseline_legal}});
            }
            write(argv[4],J(J::object{{"free_m10k",rams},{"empty_ordinary_alms",alms}}).dump()+"\n");return 0;
        }
        need(argc==6,"Apply requires output prefix and proof path");
        c.save_fes_pin_maps(false);c.archInfoToAttributes();
        auto original=serialise(c),original_pins=pin_snapshot(c).dump(),original_bindings=bindings(c).dump();auto original_labs=c.labs;
        J::array rollbacks;
        for(int stage=1;stage<=5;stage++) {
            bool caught=false;try{trial(c,moves,stage,true);}catch(const Injected&){caught=true;}
            need(caught && serialise(c)==original && pin_snapshot(c).dump()==original_pins &&
                 bindings(c).dump()==original_bindings && same_labs(c.labs,original_labs),"Exception rollback did not restore exact state");
            rollbacks.emplace_back(J::object{{"stage",stage},{"restored",true}});
        }
        trial(c,moves,0,false);
        need(serialise(c)==original && pin_snapshot(c).dump()==original_pins && bindings(c).dump()==original_bindings &&
             same_labs(c.labs,original_labs),"Rejected trial did not restore exact state");
        int rows=trial(c,moves,0,true);
        c.save_fes_pin_maps(false);c.archInfoToAttributes();
        write(std::string(argv[4])+"-baseline.json",original);
        write(std::string(argv[4])+"-candidate.json",serialise(c));
        write(argv[5],J(J::object{{"kind","host-only native placement transaction; no route or timing acceptance"},
             {"selected_cells",18},{"ram_cells",2},{"decoder_cells",16},{"physical_truth_rows",rows},
             {"exception_rollbacks",rollbacks},{"rejected_trial_rollback",true},{"full_touched_lab_legality",true},
             {"logical_graph_and_clocks_unchanged",true},{"all_unselected_placements_strengths_and_physical_pins_unchanged",true},
             {"all_logical_pin_states_unchanged",true},{"plan",plan}}).dump()+"\n");return 0;
    }catch(const std::exception &e){std::cerr<<"REJECTED: "<<e.what()<<"\n";return 1;}
    catch(...){std::cerr<<"REJECTED: native exception\n";return 2;}
}
