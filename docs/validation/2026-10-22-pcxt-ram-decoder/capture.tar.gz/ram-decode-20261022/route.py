from pathlib import Path
import hashlib, json, os, subprocess, time

root=Path(__file__).resolve().parent
task=root.parents[1]
baseline=json.loads((root.parent/'reassociate-20261022/baseline/receipt.json').read_text())
command=baseline['nextpnr_command'][:]
command[command.index('--json')+1]=str(root/'candidate-placed.json')
input_sha256=hashlib.file_digest((root/'candidate-placed.json').open('rb'),'sha256').hexdigest()
assert input_sha256=='dfaabdb773f788258dda3aa834899d840b7afad0837e8ad530bb371e7f84c95f'
assert hashlib.file_digest(open(command[0],'rb'),'sha256').hexdigest()==baseline['binary_sha256']
wrapped=[str(task/'scripts/gpu-run'),'--phase-lease','--owner','pcxt-timing',
         '--label','pcxt-ram-and-decoder-locality','--',*command]
directory=root/'route';directory.mkdir(exist_ok=False)
receipt={'command':wrapped,'nextpnr_command':command,'input_sha256':input_sha256,
         'binary_sha256':baseline['binary_sha256'],
         'baseline_receipt':str(root.parent/'reassociate-20261022/baseline/receipt.json'),
         'evidence':'leased GPU host diagnostic; two RAMs and sixteen private decoder LUTs; not acceptance',
         'limit':'native bounded router iterations; no external GPU-job termination'}
env=dict(os.environ);env['NEXTPNR_REQUIRE_GPU']='1'
start=time.monotonic()
with (directory/'nextpnr.log').open('w') as log:
    receipt['returncode']=subprocess.run(wrapped,cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
receipt['charged_seconds']=time.monotonic()-start
receipt['artifacts']={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in directory.iterdir() if p.suffix in ['.json','.rbf']}
(directory/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt['returncode'],receipt['charged_seconds'],flush=True)
