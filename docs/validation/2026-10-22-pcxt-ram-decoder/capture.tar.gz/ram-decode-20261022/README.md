# Native RAM and decoder locality diagnostic

Scope: move exactly the two byte-2 microcode ROMs that drive the east one-hot decoder bank, and their sixteen private ALUT4 decoders. All FFs, kept cells, carry cells, truth tables, RAM contents, clocks and timing constraints remain unchanged. This directory contains a standalone host diagnostic; no compiler repository or shared build was changed, and no route or hardware test was launched here.

The source is `/tmp/pcxt-replicate-leased-20261022/inputs/placed.json`, SHA256 `9241b02074cfee262c985c9ddde7e2c71f05bc654d35b989857a9a93ccc58878`. The final diagnostic is `candidate-placed.json`; use `checkpoint-proof.json` for its hash and exact 34 attribute edits. The native-written `placed-baseline.json` and `placed-candidate.json` are an intermediate audit pair, not the exact-source route input.

## Frozen implementation

The helper links copied objects from nextpnr commit `692a1c372b2b55620ba1fd5e43e0c14ae8ffa4d9`, tree `9b953cd947a89cbf7da9d203b3e07000783a45c2`. `frozen-object-manifest.json` records the copied objects and libraries, source/copy/source hashes, source archive, model headers and exact paths. The compiler build label embedded in these objects is stale (`66c97e49`); source and object hashes, not that label, identify this experiment. The frozen parent binary hash is `05dca6ea935a614e4948f5cf9e0fb2b92b3934e9b6891568d13f492d3dbc1162`.

`build_helper.py` reads only the owned frozen source, model headers and objects. It compiles the standalone helper with warnings as errors and links the existing LTO objects. Existing model-source maybe-uninitialized warnings occur during LTO; the helper translation unit passes its strict compile. No production CLI was added.

## Native operation and proof

1. Parse the original placed, unrouted checkpoint and restore logical pin states. Reject routed LAB snapshots, routed nets, frozen regions, wrong identities, protected/clustered cells, or anything outside the exact two-M10K/sixteen-ALUT4 structure.
2. Verify the four distinct RAM outputs feed all sixteen distinct one-hot masks; each decoder reads all four signals and drives exactly two kept FFs. The 24 RAM address inputs launch from kept FFs.
3. Require free native M10K destinations and ordinary-LAB LUT destinations. Every source/destination LUT ALM must be empty or contain only selected decoders. No unrelated FF/LUT may share those ALMs.
4. Snapshot complete LAB state, every cell's architecture metadata, selected bindings and strengths. Unbind and bind only the selected cells. Check every occupied BEL in each touched LAB, including LAB input/control constraints, then call `assign_alm_lut_inputs` only for affected ALMs. Never call global placement, global pin assignment or `reassign_alm_inputs` (which can insert route-through cells).
5. Check selected physical pin existence/direction and evaluate native `compute_lut_mask` against every unchanged logical truth table. There are 512 exhaustive rows: sixteen LUTs, sixteen logical inputs and two states of the unused physical input. Compare complete native serialization, logical pin states/user slots, all unselected physical maps, and all unselected bindings/strengths.
6. Inject exceptions after the first unbind, all unbinds, nine binds, affected pin assignment, and truth-table proof. Require exact restoration of serialization, all pin maps, all bindings and complete LAB state after each. Also reject one completed trial and require the same restoration. Only then commit the final trial.
7. Transfer only the native-qualified 18 `NEXTPNR_BEL` and 16 `FES_PINMAP_V1` values back into exact original source bytes. The finalizer verifies every source cell attribute matches the native normalized baseline, all other native data is unchanged, all ordered source graph data is unchanged, and inverse replacement restores the exact original bytes.
8. Independently reload the final artifact. Normal `restore_placed_pin_maps` reconstructs temporary COMB placement-estimator pin maps via `assignArchInfo`; these are not physical LUT encodings. The verifier therefore calls native `restore_cell_pin_map` again for the sixteen selected LUTs, compares each result exactly with its serialized map, and checks complete touched-LAB legality plus all 512 physical truth rows. It performs no new pin assignment. A later ordinary full route still performs its usual native pre-route pin assignment.

The exact-source finalizer matters because normal nextpnr JSON reload/write omits 18 orphan iobuf aliases and empty FF ports. Those source details are retained in the final artifact. This is not blind LUT BEL editing: both the new placement and its saved physical maps are produced and checked by the frozen native backend first.

`native-proof.json`, `checkpoint-proof.json`, `final-reload-proof.json` and `rejection-tests.json` are the proof receipts. Occupied RAM, duplicate destination, wrong BEL type and protected-FF plans must reject without creating output checkpoints. The first geometry plan was rejected by full LAB legality; `rejected-capacity-*` retains that attempt. The final plan uses native input counts and permits no more than `floor((42-existing_inputs)/4)` additional decoder ALMs per LAB.

## Placement and tradeoffs

ROM0 moves `(41,43)` to `(14,39)` and ROM1 moves `(38,43)` to `(14,40)`. The sixteen decoders move to explicitly listed whole-empty ALMs in columns 10–17. `plan.json` has all old/new BELs. `geometry-and-fanouts.json` inventories every incident net and complete users, including 24 address, 64 RAM-to-decoder, 32 decoder-to-capture and four direct RAM-to-capture edges. Control/clock/constant consumers are retained too.

The plan minimizes the sum of each decoder's worst two-leg RAM-to-decoder-to-capture placement estimate, with edge sum as a secondary objective, over the native-qualified empty ALMs and per-LAB capacity. Fixed RAM locations were chosen near the existing address bank and fixed output FFs. Geometry uses the backend's cross-LAB estimate `650 + 250*(dy != 0) + 35*dx + 100*dy` ps and is not routed STA.

| Quantity | Original | Candidate |
| --- | ---: | ---: |
| Worst selected address estimate | 2600 ps | 1895 ps |
| Address Manhattan sum, 24 edges | 526 | 270 |
| Decoder-to-capture Manhattan sum, 32 edges | 769 | 189 |
| Worst complete return two-leg estimate | 3530 ps | 2795 ps |
| Worst RAM-to-decoder estimate | 1315 ps | 1705 ps |

Twenty address edges get shorter and four longer. Twenty-four complete return estimates improve and eight worsen. The RAM input fanout becomes more dispersed; this can worsen congestion or individual return paths despite improving the worst geometric estimate. Global clock routing and shared-net routes may also change. A complete fresh route and complete endpoint/setup/hold comparison are required; none of these geometry or Boolean proofs establish timing acceptance.

These RAM destinations conflict with the separate fourteen-RAM experiment. Treat this as an isolated experiment from the original placement; combining candidates requires an explicit new noncolliding plan and native validation. The outstanding 105 unsupported timing endpoints remain an independent signoff obligation.

## Reproduction

Run from the PC/XT task directory, with `set -e`:

```sh
python3 out/ram-decode-20261022/build_helper.py
out/ram-decode-20261022/native-ram-decode inventory /tmp/pcxt-replicate-leased-20261022/inputs/placed.json out/ram-decode-20261022/identities.json out/ram-decode-20261022/native-sites-capacity.json
python3 out/ram-decode-20261022/prepare_plan.py
out/ram-decode-20261022/native-ram-decode apply /tmp/pcxt-replicate-leased-20261022/inputs/placed.json out/ram-decode-20261022/plan.json out/ram-decode-20261022/placed out/ram-decode-20261022/native-proof.json
python3 out/ram-decode-20261022/finalize_checkpoint.py
out/ram-decode-20261022/native-ram-decode verify out/ram-decode-20261022/candidate-placed.json out/ram-decode-20261022/plan.json out/ram-decode-20261022/final-reload-proof.json
python3 out/ram-decode-20261022/test_rejections.py
```

Do not use a global re-place on this packed checkpoint: packed carry-cluster metadata is not serialized, and default HeAP refinement does not preserve the intended kept-FF boundary. The next integration step is parent-owned full routing of the exact diagnostic input under the same frozen route recipe, followed by complete identity-matched setup/hold/coverage analysis.

## Completed full-route result

Parent ran the exact frozen 692 binary and original placed seed-1 route recipe. It completed with exit 1 due timing failure, wrote routed JSON, full endpoint/timing reports and an RBF, and charged **257.6850187298842 seconds**. This is this run's charge only; the parent owns the cumulative ledger.

`proof-routed.json` checks all 12,605 routed cells, 15,736 named nets, and 2,157 generated route-through buffers. Every primitive function, connection, alias class and logical pin state matches baseline; only the 18 declared BELs and 16 native-qualified physical decoder maps differ. Serialized LAB state is exactly unchanged. The final route maps match the native preparation maps. Ten corruption self-tests reject changes to RAM initialization, decoder function/maps, unrelated placement/inversion, route-through cells and aliases.

The independent `verify_routed_masks.cc` executable reads the final routed snapshot, interprets its saved LAB state without locking or parking cells, restores selected saved maps exactly, and proves all 512 truth rows again. It performs no pin assignment or routing. Its build and output receipts are separate from the original placement helper, whose bytes and proof identities remain intact.

All 17,199 native endpoint identities and their clock/constraint tuples match exactly. `result-summary.json` records the full result:

| Native setup group | Baseline failures / WNS | Candidate failures / WNS |
| --- | ---: | ---: |
| Entire design | 343 / -1638 ps | 299 / -1542 ps |
| CPU, 10 ns window | 194 / -1638 ps | 174 / -1428 ps |
| All 192 microcode addresses, 2.5 ns window | 147 / -1461 ps | 125 / -1542 ps |
| Selected 24 addresses | 24 / -880 ps | 6 / -249 ps |
| All 90 microcode returns, 7.5 ns window | 1 / -358 ps | 0 / +775 ps |
| Selected 36 returns | 1 / -358 ps | 0 / +1126 ps |
| Pixel domain | 1 / -228 ps | 0 / +1084 ps |

Both reports have zero related-hold failures and a minimum related hold margin of 795 ps. There are 6,124 setup-margin regressions and 7,854 positive hold-margin decreases; this diagnostic does not relax any regression gate. The 105 unsupported endpoints are unchanged and timing coverage remains incomplete.

The six selected address failures are bits 4, 6 and 11 of each moved RAM, with margins from -67 to -249 ps. The overall worst address path is an unmoved byte-0 ROM0 bit 4 at -1542 ps. This supports moving RAMs with their private decode logic as a useful placement repair, while showing that the complete bank and the separate CPU logic path still need work. No timing, exact-artifact hardware, primitive-clock margin or board-IO acceptance is claimed.

FES base: `f09356de3fc5b9b81a02cd9434fa6133ac92e458`. No tracked source or shared module contract changed; these are uncommitted diagnostic artifacts. `compact-evidence.tar.gz` retains source, small plans, hashes, native preparation/reload/final-route proofs, route receipts/log and analysis. Large frozen compiler objects/source/binaries, checkpoints, reports and RBF bytes remain at their original paths and are explicitly hashed in `compact-evidence/artifact-manifest.json`.
