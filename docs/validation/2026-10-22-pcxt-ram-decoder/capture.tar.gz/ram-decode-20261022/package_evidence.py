#!/usr/bin/env python3
"""Package compact sources/receipts; preserve and hash all large external artifacts."""
import hashlib,json,shutil,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['README.md','native_ram_decode.cc','verify_routed_masks.cc','build_helper.py','build_routed_verifier.py',
 'prepare_plan.py','finalize_checkpoint.py','test_rejections.py','prove-routed.py','run_final_checks.py','package_evidence.py',
 'identities.json','plan.json','native-sites-capacity.json','geometry-and-fanouts.json','native-proof.json',
 'checkpoint-proof.json','final-reload-proof.json','rejection-tests.json','frozen-object-manifest.json',
 'original-link-command.txt','helper-build-commands.json','routed-verifier-build-commands.json',
 'route-native-mask-proof.json','route-native-mask-receipt.json','proof-routed.json','proof-routed-clocks.json',
 'proof-routed-selftest.json','result-summary.json','apply.log','finalize.log','final-reload.log',
 'route-native-mask.log','final-checks.log','rejection-tests.log','route/receipt.json','route/nextpnr.log',
 'rejected-capacity-plan.json','rejected-capacity-apply.log','rejected-placement-scaffold-reload.log']
assert len(set(files))==len(files) and all((ROOT/f).is_file() for f in files)
large=['candidate-placed.json','placed-baseline.json','placed-candidate.json','native-ram-decode','native-routed-masks',
       'compiler-692.tar','route/routed.json','route/endpoints.json','route/timing.json','route/diagnostic.rbf']
external=[ROOT/f for f in large]
external += [Path('/tmp/pcxt-replicate-leased-20261022/inputs/placed.json')]
external += [ROOT.parent/'reassociate-20261022/baseline'/f for f in ['routed.json','endpoints.json','timing.json','receipt.json']]
manifest={'kind':'Compact diagnostic sources and receipts; excluded artifacts retained with explicit hashes',
 'route_charge_seconds':json.loads((ROOT/'route/receipt.json').read_text())['charged_seconds'],
 'ledger_scope':'This run only; no cumulative accounting',
 'included':{f:{'sha256':sha(ROOT/f),'bytes':(ROOT/f).stat().st_size} for f in files},
 'excluded_retained_artifacts':{str(p.resolve()):{'sha256':sha(p),'bytes':p.stat().st_size} for p in external},
 'excluded_frozen_objects_and_libraries':'All objects/libraries and frozen model headers are enumerated by frozen-object-manifest.json; none are copied here',
 'excluded_source_archive_commit':'692a1c372b2b55620ba1fd5e43e0c14ae8ffa4d9',
 'timing_accepted':False,'hardware_evidence':'none'}
bundle=ROOT/'compact-evidence';bundle.mkdir(exist_ok=True)
expected=set(files)|{'artifact-manifest.json'}
for existing in bundle.rglob('*'):
    if existing.is_file():assert str(existing.relative_to(bundle)) in expected,'Unexpected stale bundle file'
for name in files:
    dest=bundle/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,dest)
(bundle/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=ROOT/'compact-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
    for p in sorted(bundle.rglob('*')):
        if p.is_file():tar.add(p,arcname=str(Path('ram-decode-20261022')/p.relative_to(bundle)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    names={m.name for m in tar.getmembers()};assert len(names)==len(expected)
    for name in files:
        data=tar.extractfile('ram-decode-20261022/'+name).read()
        assert hashlib.sha256(data).hexdigest()==manifest['included'][name]['sha256']
receipt={'archive_path':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
         'included_files':len(expected),'artifact_manifest_sha256':sha(bundle/'artifact-manifest.json'),
         'all_archive_member_hashes_verified':True}
(ROOT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
