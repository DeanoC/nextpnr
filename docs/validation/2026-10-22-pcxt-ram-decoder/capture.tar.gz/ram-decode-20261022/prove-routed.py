#!/usr/bin/env python3
"""Check complete final routed graph preservation under an explicit two-RAM/sixteen-decoder native plan.

All logical primitives, parameters, connections, aliases and pin states are exact.
Full-route wire choices may differ. This does not decode RBFs, prove electrical
routing, or establish timing or hardware acceptance.
"""
import argparse
import collections
import copy
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate JSON key: {key}')
        result[key] = value
    return result


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=unique_object)


def unpack(value):
    return json.loads(bytes.fromhex(value).decode(), object_pairs_hook=unique_object)


def pack(value):
    return json.dumps(value, sort_keys=True).encode().hex()


def pinmap(cell, name):
    payload = unpack(cell['attributes']['FES_PINMAP_V1'])
    require(set(payload) == {'count', 'pins'}, f'{name}: pin-map schema changed')
    pins = payload['pins']
    require(payload['count'] == len(pins), f'{name}: incomplete pin-map count')
    for port, bits in cell['connections'].items():
        # The JSON writer regroups scalar bus ports (for example M10K
        # A1ADDR[0..N]) into one connection vector; the pin snapshot keeps
        # the exact scalar identities. Require every lane, not an overlap.
        logical = [port] if port in pins else [f'{port}[{index}]' for index in range(len(bits))]
        require(logical and all(pin in pins for pin in logical), f'{name}.{port}: missing logical pin state')
        require(len(bits) <= 1 or port not in pins, f'{name}.{port}: ambiguous vector pin state')
    for pin, values in pins.items():
        require(isinstance(values, list) and values and type(values[0]) is int and values[0] in range(4),
                f'{name}.{pin}: invalid pin state')
        require(all(isinstance(value, str) for value in values[1:]), f'{name}.{pin}: invalid physical map')
    return pins



def plan_moves(plan):
    moves = {}
    destinations = set()
    require(len(plan['moves']) == 18, 'requires exactly eighteen native-qualified moves')
    counts = collections.Counter()
    for move in plan['moves']:
        name, old, new = (move[key] for key in ('cell', 'old_bel', 'new_bel'))
        require(name not in moves and new not in destinations, 'duplicate planned cell or destination')
        require(old != new, 'unchanged planned placement')
        if move['type'] == 'MISTRAL_M10K':
            require(all(re.fullmatch(r'MISTRAL_M10K\.\d+\.\d+\.0', bel) for bel in (old,new)), 'invalid RAM BEL')
        else:
            require(move['type'] == 'MISTRAL_ALUT4', 'unexpected selected primitive')
            require(re.fullmatch(r'MISTRAL_M?COMB\.\d+\.\d+\.\d+',old) and
                    re.fullmatch(r'MISTRAL_COMB\.\d+\.\d+\.\d+',new), 'invalid decoder BEL')
        counts[move['type']] += 1
        moves[name] = (old, new)
        destinations.add(new)
    require(counts == {'MISTRAL_M10K':2,'MISTRAL_ALUT4':16}, 'wrong selected primitive counts')
    return moves


def verify_preparation(plan, moves):
    paths = [Path(plan[key]).resolve() for key in ('source_path', 'candidate_path')]
    for path, key in zip(paths, ('source_sha256', 'candidate_sha256')):
        require(digest(path) == plan[key], f'placed input hash mismatch: {path}')
    for name, expected in plan['evidence_sha256'].items():
        require(digest(ROOT/name) == expected, f'native preparation evidence hash mismatch: {name}')
    native = read(ROOT/'native-proof.json')
    reload = read(ROOT/'final-reload-proof.json')
    require(native['physical_truth_rows'] == reload['physical_truth_rows'] == 512, 'native physical mask proof missing')
    require(native['full_touched_lab_legality'] and reload['full_touched_lab_legality'], 'native LAB proof missing')
    require(reload['selected_saved_maps_explicitly_restored_after_placement_scaffold'], 'saved-map reload proof missing')
    documents = [read(path) for path in paths]
    require(set(documents[0]['modules']) == set(documents[1]['modules']) == {'top'}, 'unexpected prepared modules')
    modules = [doc['modules']['top'] for doc in documents]
    require(all(module['attributes']['step'] == 'place' for module in modules), 'plan requires placed inputs')
    candidate_cells = copy.deepcopy(modules[1]['cells'])
    for name, (old, new) in moves.items():
        before, after = [m['cells'][name] for m in modules]
        require(before['attributes']['NEXTPNR_BEL'] == old and after['attributes']['NEXTPNR_BEL'] == new,
                f'{name}: plan does not match placed inputs')
        after['attributes']['NEXTPNR_BEL'] = old
        if before['type'] == 'MISTRAL_ALUT4':
            pins = [pinmap(cell,name) for cell in (before,after)]
            require({p:v[0] for p,v in pins[0].items()} == {p:v[0] for p,v in pins[1].items()},
                    f'{name}: prepared logical pin state changed')
            after['attributes']['FES_PINMAP_V1'] = before['attributes']['FES_PINMAP_V1']
    require(documents[0] == documents[1], 'placed inputs differ beyond exactly planned BELs and decoder physical maps')
    return paths, candidate_cells


def graph_proof(documents, moves, prepared_cells):
    require(all(set(doc) == {'creator', 'modules'} for doc in documents), 'root schema changed')
    require(documents[0]['creator'] == documents[1]['creator'], 'compiler creator changed')
    require(set(documents[0]['modules']) == set(documents[1]['modules']) == {'top'}, 'module inventory changed')
    a, b = [doc['modules']['top'] for doc in documents]
    require(set(a) == set(b) == {'settings', 'attributes', 'ports', 'cells', 'netnames'}, 'module schema changed')
    require(a['attributes']['step'] == b['attributes']['step'] == 'route', 'requires final routed JSONs')
    require(a['attributes'] == b['attributes'], 'module metadata or serialized LAB state changed')
    require(set(a['cells']) == set(b['cells']), 'complete cell inventory changed')
    require(set(a['netnames']) == set(b['netnames']), 'complete named-net/alias inventory changed')
    require(set(a['ports']) == set(b['ports']), 'complete external port inventory changed')
    require(set(moves) <= set(a['cells']), 'planned RAM cell missing from routed graph')

    forward, reverse = {}, {}
    changed_routes = []
    for name in sorted(a['netnames']):
        x, y = a['netnames'][name], b['netnames'][name]
        require(set(x) == set(y) == {'hide_name', 'bits', 'attributes'}, f'{name}: net schema changed')
        require(x['hide_name'] == y['hide_name'] and len(x['bits']) == len(y['bits']), f'{name}: net shape changed')
        for index, (old, new) in enumerate(zip(x['bits'], y['bits'])):
            require(type(old) is type(new), f'{name}[{index}]: signal/literal classification changed')
            if type(old) is int:
                require(old not in forward or forward[old] == new, f'{name}[{index}]: alias split')
                require(new not in reverse or reverse[new] == old, f'{name}[{index}]: alias merge')
                forward[old], reverse[new] = new, old
            else:
                require(old == new and old in ('0', '1', 'x', 'z'), f'{name}[{index}]: literal changed')
        attrs = [{key: value for key, value in net['attributes'].items() if key != 'ROUTING'} for net in (x, y)]
        require(attrs[0] == attrs[1], f'{name}: non-routing net metadata changed')
        if x['attributes'].get('ROUTING') != y['attributes'].get('ROUTING'):
            changed_routes.append(name)

    def normalize(bits, candidate):
        result = []
        for bit in bits:
            if type(bit) is int:
                require(bit in (reverse if candidate else forward), f'unknown or unnamed connected bit: {bit}')
                result.append(reverse[bit] if candidate else bit)
            else:
                require(bit in ('0', '1', 'x', 'z'), f'invalid connected literal: {bit!r}')
                result.append(bit)
        return result

    for name in a['ports']:
        x, y = a['ports'][name], b['ports'][name]
        require(set(x) == set(y) == {'direction', 'bits'}, f'{name}: external port schema changed')
        require(x['direction'] == y['direction'] and normalize(x['bits'], False) == normalize(y['bits'], True),
                f'{name}: external connectivity changed')
    states, inputs, moved = 0, 0, []
    for name in sorted(a['cells']):
        x, y = a['cells'][name], b['cells'][name]
        require(set(x) == set(y) == {'hide_name', 'type', 'parameters', 'attributes', 'port_directions', 'connections'},
                f'{name}: cell schema changed')
        for key in ('hide_name', 'type', 'parameters', 'port_directions'):
            require(x[key] == y[key], f'{name}: {key} changed')
        for cell in (x, y):
            require(set(cell['port_directions']) == set(cell['connections']), f'{name}: inconsistent port inventory')
            require(all(direction in ('input', 'output', 'inout') for direction in cell['port_directions'].values()),
                    f'{name}: invalid port direction')
        require({pin: normalize(bits, False) for pin, bits in x['connections'].items()} ==
                {pin: normalize(bits, True) for pin, bits in y['connections'].items()}, f'{name}: connectivity changed')
        pins = [pinmap(cell, name) for cell in (x, y)]
        require({p:v[0] for p,v in pins[0].items()} == {p:v[0] for p,v in pins[1].items()},
                f'{name}: logical pin state or inversion changed')
        if name in moves and x['type'] == 'MISTRAL_ALUT4':
            require(pins[1] == pinmap(prepared_cells[name],name), f'{name}: final decoder map differs from native-qualified map')
        else:
            require(pins[0] == pins[1], f'{name}: undeclared physical pin assignment changed')
        states += len(pins[0])
        inputs += sum(direction == 'input' for direction in x['port_directions'].values())
        old_attrs, new_attrs = x['attributes'], dict(y['attributes'])
        if name in moves:
            old, new = moves[name]
            require(x['type'] in ('MISTRAL_M10K','MISTRAL_ALUT4') and old_attrs['NEXTPNR_BEL'] == old and new_attrs['NEXTPNR_BEL'] == new,
                    f'{name}: final routed placement does not match exact plan')
            new_attrs['NEXTPNR_BEL'] = old
            if x['type'] == 'MISTRAL_ALUT4':
                new_attrs['FES_PINMAP_V1'] = old_attrs['FES_PINMAP_V1']
            moved.append({'cell': name, 'before': old, 'after': new})
        require(old_attrs == new_attrs, f'{name}: undeclared attribute or placement change')
    # This exact observed router bookkeeping serialization is harmless, but no
    # arbitrary setting (including another value of this key) is ignored.
    changes = [{'key': key, 'before': a['settings'].get(key), 'after': b['settings'].get(key)}
               for key in sorted(set(a['settings']) | set(b['settings']))
               if a['settings'].get(key) != b['settings'].get(key)]
    require(changes in ([], [{'key': 'gpurouter/localInputEscape', 'before': None, 'after': '0 '}]),
            'unexpected serialized setting difference')
    generated = sorted(name for name, cell in a['cells'].items()
                       if cell['type'] == 'MISTRAL_BUF' and '$ROUTETHRU' in name)
    return {'complete_cell_inventory': len(a['cells']), 'complete_net_name_inventory': len(a['netnames']),
            'bijective_named_signal_bits': len(forward), 'external_ports_unchanged': len(a['ports']),
            'input_ports_checked': inputs, 'pin_states_checked': states, 'selected_decoder_physical_maps_match_native_proof':16,
            'all_functions_parameters_connections_pin_states_preserved': True,
            'all_net_alias_classes_and_nonrouting_attributes_preserved': True,
            'route_generated_buffers_exactly_matched': len(generated), 'planned_ram_and_decoder_bel_changes': moved,
            'module_metadata_and_lab_state_exact': True, 'changed_route_attributes': len(changed_routes),
            'changed_route_identity_sha256': hashlib.sha256(json.dumps(changed_routes).encode()).hexdigest(),
            'serialized_setting_differences': changes}


def clock_report(paths, moved):
    documents = [read(path.parent / 'endpoints.json') for path in paths]
    a, b = documents
    require(set(a) == set(b), 'endpoint report schema inventory changed')
    for key in set(a) - {'endpoints'}:
        require(a[key] == b[key], f'endpoint coverage/contract metadata changed: {key}')
    require(set(a['endpoints']) == set(b['endpoints']), 'complete native endpoint identity inventory changed')
    numeric = {'setup', 'hold', 'min_path', 'max_path'}
    counts = {'setup_regressions': 0, 'hold_regressions': 0, 'positive_hold_decreases': 0}
    moved_rows = []
    all_rows = []
    for identity in sorted(a['endpoints']):
        rows = []
        for document in documents:
            keyed = {}
            for row in document['endpoints'][identity]:
                require(numeric <= set(row), f'{identity}: incomplete timing metrics')
                key = json.dumps({k: v for k, v in row.items() if k not in numeric}, sort_keys=True)
                require(key not in keyed, f'{identity}: duplicate clock/constraint tuple')
                keyed[key] = row
            rows.append(keyed)
        require(set(rows[0]) == set(rows[1]), f'{identity}: native clock/constraint tuple coverage changed')
        for key in rows[0]:
            old, new = rows[0][key], rows[1][key]
            record = {'identity': json.loads(identity), 'clock_and_constraint_tuple': json.loads(key),
                      'before': {metric: old[metric] for metric in sorted(numeric)},
                      'after': {metric: new[metric] for metric in sorted(numeric)}}
            if old['setup_timed']:
                counts['setup_regressions'] += new['setup'] < old['setup']
            if old['hold_related']:
                counts['hold_regressions'] += new['hold'] < old['hold']
                counts['positive_hold_decreases'] += 0 <= new['hold'] < old['hold']
            all_rows.append(record)
            if record['identity'][0] in moved:
                moved_rows.append(record)
    summaries = []
    for side in ('before', 'after'):
        setup = [row[side]['setup'] for row in all_rows if row['clock_and_constraint_tuple']['setup_timed']]
        hold = [row[side]['hold'] for row in all_rows if row['clock_and_constraint_tuple']['hold_related']]
        summaries.append({'setup_failures': sum(value < 0 for value in setup),
                          'hold_failures': sum(value < 0 for value in hold),
                          'setup_worst_ps': min(setup), 'hold_worst_ps': min(hold)})
    def summarize_subset(rows):
        summaries = []
        for side in ('before','after'):
            setup = [r[side]['setup'] for r in rows if r['clock_and_constraint_tuple']['setup_timed']]
            hold = [r[side]['hold'] for r in rows if r['clock_and_constraint_tuple']['hold_related']]
            summaries.append({'setup_rows':len(setup),'setup_failures':sum(v<0 for v in setup),
                'setup_worst_ps':min(setup) if setup else None,'related_hold_rows':len(hold),
                'hold_failures':sum(v<0 for v in hold),'hold_worst_ps':min(hold) if hold else None})
        return {'rows':len(rows),'before':summaries[0],'after':summaries[1]}
    by_pair = collections.defaultdict(list)
    for row in all_rows:
        contract = row['clock_and_constraint_tuple']
        key = json.dumps([contract['launch'],contract['capture'],contract.get('setup_window')])
        by_pair[key].append(row)
    pairs = [{'launch_capture_window':json.loads(key),**summarize_subset(rows)}
             for key,rows in sorted(by_pair.items())]
    geometry = read(ROOT/'geometry-and-fanouts.json')
    capture_names = {r['user']['cell'] for key in ('decoder_to_capture','ram_to_direct_capture')
                     for r in geometry['edge_geometry'][key]}
    require(len(capture_names)==36,'Complete selected return-capture inventory changed')
    selected_address = [r for r in all_rows if r['identity'][0] in moved and r['identity'][1].startswith('B1ADDR[')]
    selected_return = [r for r in all_rows if r['identity'][0] in capture_names and r['identity'][1]=='DATAIN'
                       and r['clock_and_constraint_tuple']['launch']==['clocks[2]',0]
                       and r['clock_and_constraint_tuple']['capture']==['clocks[0]',0]]
    require(len(selected_address)==24 and len(selected_return)==36,'Selected timing row coverage changed')
    microcode_prefix=next(name for name in moved if '.bytes[' in name).split('.bytes[')[0]+'.bytes['
    all_addresses = [r for r in all_rows if r['identity'][0].startswith(microcode_prefix) and r['identity'][1].startswith('B1ADDR[')]
    require(len(all_addresses)==192,'Complete sixteen-ROM address inventory changed')
    require(a['primitive_clocks'] == b['primitive_clocks'] == {},
            'native primitive-clock rows are present; extend explicit margin comparison before claiming coverage')
    return {'evidence': 'data endpoint timing comparison; native primitive-clock margins unavailable',
            'endpoint_report_sha256': [digest(path.parent / 'endpoints.json') for path in paths],
            'complete_endpoint_identity_count': len(a['endpoints']), 'exact_clock_constraint_tuple_count': len(all_rows),
            'all_non_endpoint_metadata_identical': True, 'complete': a['complete'],
            'native_primitive_clock_records': 0, 'native_primitive_clock_margin_preservation_proven': False,
            'before': summaries[0], 'after': summaries[1], **counts, 'moved_ram_data_endpoints': moved_rows,
            'timing_accepted': False, 'unsupported_endpoint_count':len(a['unsupported']),
            'clock_domain_pairs':pairs,'selected_24_address_summary':summarize_subset(selected_address),
            'selected_36_return_summary':summarize_subset(selected_return),'all_192_address_summary':summarize_subset(all_addresses),
            'selected_return_endpoints':selected_return,
            'limits': ['M10K data setup/hold records do not establish primitive clock period or pulse-width margins.',
                       'Identical logical clocks do not prove clock routing or physical mux margin preservation.',
                       'Complete endpoint coverage and positive hold alone do not waive any regression gate.',
                       'This artifact does not establish physical routing, board IO, or hardware acceptance.']}


def selftest(documents, moves, prepared_cells):
    module = documents[1]['modules']['top']
    original = graph_proof(documents, moves, prepared_cells)
    tests = []

    def reject(label, mutate, restore):
        mutate()
        try:
            try:
                graph_proof(documents, moves, prepared_cells)
            except (ValueError, KeyError) as error:
                tests.append({'mutation': label, 'rejected': True, 'reason': str(error)})
            else:
                raise AssertionError(f'mutation accepted: {label}')
        finally:
            restore()

    ram = module['cells'][next(iter(moves))]
    params = copy.deepcopy(ram['parameters'])
    key = next(key for key in params if 'INIT' in key)
    value = params[key]
    altered = ('1' if value[0] == '0' else '0') + value[1:]
    reject('moved RAM initialization bit changed', lambda: ram['parameters'].update({key: altered}),
           lambda: ram.update(parameters=params))
    outside = next(name for name, cell in module['cells'].items() if cell['type'] == 'MISTRAL_BUF' and '$ROUTETHRU' in name)
    cell = module['cells'][outside]
    saved = cell['attributes']['FES_PINMAP_V1']
    changed = unpack(saved)
    changed['pins']['A'][0] = 3 if changed['pins']['A'][0] == 0 else 0
    reject('outside input inversion changed', lambda: cell['attributes'].update(FES_PINMAP_V1=pack(changed)),
           lambda: cell['attributes'].update(FES_PINMAP_V1=saved))
    reject('route-generated buffer removed', lambda: module['cells'].pop(outside),
           lambda: module['cells'].update({outside: cell}))
    bel = ram['attributes']['NEXTPNR_BEL']
    reject('planned RAM not at exact destination', lambda: ram['attributes'].update(NEXTPNR_BEL='MISTRAL_M10K.0.0.0'),
           lambda: ram['attributes'].update(NEXTPNR_BEL=bel))
    old_attrs = copy.deepcopy(cell['attributes'])
    reject('undeclared cell placement changed', lambda: cell['attributes'].update(NEXTPNR_BEL='MUTATED'),
           lambda: cell.update(attributes=old_attrs))
    name = next(name for name, net in module['netnames'].items() if any(type(bit) is int for bit in net['bits']))
    net = module['netnames'][name]
    bits = net['bits']
    changed = list(bits)
    changed[next(index for index, bit in enumerate(bits) if type(bit) is int)] = 1000000000
    reject('named-net alias or connection identity changed', lambda: net.update(bits=changed), lambda: net.update(bits=bits))
    reject('named net removed', lambda: module['netnames'].pop(name), lambda: module['netnames'].update({name: net}))
    saved = ram['attributes']['FES_PINMAP_V1']
    changed = unpack(saved)
    pin = next(pin for pin, value in changed['pins'].items() if len(value) > 1)
    changed['pins'][pin][1] = 'MUTATED'
    reject('RAM physical pin mapping changed', lambda: ram['attributes'].update(FES_PINMAP_V1=pack(changed)),
           lambda: ram['attributes'].update(FES_PINMAP_V1=saved))
    decoder_name = next(name for name in moves if module['cells'][name]['type'] == 'MISTRAL_ALUT4')
    decoder = module['cells'][decoder_name]
    saved = decoder['attributes']['FES_PINMAP_V1']
    changed = unpack(saved)
    changed['pins']['A'][1] = 'MUTATED'
    reject('selected decoder physical pin differs from native proof',
           lambda: decoder['attributes'].update(FES_PINMAP_V1=pack(changed)),
           lambda: decoder['attributes'].update(FES_PINMAP_V1=saved))
    lut = decoder['parameters']['LUT']
    reject('selected decoder truth table changed', lambda: decoder['parameters'].update(LUT='0'*len(lut)),
           lambda: decoder['parameters'].update(LUT=lut))
    require(graph_proof(documents, moves, prepared_cells) == original, 'negative tests failed to restore original graph')
    return {'unchanged_valid_graph_accepted': True, 'negative_mutations': tests, 'all_mutations_rejected': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, default=ROOT.parent / 'reassociate-20261022/baseline/routed.json')
    parser.add_argument('--candidate', type=Path, default=ROOT / 'route/routed.json')
    parser.add_argument('--plan', type=Path, default=ROOT / 'plan.json')
    parser.add_argument('--output-prefix', type=Path, default=ROOT / 'proof-routed')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    paths = [args.baseline.resolve(), args.candidate.resolve()]
    plan = read(args.plan)
    moves = plan_moves(plan)
    preparation = read(ROOT/'checkpoint-proof.json')
    inputs, prepared_cells = verify_preparation(preparation, moves)
    receipts = [read(path.parent / 'receipt.json') for path in paths]
    commands = [list(receipt['nextpnr_command']) for receipt in receipts]
    binary = receipts[0]['binary_sha256']
    require(binary == receipts[1]['binary_sha256'], 'compiler binary receipt hashes differ')
    for side, command in enumerate(commands):
        require(digest(Path(command[0])) == binary, 'actual compiler binary hash mismatch')
        require(command.count('--json') == 1, 'ambiguous route input argument')
        index = command.index('--json') + 1
        require(Path(command[index]).resolve() == inputs[side], 'route input does not match verified preparation')
        command[index] = '<verified-input>'
        for filename in ('routed.json', 'endpoints.json'):
            require(digest(paths[side].parent / filename) == receipts[side]['artifacts'][filename],
                    f'{filename}: artifact receipt hash mismatch')
    require(commands[0] == commands[1], 'route command differs beyond prepared JSON input')
    mask_receipt = read(ROOT/'route-native-mask-receipt.json')
    require(mask_receipt['input_sha256']==digest(paths[1]) and mask_receipt['plan_sha256']==digest(args.plan),
            'Final native-mask evidence is not bound to routed input/plan')
    require(mask_receipt['returncode']==0 and mask_receipt['proof_sha256']==digest(ROOT/'route-native-mask-proof.json'),
            'Final native-mask proof receipt failed')
    mask_proof = read(ROOT/'route-native-mask-proof.json')
    require(mask_proof['physical_truth_rows']==512 and mask_proof['all_touched_labs_legal'], 'Final native-mask proof incomplete')
    documents = [read(path) for path in paths]
    result = graph_proof(documents, moves, prepared_cells)
    result.update(schema=1, evidence='final routed JSON complete primitive-function and logical graph preservation',
                  checker_sha256=digest(Path(__file__).resolve()), plan_sha256=digest(args.plan),
                  before={'path': str(paths[0]), 'sha256': digest(paths[0])},
                  after={'path': str(paths[1]), 'sha256': digest(paths[1])},
                  same_compiler_binary_sha256=binary, commands_differ_only_by_prepared_input=True,
                  final_native_mask_receipt_sha256=digest(ROOT/'route-native-mask-receipt.json'),
                  placed_inputs_differ_only_by_declared_bels_and_decoder_physical_maps=True,
                  limits=['Every primitive retains exactly its type, parameters, ports, inputs and logical pin states; their documented semantics are assumed.',
                          'No RBF decode or physical routing/electrical/mux proof is performed.',
                          'No setup/hold, native primitive-clock, board IO or hardware acceptance is established.'])
    clock = clock_report(paths, moves)
    clock['checker_sha256'] = result['checker_sha256']
    outputs = {'': result, '-clocks': clock}
    if args.self_test:
        tests = selftest(documents, moves, prepared_cells)
        tests['checker_sha256'] = result['checker_sha256']
        outputs['-selftest'] = tests
    for suffix, data in outputs.items():
        Path(str(args.output_prefix) + suffix + '.json').write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps({'graph': result, 'timing': {key: value for key, value in clock.items() if key != 'moved_ram_data_endpoints'}}, indent=2))


if __name__ == '__main__':
    main()
