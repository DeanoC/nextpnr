#!/usr/bin/env python3
"""Read-only compiler replay checks and geometry analysis; never runs nextpnr."""
import collections
import copy
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / "placement-phase-audit-20261022/trace"
SETTING = "placerHeap/correctSpread"
TRACE = re.compile(
    r"HeAP target: stage=(\w+) iter=(\d+)(?: dispatch=(\d+))? "
    r"cell='([^']+)' type='([^']+)' raw=\(([^,]+),([^)]+)\) "
    r"target=\((-?\d+),(-?\d+)\)(?: priority=(-?\d+))?(?: bel='([^']+)')?"
)
ITER = re.compile(r"at iteration #(\d+), type ALL: wirelen solved = (\d+), spread = (\d+), legal = (\d+)")
SA = re.compile(r"at iteration #(\d+): temp = [^,]+, timing cost = (\d+), wirelen = (\d+)")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def differences(a, b, path=()):
    if type(a) is not type(b):
        return [{"path": path, "before": a, "after": b}]
    if isinstance(a, dict):
        result = []
        for key in sorted(a.keys() | b.keys()):
            if key not in a or key not in b:
                result.append({"path": path + (key,), "before": a.get(key), "after": b.get(key),
                               "absent": "before" if key not in a else "after"})
            else:
                result.extend(differences(a[key], b[key], path + (key,)))
        return result
    if isinstance(a, list):
        if len(a) != len(b):
            return [{"path": path, "before": a, "after": b}]
        return [change for index, (x, y) in enumerate(zip(a, b))
                for change in differences(x, y, path + (index,))]
    return [] if a == b else [{"path": path, "before": a, "after": b}]


def restore_exact_alias_ids(reference, candidate):
    """Prove a complete alias-induced bijection, then rename numeric bit IDs only."""
    require(reference["modules"].keys() == candidate["modules"].keys(), "Module inventory changed")
    result = copy.deepcopy(candidate)
    proof = {}
    for module_name, expected in reference["modules"].items():
        actual = candidate["modules"][module_name]
        require(expected["netnames"].keys() == actual["netnames"].keys(), "Exact net-alias inventory changed")
        forward, inverse = {}, {}
        for name, alias in expected["netnames"].items():
            bits = actual["netnames"][name]["bits"]
            require(len(bits) == len(alias["bits"]), "Alias width changed: " + name)
            for old, new in zip(alias["bits"], bits):
                require(type(old) is type(new), "Alias bit kind changed")
                if type(old) is int:
                    require(forward.get(old, new) == new and inverse.get(new, old) == old,
                            "Alias correspondence is not a bijection")
                    forward[old], inverse[new] = new, old
                else:
                    require(old == new, "Alias constant changed")

        def restore(bits):
            for bit in bits:
                require(type(bit) is not int or bit in inverse, "Connection has no exact named-alias identity")
            return [inverse[bit] if type(bit) is int else bit for bit in bits]

        normalized = result["modules"][module_name]
        for alias in normalized["netnames"].values():
            alias["bits"] = restore(alias["bits"])
        for port in normalized["ports"].values():
            port["bits"] = restore(port["bits"])
        for cell in normalized["cells"].values():
            for pin, bits in cell["connections"].items():
                cell["connections"][pin] = restore(bits)
        proof[module_name] = {"exact_aliases": len(expected["netnames"]), "bijective_numeric_bits": len(forward),
                              "changed_numeric_ids": [{"before": old, "after": new}
                                                      for old, new in sorted(forward.items()) if old != new]}
    return result, proof


def location(bel):
    match = re.fullmatch(r"MISTRAL_[^.]+\.(-?\d+)\.(-?\d+)\.(-?\d+)", bel)
    require(match is not None, "Unknown BEL coordinate format: " + bel)
    return [int(match[i]) for i in range(1, 4)]


def summary(rows, key):
    points = [row[key][:2] for row in rows]
    require(points, "Empty geometry summary")
    return {"count": len(points), "mean": [sum(p[i] for p in points) / len(points) for i in range(2)],
            "min": [min(p[i] for p in points) for i in range(2)],
            "max": [max(p[i] for p in points) for i in range(2)],
            "x_counts": dict(sorted(collections.Counter(p[0] for p in points).items()))}


def parse_trace(path, ram_names):
    rows, iterations, refinement = [], [], []
    with path.open() as stream:
        for line in stream:
            if "HeAP target:" in line and "type='MISTRAL_M10K'" in line:
                match = TRACE.search(line)
                require(match is not None, "Unparsed RAM trace row")
                require(match[4] in ram_names, "Trace RAM identity outside exact checkpoint inventory")
                rows.append({"stage": match[1], "iteration": int(match[2]),
                             "dispatch": int(match[3]) if match[3] else None,
                             "cell": match[4], "raw": [float(match[6]), float(match[7])],
                             "target": [int(match[8]), int(match[9])],
                             "priority": int(match[10]) if match[10] else None, "bel": match[11]})
            match = ITER.search(line)
            if match:
                iterations.append(dict(zip(["iteration", "solved", "spread", "legal"], map(int, match.groups()))))
            match = SA.search(line)
            if match:
                refinement.append(dict(zip(["iteration", "timing_cost", "wirelen"], map(int, match.groups()))))
    require(iterations and refinement, "Incomplete placement log")
    # The implementation saves only strict HPWL improvements; first minimum wins ties.
    selected = min(iterations, key=lambda row: row["legal"])
    stages = {}
    for stage in ["solved", "spread", "bound"]:
        stage_rows = [row for row in rows if row["iteration"] == selected["iteration"] and row["stage"] == stage]
        last = {row["cell"]: row for row in stage_rows}
        require(set(last) == ram_names, "Incomplete selected-iteration RAM identities at " + stage)
        if stage != "bound":
            require(len(last) == len(stage_rows), "Duplicate solved/spread identity")
        stages[stage] = [last[name] for name in sorted(last)]
    return {"iterations": iterations, "selected": selected, "refinement_final_logged": refinement[-1],
            "selected_ram_rows": stages, "rom_rows": rows}


def geometry(trace, checkpoint, rom_names, framebuffer_names):
    ram_names = {name for name, cell in checkpoint["modules"]["top"]["cells"].items()
                 if cell["type"] == "MISTRAL_M10K"}
    groups = {"microcode": rom_names, "framebuffer": framebuffer_names,
              "other_ram": ram_names - rom_names - framebuffer_names}
    result = {"iterations": trace["iterations"], "selected": trace["selected"],
              "refinement_final_logged": trace["refinement_final_logged"], "groups": {}}
    for group, names in groups.items():
        stages = {}
        for stage, rows in trace["selected_ram_rows"].items():
            selected = [row for row in rows if row["cell"] in names]
            stages[stage] = {"raw": summary(selected, "raw"), "target": summary(selected, "target")}
        final = [{"cell": name, "bel": checkpoint["modules"]["top"]["cells"][name]["attributes"]["NEXTPNR_BEL"]}
                 for name in sorted(names)]
        for row in final:
            row["location"] = location(row["bel"])
        stages["final_after_refinement"] = summary(final, "location")
        stages["final_cells"] = final
        result["groups"][group] = stages
    solved = trace["selected_ram_rows"]["solved"]
    rom_x = [row["raw"][0] for row in solved if row["cell"] in rom_names]
    result["printed_solved_x_rank_evidence"] = {
        "all_ram_count": len(solved), "microcode_x_interval": [min(rom_x), max(rom_x)],
        "microcode_rank_interval_1_based": [1 + sum(row["raw"][0] < min(rom_x) for row in solved),
                                             sum(row["raw"][0] <= max(rom_x) for row in solved)],
        "framebuffer_below_microcode_interval": sum(row["cell"] in framebuffer_names and row["raw"][0] < min(rom_x)
                                                     for row in solved),
        "framebuffer_above_microcode_interval": sum(row["cell"] in framebuffer_names and row["raw"][0] > max(rom_x)
                                                     for row in solved),
        "limitation": "Global printed-coordinate ranks; recursive cut regions and exact unrounded tie order are not traced."}
    result["selected_ram_rows"] = trace["selected_ram_rows"]
    result["all_iteration_microcode_rows"] = [row for row in trace["rom_rows"] if row["cell"] in rom_names]
    return result


def clearance_followups():
    # Independent small witnesses; no production solver or placement is run.
    sizes, pivot = [1, 5, 1], 1
    old = [max(sizes[:pivot], default=0), max(sizes[pivot:], default=0)]
    actual = [max(sizes[:pivot + 1], default=0), max(sizes[pivot + 1:], default=0)]
    require(old == [1, 5] and actual == [5, 1], "Bad clearance witness")
    # Initial partition weights [2,2] | [3,1], extents [2,1] | [3,1].
    # Capacity by row [5,5,1,1,1] selects cut row1; moving the width3 chain left cannot fit its width2 child.
    candidates = []
    capacity = [5, 5, 1, 1, 1]
    for cut in range(5):
        if cut + 1 >= 2 and 4 - cut + 1 >= 3:
            left, right = sum(capacity[:cut + 1]), sum(capacity[cut + 1:])
            candidates.append((abs(4 / max(left, 1) - 4 / max(right, 1)), cut))
    chosen = min(candidates)[1]
    require(chosen == 1 and 4 / 10 - 4 / 3 < 0 and 7 / 10 - 1 / 3 > 0, "Bad perturbation witness")
    return {
        "compiler_unchanged": True,
        "pivot_membership": {"source": "placer_heap.cc clearance loop uses i < pivot; cell/count partitions use i <= pivot",
                             "chain_extents": sizes, "pivot": pivot, "current_clearance": old,
                             "required_clearance": actual,
                             "test": "A widest macro exactly at pivot must count toward left clearance; cover pivot0 and last index."},
        "right_width": {"source": "candidate cut admits trimmed_r - cut + 1; right child starts cut + 1",
                        "region": [0, 5], "cut": 3, "right_child": [4, 5], "actual_width": 2,
                        "current_width": 3, "required_width": 3,
                        "test": "Reject a right macro one row wider than its child; accept an exact-width fit and translated bounds."},
        "post_perturbation": {"source": "pivot moves after clearances/target cut are chosen, without rechecking extents",
                              "weights": [2, 2, 3, 1], "extents": [2, 1, 3, 1], "initial_pivot": 1,
                              "capacity_by_row": capacity, "selected_cut": chosen,
                              "initial_counts": [4, 4], "final_counts": [7, 1], "final_pivot": 2,
                              "left_child_width": 2, "final_left_required_extent": 3,
                              "test": "After each final pivot, recompute actual child clearances and reject/retarget before coordinate mutation; mirror the transfer direction and both axes."},
        "impact_boundary": "These are macro-spreading defects. They do not establish physical illegality because strict legalization independently checks final BELs. Unclustered M10Ks have unit extents; no claim that these defects explain the ROM displacement.",
        "smallest_candidate_followup": "Correct membership and right width, then reject a cut before interpolation if the final pivot makes either child too narrow. Evaluate separately; rejecting can defer to the other axis and may affect QoR. Extent width remains necessary but not sufficient for exact cluster/root anchoring or regions."
    }


def allocation_proposal():
    return {
        "status": "read-only proposal; no implementation or timing acceptance",
        "source_mechanism": [
            "Mistral invokes a separate CutSpreader for the M10K bucket; COMB/FF are the only joint group.",
            "cut_region sorts cells by raw coordinate, chooses an approximately half-weight pivot, then chooses a target cut minimizing per-bucket utilization imbalance. No distance-to-original-target or endpoint window enters that target-cut objective.",
            "spread_binlerp assigns up to ten equal spatial bins and linearly redistributes the source ranks within them. Strict legalization follows the spread targets, not the raw solved positions.",
            "SpreaderRegion::overused applies beta to aggregate capacity once it reaches four BELs. The single-hard-block exception in scaled_bels_at disables congestion scaling, not beta. With318 movable RAMs and553 native sites, beta0.5 asks for636 sites, above the device total. This pressures region expansion; the existing traces do not record whether one particular merged region covered the entire device."
        ],
        "evidence_and_inference": [
            "Observed: prior iteration6 places all192 framebuffer solved x coordinates below all16 ROM coordinates, with ROM rank interval193..208 among318 RAMs. All16 ROMs spread to x41 while69 framebuffer RAMs legalize at x26.",
            "Observed: enabled iteration2 again has every framebuffer below every ROM in solved x rank. ROM ranks239..254 still spread to x41, while68 framebuffer RAMs legalize at x26.",
            "Observed: framebuffer solved mean x moves8.436 to22.405 between these selected iterations, while spread mean x stays23.273 to23.279. This is strong evidence that resource-rank redistribution dominates displacement distance.",
            "Inference: density-balanced recursive rank allocation is the leading mechanism for persistent eastward displacement. The trace does not prove the exact sequence of merged regions/cuts; a small cut-region diagnostic would be needed to claim that exact sequence."
        ],
        "smallest_phase_aware_candidate": {
            "scope": "Default-off discrete assignment for one architecture-declared sparse hard-block bucket, initially M10K. Exclude clusters, pseudo/fixed/kept cells, mixed physical resource views and unsupported legality dependencies; account for their occupied sites as unavailable. Never select by hierarchical cell name.",
            "placement_stage": "Replace that bucket's CutSpreader target allocation with one-to-one cell/BEL matching from the solved targets. Include all eligible bucket cells, so moving a critical ROM has an explicit opportunity cost for every displaced framebuffer. Apply the complete assignment at strict-legalizer initialization after ordinary unbinding; subsequent queue entries skip already-bound cells. Keep ordinary strengths and subsequent refinement.",
            "first_cost": "For each eligible cell i, use w_i=max(1,max_e P_capture(e)/W_native(e)) over complete finite positive setup-timed native input endpoint rows. First experiment minimizes sum_i w_i * Manhattan(solved_i,site_i), with deterministic cell/BEL tie order. This directly responds to a quarter-cycle window (weight4 for period10ns/window2.5ns) while retaining displacement costs for all RAMs. It is a heuristic, not an admissible timing bound.",
            "stronger_cost_if_needed": "Use architecture-predicted incident input and output net delays and native endpoint setup windows to penalize candidate normalized setup deficits. Include output/return paths and the displaced RAM's endpoints; avoid charging only the short-window address side. Recompute timing between assignments, not a full STA for each matrix entry.",
            "timing_prerequisite": "HeAP's existing analyser sets setup_only=true; get_endpoint_clock_pair_timings deliberately rejects that mode. Do not relax it. Either run a separate full placement analyser with existing validated endpoint export, or add a separate heuristic-only native setup-window accessor preserving clock-edge/PLL phase, false paths and multicycle rules. Omit unsupported rows from weighting and report them; never manufacture a window or claim coverage.",
            "legality_prerequisite": "Candidate edges require correct BEL type, exact region/FES restrictions, no fixed-site conflicts, and a whole-bucket one-to-one assignment. Native bind/full isBelLocationValid checks must validate the complete transaction. On unsupported interactions, insufficient candidates or any invalid binding, restore all bindings/strengths and architecture cache state and fall back to the existing bucket spread/legalize path. Merely assigning continuous target coordinates would still permit competition/eviction and is weaker.",
            "complexity": "Dense318x553 cost matrix:175854 candidate edges. Rectangular Hungarian matching is O(N^2*M), about56million elementary iterations here, with O(N*M) cost storage. Sparse min-cost flow is an alternative when region constraints prune most edges. Candidate costs should reuse cached endpoint/window data; no per-edge global STA.",
            "tests": [
                "Synthetic two-block/two-site case where phase shift changes W from10ns to2.5ns without changing period: allocation should prioritize the short-window block and explicitly charge the displaced block.",
                "Equal-window case preserves a deterministic minimum-displacement assignment; solve coordinate translation must translate an equivalent site problem.",
                "False-path/unrelated/unknown-clock rows create no invented urgency; mixed valid/unsupported coverage is reported. Multicycle and opposite edges follow native timing relationships.",
                "Protected sites, regions, shared-resource conflicts and insufficient complete match trigger exact rollback/fallback; clusters and unsupported hard blocks never enter the candidate set.",
                "Paired same-binary full routes retain exact endpoint/clock/IO/native primitive coverage and all setup/hold gates. Preparation cost or lower HPWL alone cannot select a winner."
            ]
        },
        "lower_scope_diagnostic": "Before implementing assignment, timing_strategy's independent reciprocal ROM/framebuffer swap audit should establish both blocks' complete incident timing and whether legal exchanges at column26 can improve the short window without damaging framebuffer/return paths. A generic hard-block beta experiment could isolate density expansion, but by itself does not prioritize native capture windows."
    }


def main():
    identity = read(ROOT / "source-identity.json")
    require(sha(ROOT / "nextpnr-mistral") == identity["binary_sha256"], "Binary identity mismatch")
    for name, expected in identity["sources"].items():
        require(sha(ROOT / "sources" / name) == expected, "Captured compiler source mismatch: " + name)
    pending = [label for label in ["default", "enabled", "explicit-zero", "conflict"]
               if not (ROOT / ("prepare-" + label) / "receipt.json").exists()]
    if pending:
        return {"status": "pending", "pending": pending}
    receipts = {label: read(ROOT / ("prepare-" + label) / "receipt.json")
                for label in ["default", "enabled", "explicit-zero", "conflict"]}
    parent_receipt = read(PRIOR / "parent-off-cpu/receipt.json")
    parent = read(PRIOR / "parent-off-cpu/placed.json")
    command = parent_receipt["nextpnr_command"][1:]
    suffixes = {"default": [], "enabled": ["--placer-heap-correct-spread", "--debug-placer"],
                "explicit-zero": ["--set", SETTING + "=0"],
                "conflict": ["--set", SETTING + "=0", "--placer-heap-correct-spread"]}
    outputs = {}
    for label, receipt in receipts.items():
        require(receipt["command"] == [str(ROOT / "nextpnr-mistral")] + command + suffixes[label],
                "Unexpected recipe: " + label)
        require(receipt["binary_sha256"] == identity["binary_sha256"], "Receipt binary mismatch")
        path = ROOT / ("prepare-" + label) / "placed.json"
        if label != "conflict":
            require(receipt["returncode"] == 0 and path.exists(), "Preparation failed: " + label)
            require(sha(path) == receipt["placed_sha256"], "Checkpoint receipt mismatch: " + label)
            outputs[label] = read(path)
    default = outputs["default"]
    default_raw = (ROOT / "prepare-default/placed.json").read_bytes()
    parent_raw = (PRIOR / "parent-off-cpu/placed.json").read_bytes()
    default_exact = default_raw == parent_raw
    parent_changes = differences(parent, default)
    require(all(tuple(change["path"]) == ("creator",) for change in parent_changes),
            "Default changes something beyond the top-level compiler creator label")
    require(sha(PRIOR / "parent-off-cpu/placed.json") == parent_receipt["placed_sha256"], "Parent receipt mismatch")
    current_creator, old_creator = default["creator"].encode(), parent["creator"].encode()
    require(default_raw.count(current_creator) == parent_raw.count(old_creator) == 1,
            "Creator label is not a unique byte replacement")
    require(default_raw.replace(current_creator, old_creator) == parent_raw,
            "Creator-only byte inverse does not restore the exact parent checkpoint")
    zero_raw_changes = differences(default, outputs["explicit-zero"])
    zero_normalized, zero_alias_proof = restore_exact_alias_ids(default, outputs["explicit-zero"])
    zero_changes = differences(default, zero_normalized)
    allowed = {("creator",), ("modules", "top", "settings", SETTING)}
    require(zero_changes and all(tuple(change["path"]) in allowed for change in zero_changes),
            "Explicit zero changed more than the declared setting/creator")
    require(SETTING not in default["modules"]["top"]["settings"], "Default inserted new setting")
    require(str(outputs["explicit-zero"]["modules"]["top"]["settings"][SETTING]).strip() == "0", "Zero not saved")
    require(outputs["enabled"]["modules"]["top"]["settings"][SETTING] == "0" * 31 + "1", "Enabled flag not saved")
    conflict = ROOT / "prepare-conflict"
    conflict_message = "setting 'placerHeap/correctSpread' is set by both --set and a dedicated command-line option"
    require(receipts["conflict"]["returncode"] != 0 and conflict_message in (conflict / "nextpnr.log").read_text(),
            "Conflicting setting was not rejected for the expected reason")
    require({p.name for p in conflict.iterdir()} == {"receipt.json", "nextpnr.log"}, "Conflict produced another artifact")
    cells = default["modules"]["top"]["cells"]
    names = set(cells)
    ram_names = {name for name, cell in cells.items() if cell["type"] == "MISTRAL_M10K"}
    rom_names = {row["cell"] for row in read(PRIOR / "microcode-trace.json")["rows"]}
    framebuffer_names = {name for name in ram_names if name.startswith("system.video.adapter.framebuffer_banks[")}
    require(len(rom_names) == 16 and rom_names <= ram_names and len(framebuffer_names) == 192, "Unexpected RAM cohorts")
    placements = {}
    for label, checkpoint in outputs.items():
        candidate_cells = checkpoint["modules"]["top"]["cells"]
        require(set(candidate_cells) == names, "Complete cell inventory changed: " + label)
        placements[label] = {name: cell["attributes"].get("NEXTPNR_BEL") for name, cell in candidate_cells.items()}
    require(placements["default"] == placements["explicit-zero"], "Explicit-zero placements differ")
    previous_trace = parse_trace(PRIOR / "trace-debug-cpu/nextpnr.log", ram_names)
    enabled_trace = parse_trace(ROOT / "prepare-enabled/nextpnr.log", ram_names)
    result = {"status": "pass_with_serialization_differences",
              "evidence_class": "host-only placement and compiler-behavior checks; no route/timing/hardware acceptance",
              "source_identity": identity, "checks": {
                  "same_recipe_except_declared_options": True, "default_byte_identical_to_parent": default_exact,
                  "default_sha256": receipts["default"]["placed_sha256"],
                  "parent_sha256": parent_receipt["placed_sha256"],
                  "default_complete_modules_identical": True, "default_creator_only_byte_inverse": True,
                  "default_differences": parent_changes,
                  "explicit_zero_exact_cell_inventory_and_placements": True,
                  "explicit_zero_raw_settings_creator_only": all(tuple(change["path"]) in allowed for change in zero_raw_changes),
                  "explicit_zero_raw_difference_count": len(zero_raw_changes),
                  "explicit_zero_complete_alias_bijection": zero_alias_proof,
                  "explicit_zero_after_alias_bijection_differences": zero_changes,
                  "conflict_rejected_without_checkpoint": True, "conflict_returncode": receipts["conflict"]["returncode"],
                  "total_cells": len(names), "total_rams": len(ram_names),
                  "enabled_changed_placements": sum(placements["default"][name] != placements["enabled"][name] for name in names)},
              "prior": geometry(previous_trace, parent, rom_names, framebuffer_names),
              "enabled": geometry(enabled_trace, outputs["enabled"], rom_names, framebuffer_names),
              "interpretation": {
                  "observed": "The opt-in changes the placement trajectory. Selected-iteration spreading still sends all sixteen ROMs to x41; final refinement retains columns38/41 with different rows.",
                  "not_established": "A reduced wirelength or changed ROM geometry does not prove improved routed timing, nor establish either repaired defect as the cause of the persistent eastward displacement.",
                  "causal_limit": "The option changes both verified defects, and the chosen iteration changes. Traces show stage boundaries, not recursive spreader cut decisions. Global coordinate ranks alone do not prove the exact recursive allocation."},
              "clearance_followups": clearance_followups(), "allocation_proposal": allocation_proposal(), "receipts": receipts,
              "artifact_sha256": {str(path.relative_to(ROOT.parent)): sha(path) for path in [
                  ROOT / "analysis.py", ROOT / "source.diff", ROOT / "source-identity.json",
                  ROOT / "prepare-default/placed.json", ROOT / "prepare-enabled/placed.json",
                  ROOT / "prepare-explicit-zero/placed.json", ROOT / "prepare-enabled/nextpnr.log",
                  PRIOR / "parent-off-cpu/placed.json", PRIOR / "trace-debug-cpu/nextpnr.log"]}}
    return result


if __name__ == "__main__":
    try:
        result = main()
    except Exception as error:
        result = {"status": "failed", "error": str(error)}
    (ROOT / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ["status", "error", "pending", "checks"] if key in result}, indent=2))
    raise SystemExit(0 if result["status"] in {"pass", "pass_with_serialization_differences"} else 1)
