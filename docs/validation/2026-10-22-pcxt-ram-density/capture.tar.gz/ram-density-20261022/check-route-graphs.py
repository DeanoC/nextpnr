#!/usr/bin/env python3
"""Verify complete corresponding placed/routed captures; no compiler invocation."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
helper = ROOT / 'route-graph.py'
spec = importlib.util.spec_from_file_location('density_route_graph', helper)
graph = importlib.util.module_from_spec(spec)
spec.loader.exec_module(graph)
result = {'helper_source': str(helper), 'helper_sha256': hashlib.sha256(helper.read_bytes()).hexdigest(),
          'scope': 'Complete corresponding placed-to-routed graph proof through verified identity buffers; no native mask or electrical proof.',
          'cases': {}}
for label in ['beta090', 'overflow075', 'overflow090']:
    before = ROOT / ('prepare-' + label) / 'placed.json'
    after = ROOT / ('route-' + label) / 'routed.json'
    placed, routed = graph.read(before), graph.read(after)
    proof = graph.graph_proof(placed, routed)
    case = {'status': 'pass', 'proof': proof,
            'artifact_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in [before, after]}}
    if label == 'beta090':
        case['negative_checks'] = graph.selftest(placed, routed)
    result['cases'][label] = case
    print(label, 'PASS', proof['original_cells'], 'original cells,',
          proof['verified_generated_identity_helpers'], 'verified identity helpers', flush=True)
(ROOT / 'route-graph-proof.json').write_text(json.dumps(result, indent=2) + '\n')
