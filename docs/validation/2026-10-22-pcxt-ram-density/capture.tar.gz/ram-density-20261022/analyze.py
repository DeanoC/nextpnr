#!/usr/bin/env python3
"""Read existing density replays only; never launches a compiler or route."""
import collections
import copy
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent
HELPER = OUT / "spreader-correction-20261022/analysis.py"
spec = importlib.util.spec_from_file_location("frozen_spreader_analysis", HELPER)
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
require, read, sha = p.require, p.read, p.sha
CASES = {"beta075": ("baseline", "0.75"), "beta090": ("baseline", "0.90"),
         "overflow075": ("overflow17", "0.75"), "overflow090": ("overflow17", "0.90")}
BINARY = "43b3c94c5c44d82f229d1df15cf90a419603c2eaadca3922f91cd6947d6e653a"
BETA_PATH = ("modules", "top", "settings", "placerHeap/beta")


def bel_change(path):
    return len(path) == 6 and path[:3] == ("modules", "top", "cells") and path[4:] == ("attributes", "NEXTPNR_BEL")


def compare(reference, candidate, rewritten=frozenset()):
    normalized, aliases = p.restore_exact_alias_ids(reference, candidate)
    changes = p.differences(reference, normalized)
    functional = []
    for change in changes:
        path = change["path"]
        if bel_change(path) or path == BETA_PATH:
            continue
        require(len(path) >= 5 and path[:3] == ("modules", "top", "cells") and path[3] in rewritten,
                "Unexpected graph, polarity, clock, metadata or setting change: " + repr(path))
        functional.append(change)
    if rewritten:
        require({d["path"][3] for d in functional} == set(rewritten), "Rewrite cell identities changed")
    return normalized, {"exact_alias_bijection": aliases,
                        "complete_cell_inventory": len(reference["modules"]["top"]["cells"]),
                        "changed_placements": sum(bel_change(c["path"]) for c in changes),
                        "beta_changes": [c for c in changes if c["path"] == BETA_PATH],
                        "outside_declared_rewrite_all_functions_connections_polarities_metadata_settings_exact": True,
                        "declared_rewrite_cells": sorted(rewritten), "declared_rewrite_changes": functional}


def output_drivers(module):
    result = collections.defaultdict(list)
    for name, cell in module["cells"].items():
        for pin, direction in cell["port_directions"].items():
            if direction == "output":
                for bit in cell["connections"].get(pin, []):
                    result[bit].append((name, pin))
    return result


def address_edges(checkpoint, roms):
    module = checkpoint["modules"]["top"]
    drivers = output_drivers(module)
    result = []
    for rom in sorted(roms):
        bits = module["cells"][rom]["connections"]["B1ADDR"]
        require(len(bits) == 12, "Unexpected ROM address width")
        for index, bit in enumerate(bits):
            require(len(drivers[bit]) == 1, "ROM address does not have one output driver")
            driver, pin = drivers[bit][0]
            cell = module["cells"][driver]
            require(cell["type"] == "MISTRAL_FF" and pin == "Q", "ROM address launch is not FF Q")
            require(cell["attributes"].get("keep") == "0" * 31 + "1", "Address FF lost keep")
            require(cell["attributes"].get("BEL_STRENGTH") == "0" * 31 + "1", "Address FF strength changed")
            result.append({"driver": driver, "driver_pin": pin, "sink": rom, "sink_pin": f"B1ADDR[{index}]"})
    counts = collections.Counter(row["driver"] for row in result)
    require(len(counts) == 48 and set(counts.values()) == {4}, "Address FF identity/fanout changed")
    return result


def positions(checkpoint, names):
    cells = checkpoint["modules"]["top"]["cells"]
    return [{"cell": name, "bel": cells[name]["attributes"]["NEXTPNR_BEL"],
             "location": p.location(cells[name]["attributes"]["NEXTPNR_BEL"])} for name in sorted(names)]


def edge_geometry(checkpoint, edges):
    names = {e["driver"] for e in edges} | {e["sink"] for e in edges}
    locs = {r["cell"]: r["location"] for r in positions(checkpoint, names)}
    rows = []
    for e in edges:
        a, b = locs[e["driver"]], locs[e["sink"]]
        rows.append({**e, "launch_location": a, "capture_location": b,
                     "dx": abs(a[0] - b[0]), "dy": abs(a[1] - b[1]),
                     "manhattan": abs(a[0] - b[0]) + abs(a[1] - b[1])})
    return {"edge_count": len(rows), "mean_manhattan": sum(r["manhattan"] for r in rows) / len(rows),
            "max_manhattan": max(r["manhattan"] for r in rows),
            "mean_dx": sum(r["dx"] for r in rows) / len(rows),
            "mean_dy": sum(r["dy"] for r in rows) / len(rows), "edges": rows}


def annotate_geometry(geometry, trace, checkpoint, cohorts, edges):
    for group, names in cohorts.items():
        bound = [{"cell": r["cell"], "location": p.location(r["bel"])}
                 for r in trace["selected_ram_rows"]["bound"] if r["cell"] in names]
        geometry["groups"][group]["selected_actual_chosen_bels"] = p.summary(bound, "location")
    rams = set().union(*cohorts.values())
    final = positions(checkpoint, rams)
    require(len({r["bel"] for r in final}) == 318, "RAM placements collide")
    geometry["all_318_ram_final_occupancy"] = p.summary(final, "location")
    geometry["kept_address_ff_final"] = p.summary(positions(checkpoint, {e["driver"] for e in edges}), "location")
    geometry["address_edge_geometry"] = edge_geometry(checkpoint, edges)
    return geometry


def predicted(report, edges):
    require(report["timing_summary"]["final_analogue_model"] is False, "Unexpected report timing model")
    expected = {(r["sink"], r["sink_pin"]): (r["driver"], r["driver_pin"]) for r in edges}
    rows = {}
    for path in report["critical_paths"]:
        segments = path["path"]
        if not segments:
            continue
        endpoint = (segments[-1]["to"]["cell"], segments[-1]["to"]["port"])
        if endpoint not in expected:
            continue
        require(path["from"] == "posedge clocks[0]" and path["to"] == "posedge clocks[2]",
                "ROM address clock relation changed")
        require(path["max_delay"] == 2.5, "ROM address capture window changed")
        require(endpoint not in rows, "Duplicate predicted ROM endpoint")
        launch = [s for s in segments if s["type"] == "clk-to-q"]
        require(len(launch) == 1 and (launch[0]["from"]["cell"], launch[0]["from"]["port"]) == expected[endpoint],
                "Predicted path launch identity differs from complete graph")
        require(segments[-1]["type"] == "setup", "Missing primitive setup segment")
        rows[endpoint] = {"sink": endpoint[0], "pin": endpoint[1], "launch": expected[endpoint][0],
                          "window_ns": 2.5, "total_segment_delay_ns": sum(s["delay"] for s in segments),
                          "slack_ns": 2.5 - sum(s["delay"] for s in segments), "segments": segments}
    require(set(rows) == set(expected), "Predicted ROM address path inventory incomplete")
    return {"evidence": "Placement estimate only; final_analogue_model=false; no routed acceptance",
            "exact_rom_address_paths": len(rows), "window_ns": 2.5,
            "setup_failures": sum(r["slack_ns"] < 0 for r in rows.values()),
            "setup_wns_ns": min(r["slack_ns"] for r in rows.values()),
            "calculation": "max_delay minus sum of all path segments, including signed clk-skew and primitive setup",
            "aggregate_clock_summaries_are_not_this_cross_phase_cohort": report["timing_summary"],
            "fmax": report["fmax"], "paths": [rows[e] for e in sorted(rows)]}


def negative_checks(reference, ff):
    tests = {}
    for label in ["missing_alias", "changed_ff_clock", "lost_keep", "changed_pin_polarity", "clock_setting"]:
        corrupt = copy.deepcopy(reference)
        module = corrupt["modules"]["top"]
        cell = module["cells"][ff]
        if label == "missing_alias":
            del module["netnames"][next(iter(module["netnames"]))]
        elif label == "changed_ff_clock":
            cell["connections"]["CLK"] = cell["connections"]["Q"].copy()
        elif label == "lost_keep":
            del cell["attributes"]["keep"]
        elif label == "changed_pin_polarity":
            cell["attributes"]["FES_PINMAP_V1"] += "00"
        else:
            module["settings"]["target_freq"] = "50000000.000000"
        try:
            compare(reference, corrupt)
        except ValueError:
            tests[label] = "rejected"
        else:
            raise ValueError("Corruption accepted: " + label)
    return tests


def main():
    prior_path = OUT / "spreader-correction-20261022/analysis.json"
    prior = read(prior_path)
    reference_path = OUT / "spreader-correction-20261022/prepare-enabled/placed.json"
    baseline = read(reference_path)
    cells = baseline["modules"]["top"]["cells"]
    rams = {n for n, c in cells.items() if c["type"] == "MISTRAL_M10K"}
    roms = {r["cell"] for r in prior["enabled"]["groups"]["microcode"]["final_cells"]}
    framebuffer = {r["cell"] for r in prior["enabled"]["groups"]["framebuffer"]["final_cells"]}
    require(len(rams) == 318 and len(roms) == 16 and len(framebuffer) == 192, "RAM cohort changed")
    cohorts = {"microcode": roms, "framebuffer": framebuffer, "other_ram": rams - roms - framebuffer}
    edges = address_edges(baseline, roms)
    ff_names = {e["driver"] for e in edges}
    rewrite_path = OUT / "reduction-balanced-20261022/proof-overflow17.json"
    rewrite = read(rewrite_path)
    require(rewrite["roots"]["overflow17"]["equivalent"] is True, "Missing existing overflow proof")
    rewritten = frozenset(rewrite["changed_cells"])
    require(len(rewritten) == 4 and not rewritten & (rams | ff_names), "Unexpected overflow scope")
    cases, checkpoints, hashes = {}, {}, {}
    for name, (variant, beta) in CASES.items():
        folder = ROOT / ("prepare-" + name)
        receipt = read(folder / "receipt.json")
        require(receipt["returncode"] == 0 and receipt["charged_seconds"] == 0, "Preparation failed or charged GPU")
        command = receipt["nextpnr_command"]
        require(command == receipt["command"], "Preparation command wrapper mismatch")
        require("--no-route" in command and "--debug-placer" in command and "--placer-heap-correct-spread" in command,
                "Unexpected prepare flags")
        require("--rbf" not in command and "--routed-endpoints" not in command, "Not a placement-only command")
        require(command[command.index("--placer-heap-beta") + 1] == beta and receipt["beta"] == beta, "Wrong beta")
        require(command[command.index("--freq") + 1] == "100.0" and command[command.index("--seed") + 1] == "1",
                "Frequency or seed changed")
        require(receipt["binary_sha256"] == BINARY and sha(Path(command[0])) == BINARY, "Binary identity changed")
        require(receipt["source_identity"] == read(ROOT / "prepare-beta075/receipt.json")["source_identity"],
                "Compiler source identity differs")
        expected_roots = [] if variant == "baseline" else ["overflow17"]
        require(receipt["selected_roots"] == expected_roots, "Unexpected root selection")
        for artifact, digest in receipt["artifacts"].items():
            require(sha(folder / artifact) == digest, "Receipt artifact hash mismatch")
        input_hashes = {flag: sha(Path(command[command.index(flag) + 1])) for flag in ["--json", "--qsf", "--sdc"]}
        require(input_hashes["--json"] == rewrite["source_synth_sha256"], "Source differs from overflow proof")
        if cases:
            require(input_hashes == cases["beta075"]["input_sha256"], "Inputs differ across beta experiments")
        checkpoint = read(folder / "placed.json")
        normalized, graph = compare(baseline, checkpoint, rewritten if variant == "overflow17" else frozenset())
        checkpoints[name] = checkpoint
        require(address_edges(normalized, roms) == edges, "Address FF/ROM complete edge identities changed")
        trace = p.parse_trace(folder / "nextpnr.log", rams)
        geom = annotate_geometry(p.geometry(trace, checkpoint, roms, framebuffer), trace, checkpoint, cohorts, edges)
        timing = read(folder / "predicted-timing.json")
        require(timing["utilization"]["MISTRAL_M10K"] == {"available": 553, "used": 318}, "RAM utilization changed")
        cases[name] = {"variant": variant, "beta": float(beta), "receipt": receipt,
                       "input_sha256": input_hashes, "graph_vs_baseline_beta05": graph,
                       "geometry": geom, "predicted_timing": predicted(timing, edges),
                       "kept_address_ffs_moved_vs_beta05": sum(cells[n]["attributes"]["NEXTPNR_BEL"] !=
                                                              normalized["modules"]["top"]["cells"][n]["attributes"]["NEXTPNR_BEL"]
                                                              for n in ff_names)}
        for f in ["receipt.json", "nextpnr.log", "placed.json", "predicted-timing.json"]:
            hashes[str((folder / f).relative_to(OUT))] = sha(folder / f)
    _, overflow_same_graph = compare(checkpoints["overflow075"], checkpoints["overflow090"])
    baseline_trace = p.parse_trace(reference_path.parent / "nextpnr.log", rams)
    baseline_geometry = annotate_geometry(p.geometry(baseline_trace, baseline, roms, framebuffer), baseline_trace,
                                          baseline, cohorts, edges)
    overflow_route_path = OUT / "spreader-correction-20261022/route-overflow17/routed.json"
    routed = read(overflow_route_path)
    overflow_reference = {"source": str(overflow_route_path),
                          "scope": "Final geometry only from completed route; no equivalent no-route checkpoint or debug target trace exists here",
                          "groups": {group: p.summary(positions(routed, names), "location") for group, names in cohorts.items()},
                          "kept_address_ff_final": p.summary(positions(routed, ff_names), "location"),
                          "address_edge_geometry": edge_geometry(routed, edges)}
    hashes.update({str(path.relative_to(OUT)): sha(path) for path in
                   [Path(__file__), HELPER, prior_path, reference_path, rewrite_path, overflow_route_path]})
    return {"status": "pass", "evidence": "Host-only placement diagnostic; no timing acceptance or hardware evidence",
            "checks": {"all_four_prepare_exit_zero": True, "same_frozen_binary": BINARY,
                       "same_inputs_seed_frequency_except_declared_beta_and_overflow_variant": True,
                       "exact_ram_cells": 318, "microcode_rams": 16, "framebuffer_rams": 192, "other_rams": 110,
                       "kept_address_ffs": 48, "exact_address_edges": 192,
                       "same_variant_overflow_complete_graph": overflow_same_graph,
                       "negative_self_tests": negative_checks(baseline, sorted(ff_names)[0])},
            "baseline_beta05": baseline_geometry, "overflow_beta05_final_route_geometry": overflow_reference,
            "cases": cases,
            "keep_interpretation": {"attributes_unchanged_except_bel": True, "all_keep": 1, "all_bel_strength": 1,
                                    "meaning": "Keep preserves these logical FFs; it is not a fixed-placement constraint. Ordinary fresh HeAP placement moves these weak FFs.",
                                    "register_cells": sorted(ff_names)},
            "interpretation": {
                "observed": "All four selected iterations rank all192 framebuffer RAMs west of all16 microcode ROMs. Higher global beta changes the solved/spread trajectory but leaves the final ROM bank east: columns38/41, except overflow075 also uses column49. None frees a ROM into column26 or14.",
                "predicted_only": "All192 short-window address identities survive and each run still predicts setup failures. Aggregate clock summaries do not replace the cross-phase endpoint cohort. Routed analogue setup/hold and complete coverage remain required.",
                "inference": "Beta0.5's aggregate capacity pressure is real, but increasing beta globally does not remove rank-based eastward ROM allocation. Density is not an established sufficient cause or fix; changes to the logic trajectory confound a global beta comparison.",
                "per_bucket_prototype_decision": "Not justified as a demonstrated timing repair. A default-off M10K-only beta override keeping COMB/FF0.5 is justified only as the smallest controlled experiment to separate hard-block density from changed logic trajectories, preferably after the four existing full routes. Do not expect it to fix the persistent framebuffer-before-ROM rank allocation.",
                "implementation_if_authorized": "Use an architecture-declared bucket beta in(0,1], default absent. Apply consistently to aggregate region expansion and congestion capacity viability; preserve fixed occupancy, region/cluster checks and native strict legalization. Existing global --placer-heap-beta should retain its exact default semantics. No phase/window urgency is introduced by beta itself.",
                "remaining_uncertainty": "Current trace does not expose recursive merged regions/cut sequence or prove minimum-displacement assignment. The overflow beta0.5 reference has final routed geometry only. This script cites the existing exhaustive overflow rewrite proof, but does not repeat its Boolean proof or prove physical LUT masks/RBF behavior."},
            "artifact_sha256": hashes}


if __name__ == "__main__":
    try:
        result = main()
    except Exception as error:
        result = {"status": "failed", "error": str(error)}
    (ROOT / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], **({"error": result["error"]} if "error" in result else
                      {"cases": {n: {"selected_iteration": c["geometry"]["selected"]["iteration"],
                                      "final_rom_columns": c["geometry"]["groups"]["microcode"]["final_after_refinement"]["x_counts"],
                                      "predicted_address_failures": c["predicted_timing"]["setup_failures"],
                                      "predicted_address_wns_ns": c["predicted_timing"]["setup_wns_ns"]}
                                 for n, c in result["cases"].items()}})}, indent=2))
    raise SystemExit(0 if result["status"] == "pass" else 1)
