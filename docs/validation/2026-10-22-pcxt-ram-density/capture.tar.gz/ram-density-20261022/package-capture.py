#!/usr/bin/env python3
"""Package existing diagnostic evidence and independently read every byte back."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    final = json.loads((ROOT / 'final-proof.json').read_text())
    assert final['status'] == 'proof-passed-all-candidates-rejected'
    paths = []
    paths.extend(p for p in ROOT.iterdir() if p.is_file() and
                 p.name not in {'capture.tar.gz', 'capture-readback.json', 'capture-manifest.json', 'package-capture.log'})
    for directory in sorted(ROOT.glob('prepare-*')) + sorted(ROOT.glob('route-*')):
        if directory.is_dir():
            paths.extend(p for p in directory.iterdir() if p.is_file())
    reference = OUT / 'spreader-correction-20261022'
    paths.extend(reference / name for name in ['analysis.py', 'analysis.json', 'source-identity.json'])
    for directory in ['prepare-enabled', 'route-enabled', 'route-overflow17']:
        paths.extend(p for p in (reference / directory).iterdir() if p.is_file())
    previous = OUT / 'reduction-balanced-20261022'
    paths.extend(p for p in (previous / 'inputs').iterdir() if p.is_file())
    paths.extend(previous / name for name in ['proof-overflow17.json', 'route-baseline/receipt.json',
                                             'route-overflow17/receipt.json'])
    contents = {}
    records = {}
    for path in sorted(set(paths)):
        assert path.is_file() and not path.is_symlink(), path
        assert path.suffix in {'.py', '.json', '.log', '.md', '.qsf', '.sdc', '.rbf'}, path
        name = str(path.relative_to(OUT))
        data = path.read_bytes()
        contents[name] = data
        records[name] = {'source': str(path), 'size': len(data), 'sha256': digest(data)}
    manifest = {'classification': 'host-only diagnostic evidence; all four candidates rejected',
                'files': records, 'excluded': ['compiler executables', 'compiled objects', 'full source trees'],
                'compiler_identity': final['compiler_identity'],
                'charged_seconds': final['charged_seconds'],
                'cumulative_through_density': final['cumulative_through_density']}
    manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
    (ROOT / 'capture-manifest.json').write_bytes(manifest_bytes)
    contents['ram-density-20261022/capture-manifest.json'] = manifest_bytes
    archive = ROOT / 'capture.tar.gz'
    with tarfile.open(archive, 'w:gz', compresslevel=6) as target:
        for name, data in sorted(contents.items()):
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mtime = 0
            item.mode = 0o644
            target.addfile(item, io.BytesIO(data))
    readback = {}
    with tarfile.open(archive, 'r:gz') as source:
        members = source.getmembers()
        assert len(members) == len(contents) and {m.name for m in members} == set(contents)
        for member in members:
            assert member.isfile()
            data = source.extractfile(member).read()
            assert data == contents[member.name], member.name
            readback[member.name] = {'size': len(data), 'sha256': digest(data)}
    # Recheck the original source files after compression, without relying only
    # on the in-memory copy used to create the tar archive.
    for name, record in records.items():
        assert Path(record['source']).read_bytes() == contents[name], name
    result = {'archive_sha256': digest(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
              'member_count': len(readback), 'all_source_bytes_read_back_exactly': True,
              'members': readback}
    (ROOT / 'capture-readback.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in result if key != 'members'}, indent=2))


if __name__ == '__main__':
    main()
