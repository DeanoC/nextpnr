#!/usr/bin/env python3
"""Complete placed-to-routed graph proof for these frozen full-design runs.

Proves logical preservation through individually verified identity buffers.
Records physical maps/LAB state; it does not prove LUT masks or RBF routing.
"""
import collections
import copy
import hashlib
import json
import re

ROUTE_SETTINGS_SHA = "0abcd1b1b83a1cedde5c415414ab703152d6432928baf04a8fe39f58fe36b9cf"


def require(value, message):
    if not value:
        raise ValueError(message)


def unique(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, "Duplicate JSON key: " + key)
        value[key] = item
    return value


def read(path):
    return json.loads(path.read_bytes(), object_pairs_hook=unique)


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def unpack(value):
    return json.loads(bytes.fromhex(value), object_pairs_hook=unique)


def pinmap(cell, name):
    value = unpack(cell["attributes"]["FES_PINMAP_V1"])
    require(set(value) == {"count", "pins"} and type(value["count"]) is int and value["count"] == len(value["pins"]),
            name + ": incomplete pin snapshot")
    pins = value["pins"]
    for pin, state in pins.items():
        require(isinstance(state, list) and state and type(state[0]) is int and 0 <= state[0] <= 3
                and all(type(x) is str and x for x in state[1:]), name + ": invalid pin state/map")
        require(len(set(state[1:])) == len(state[1:]), name + ": duplicate physical pin")
    for port, bits in cell["connections"].items():
        names = [port] if port in pins else [f"{port}[{i}]" for i in range(len(bits))]
        require(names and all(pin in pins for pin in names) and (len(bits) <= 1 or port not in pins),
                name + "." + port + ": incomplete logical lane state")
    return pins


def location(bel):
    m = re.fullmatch(r"(MISTRAL_[^.]+)\.(\d+)\.(\d+)\.(\d+)", bel)
    require(m is not None, "Invalid BEL " + bel)
    return m[1], [int(m[i]) for i in range(2, 5)]


def graph_proof(placed, routed):
    require(set(placed) == set(routed) == {"creator", "modules"}, "Root schema changed")
    require(placed["creator"] == routed["creator"], "Compiler creator changed")
    require(set(placed["modules"]) == set(routed["modules"]) == {"top"}, "Module inventory changed")
    a, b = placed["modules"]["top"], routed["modules"]["top"]
    require(set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"}, "Module schema changed")
    require(a["attributes"]["step"] == "place" and b["attributes"]["step"] == "route", "Wrong checkpoint phases")
    attrs = dict(b["attributes"])
    labs = unpack(attrs.pop("FES_LABSTATE_V1"))
    attrs["step"] = "place"
    require(attrs == a["attributes"], "Nonphysical module attributes changed")
    require(set(labs) == {"device", "labs"} and labs["device"] == "5CSEBA6U23I7" and len(labs["labs"]) == 4191,
            "Incomplete LAB snapshot/device")
    lab_keys = set()
    for row in labs["labs"]:
        require(len(row) == 4 and all(type(x) is int for x in row[:3]) and row[2] in [0, 1]
                and len(row[3]) == 62 and tuple(row[:2]) not in lab_keys, "Malformed LAB geometry")
        lab_keys.add(tuple(row[:2]))
        for i, value in enumerate(row[3]):
            maximum = 2 if i >= 2 and (i - 2) % 6 in [2, 3] else 1
            require(type(value) is int and 0 <= value <= maximum, "Invalid LAB mode/control field")
    require(set(a["settings"]) <= set(b["settings"]), "Original setting removed")
    require(all(b["settings"][k] == v for k, v in a["settings"].items()), "Original setting changed")
    extra_settings = {k: v for k, v in b["settings"].items() if k not in a["settings"]}
    fixed_settings = dict(extra_settings)
    if "gpurouter/localInputEscape" in fixed_settings:
        require(fixed_settings.pop("gpurouter/localInputEscape") == "0 ", "Unexpected local-input escape setting")
    require(canonical_sha(fixed_settings) == ROUTE_SETTINGS_SHA, "Unexpected routing settings/defaults")
    originals = set(a["cells"])
    require(originals <= set(b["cells"]), "Original cell removed")
    helpers = set(b["cells"]) - originals
    require(set(a["netnames"]) <= set(b["netnames"]), "Original alias removed")
    extra_aliases = set(b["netnames"]) - set(a["netnames"])
    require(len(helpers) == len(extra_aliases), "Generated cell/alias counts differ")

    forward, reverse = {}, {}
    aliases_by_bit = collections.defaultdict(list)
    for name in sorted(a["netnames"]):
        old, new = a["netnames"][name], b["netnames"][name]
        require(set(old) == set(new) == {"hide_name", "bits", "attributes"}, name + ": alias schema changed")
        require(old["hide_name"] == new["hide_name"] and len(old["bits"]) == len(new["bits"]), name + ": alias shape changed")
        require({k: v for k, v in old["attributes"].items() if k != "ROUTING"} ==
                {k: v for k, v in new["attributes"].items() if k != "ROUTING"}, name + ": alias metadata changed")
        require(type(new["attributes"].get("ROUTING")) is str, name + ": missing routing snapshot")
        for i, (x, y) in enumerate(zip(old["bits"], new["bits"])):
            require(type(x) is type(y), name + ": bit kind changed")
            if type(x) is int:
                require(forward.get(x, y) == y and reverse.get(y, x) == x, name + ": alias split/merge")
                forward[x], reverse[y] = y, x
                aliases_by_bit[y].append((name, i))
            else:
                require(x == y and x in ["0", "1", "x", "z"], name + ": alias constant changed")

    drivers, consumers, external = collections.defaultdict(list), collections.defaultdict(list), set()
    for name, cell in b["cells"].items():
        require(set(cell) == {"hide_name", "type", "parameters", "attributes", "port_directions", "connections"},
                name + ": cell schema changed")
        require(set(cell["connections"]) == set(cell["port_directions"]), name + ": port inventory differs")
        for port, bits in cell["connections"].items():
            direction = cell["port_directions"][port]
            require(direction in ["input", "output", "inout"], name + ": bad direction")
            for i, bit in enumerate(bits):
                if direction in ["output", "inout"]:
                    drivers[bit].append((name, port, i))
                if direction in ["input", "inout"]:
                    consumers[bit].append((name, port, i))
    for port in b["ports"].values():
        external.update(port["bits"])

    substitutions, ledger, alias_substitutions, generated_bits = {}, {}, {}, set()
    for name in sorted(helpers):
        cell = b["cells"][name]
        require(name.endswith("$ROUTETHRU"), name + ": unknown generated cell")
        ff = name[:-len("$ROUTETHRU")]
        require(ff in originals and a["cells"][ff]["type"] == "MISTRAL_FF", name + ": not a source FF helper")
        require(cell["type"] == "MISTRAL_BUF" and cell["parameters"] == {} and cell["hide_name"] == 0
                and cell["port_directions"] == {"A": "input", "Q": "output"}
                and set(cell["connections"]) == {"A", "Q"}, name + ": helper is not exact identity primitive")
        require(set(cell["attributes"]) == {"NEXTPNR_BEL", "BEL_STRENGTH", "FES_PINMAP_V1"}
                and cell["attributes"]["BEL_STRENGTH"] == "0" * 30 + "10", name + ": unexpected helper metadata/strength")
        pins = pinmap(cell, name)
        require(set(pins) == {"A", "Q"} and pins["Q"] == [0, "COMBOUT"] and len(pins["A"]) == 2
                and pins["A"][0] == 0 and pins["A"][1] in ["E0", "E1", "F0", "F1"], name + ": nonidentity helper pins")
        require(len(cell["connections"]["A"]) == len(cell["connections"]["Q"]) == 1, name + ": helper width changed")
        source, output = cell["connections"]["A"][0], cell["connections"]["Q"][0]
        require(type(source) is int and type(output) is int and source in reverse and output not in reverse
                and output not in generated_bits and source != output, name + ": invalid helper signal ancestry")
        generated_bits.add(output)
        require(a["cells"][ff]["connections"]["DATAIN"] == [reverse[source]], name + ": source is not original FF data")
        require(b["cells"][ff]["connections"]["DATAIN"] == [output], name + ": helper does not feed exact FF DATAIN")
        require(drivers[output] == [(name, "Q", 0)] and consumers[output] == [(ff, "DATAIN", 0)]
                and output not in external, name + ": helper output has extra driver/user/external port")
        alias = name + "$conn$Q"
        require(alias in extra_aliases, name + ": missing exact generated alias")
        net = b["netnames"][alias]
        require(set(net) == {"hide_name", "bits", "attributes"} and net["hide_name"] == 0 and net["bits"] == [output]
                and set(net["attributes"]) == {"ROUTING"} and type(net["attributes"]["ROUTING"]) is str,
                name + ": unexpected generated net/attributes")
        kind, loc = location(cell["attributes"]["NEXTPNR_BEL"])
        ff_kind, ff_loc = location(b["cells"][ff]["attributes"]["NEXTPNR_BEL"])
        require(kind in ["MISTRAL_COMB", "MISTRAL_MCOMB"] and ff_kind == "MISTRAL_FF" and loc[:2] == ff_loc[:2]
                and loc[2] // 6 == ff_loc[2] // 6 and loc[2] % 6 in [0, 1]
                and ff_loc[2] % 6 in ([2, 3] if loc[2] % 6 == 0 else [4, 5])
                and pins["A"][1][-1] == str(loc[2] % 6), name + ": helper is outside its FF half")
        # The original net aliases prove this source identity; no name-only collapse.
        source_aliases = sorted(aliases_by_bit[source])
        require(source_aliases, name + ": source has no original alias")
        substitutions[output] = source
        alias_substitutions[alias] = source_aliases[0][0]
        ledger[name] = {"ff": ff, "source_original_bit": reverse[source], "source_aliases": source_aliases,
                        "source_final_bit": source, "output_final_bit": output, "output_alias": alias,
                        "sole_driver": drivers[output][0], "sole_user": consumers[output][0],
                        "bel": cell["attributes"]["NEXTPNR_BEL"], "ff_bel": b["cells"][ff]["attributes"]["NEXTPNR_BEL"],
                        "pins": pins, "identity_primitive": True}
    require(extra_aliases == {row["output_alias"] for row in ledger.values()}, "Unknown generated alias")
    actual_extra_bits = {bit for alias in extra_aliases for bit in b["netnames"][alias]["bits"]}
    require(actual_extra_bits == generated_bits, "Unknown generated signal class")

    def normalize(bits):
        result = []
        for bit in bits:
            if type(bit) is int:
                bit = substitutions.get(bit, bit)
                require(bit in reverse, "Connected signal has no complete original alias identity")
                result.append(reverse[bit])
            else:
                require(bit in ["0", "1", "x", "z"], "Unknown constant")
                result.append(bit)
        return result

    require(set(a["ports"]) == set(b["ports"]), "External port inventory changed")
    for name, old in a["ports"].items():
        new = dict(b["ports"][name])
        new["bits"] = normalize(new["bits"])
        require(old == new, name + ": external port changed")
    physical_maps, states = [], 0
    for name in sorted(originals):
        old, new = a["cells"][name], b["cells"][name]
        for field in ["hide_name", "type", "parameters", "port_directions"]:
            require(old[field] == new[field], name + ": function/port metadata changed: " + field)
        require(old["connections"] == {pin: normalize(bits) for pin, bits in new["connections"].items()},
                name + ": logical graph changed after exact helper substitution")
        op, np = pinmap(old, name), pinmap(new, name)
        require({k: v[0] for k, v in op.items()} == {k: v[0] for k, v in np.items()}, name + ": logical pin state/inversion changed")
        states += len(op)
        require({k: v for k, v in old["attributes"].items() if k != "FES_PINMAP_V1"} ==
                {k: v for k, v in new["attributes"].items() if k != "FES_PINMAP_V1"}, name + ": original placement/attributes changed")
        if op != np:
            physical_maps.append({"cell": name, "before": op, "after": np})
    return {"status": "pass", "original_cells": len(originals), "original_aliases": len(a["netnames"]),
            "original_numeric_signals": len(forward), "routed_cells": len(b["cells"]), "routed_aliases": len(b["netnames"]),
            "verified_generated_identity_helpers": len(helpers), "original_logical_pin_states_checked": states,
            "all_original_functions_connections_aliases_attributes_placements_and_polarities_preserved": True,
            "complete_helper_ledger": ledger, "helper_alias_to_original_alias": alias_substitutions,
            "physical_pin_mapping_changes": physical_maps,
            "lab_state": {"device": labs["device"], "complete_labs": len(labs["labs"]),
                          "canonical_sha256": canonical_sha(labs), "geometry_sha256": canonical_sha([row[:3] for row in labs["labs"]])},
            "routing_settings_added": extra_settings,
            "limits": ["Logical graph proof through exact identity primitives; physical pin maps and LAB state are recorded, not waived.",
                       "No native reload, physical mask/RBF equivalence, analogue timing acceptance or hardware proof is supplied by this checker."]}


def selftest(placed, routed):
    """Mutate actual artifact records, requiring fail-closed independent rechecks."""
    a, b = placed["modules"]["top"], routed["modules"]["top"]
    helper = sorted(set(b["cells"]) - set(a["cells"]))[0]
    original = helper.removesuffix("$ROUTETHRU")
    other = next(n for n, c in a["cells"].items() if c["type"] == "MISTRAL_FF" and n != original)
    alias = next(iter(a["netnames"]))
    labels = ["original_alias_removed", "extra_alias", "original_cell_removed", "helper_input_changed",
              "helper_extra_consumer", "helper_nonidentity_parameter", "helper_pin_inverted", "helper_wrong_half",
              "original_pin_inverted", "original_connection_changed", "original_keep_changed", "route_setting_changed",
              "lab_mode_out_of_range"]
    result = {}
    for label in labels:
        corrupt = copy.deepcopy(routed)
        m = corrupt["modules"]["top"]
        h, c = m["cells"][helper], m["cells"][original]
        if label == "original_alias_removed":
            del m["netnames"][alias]
        elif label == "extra_alias":
            m["netnames"]["__extra"] = copy.deepcopy(m["netnames"][alias])
        elif label == "original_cell_removed":
            del m["cells"][other]
        elif label == "helper_input_changed":
            h["connections"]["A"] = c["connections"]["Q"].copy()
        elif label == "helper_extra_consumer":
            m["cells"][other]["connections"]["DATAIN"] = h["connections"]["Q"].copy()
        elif label == "helper_nonidentity_parameter":
            h["parameters"]["LUT"] = "01"
        elif label in ["helper_pin_inverted", "original_pin_inverted"]:
            target, pin = (h, "A") if label == "helper_pin_inverted" else (c, "CLK")
            pm = unpack(target["attributes"]["FES_PINMAP_V1"])
            pm["pins"][pin][0] ^= 3
            target["attributes"]["FES_PINMAP_V1"] = json.dumps(pm).encode().hex()
        elif label == "helper_wrong_half":
            name, loc = location(h["attributes"]["NEXTPNR_BEL"])
            h["attributes"]["NEXTPNR_BEL"] = ".".join([name, str(loc[0]), str(loc[1]), str(loc[2] ^ 1)])
        elif label == "original_connection_changed":
            c["connections"]["CLK"] = c["connections"]["Q"].copy()
        elif label == "original_keep_changed":
            c["attributes"]["keep"] = "__corrupt"
        elif label == "route_setting_changed":
            m["settings"]["gpurouter/maxIter"] = "999"
        else:
            payload = unpack(m["attributes"]["FES_LABSTATE_V1"])
            payload["labs"][0][3][0] = 2
            m["attributes"]["FES_LABSTATE_V1"] = json.dumps(payload).encode().hex()
        try:
            graph_proof(placed, corrupt)
        except ValueError:
            result[label] = "rejected"
        else:
            raise ValueError("Accepted corrupted graph: " + label)
    return result
