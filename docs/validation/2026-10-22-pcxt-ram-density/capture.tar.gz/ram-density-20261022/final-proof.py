#!/usr/bin/env python3
"""Read completed density captures; never invoke placement, routing or hardware."""
from collections import Counter
from copy import deepcopy
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent
COMPILER = Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
CASES = {'beta075': ('route-enabled', '0.75'), 'beta090': ('route-enabled', '0.90'),
         'overflow075': ('route-overflow17', '0.75'), 'overflow090': ('route-overflow17', '0.90')}
PHYSICAL = {'constant_outputs', 'static_endpoints', 'unsupported_details'}
NUMERIC = {'setup', 'hold', 'max_path', 'min_path'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_bytes(), object_pairs_hook=unique)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def rows(report):
    result = {}
    for endpoint, records in report['endpoints'].items():
        for record in records:
            identity = (endpoint, tuple(record['launch']), tuple(record['capture']))
            require(identity not in result, 'Duplicate endpoint/clock tuple')
            result[identity] = record
    return result


def check_reports(before, after):
    require(before.keys() == after.keys(), 'Top-level report inventory changed')
    require(type(before['complete']) is bool and type(after['complete']) is bool, 'Malformed completeness flag')
    require(before['final_analogue'] is True and after['final_analogue'] is True, 'Not final routed analogue')
    for field in before.keys() - PHYSICAL - {'endpoints'}:
        require(before[field] == after[field], 'Timing contract/coverage changed: ' + field)
    for field in PHYSICAL:
        require(before[field].keys() == after[field].keys(), 'Physical endpoint identity changed: ' + field)
    old, new = rows(before), rows(after)
    require(old.keys() == new.keys(), 'Complete endpoint/clock identity inventory changed')
    for identity, record in old.items():
        candidate = new[identity]
        require(record.keys() == candidate.keys(), 'Endpoint record fields changed')
        for field in record.keys() - NUMERIC:
            require(record[field] == candidate[field], 'Endpoint window/status changed: ' + field)
        for margin, active in [('setup', 'setup_timed'), ('hold', 'hold_related')]:
            require((type(candidate[margin]) is int) == candidate[active], 'Malformed active/untimed margin')
    return old, new


def differences(before, after, path=()):
    if type(before) is not type(after):
        return [{'path': path, 'before': before, 'after': after}]
    if isinstance(before, dict):
        result = []
        for key in sorted(before.keys() | after.keys()):
            if key not in before or key not in after:
                result.append({'path': path + (key,), 'before': before.get(key), 'after': after.get(key),
                               'absent': 'before' if key not in before else 'after'})
            else:
                result.extend(differences(before[key], after[key], path + (key,)))
        return result
    if isinstance(before, list):
        if len(before) != len(after):
            return [{'path': path, 'before': before, 'after': after}]
        return [change for index, (a, b) in enumerate(zip(before, after))
                for change in differences(a, b, path + (index,))]
    return [] if before == after else [{'path': path, 'before': before, 'after': after}]


def without_bel(value):
    if isinstance(value, dict):
        return {key: without_bel(item) for key, item in value.items() if key != 'NEXTPNR_BEL'}
    if isinstance(value, list):
        return [without_bel(item) for item in value]
    return value


def negative_checks(reference):
    result = {}
    endpoint = next(iter(reference['endpoints']))
    for case in ['missing_endpoint', 'setup_window', 'new_row_field', 'clock_contract', 'unsupported_identity', 'not_final']:
        modified = deepcopy(reference)
        if case == 'missing_endpoint':
            del modified['endpoints'][endpoint]
        elif case == 'setup_window':
            modified['endpoints'][endpoint][0]['setup_window'] += 1
        elif case == 'new_row_field':
            modified['endpoints'][endpoint][0]['invented'] = True
        elif case == 'clock_contract':
            modified['clocks']['invented'] = {}
        elif case == 'unsupported_identity':
            modified['unsupported'] = []
        else:
            modified['final_analogue'] = False
        try:
            check_reports(reference, modified)
        except ValueError:
            result[case] = 'rejected'
        else:
            raise ValueError('Corruption accepted: ' + case)
    return result


def main():
    placement = read(ROOT / 'analysis.json')
    require(placement['status'] == 'pass', 'Placement proof not passed')
    for path, expected in placement['artifact_sha256'].items():
        require(sha(OUT / path) == expected, 'Placement proof source changed: ' + path)
    identity = read(OUT / 'spreader-correction-20261022/source-identity.json')
    tree = subprocess.check_output(['git', 'rev-parse', identity['result_commit'] + '^{tree}'], cwd=COMPILER, text=True).strip()
    require(tree == identity['result_tree'], 'Compiler committed tree mismatch')
    for path, expected in identity['sources'].items():
        content = subprocess.check_output(['git', 'show', identity['result_commit'] + ':' + path], cwd=COMPILER)
        require(hashlib.sha256(content).hexdigest() == expected, 'Compiler committed source mismatch: ' + path)
    result = {'evidence': 'Host-only fresh full-placement/route diagnostics; no acceptance',
              'compiler_identity': identity, 'placement_proof_hashes_verified': len(placement['artifact_sha256']),
              'cases': {}, 'prior_completed_total_including_swaps': '15783.49161636922436'}
    charges = []
    for label, (ref, beta) in CASES.items():
        folder = ROOT / ('route-' + label)
        reference = OUT / 'spreader-correction-20261022' / ref
        receipt, parent = read(folder / 'receipt.json'), read(reference / 'receipt.json')
        require(receipt['source_identity'] == identity, 'Compiler identity differs')
        command = receipt['nextpnr_command'][:]
        require(sha(Path(command[0])) == identity['binary_sha256'] == receipt['binary_sha256'], 'Compiler binary mismatch')
        at = command.index('--placer-heap-beta')
        require(command[at + 1] == beta == receipt['beta'], 'Density setting mismatch')
        del command[at:at + 2]
        require(command == parent['nextpnr_command'], 'Recipe differs beyond declared beta')
        inputs = {flag: sha(Path(command[command.index(flag) + 1])) for flag in ['--json', '--qsf', '--sdc']}
        require(inputs == placement['cases'][label]['input_sha256'], 'Frozen route inputs differ')
        for name, expected in receipt['artifacts'].items():
            require(sha(folder / name) == expected, 'Route artifact mismatch: ' + name)
        for name, expected in parent['artifacts'].items():
            require(sha(reference / name) == expected, 'Reference artifact mismatch: ' + name)
        charge = Decimal(str(receipt['charged_seconds']))
        charges.append(charge)
        case = {'returncode': receipt['returncode'], 'charged_seconds': str(charge),
                'reference': str(reference), 'recipe_exact_except_beta': True, 'input_hashes': inputs,
                'receipt_sha256': sha(folder / 'receipt.json'), 'route_log_sha256': sha(folder / 'nextpnr.log'),
                'all_receipt_artifact_hashes_match': True}
        if not (folder / 'endpoints.json').exists():
            require(label == 'beta075' and receipt['returncode'] == 125 and receipt['artifacts'] == {},
                    'Unexpected incomplete-route state')
            case.update({'status': 'route-failed-no-final-artifacts',
                         'log_tail': (folder / 'nextpnr.log').read_text().splitlines()[-8:]})
            result['cases'][label] = case
            continue
        before, after = read(reference / 'endpoints.json'), read(folder / 'endpoints.json')
        old, new = check_reports(before, after)
        require(len(new) == 17199, 'Unexpected complete endpoint count')
        deltas = []
        for key in sorted(old):
            a, b = old[key], new[key]
            deltas.append({'endpoint': json.loads(key[0]), 'launch': key[1], 'capture': key[2],
                           'setup_window': b['setup_window'], 'setup_timed': b['setup_timed'],
                           'hold_related': b['hold_related'],
                           'before': {k: a[k] for k in sorted(NUMERIC)},
                           'after': {k: b[k] for k in sorted(NUMERIC)}})
        save(label + '-all-endpoint-deltas.json', deltas)
        physical = {field: differences(before[field], after[field]) for field in sorted(PHYSICAL)}
        save(label + '-physical-record-differences.json', physical)
        require(without_bel(before['constant_outputs']) == without_bel(after['constant_outputs']),
                'Constant-output contract changed beyond placement')
        for key, record in before['static_endpoints'].items():
            require({k: v for k, v in record.items() if k != 'chain'} ==
                    {k: v for k, v in after['static_endpoints'][key].items() if k != 'chain'},
                    'Static sink/clock/value contract changed')
        timed = [v for v in new.values() if v['setup_timed']]
        related = [v for v in new.values() if v['hold_related']]
        transitions = Counter(('new_failure' if old[k]['setup'] >= 0 > v['setup'] else
                               'fixed_failure' if old[k]['setup'] < 0 <= v['setup'] else 'same_sign')
                              for k, v in new.items() if v['setup_timed'])
        case.update({'status': 'complete-route-rejected-for-setup', 'exported_endpoint_rows': len(new),
                     'native_report_complete': after['complete'],
                     'setup_timed_rows': len(timed), 'hold_related_rows': len(related),
                     'setup_failures': sum(v['setup'] < 0 for v in timed), 'setup_wns_ps': min(v['setup'] for v in timed),
                     'hold_failures': sum(v['hold'] < 0 for v in related), 'hold_wns_ps': min(v['hold'] for v in related),
                     'setup_failure_transitions': transitions, 'native_unsupported_rows': len(after['unsupported']),
                     'native_primitive_clock_rows': len(after['primitive_clocks']),
                     'all_nonphysical_top_level_fields_exact': sorted(before.keys() - PHYSICAL - {'endpoints'}),
                     'every_endpoint_field_except_four_numeric_path_margins_exact': True,
                     'physical_endpoint_key_inventories_exact': {f: len(after[f]) for f in sorted(PHYSICAL)},
                     'constant_outputs_exact_except_bel': True, 'static_sink_clock_value_contracts_exact': True,
                     'changed_static_chains': sum(before['static_endpoints'][k] != after['static_endpoints'][k]
                                                  for k in before['static_endpoints']),
                     'physical_difference_counts': {f: len(d) for f, d in physical.items()},
                     'negative_checks': negative_checks(before),
                     'limits': ['Unsupported-detail physical driver/pin-map records differ and remain fully retained.',
                                'Fresh route-through inventories differ; whole routed graph and emitted masks are not proven equivalent.',
                                'No primitive-clock margins, complete IO signoff, seed qualification or hardware acceptance.']})
        placed_cells = read(ROOT / ('prepare-' + label) / 'placed.json')['modules']['top']['cells']
        routed_cells = read(folder / 'routed.json')['modules']['top']['cells']
        ram_names = {n for n, c in placed_cells.items() if c['type'] == 'MISTRAL_M10K'}
        require(len(ram_names) == 318 and ram_names == {n for n, c in routed_cells.items() if c['type'] == 'MISTRAL_M10K'},
                'Final RAM inventory changed')
        require(all(placed_cells[n]['attributes']['NEXTPNR_BEL'] == routed_cells[n]['attributes']['NEXTPNR_BEL']
                    for n in ram_names), 'Final RAM locations differ from corresponding placement diagnostic')
        rom_names = [v['cell'] for v in placement['cases'][label]['geometry']['groups']['microcode']['final_cells']]
        case['all_318_ram_bels_match_corresponding_placement'] = True
        case['final_microcode_rom_columns'] = Counter(int(routed_cells[n]['attributes']['NEXTPNR_BEL'].split('.')[1])
                                                      for n in rom_names)
        result['cases'][label] = case
    result['charged_seconds'] = str(sum(charges, Decimal(0)))
    result['cumulative_through_density'] = str(Decimal(result['prior_completed_total_including_swaps']) + sum(charges, Decimal(0)))
    result['charge_basis'] = 'Each recorded route subprocess elapsed time, including phase-lease waits; no external route budget cap.'
    result['status'] = 'proof-passed-all-candidates-rejected'
    save('final-proof.json', result)
    print(json.dumps({k: result[k] for k in ['status', 'charged_seconds', 'cumulative_through_density']}, indent=2))


if __name__ == '__main__':
    main()
