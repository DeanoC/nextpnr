from pathlib import Path
from collections import Counter
from decimal import Decimal
import hashlib,json
root=Path(__file__).resolve().parent
reference=root.parent/'spreader-correction-20261022'

def digest(path):return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
def row_map(snapshot):
 result={}
 for key,rows in snapshot['endpoints'].items():
  for row in rows:
   ident=(key,tuple(row['launch']),tuple(row['capture']))
   assert ident not in result
   result[ident]=row
 return result

def margins(rows):
 groups={}
 for key,row in rows.items():
  group=json.dumps([row['launch'],row['capture'],row.get('setup_window')])
  g=groups.setdefault(group,{'rows':0,'setup_failures':0,'hold_failures':0,'setup_wns_ps':None,'hold_wns_ps':None})
  g['rows']+=1
  for field,active in [('setup','setup_timed'),('hold','hold_related')]:
   if row.get(active):
    value=row[field];g[field+'_failures']+=value<0
    old=g[field+'_wns_ps'];g[field+'_wns_ps']=value if old is None else min(old,value)
 return groups

results={};charges=[]
for label,ref in [('beta075','route-enabled'),('beta090','route-enabled'),('overflow075','route-overflow17'),('overflow090','route-overflow17')]:
 directory=root/('route-'+label)
 receipt=json.loads((directory/'receipt.json').read_text());charges.append(Decimal(str(receipt['charged_seconds'])))
 for name,sha in receipt['artifacts'].items():assert digest(directory/name)==sha,(label,name)
 assert digest(Path(receipt['nextpnr_command'][0]))==receipt['binary_sha256']
 result={'returncode':receipt['returncode'],'charged_seconds':str(charges[-1]),'receipt_sha256':digest(directory/'receipt.json'),'receipt_artifacts_verified':True,'final_route_present':(directory/'endpoints.json').exists(),'reference':str(reference/ref)}
 if not result['final_route_present']:
  assert receipt['returncode']!=0
  result['failure_log_tail']=(directory/'nextpnr.log').read_text().splitlines()[-5:]
  results[label]=result;continue
 ep=json.loads((directory/'endpoints.json').read_text());base=json.loads((reference/ref/'endpoints.json').read_text())
 rows=row_map(ep);before=row_map(base);assert rows.keys()==before.keys()
 invariants=['clocks','schema','complete','io_constraints','output_contracts','registered_contracts','unregistered_contracts','reset_contracts','forwarded_clocks','primitive_clocks','physical_obligations','unsupported']
 for field in invariants:assert ep[field]==base[field],(label,field)
 physical={field:{'identical':ep[field]==base[field],'reference_sha256':hashlib.sha256(json.dumps(base[field],sort_keys=True).encode()).hexdigest(),'candidate_sha256':hashlib.sha256(json.dumps(ep[field],sort_keys=True).encode()).hexdigest()} for field in ['constant_outputs','static_endpoints','unsupported_details']}
 changes={'setup':Counter(),'hold':Counter()}
 for key,row in rows.items():
  old=before[key]
  for field in ['setup_timed','hold_related','setup_window']:assert row.get(field)==old.get(field),(label,key,field)
  for field,active in [('setup','setup_timed'),('hold','hold_related')]:
   if row.get(active):
    delta=row[field]-old[field];changes[field]['improved' if delta>0 else 'regressed' if delta<0 else 'unchanged']+=1
 result.update({'endpoint_rows':len(rows),'complete_timing_identity_and_window_match':True,'unchanged_contracts':invariants,'physical_records':physical,'groups':margins(rows),'reference_groups':margins(before),'margin_changes':changes,'unsupported':len(ep['unsupported']),'final_native_summary':json.loads((directory/'timing.json').read_text())['timing_summary'],'final_graph_equivalence':'not established; fresh placement changes helper inventories; complete raw artifacts retained'})
 results[label]=result
out={'evidence':'host-only fresh placement/route diagnostic; no acceptance','results':results,'charged_seconds':str(sum(charges,Decimal(0))),'prior_completed_total_including_swaps':'15783.49161636922436','cumulative_through_density':str(Decimal('15783.49161636922436')+sum(charges,Decimal(0))),'total_route_cap':None}
(root/'route-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for label,result in results.items():
 print(label,result['returncode'],result['charged_seconds'],result.get('final_native_summary',result.get('failure_log_tail')))
print('density charge',out['charged_seconds'],'cumulative',out['cumulative_through_density'])
