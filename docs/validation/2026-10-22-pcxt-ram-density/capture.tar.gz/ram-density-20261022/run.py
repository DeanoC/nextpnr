from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,sys,time

root=Path(__file__).resolve().parent
task=root.parents[1]
old=root.parent/'reduction-balanced-20261022'
fixed=root.parent/'spreader-correction-20261022'
identity=json.loads((fixed/'source-identity.json').read_text())
route='--route' in sys.argv
cases=[('beta075','baseline','0.75'),('beta090','baseline','0.90'),
       ('overflow075','overflow17','0.75'),('overflow090','overflow17','0.90')]
if route and len(sys.argv)>2:cases=[case for case in cases if case[0] in sys.argv[2:]]

def run(label,source,beta):
    parent=json.loads((old/('route-'+source)/'receipt.json').read_text())
    command=parent['nextpnr_command'][:];command[0]=str(fixed/'nextpnr-mistral')
    command+=['--placer-heap-correct-spread','--placer-heap-beta',beta]
    if not route:
        for flag in ['--rbf','--routed-endpoints']:
            at=command.index(flag);del command[at:at+2]
        command.remove('--compress-rbf');command+=['--no-route','--debug-placer']
        command[command.index('--write')+1]='placed.json'
        command[command.index('--report')+1]='predicted-timing.json'
    wrapped=([str(task/'scripts/gpu-run'),'--phase-lease','--owner','pcxt-timing',
              '--label','pcxt-density-'+label,'--',*command] if route else command)
    directory=root/(('route-' if route else 'prepare-')+label);directory.mkdir(exist_ok=False)
    receipt={'command':wrapped,'nextpnr_command':command,'beta':beta,'selected_roots':parent['selected_roots'],
             'source_identity':identity,'binary_sha256':identity['binary_sha256'],
             'evidence':'leased GPU full-route host diagnostic' if route else 'CPU-only placement diagnostic',
             'limit':'native bounded router iterations; no external GPU-job termination'}
    assert hashlib.file_digest(open(command[0],'rb'),'sha256').hexdigest()==receipt['binary_sha256']
    env=dict(os.environ)
    if route:env['NEXTPNR_REQUIRE_GPU']='1'
    start=time.monotonic()
    with (directory/'nextpnr.log').open('w') as log:
        receipt['returncode']=subprocess.run(wrapped,cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    receipt['elapsed_seconds']=time.monotonic()-start
    receipt['charged_seconds']=receipt['elapsed_seconds'] if route else 0
    receipt['artifacts']={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in directory.iterdir() if p.suffix in ['.json','.rbf']}
    (directory/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(label,receipt['returncode'],receipt['elapsed_seconds'],flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures=[pool.submit(run,*case) for case in cases]
    for future in futures:future.result()
