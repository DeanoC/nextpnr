#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,time
R=Path(__file__).resolve().parent
routes={'baseline':R.parent/'hard-block-windows-20261022/route-windows-correct-overflow','arrival':R/'arrival'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for mode,route in routes.items():
 ref=json.loads((route/'receipt.json').read_text());cmd=ref['nextpnr_command'][:];expected=ref['binary_sha256'];assert sha(Path(cmd[0]))==expected
 for opt in ('--rbf','--compress-rbf','--routed-endpoints'):
  i=cmd.index(opt);del cmd[i:i+(1 if opt=='--compress-rbf' else 2)]
 cmd+=['--no-route'];cmd[cmd.index('--write')+1]='placed.json';cmd[cmd.index('--report')+1]='predicted-timing.json';folder=R/('prepare-'+mode);folder.mkdir(exist_ok=False)
 start=time.monotonic()
 with (folder/'nextpnr.log').open('w') as log:proc=subprocess.run(cmd,cwd=folder,stdout=log,stderr=subprocess.STDOUT)
 rec={'command':cmd,'binary_sha256':expected,'binary_unchanged':sha(Path(cmd[0]))==expected,'route_receipt_sha256':sha(route/'receipt.json'),'inputs':ref['inputs'],'returncode':proc.returncode,'elapsed_seconds':time.monotonic()-start,'evidence':'fresh CPU pack/place reconstruction only, no route','artifacts':{n:sha(folder/n) for n in ('placed.json','predicted-timing.json','nextpnr.log') if (folder/n).exists()}}
 (folder/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(mode,proc.returncode,flush=True);assert proc.returncode==0
