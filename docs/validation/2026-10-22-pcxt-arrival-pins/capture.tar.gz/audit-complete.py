#!/usr/bin/env python3
"""Offline-compatible complete endpoint and detailed-path comparison."""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json
R=Path(__file__).resolve().parent
B=R/'reference-baseline' if (R/'reference-baseline').exists() else R.parent/'hard-block-windows-20261022/route-windows-correct-overflow'
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def rows(s):
 d={}
 for ident,values in s['endpoints'].items():
  for v in values:
   k=(ident,tuple(v['launch']),tuple(v['capture']));assert k not in d;d[k]=v
 return d
runs={};snaps={};rr={}
for mode,folder in [('baseline',B),('arrival',R/'arrival')]:
 rec=read(folder/'receipt.json');assert rec['returncode']==1
 for n,h in rec['artifacts'].items():assert sha(folder/n)==h
 s=read(folder/'endpoints.json');t=read(folder/'timing.json');assert s['final_analogue'] and t['timing_summary']['final_analogue_model'];snaps[mode]=s;rr[mode]=rows(s)
 cohorts=defaultdict(list)
 for k,v in rr[mode].items():cohorts[k[1:]].append((k[0],v))
 def metric(seq):
  seq=list(seq);d={'rows':len(seq)}
  for m,f in [('setup','setup_timed'),('hold','hold_related')]:
   vals=[v[m] for v in seq if v[f]];d[m+'_wns_ps']=min(vals,default=None);d[m+'_failures']=sum(v<0 for v in vals)
  return d
 def paths(cpu):
  ps=[p for p in t['critical_paths'] if p['from']==p['to']=='posedge clocks[0]' and (not cpu or p['path'][-1]['to']['cell'].startswith('system.machine.cpu.'))]
  out=[]
  for p in sorted(ps,key=lambda p:p['max_delay']-sum(s['delay'] for s in p['path']))[:5]:
   start=next(s['from'] for s in p['path'] if s['type']=='clk-to-q');end=p['path'][-1]['to'];totals=defaultdict(float)
   for seg in p['path']:totals[seg['type']]+=seg['delay']
   out.append({'launch':start,'capture':end,'reported_max_delay_ns':p['max_delay'],'recomputed_slack_ns':p['max_delay']-sum(s['delay'] for s in p['path']),'segment_sum_ns':dict(totals),'complete_path':p})
  return out
 runs[mode]={'receipt_sha256':sha(folder/'receipt.json'),'artifact_sha256':rec['artifacts'],'binary_sha256':rec['binary_sha256'],'returncode':rec['returncode'],'schema':s['schema'],'complete':s['complete'],'unsupported_count':len(s['unsupported']),**metric(rr[mode].values()),'clock_pairs':[{'launch':k[0],'capture':k[1],**metric(v for _,v in vals),'cpu_destinations':metric(v for ident,v in vals if json.loads(ident)[0].startswith('system.machine.cpu.'))} for k,vals in sorted(cohorts.items())],'worst_cpu_system_paths':paths(True),'worst_whole_system_paths':paths(False)}
a,b=rr['baseline'],rr['arrival'];assert set(a)==set(b)
changes=[];counts={};cohort_deltas=defaultdict(lambda:defaultdict(Counter))
for k,x in sorted(a.items()):
 y=b[k];assert {p:v for p,v in x.items() if p not in ('setup','hold','min_path','max_path')}=={p:v for p,v in y.items() if p not in ('setup','hold','min_path','max_path')}
 row={'identity':json.loads(k[0]),'launch':k[1],'capture':k[2],'baseline':x,'arrival':y,'delta_ps':{m:(y[m]-x[m] if y[m] is not None and x[m] is not None else None) for m in ('setup','hold','min_path','max_path')}};changes.append(row)
 for m,f in [('setup','setup_timed'),('hold','hold_related')]:
  if x[f]:
   d=y[m]-x[m];cohort_deltas[k[1:]][m]['improved' if d>0 else 'regressed' if d<0 else 'unchanged']+=1
for m,f in [('setup','setup_timed'),('hold','hold_related')]:
 vals=[y[m]-a[k][m] for k,y in b.items() if y[f]];counts[m]={'rows':len(vals),'improved':sum(d>0 for d in vals),'regressed':sum(d<0 for d in vals),'unchanged':sum(d==0 for d in vals),'largest_improvement_ps':max(vals),'largest_regression_ps':min(vals)}
contracts={}
for key in ('clocks','forwarded_clocks','io_constraints','output_contracts','physical_obligations','primitive_clocks','registered_contracts','reset_contracts','unregistered_contracts','unsupported'):
 x,y=snaps['baseline'][key],snaps['arrival'][key];assert x==y,key;contracts[key]={'equal':True,'baseline':x,'arrival':y}
other={key:{'equal':snaps['baseline'][key]==snaps['arrival'][key],'baseline':snaps['baseline'][key],'arrival':snaps['arrival'][key]} for key in ('constant_outputs','static_endpoints','unsupported_details')}
result={'status':'pass','meaning':'Complete comparison performed; both routes fail timing and coverage remains incomplete.','runs':runs,'exact_endpoint_identity_windows_flags_equal':True,'all_endpoint_rows':len(a),'margin_delta_counts':counts,'clock_pair_delta_counts':[{'launch':k[0],'capture':k[1],'delta_counts':v} for k,v in sorted(cohort_deltas.items())],'complete_contract_records':contracts,'other_complete_records':other,'every_endpoint_delta':changes,'new_route_charge_seconds':'212.69421951379627','reference_route_already_charged':True,'limits':['All endpoint rows and contract records retained, with no graph/report intersection used as acceptance.','Detailed paths are bounded report evidence (1024 per requested group), not the complete endpoint inventory.','No electrical route/RBF encoding, physical margin, complete coverage or hardware signoff.']}
(R/'complete-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'pass','rows':len(a),'margin_delta_counts':counts,'other_record_equality':{k:v['equal'] for k,v in other.items()},'worst_cpu':{m:r['worst_cpu_system_paths'][0] for m,r in runs.items()}},indent=2))
