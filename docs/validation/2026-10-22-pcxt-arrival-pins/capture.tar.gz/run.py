#!/usr/bin/env python3
"""One arrival-aware pin-assignment comparison on the best fixed recipe."""
from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time

ROOT = Path(__file__).resolve().parent
TASK = ROOT.parent.parent
BASE = ROOT.parent / 'hard-block-windows-20261022/route-windows-correct-overflow'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def run(seed):
    baseline = json.loads((BASE / 'receipt.json').read_text())
    command = baseline['nextpnr_command'][:]
    assert command[command.index('--seed') + 1] == '1'
    assert seed == 1
    command += ['--arrival-pin-assignment']
    assert sha(Path(command[0])) == baseline['binary_sha256']
    for info in baseline['inputs'].values():
        assert sha(Path(info['path'])) == info['sha256']
    target = ROOT / 'arrival'
    target.mkdir(exist_ok=False)
    wrapped = [str(TASK / 'scripts/gpu-run'), '--phase-lease', '--owner',
               'pcxt-timing', '--label', 'pcxt-hard-block-arrival-pins', '--', *command]
    receipt = {
        'command': wrapped, 'nextpnr_command': command, 'seed': seed,
        'source_identity': baseline['source_identity'],
        'binary_sha256': baseline['binary_sha256'], 'inputs': baseline['inputs'],
        'seed1_receipt_sha256': sha(BASE / 'receipt.json'),
        'changed_recipe': 'only --arrival-pin-assignment added',
        'env': {'NEXTPNR_REQUIRE_GPU': '1', 'GPU_LEASE_MAX_PER_OWNER': '2'},
        'limit': 'native router iterations; no external GPU-job termination',
        'evidence': 'fixed-recipe leased GPU diagnostic; no seal or hardware acceptance',
    }
    start = time.monotonic()
    with (target / 'nextpnr.log').open('w') as log:
        receipt['returncode'] = subprocess.run(
            wrapped, cwd=target, env=dict(os.environ, **receipt['env']),
            stdout=log, stderr=subprocess.STDOUT).returncode
    receipt['charged_seconds'] = time.monotonic() - start
    for info in receipt['inputs'].values():
        assert sha(Path(info['path'])) == info['sha256']
    assert sha(Path(command[0])) == receipt['binary_sha256']
    receipt['artifacts'] = {p.name: sha(p) for p in sorted(target.iterdir()) if p.is_file()}
    (target / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(seed, receipt['returncode'], receipt['charged_seconds'], flush=True)


if __name__ == '__main__':
    run(1)
