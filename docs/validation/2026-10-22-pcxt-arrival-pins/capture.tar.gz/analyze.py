#!/usr/bin/env python3
"""Read complete native reports for the arrival-pin comparison; run2 is arrival pins, not another seed."""
from collections import defaultdict
from decimal import Decimal
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'hard-block-windows-20261022'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def rows(snapshot):
    result = {}
    for identity, values in snapshot['endpoints'].items():
        assert len(json.loads(identity)) == 2
        for value in values:
            key = (identity, tuple(value['launch']), tuple(value['capture']))
            assert key not in result
            result[key] = value
    return result


def metrics(values):
    values = list(values)
    result = {'rows': len(values)}
    for metric, flag in [('setup', 'setup_timed'), ('hold', 'hold_related')]:
        margins = [v[metric] for v in values if v[flag]]
        result[metric + '_wns_ps'] = min(margins, default=None)
        result[metric + '_failures'] = sum(v < 0 for v in margins)
    return result


result = {'evidence': 'Complete final native timing reports; no timing qualification or hardware acceptance.',
          'runs': {}, 'comparisons': {}}
snaps = {}
inventories = {}
receipts = {}
charge = Decimal(0)
for seed in (1, 2):
    folder = BASE / 'route-windows-correct-overflow' if seed == 1 else ROOT / 'arrival'
    rec = read(folder / 'receipt.json')
    receipts[seed] = rec
    for name, digest in rec['artifacts'].items():
        assert sha(folder / name) == digest, (seed, name)
    for item in rec['inputs'].values():
        assert sha(Path(item['path'])) == item['sha256']
    if seed != 1:
        command = rec['nextpnr_command'][:]
        command.remove('--arrival-pin-assignment')
        assert command == receipts[1]['nextpnr_command']
        assert rec['inputs'] == receipts[1]['inputs']
        assert rec['binary_sha256'] == receipts[1]['binary_sha256']
        assert rec['seed1_receipt_sha256'] == sha(BASE / 'route-windows-correct-overflow/receipt.json')
        charge += Decimal(str(rec['charged_seconds']))
    timing, snapshot = read(folder / 'timing.json'), read(folder / 'endpoints.json')
    assert timing['timing_summary']['final_analogue_model'] and snapshot['final_analogue']
    rr = rows(snapshot)
    snaps[seed], inventories[seed] = snapshot, rr
    pairs = defaultdict(list)
    for key, value in rr.items():
        pairs[key[1:]].append((key[0], value))
    pair_rows = []
    for (launch, capture), values in sorted(pairs.items()):
        pair_rows.append({'launch': launch, 'capture': capture,
                          **metrics(v for _, v in values),
                          'cpu_destinations': metrics(v for key, v in values
                                                     if json.loads(key)[0].startswith('system.machine.cpu.'))})
    result['runs'][str(seed)] = {'returncode': rec['returncode'], 'receipt_sha256': sha(folder / 'receipt.json'),
                                'artifacts': rec['artifacts'], 'charged_seconds': str(rec['charged_seconds']),
                                'clocks': timing['timing_summary']['clocks'], 'clock_pairs': pair_rows,
                                'schema': snapshot['schema'], 'complete': snapshot['complete'],
                                'unsupported_count': len(snapshot['unsupported']), **metrics(rr.values())}
    if seed != 1:
        before = inventories[1]
        assert set(rr) == set(before), 'Complete endpoint identity inventory differs'
        changed = [key for key in rr if {k:v for k,v in rr[key].items() if k not in ('setup','hold','min_path','max_path')} !=
                   {k:v for k,v in before[key].items() if k not in ('setup','hold','min_path','max_path')}]
        assert not changed, 'Native windows/flags changed'
        metadata = {}
        for key in ['clocks', 'forwarded_clocks', 'io_constraints', 'output_contracts', 'physical_obligations',
                    'primitive_clocks', 'registered_contracts', 'reset_contracts', 'unregistered_contracts', 'unsupported']:
            metadata[key] = {'equal': snaps[1][key] == snapshot[key],
                             'baseline': snaps[1][key], 'candidate': snapshot[key]}
        result['comparisons'][str(seed)] = {'all_endpoint_identities_windows_and_flags_equal': True,
                                          'rows': len(rr), 'contract_records': metadata,
                                          'physical_details': 'Complete constant, static and unsupported-detail records retained in each artifact; not treated as physically equivalent.'}
result['accounting'] = {'new_arrival_pin_route_seconds': str(charge), 'seed_1_already_charged': True,
                        'route_cap': None}
result['conclusion'] = 'The baseline and arrival-pin candidate are separate complete recipes; inspect their full margins. Neither partial timing nor matched unsupported rows establishes qualification. No common-only endpoint subset, waived coverage, whole-graph equivalence, electrical signoff or hardware acceptance is claimed.'
(ROOT / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'runs': {k:{f:v for f,v in x.items() if f in ['setup_failures','setup_wns_ps','hold_failures','unsupported_count','clock_pairs']} for k,x in result['runs'].items()}, 'accounting': result['accounting']}, indent=2))
