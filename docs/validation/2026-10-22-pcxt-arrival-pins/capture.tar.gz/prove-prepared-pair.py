#!/usr/bin/env python3
"""Compare the entire fresh placed graph; only the explicit arrival flag may differ."""
from pathlib import Path
import copy, importlib.util, json
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('support',R/'proof-routed-support.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
def prove(ad,bd):
 s.require(set(ad)==set(bd)=={'creator','modules'},'document schema')
 s.require(ad['creator']==bd['creator'],'creator changed')
 s.require(set(ad['modules'])==set(bd['modules'])=={'top'},'module inventory')
 a,b=ad['modules']['top'],bd['modules']['top']
 s.require(set(a)==set(b)=={'settings','attributes','ports','cells','netnames'},'module schema')
 s.require(a['attributes']==b['attributes'],'module attributes changed')
 s.require(a['attributes']['step']=='place','not placed')
 settings=dict(b['settings']);s.require(settings.pop('mistral/arrival_pin_assignment')=='1','arrival option missing')
 s.require(settings==a['settings'],'other compiler settings changed')
 s.require(set(a['netnames'])==set(b['netnames']),'complete alias inventory changed')
 fwd,rev={},{}
 for n in a['netnames']:
  x,y=a['netnames'][n],b['netnames'][n]
  s.require(set(x)==set(y)=={'hide_name','bits','attributes'},'net schema')
  s.require(x['hide_name']==y['hide_name'] and x['attributes']==y['attributes'],f'{n}: net metadata')
  s.require(len(x['bits'])==len(y['bits']),f'{n}: width')
  for old,new in zip(x['bits'],y['bits']):
   s.require(type(old)==type(new),f'{n}: signal kind')
   if type(old)==int:
    s.require(fwd.get(old,new)==new and rev.get(new,old)==old,f'{n}: alias merge/split')
    fwd[old]=new;rev[new]=old
   else:s.require(old==new and old in ('0','1','x','z'),f'{n}: literal')
 def normalize(bits,candidate):
  out=[]
  for bit in bits:
   if type(bit)==int:
    s.require(bit in (rev if candidate else fwd),'unnamed signal')
    out.append(rev[bit] if candidate else bit)
   else:s.require(bit in ('0','1','x','z'),'unknown literal');out.append(bit)
  return out
 s.require(set(a['ports'])==set(b['ports']),'top port inventory')
 for n in a['ports']:
  x,y=a['ports'][n],b['ports'][n]
  s.require(set(x)==set(y)=={'direction','bits'},'top port schema')
  s.require(x['direction']==y['direction'] and normalize(x['bits'],False)==normalize(y['bits'],True),f'{n}: top port changed')
 s.require(set(a['cells'])==set(b['cells']),'complete cell inventory')
 pins=0
 for n,x in a['cells'].items():
  y=b['cells'][n]
  s.require(set(x)==set(y)=={'hide_name','type','parameters','attributes','port_directions','connections'},f'{n}: cell schema')
  for k in ('hide_name','type','parameters','attributes','port_directions'):s.require(x[k]==y[k],f'{n}: {k} changed')
  s.require(set(x['connections'])==set(y['connections'])==set(x['port_directions']),f'{n}: pin inventory')
  for p,old in x['connections'].items():
   s.require(normalize(old,False)==normalize(y['connections'][p],True),f'{n}.{p}: logical connection changed')
   pins+=len(old)
  s.require(s.pinmap(x,n)==s.pinmap(y,n),f'{n}: physical/logical pin map changed')
 return {'cells':len(a['cells']),'named_nets_and_aliases':len(a['netnames']),'signal_bijection_size':len(fwd),'top_ports':len(a['ports']),'connected_pin_bits':pins,'all_cell_types_parameters_metadata_connections_equal':True,'all_alias_classes_net_metadata_top_ports_equal':True,'all_placed_bels_and_physical_and_logical_pin_maps_equal':True,'all_module_attributes_equal':True,'only_setting_delta':{'mistral/arrival_pin_assignment':[None,'1']}}
a,b=[s.read(R/f'prepare-{m}/placed.json') for m in ('baseline','arrival')];result=prove(a,b);negative=[]
def reject(label,mutation):
 c=copy.deepcopy(b);mutation(c['modules']['top'])
 try:prove(a,c)
 except (ValueError,AssertionError,KeyError) as e:negative.append({'mutation':label,'rejected':True,'reason':str(e)})
 else:raise AssertionError('accepted mutation '+label)
n=next(n for n,c in b['modules']['top']['cells'].items() if c['type']=='MISTRAL_ALUT6')
def truth(m):
 v=m['cells'][n]['parameters']['LUT'];m['cells'][n]['parameters']['LUT']=('1' if v[0]=='0' else '0')+v[1:]
reject('LUT function bit',truth)
reject('extra public net alias',lambda m:m['netnames'].update({'unexpected_public_alias':copy.deepcopy(next(iter(m['netnames'].values())))}))
def pin(m):
 p=s.unpack(m['cells'][n]['attributes']['FES_PINMAP_V1']);p['pins']['A'][0]^=3;m['cells'][n]['attributes']['FES_PINMAP_V1']=s.pack(p)
reject('input logical polarity',pin)
result={'status':'pass','comparison':result,'negative_mutations':negative,'prepared_sha256':{m:s.digest(R/f'prepare-{m}/placed.json') for m in ('baseline','arrival')},'checker_sha256':s.digest(Path(__file__)),'limits':'Complete prepared graph identity modulo net numbering and the explicit option; separate final-route bridges account for every route helper and logical pin state. This does not prove electrical routing, RBF/LAB encoding, timing signoff, or hardware acceptance.'}
(R/'prepared-pair-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
