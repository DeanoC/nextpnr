#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil
R=Path(__file__).resolve().parent;H=R.parent/'hard-block-windows-20261022';D=R/'capture-source';D.mkdir(exist_ok=False);copies={}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def cp(src,name):
 dst=D/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert sha(src)==sha(dst);copies[str(name)]={'source':str(src),'sha256':sha(dst),'size':dst.stat().st_size}
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in ('.py','.md','.json','.log'):cp(p,Path(p.name))
for folder in ('arrival','prepare-baseline','prepare-arrival','option-source'):
 for p in sorted((R/folder).rglob('*')):
  if p.is_file():cp(p,p.relative_to(R))
for p in sorted((H/'route-windows-correct-overflow').iterdir()):
 if p.is_file():cp(p,Path('reference-baseline')/p.name)
rec=json.loads((R/'arrival/receipt.json').read_text())
for item in rec['inputs'].values():
 p=Path(item['path']);assert sha(p)==item['sha256'];cp(p,Path('inputs')/p.name)
cp(R.parent/'reduction-balanced-20261022/inputs/manifest.json',Path('inputs/original-provenance.json'))
assert sha(H/'nextpnr-mistral')==rec['binary_sha256']
for name in ('source-identity.json','hard-block-source.diff','hard-block-native-frozen.log','hard-block-build-frozen.log','hard-block-ctest.log'):
 cp(H/name,Path('compiler-source')/name)
for p in sorted((H/'sources').rglob('*')):
 if p.is_file():
  name=str(p.relative_to(H/'sources'));assert sha(p)==rec['source_identity']['source_files'][name];cp(p,Path('compiler-source/sources')/name)
cp(Path('/tmp/pcxt-capture.py'),Path('capture.py'))
(D/'collection.json').write_text(json.dumps({'files':len(copies),'copies':copies,'scope':'Original full reference and arrival-only routes, same-recipe fresh CPU-only placed reconstructions, complete per-artifact graph/helper proofs, exact endpoint comparison, frozen source and input bindings. No new full route, compiler/source change or hardware.'},indent=2)+'\n');print('collected',len(copies),'files')
