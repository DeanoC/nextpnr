#!/usr/bin/env python3
"""Fresh CPU-only default/list/explicit selected private-pair preparations."""
from pathlib import Path
import argparse
import concurrent.futures
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT.parent / 'post-route-checkpoint-20261022/prepare-default'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def run(case, selection=None):
    prior = json.loads((REFERENCE / 'receipt.json').read_text())
    identity = json.loads((ROOT / 'source-identity.json').read_text())
    command = prior['nextpnr_command'][:]
    command[0] = str(ROOT / 'nextpnr-mistral')
    inputs = prior['inputs'].copy()
    if case != 'default':
        report = REFERENCE / 'predicted-timing.json'
        command += ['--remap-private-pair-critical', str(report)]
        inputs['--remap-private-pair-critical'] = {'path': str(report), 'sha256': sha(report)}
    if selection is not None:
        command += ['--remap-private-pair-candidate', str(selection)]
    assert '--no-route' in command and '--rbf' not in command
    assert sha(command[0]) == identity['binary_sha256']
    for item in inputs.values():
        assert sha(item['path']) == item['sha256']
    target = ROOT / ('prepare-' + case)
    target.mkdir(exist_ok=False)
    receipt = {'nextpnr_command': command, 'source_identity': identity,
               'inputs': inputs, 'binary_sha256': identity['binary_sha256'],
               'scope': 'CPU-only fresh placement, not routed qualification', 'charged_seconds': 0,
               'reference_receipt': str(REFERENCE / 'receipt.json'),
               'reference_receipt_sha256': sha(REFERENCE / 'receipt.json')}
    start = time.monotonic()
    with (target / 'nextpnr.log').open('w') as log:
        receipt['returncode'] = subprocess.run(command, cwd=target, stdout=log,
                                               stderr=subprocess.STDOUT).returncode
    receipt['elapsed_seconds'] = time.monotonic() - start
    assert sha(command[0]) == identity['binary_sha256']
    for item in inputs.values():
        assert sha(item['path']) == item['sha256']
    receipt['artifacts'] = {path.name: sha(path) for path in target.iterdir() if path.is_file()}
    (target / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(case, receipt['returncode'], receipt['elapsed_seconds'], flush=True)
    assert receipt['returncode'] == 0

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--selection', type=int)
    options = parser.parse_args()
    if options.selection is None:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(run, ['default', 'list']))
    else:
        assert options.selection >= 0
        run('selected-' + str(options.selection), options.selection)
