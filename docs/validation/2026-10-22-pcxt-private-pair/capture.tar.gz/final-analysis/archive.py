#!/usr/bin/env python3
"""Self-contained diagnostic evidence, excluding the executable and object trees."""
from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,sys,tarfile,tempfile
R=Path(__file__).resolve().parent;ROOT=R.parent;CAPTURE=ROOT/'capture';SOURCE=CAPTURE/'source'
def need(value,message):
 if not value:raise ValueError(message)
def sha(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def main():
 need(not CAPTURE.exists(),'capture already exists; immutable result must not be overwritten')
 need(read(R/'graph-proof.json')['status']=='pass','complete logical graph proof missing')
 need(read(R/'route-comparison.json')['status']=='complete_comparison','complete final timing comparison missing')
 excluded={'capture','nextpnr-mistral','__pycache__'}
 SOURCE.mkdir(parents=True)
 for p in sorted(ROOT.iterdir()):
  if p.name in excluded:continue
  target=SOURCE/p.name
  if p.is_dir():shutil.copytree(p,target,ignore=shutil.ignore_patterns('__pycache__'))
  elif p.is_file():shutil.copy2(p,target)
 receipts=[read(ROOT/n/'receipt.json') for n in ['prepare-default','prepare-list','prepare-selected-0','route-default','route-selected-0']]
 external={};inputs=SOURCE/'external-inputs';inputs.mkdir()
 for receipt in receipts:
  for info in receipt['inputs'].values():
   path=Path(info['path']);need(sha(path)==info['sha256'],'external input digest')
   retained=Path('external-inputs')/(info['sha256']+'-'+path.name)
   if not (SOURCE/retained).exists():shutil.copy2(path,SOURCE/retained)
   value={'sha256':info['sha256'],'retained_path':str(retained)}
   need(info['path'] not in external or external[info['path']]==value,'conflicting input identity')
   external[info['path']]=value
 references=SOURCE/'references';references.mkdir()
 prior=ROOT.parent/'post-route-checkpoint-20261022/route-only';shutil.copytree(prior,references/'prior-fixed-route')
 for label in ['prepare-default','prepare-explicit-zero']:
  p=ROOT.parent/'post-route-checkpoint-20261022'/label
  shutil.copytree(p,references/('prior-'+label))
 (SOURCE/'archive-mode.json').write_text(json.dumps({'scope':'Offline replay of immutable captured graph and native reports; executable intentionally omitted, no route rerun.',
    'excluded_binary_sha256':receipts[0]['binary_sha256'],'external_inputs':external,
    'excluded_binary_reason':'643 MiB executable is bound by SHA256; exact committed sources and source verification are retained.'},indent=2)+'\n')
 files=[p for p in sorted(SOURCE.rglob('*')) if p.is_file()]
 manifest={str(p.relative_to(SOURCE)):{'sha256':sha(p),'size':p.stat().st_size} for p in files}
 manifest_data=(json.dumps(manifest,indent=2)+'\n').encode();(SOURCE/'manifest.json').write_bytes(manifest_data)
 archive=CAPTURE/'capture.tar.gz'
 with archive.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,compresslevel=6) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tar:
  for p in files:
   info=tar.gettarinfo(str(p),arcname=str(p.relative_to(SOURCE)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
   with p.open('rb') as source:tar.addfile(info,source)
  info=tarfile.TarInfo('manifest.json');info.size=len(manifest_data);info.mtime=0;tar.addfile(info,io.BytesIO(manifest_data))
 with tarfile.open(archive,'r:gz') as tar:
  need(set(tar.getnames())==set(manifest)|{'manifest.json'},'archive member inventory')
  for name,identity in manifest.items():
   payload=tar.extractfile(name).read();need(len(payload)==identity['size'] and hashlib.sha256(payload).hexdigest()==identity['sha256'],'archive readback '+name)
 readback={'status':'pass','archive_sha256':sha(archive),'bytes':archive.stat().st_size,'verified_members':len(manifest)+1,'manifest_sha256':sha(SOURCE/'manifest.json')}
 (CAPTURE/'archive-readback.json').write_text(json.dumps(readback,indent=2)+'\n')
 replay=Path(tempfile.mkdtemp(prefix='pcxt-private-pair-offline-',dir='/tmp'))
 with tarfile.open(archive,'r:gz') as tar:tar.extractall(replay,filter='data')
 outputs=[]
 for script,proof in [('prove-graphs.py','graph-proof.json'),('compare-routes.py','route-comparison.json'),('repair-decisions.py','repair-decisions.json')]:
  expected=(replay/'final-analysis'/proof).read_bytes();command=[sys.executable,str(replay/'final-analysis'/script)]
  completed=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (CAPTURE/('offline-'+script+'.log')).write_text(completed.stdout)
  need(completed.returncode==0,'offline proof failed '+script+'; retained '+str(replay))
  need((replay/'final-analysis'/proof).read_bytes()==expected,'offline proof differs '+proof)
  outputs.append({'script':script,'returncode':completed.returncode,'proof_byte_identical':True})
 result={**readback,'offline_extraction':str(replay),'offline_checks':outputs,
         'offline_scope':'Re-evaluates complete captured graph functions/helpers and all emitted final timing records; it does not reconstruct or rerun the omitted compiler.'}
 (CAPTURE/'offline-readback.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
