#!/usr/bin/env python3
"""Retain every bounded native repair proposal/decision and exact graph binding."""
from pathlib import Path
import collections,hashlib,json,re
R=Path(__file__).resolve().parent;ROOT=R.parent
def need(value,message):
 if not value:raise ValueError(message)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 cases={}
 for case in ['default','selected-0']:
  folder=ROOT/('route-'+case);receipt=json.loads((folder/'receipt.json').read_text())
  for name in ['nextpnr.log','routed.json']:need(sha(folder/name)==receipt['artifacts'][name],'artifact digest')
  module=json.loads((folder/'routed.json').read_text())['modules']['top'];all_lines=[];proposals=[];trials=[];generations=[];generation=None;summary=None
  for line_no,line in enumerate((folder/'nextpnr.log').read_text().splitlines(),1):
   if 'Critical route' in line:all_lines.append({'line':line_no,'text':line})
   m=re.search(r'Critical route generation (\d+): learned observations=(\d+)',line)
   if m:generation=int(m[1]);generations.append({'generation':generation,'learned_observations':int(m[2]),'line':line_no})
   m=re.search(r'Critical route proposal: net (.*?) variant (\d+) native worst-sink gain ([^ ]+) ps',line)
   if m:proposals.append({'generation':generation,'net':m[1],'variant':int(m[2]),'gain_ps':float(m[3]),'line':line_no})
   m=re.search(r'Critical route trial (\d+): net (.*?) variant (\d+) accepted=(\d+)',line)
   if m:trials.append({'generation':generation,'trial':int(m[1]),'net':m[2],'variant':int(m[3]),'accepted':bool(int(m[4])),'line':line_no})
   m=re.search(r'Critical route decision: (.*)',line)
   if m:need(trials and 'decision' not in trials[-1],'unpaired native decision');trials[-1]['decision']=m[1]
   m=re.search(r'Critical route repair: tried=(\d+)/(\d+) kept=(\d+)',line)
   if m:need(summary is None,'duplicate repair summary');summary={'tried':int(m[1]),'budget':int(m[2]),'kept':int(m[3]),'line':line_no}
  need(summary is not None and summary['budget']==32,'missing bounded native repair summary')
  need(summary['tried']==len(trials) and summary['kept']==sum(t['accepted'] for t in trials),'native trial accounting')
  need([t['trial'] for t in trials]==list(range(1,len(trials)+1)),'native trial numbering')
  usages=collections.defaultdict(list);aliases=collections.defaultdict(list)
  for name,c in module['cells'].items():
   for pin,bits in c['connections'].items():
    for lane,bit in enumerate(bits):usages[bit].append({'cell':name,'type':c['type'],'pin':pin,'lane':lane,'direction':c['port_directions'][pin]})
  for name,net in module['netnames'].items():
   for lane,bit in enumerate(net['bits']):aliases[bit].append([name,lane])
  for trial in trials:
   need('decision' in trial,'trial lacks decision reason')
   net=module['netnames'][trial['net']];need(len(net['bits'])==1 and type(net['bits'][0])==int,'trial net identity');bit=net['bits'][0]
   trial['all_matching_proposals']=[p for p in proposals if p['net']==trial['net'] and p['variant']==trial['variant']]
   need(trial['all_matching_proposals'],'trial has no proposal')
   trial['final_graph_binding']={'all_pins':usages[bit],'all_aliases':aliases[bit],
                                 'top_port_observers':[[name,lane] for name,p in module['ports'].items() for lane,b in enumerate(p['bits']) if b==bit],
                                 'complete_net_metadata':net['attributes']}
  cases[case]={'receipt_sha256':sha(folder/'receipt.json'),'all_native_repair_lines':all_lines,'generations':generations,
               'all_proposals':proposals,'all_trials':trials,'summary':summary}
 result={'status':'complete_accounting','checker_sha256':sha(Path(__file__)),'cases':cases,
         'limits':['Native local arc gains are proposal scores; accepted flags and native decision reasons are retained separately.',
                   'Final pair metrics combine the decomposition and the same32-trial repair budget. This ledger does not attribute each margin delta to one proposal.',
                   'Bindings and final saved ROUTING strings are complete serialized records; this script does not validate native physical pip connectivity or RBF masks.']}
 (R/'repair-decisions.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'status':result['status'],'cases':{k:v['summary'] for k,v in cases.items()}},indent=2))
if __name__=='__main__':main()
