#!/usr/bin/env python3
"""Prove each routed chain step and its exact prepared-graph bridge.

This is a Boolean/structural proof. It does not establish RBF encoding, timing,
physical IO margins, sequential equivalence of arbitrary rewrites, or hardware
acceptance. Every cell, named net/alias and top-level port is accounted for.
"""
import argparse
import collections
import copy
import hashlib
import itertools
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f'duplicate JSON key: {key}')
        result[key] = value
    return result


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=unique_object)


def unpack(value):
    return json.loads(bytes.fromhex(value).decode(), object_pairs_hook=unique_object)


def pack(value):
    return json.dumps(value, sort_keys=True).encode().hex()


def pinmap(cell, name):
    payload = unpack(cell['attributes']['FES_PINMAP_V1'])
    require(set(payload) == {'count', 'pins'}, f'{name}: pin-map schema changed')
    pins = payload['pins']
    require(payload['count'] == len(pins), f'{name}: incomplete pin-map count')
    for port, bits in cell['connections'].items():
        # The JSON writer regroups scalar bus ports (for example M10K
        # A1ADDR[0..N]) into one connection vector; the pin snapshot keeps
        # the exact scalar identities. Require every lane, not an overlap.
        logical = [port] if port in pins else [f'{port}[{index}]' for index in range(len(bits))]
        require(logical and all(pin in pins for pin in logical), f'{name}.{port}: missing logical pin state')
        require(len(bits) <= 1 or port not in pins, f'{name}.{port}: ambiguous vector pin state')
    for pin, values in pins.items():
        require(isinstance(values, list) and values and type(values[0]) is int and values[0] in range(4),
                f'{name}.{pin}: invalid pin state')
        require(all(isinstance(value, str) for value in values[1:]), f'{name}.{pin}: invalid physical map')
    return pins


def site(cell):
    match = re.fullmatch(r'MISTRAL_(M?COMB)\.(\d+)\.(\d+)\.(\d+)', cell['attributes']['NEXTPNR_BEL'])
    require(match is not None, 'pair cell is not on a COMB BEL')
    kind, x, y, z = match.groups()
    z = int(z)
    require(z % 6 in (0, 1), 'pair cell is not on a LUT half')
    return int(x), int(y), int(kind == 'MCOMB'), z // 6


def proof(documents, producer, selected_input):
    a_doc, b_doc = documents
    require(set(a_doc) == set(b_doc) == {'creator', 'modules'}, 'root schema changed')
    require(a_doc['creator'] == b_doc['creator'], 'compiler creator label changed')
    require(set(a_doc['modules']) == set(b_doc['modules']) and len(a_doc['modules']) == 1,
            'module inventory changed or is not flat')
    module_name = next(iter(a_doc['modules']))
    modules = [document['modules'][module_name] for document in documents]
    a, b = modules
    require(set(a) == set(b) == {'settings', 'attributes', 'ports', 'cells', 'netnames'}, 'module schema changed')
    require(a['attributes']['step'] == b['attributes']['step'] == 'route', 'requires two final routed netlists')
    require(set(a['cells']) == set(b['cells']), 'complete cell inventory changed')
    require(set(a['netnames']) == set(b['netnames']), 'complete net-name/alias inventory changed')
    require(set(a['ports']) == set(b['ports']), 'top-level port inventory changed')

    # Establish a bijection using EVERY named-net bit, including every alias.
    # A merge or split of alias classes is rejected before examining cells.
    forward, reverse = {}, {}
    labels = collections.defaultdict(list)
    changed_routes = []
    for name in sorted(a['netnames']):
        x, y = a['netnames'][name], b['netnames'][name]
        require(set(x) == set(y) == {'hide_name', 'bits', 'attributes'}, f'{name}: net schema changed')
        require(x['hide_name'] == y['hide_name'], f'{name}: net visibility changed')
        require(len(x['bits']) == len(y['bits']), f'{name}: net width changed')
        for index, (old, new) in enumerate(zip(x['bits'], y['bits'])):
            require(type(old) is type(new), f'{name}[{index}]: signal/constant classification changed')
            if type(old) is int:
                require(old not in forward or forward[old] == new, f'{name}[{index}]: alias split')
                require(new not in reverse or reverse[new] == old, f'{name}[{index}]: alias merge')
                forward[old], reverse[new] = new, old
                labels[old].append((name, index))
            else:
                require(old == new and old in ('0', '1', 'x', 'z'), f'{name}[{index}]: literal changed')
        old_attrs = {key: value for key, value in x['attributes'].items() if key != 'ROUTING'}
        new_attrs = {key: value for key, value in y['attributes'].items() if key != 'ROUTING'}
        require(old_attrs == new_attrs, f'{name}: non-routing net attributes changed')
        if x['attributes'].get('ROUTING') != y['attributes'].get('ROUTING'):
            changed_routes.append(name)

    def normalize(bits, candidate):
        result = []
        for bit in bits:
            if type(bit) is int:
                require(bit in (reverse if candidate else forward), f'unnamed or unknown signal bit {bit}')
                result.append(reverse[bit] if candidate else bit)
            else:
                require(bit in ('0', '1', 'x', 'z'), f'unknown signal literal {bit!r}')
                result.append(bit)
        return result

    connections = []
    pinmaps = []
    for candidate, module in enumerate(modules):
        connections.append({name: {pin: normalize(bits, candidate) for pin, bits in cell['connections'].items()}
                            for name, cell in module['cells'].items()})
        pinmaps.append({name: pinmap(cell, name) for name, cell in module['cells'].items()})
    for name in a['ports']:
        x, y = a['ports'][name], b['ports'][name]
        require(set(x) == set(y) == {'direction', 'bits'}, f'{name}: top-level port schema changed')
        require(x['direction'] == y['direction'] and normalize(x['bits'], False) == normalize(y['bits'], True),
                f'{name}: external port connection changed')

    require(producer in a['cells'], 'selected producer missing')
    links = [connection[producer].get('Q') for connection in connections]
    require(links[0] == links[1] and len(links[0]) == 1 and type(links[0][0]) is int,
            'internal producer output identity changed')
    link = links[0][0]
    consumers = []
    for index, module in enumerate(modules):
        users, drivers = [], []
        for name, cell in module['cells'].items():
            require(set(cell) == {'hide_name', 'type', 'parameters', 'attributes', 'port_directions', 'connections'},
                    f'{name}: cell schema changed')
            require(set(cell['port_directions']) == set(cell['connections']), f'{name}: inconsistent port inventory')
            for pin, bits in connections[index][name].items():
                if link in bits:
                    direction = cell['port_directions'][pin]
                    require(direction in ('input', 'output'), 'internal link has an inout observer')
                    (users if direction == 'input' else drivers).extend((name, pin) for bit in bits if bit == link)
        require(drivers == [(producer, 'Q')], 'internal link driver is not exclusively producer Q')
        require(len(users) == 1, 'internal producer Q is not single-use')
        consumers.append(users[0][0])
        require(all(link not in normalize(port['bits'], index) for port in module['ports'].values()),
                'internal producer Q is externally observable')
    require(consumers[0] == consumers[1] and consumers[0] != producer, 'exclusive consumer identity changed')
    consumer = consumers[0]
    pair = {producer, consumer}
    require(connections[0][consumer]['Q'] == connections[1][consumer]['Q'], 'public consumer output identity changed')
    require(link != connections[0][consumer]['Q'][0], 'producer and consumer outputs alias')

    # Every outside cell is checked, including every generated route-through
    # cell. No graph intersection, cell-type filtering or buffer collapsing.
    outside_inputs = 0
    for name in sorted(set(a['cells']) - pair):
        x, y = a['cells'][name], b['cells'][name]
        states = [{pin: values[0] for pin, values in maps[name].items()} for maps in pinmaps]
        require(states[0] == states[1], f'{name}: outside logical pin state/inversion changed')
        for key in ('hide_name', 'type', 'parameters', 'port_directions', 'attributes'):
            require(x[key] == y[key], f'{name}: outside {key} changed')
        require(connections[0][name] == connections[1][name], f'{name}: outside functional connectivity changed')
        outside_inputs += sum(direction == 'input' for direction in x['port_directions'].values())

    networks = []
    external = set()
    for index, module in enumerate(modules):
        network = {}
        for name in pair:
            cell = module['cells'][name]
            match = re.fullmatch(r'MISTRAL_ALUT([2-6])', cell['type'])
            require(match is not None, f'{name}: unsupported pair primitive')
            width = int(match.group(1))
            pins = 'ABCDEF'[:width]
            require(set(cell['connections']) == set(pins) | {'Q'}, f'{name}: unexpected pair ports')
            require(set(cell['parameters']) == {'LUT'}, f'{name}: unexpected pair parameters')
            mask = cell['parameters']['LUT']
            require(len(mask) == 1 << width and set(mask) <= {'0', '1'}, f'{name}: undefined or malformed truth table')
            require(cell['port_directions']['Q'] == 'output' and pinmaps[index][name]['Q'][0] == 0,
                    f'{name}: unsupported output polarity/direction')
            require(all(len(bits) == 1 for bits in connections[index][name].values()), f'{name}: nonscalar pair port')
            data = []
            for pin in pins:
                require(cell['port_directions'][pin] == 'input', f'{name}.{pin}: unexpected direction')
                state = pinmaps[index][name][pin][0]
                require(state in (0, 3), f'{name}.{pin}: unsupported input state')
                signal = connections[index][name][pin][0]
                require(type(signal) is int, f'{name}.{pin}: pair has unsupported literal input')
                require(signal != connections[index][consumer]['Q'][0], 'pair feeds back from consumer output')
                if signal != link:
                    external.add(signal)
                data.append((signal, state == 3))
            network[name] = (data, int(mask, 2))
        require(all(signal != link for signal, _ in network[producer][0]), 'producer self-feedback')
        require(sum(signal == link for signal, _ in network[consumer][0]) == 1, 'consumer internal-link count changed')
        networks.append(network)
    for name in pair:
        x, y = a['cells'][name], b['cells'][name]
        require(x['hide_name'] == y['hide_name'], f'{name}: pair visibility changed')
        attrs = [{key: value for key, value in cell['attributes'].items()
                  if key not in ('FES_PINMAP_V1', 'NEXTPNR_BEL')} for cell in (x, y)]
        require(attrs[0] == attrs[1], f'{name}: unexpected pair attribute change')
    require(selected_input in a['cells'][producer]['connections'], 'selected input does not exist')
    require(a['cells'][producer]['attributes']['NEXTPNR_BEL'] == b['cells'][producer]['attributes']['NEXTPNR_BEL'],
            'producer unexpectedly moved')
    require(len(external) <= 11, 'pair proof exceeds exhaustive support bound')
    external = sorted(external)
    for assignment in itertools.product((False, True), repeat=len(external)):
        env = dict(zip(external, assignment))
        outputs = []
        for network in networks:
            def evaluate(name, internal):
                pins, mask = network[name]
                row = 0
                for position, (signal, inverted) in enumerate(pins):
                    value = internal if signal == link else env[signal]
                    row |= (int(value) ^ int(inverted)) << position
                return bool((mask >> row) & 1)
            outputs.append(evaluate(consumer, evaluate(producer, False)))
        require(outputs[0] == outputs[1], f'consumer truth table mismatch at assignment {assignment}')

    # Serialized ALM mode changes must be precisely the two-LUT width change;
    # unrelated LAB mode/control state is still checked in full.
    old_attrs = {key: value for key, value in a['attributes'].items() if key != 'FES_LABSTATE_V1'}
    new_attrs = {key: value for key, value in b['attributes'].items() if key != 'FES_LABSTATE_V1'}
    require(old_attrs == new_attrs, 'non-LAB module attributes changed')
    lab_states = [unpack(module['attributes']['FES_LABSTATE_V1']) for module in modules]
    require(set(lab_states[0]) == set(lab_states[1]) == {'device', 'labs'}, 'LAB-state schema changed')
    require(lab_states[0]['device'] == lab_states[1]['device'], 'device changed')
    labs = []
    for state in lab_states:
        table = {}
        for row in state['labs']:
            require(len(row) == 4 and len(row[3]) == 62, 'incomplete LAB state')
            key = tuple(row[:3])
            require(key not in table, 'duplicate LAB state')
            table[key] = row[3]
        labs.append(table)
    require(set(labs[0]) == set(labs[1]), 'LAB identity coverage changed')
    affected = {site(module['cells'][name]) for module in modules for name in pair}
    mode_changes = []
    for key in labs[0]:
        for index, (old, new) in enumerate(zip(labs[0][key], labs[1][key])):
            if old == new:
                continue
            alm = (index - 2) // 6
            require(index >= 2 and (index - 2) % 6 == 0 and (*key, alm) in affected,
                    f'unrelated serialized LAB state changed at {key}:{index}')
            for side in range(2):
                expected = any(cell['type'] == 'MISTRAL_ALUT6' and site(cell) == (*key, alm)
                               for cell in modules[side]['cells'].values())
                require(labs[side][key][index] == int(expected), 'serialized LUT6 mode disagrees with occupants')
            mode_changes.append({'lab': list(key), 'alm': alm, 'before_l6': old, 'after_l6': new})
    settings_changes = [{'key': key, 'before': a['settings'].get(key), 'after': b['settings'].get(key)}
                        for key in sorted(set(a['settings']) | set(b['settings']))
                        if a['settings'].get(key) != b['settings'].get(key)]
    require(settings_changes in ([], [{'key': 'gpurouter/localInputEscape', 'before': None, 'after': '0 '}]),
            'unexpected serialized settings difference')
    generated = sorted(name for name, cell in a['cells'].items()
                       if cell['type'] == 'MISTRAL_BUF' and '$ROUTETHRU' in name)
    return {
        'module': module_name, 'producer': producer, 'consumer': consumer, 'selected_input': selected_input,
        'complete_cell_inventory': len(a['cells']), 'complete_net_name_inventory': len(a['netnames']),
        'bijective_named_signal_bits': len(forward), 'external_ports_unchanged': len(a['ports']),
        'outside_pair_cells_unchanged': len(a['cells']) - 2, 'outside_pair_input_ports_checked': outside_inputs,
        'outside_pair_pin_states_checked': sum(len(pinmaps[0][name]) for name in a['cells'] if name not in pair),
        'outside_pair_functions_connections_pin_states_attributes_identical': True,
        'route_generated_buffers_exactly_matched': len(generated),
        'route_generated_buffer_identity_sha256': hashlib.sha256(json.dumps(generated).encode()).hexdigest(),
        'all_net_alias_classes_and_nonrouting_attributes_preserved': True,
        'internal_link_single_use_and_not_external': True,
        'external_signal_count': len(external), 'external_signal_identities': [sorted(labels[bit]) for bit in external],
        'assignments_exhaustively_checked': 1 << len(external), 'consumer_output_equivalent': True,
        'producer_internal_output_may_change': True, 'changed_route_attributes': len(changed_routes),
        'serialized_alm_mode_changes': mode_changes, 'serialized_settings_differences': settings_changes,
    }


def selftest(documents, producer, selected_input):
    candidate = documents[1]
    module = next(iter(candidate['modules'].values()))
    original = proof(documents, producer, selected_input)
    consumer = original['consumer']
    outside = next(name for name, cell in module['cells'].items()
                   if name not in (producer, consumer) and cell['type'] == 'MISTRAL_BUF' and '$ROUTETHRU' in name)
    tests = []

    def reject(label, mutate, restore):
        mutate()
        try:
            try:
                proof(documents, producer, selected_input)
            except (ValueError, KeyError) as error:
                tests.append({'mutation': label, 'rejected': True, 'reason': str(error)})
            else:
                raise AssertionError(f'mutation was accepted: {label}')
        finally:
            restore()

    params = copy.deepcopy(module['cells'][outside]['parameters'])
    reject('outside primitive parameter changed',
           lambda: module['cells'][outside]['parameters'].update({'MUTATED': '1'}),
           lambda: module['cells'][outside].update(parameters=params))
    saved = module['cells'][outside]['attributes']['FES_PINMAP_V1']
    mutated = unpack(saved)
    mutated['pins']['A'][0] = 3 if mutated['pins']['A'][0] == 0 else 0
    reject('outside input inversion changed',
           lambda: module['cells'][outside]['attributes'].update(FES_PINMAP_V1=pack(mutated)),
           lambda: module['cells'][outside]['attributes'].update(FES_PINMAP_V1=saved))
    cell = module['cells'][outside]
    reject('route-generated buffer removed', lambda: module['cells'].pop(outside),
           lambda: module['cells'].update({outside: cell}))
    old_bits = cell['connections']['A']
    reject('second observer of producer internal link',
           lambda: cell['connections'].update(A=module['cells'][producer]['connections']['Q']),
           lambda: cell['connections'].update(A=old_bits))
    mask = module['cells'][consumer]['parameters']['LUT']
    reject('consumer truth table complemented',
           lambda: module['cells'][consumer]['parameters'].update(LUT=''.join('1' if bit == '0' else '0' for bit in mask)),
           lambda: module['cells'][consumer]['parameters'].update(LUT=mask))
    name = next(name for name, net in module['netnames'].items() if any(type(bit) is int for bit in net['bits']))
    old = module['netnames'][name]['bits']
    altered = list(old)
    position = next(index for index, bit in enumerate(old) if type(bit) is int)
    altered[position] = 1000000000
    reject('named-net alias or connection identity changed',
           lambda: module['netnames'][name].update(bits=altered),
           lambda: module['netnames'][name].update(bits=old))
    port_name = next(iter(module['ports']))
    old = module['ports'][port_name]['bits']
    reject('external port observes producer internal link',
           lambda: module['ports'][port_name].update(bits=module['cells'][producer]['connections']['Q']),
           lambda: module['ports'][port_name].update(bits=old))
    require(proof(documents, producer, selected_input) == original, 'mutation tests failed to restore documents')
    return {'unchanged_valid_pair_accepted': True, 'negative_mutations': tests, 'all_mutations_rejected': True}



# One extra route helper exists between the two final routes. The identity is
# explicit; no pattern-based deletion or graph intersection is used for the pair.
STEP1_EXTRA = 'system.machine.cpu.cpu.u_eu_core.eu_register_sp_MISTRAL_FF_Q_4$ROUTETHRU'


def account_buffers(module, names):
    """Prove the full exact private pass-through topology before substitution."""
    usages, aliases = collections.defaultdict(list), collections.defaultdict(list)
    for name, cell in module['cells'].items():
        for port, bits in cell['connections'].items():
            for index, bit in enumerate(bits):
                usages[bit].append((name, port, index, cell['port_directions'][port]))
    for name, net in module['netnames'].items():
        for index, bit in enumerate(net['bits']):
            aliases[bit].append((name, index))
    external = {bit for port in module['ports'].values() for bit in port['bits']}
    records = []
    for name in sorted(names):
        require(name.endswith('$ROUTETHRU'), f'{name}: extra cell is not an identified FF route helper')
        target = name.removesuffix('$ROUTETHRU')
        require(target in module['cells'], f'{name}: target FF missing')
        cell, ff = module['cells'][name], module['cells'][target]
        require(set(cell) == {'hide_name', 'type', 'parameters', 'attributes', 'port_directions', 'connections'},
                f'{name}: route helper schema changed')
        require(cell['hide_name'] == 0 and cell['type'] == 'MISTRAL_BUF' and cell['parameters'] == {},
                f'{name}: route helper function changed')
        require(cell['port_directions'] == {'A': 'input', 'Q': 'output'} and set(cell['connections']) == {'A', 'Q'},
                f'{name}: route helper ports changed')
        require(all(len(bits) == 1 and type(bits[0]) is int for bits in cell['connections'].values()),
                f'{name}: malformed route helper connections')
        source, output = cell['connections']['A'][0], cell['connections']['Q'][0]
        require(source != output and ff['type'] == 'MISTRAL_FF', f'{name}: invalid pass-through destination')
        require(set(cell['attributes']) == {'BEL_STRENGTH', 'NEXTPNR_BEL', 'FES_PINMAP_V1'},
                f'{name}: unexpected route helper attributes')
        require(int(cell['attributes']['BEL_STRENGTH'], 2) == 2, f'{name}: unexpected binding strength')
        lut_site = re.fullmatch(r'MISTRAL_(M?COMB)\.(\d+)\.(\d+)\.(\d+)', cell['attributes']['NEXTPNR_BEL'])
        ff_site = re.fullmatch(r'MISTRAL_FF\.(\d+)\.(\d+)\.(\d+)', ff['attributes']['NEXTPNR_BEL'])
        require(lut_site is not None and ff_site is not None, f'{name}: invalid physical BEL identities')
        _, lx, ly, lz = lut_site.groups()
        fx, fy, fz = ff_site.groups()
        lz, fz = int(lz), int(fz)
        require((lx, ly) == (fx, fy) and lz // 6 == fz // 6 and lz % 6 in (0, 1)
                and fz % 6 in (2, 3, 4, 5) and lz % 6 == (fz % 6 - 2) // 2,
                f'{name}: helper does not occupy target FF half')
        pins = pinmap(cell, name)
        require(pins == {'A': [0, f'F{lz % 6}'], 'Q': [0, 'COMBOUT']} or
                pins == {'A': [0, f'E{lz % 6}'], 'Q': [0, 'COMBOUT']},
                f'{name}: helper is not a noninverting scalar pass-through')
        expected_uses = [(name, 'Q', 0, 'output'), (target, 'DATAIN', 0, 'input')]
        require(sorted(usages[output]) == sorted(expected_uses), f'{name}: private output has unexpected observer/driver')
        require(output not in external, f'{name}: private output externally observable')
        private_name = name + '$conn$Q'
        require(aliases[output] == [(private_name, 0)], f'{name}: private net alias inventory changed')
        net = module['netnames'][private_name]
        require(set(net) == {'hide_name', 'bits', 'attributes'} and net['hide_name'] == 0 and net['bits'] == [output]
                and set(net['attributes']) == {'ROUTING'}, f'{name}: private net metadata changed')
        records.append({'cell': name, 'destination': [target, 'DATAIN'], 'private_net': private_name,
                        'source_aliases': sorted(aliases[source]), 'physical_bel': cell['attributes']['NEXTPNR_BEL'],
                        'pinmap': pins, 'source_bit': source, 'private_output_bit': output,
                        'truth_table_exhaustively_checked': [[0, 0], [1, 1]]})
    # Only the fully accounted private output and exact DATAIN slot are changed.
    for record in records:
        module['cells'][record['destination'][0]]['connections']['DATAIN'] = [record['source_bit']]
        module['cells'].pop(record['cell'])
        module['netnames'].pop(record['private_net'])
    return records


def prepared_bridge(prepared_document, routed_document):
    prepared = copy.deepcopy(prepared_document)
    routed = copy.deepcopy(routed_document)
    require(set(prepared) == set(routed) == {'creator', 'modules'} and prepared['creator'] == routed['creator'],
            'prepared/routed root schema or creator mismatch')
    require(set(prepared['modules']) == set(routed['modules']) == {'top'}, 'prepared/routed module mismatch')
    p, r = prepared['modules']['top'], routed['modules']['top']
    require(set(p) == set(r) == {'settings', 'attributes', 'ports', 'cells', 'netnames'}, 'bridge module schema changed')
    require(set(p['cells']) <= set(r['cells']), 'prepared source cell missing after routing')
    extras = set(r['cells']) - set(p['cells'])
    records = account_buffers(r, extras)
    require(set(p['cells']) == set(r['cells']) and set(p['netnames']) == set(r['netnames']),
            'unaccounted routed cells or named nets')
    forward, reverse = {}, {}
    for name in sorted(p['netnames']):
        a, b = p['netnames'][name], r['netnames'][name]
        require(set(a) == set(b) == {'hide_name', 'bits', 'attributes'} and a['hide_name'] == b['hide_name']
                and len(a['bits']) == len(b['bits']), f'{name}: bridge net schema mismatch')
        for old, new in zip(a['bits'], b['bits']):
            require(type(old) is type(new), f'{name}: bridge net kind changed')
            if type(old) is int:
                require(old not in forward or forward[old] == new, f'{name}: bridge alias split')
                require(new not in reverse or reverse[new] == old, f'{name}: bridge alias merge')
                forward[old], reverse[new] = new, old
            else:
                require(old == new and old in ('0', '1', 'x', 'z'), f'{name}: bridge literal changed')
        attrs = [{key: value for key, value in net['attributes'].items() if key != 'ROUTING'} for net in (a, b)]
        require(attrs[0] == attrs[1], f'{name}: bridge nonrouting metadata changed')

    def normalize(bits, candidate):
        values = []
        for bit in bits:
            if type(bit) is int:
                require(bit in (reverse if candidate else forward), f'bridge connected bit has no complete named identity: {bit}')
                values.append(reverse[bit] if candidate else bit)
            else:
                require(bit in ('0', '1', 'x', 'z'), 'bridge unknown literal')
                values.append(bit)
        return values

    require(set(p['ports']) == set(r['ports']), 'bridge external port inventory changed')
    for name in p['ports']:
        a, b = p['ports'][name], r['ports'][name]
        require(set(a) == set(b) == {'direction', 'bits'} and a['direction'] == b['direction']
                and normalize(a['bits'], False) == normalize(b['bits'], True), f'{name}: bridge external port changed')
    physical = []
    pin_states = 0
    for name in p['cells']:
        a, b = p['cells'][name], r['cells'][name]
        require(set(a) == set(b) == {'hide_name', 'type', 'parameters', 'attributes', 'port_directions', 'connections'},
                f'{name}: bridge cell schema changed')
        for key in ('hide_name', 'type', 'parameters', 'port_directions'):
            require(a[key] == b[key], f'{name}: bridge primitive {key} changed')
        require({pin: normalize(bits, False) for pin, bits in a['connections'].items()} ==
                {pin: normalize(bits, True) for pin, bits in b['connections'].items()}, f'{name}: bridge input/output graph changed')
        pins = [pinmap(cell, name) for cell in (a, b)]
        require({pin: values[0] for pin, values in pins[0].items()} ==
                {pin: values[0] for pin, values in pins[1].items()}, f'{name}: bridge logical pin state/inversion changed')
        pin_states += len(pins[0])
        if pins[0] != pins[1]:
            physical.append({'cell': name, 'before': pins[0], 'after': pins[1]})
        attrs = [{key: value for key, value in cell['attributes'].items() if key != 'FES_PINMAP_V1'} for cell in (a, b)]
        require(attrs[0] == attrs[1], f'{name}: bridge placement/non-pin metadata changed')
    require(p['attributes']['step'] == 'place' and r['attributes']['step'] == 'route', 'invalid bridge stage')
    require('FES_LABSTATE_V1' not in p['attributes'], 'prepared graph unexpectedly contains routed LAB snapshot')
    require({key: value for key, value in p['attributes'].items() if key != 'step'} ==
            {key: value for key, value in r['attributes'].items() if key not in ('step', 'FES_LABSTATE_V1')},
            'bridge unexpected module metadata changed')
    # Existing settings are exact. Added runtime defaults are serialized in full,
    # and compared by the final-pair proof; they are not Boolean function inputs.
    require(all(key in r['settings'] and r['settings'][key] == value for key, value in p['settings'].items()),
            'prepared setting modified by route')
    added_settings = {key: value for key, value in r['settings'].items() if key not in p['settings']}
    return {'prepared_cell_count': len(p['cells']), 'prepared_net_name_count': len(p['netnames']),
            'route_generated_buffers_proved': records, 'all_original_functions_and_aliases_preserved': True,
            'logical_pin_states_checked': pin_states, 'physical_pinmap_change_count': len(physical),
            'all_physical_pinmap_changes': physical,
            'physical_pinmap_changes_sha256': hashlib.sha256(json.dumps(physical, sort_keys=True).encode()).hexdigest(),
            'added_runtime_settings': added_settings,
            'limits': ['Route input pin reallocation is recorded with logical states unchanged; emitted masks and electrical routing are not decoded.']}


def chain_pair(documents, selection, extras):
    docs = copy.deepcopy(documents)
    a, b = [doc['modules']['top'] for doc in docs]
    require(set(b['cells']) - set(a['cells']) == set(extras) and set(a['cells']) <= set(b['cells']),
            'final route cell delta differs from explicitly expected helper identities')
    records = account_buffers(b, extras)
    changes = [{'key': key, 'before': a['settings'].get(key), 'after': b['settings'].get(key)}
               for key in sorted(set(a['settings']) | set(b['settings']))
               if a['settings'].get(key) != b['settings'].get(key)]
    require(changes in ([], [{'key': 'gpurouter/localInputEscape', 'before': None, 'after': '0 '}],
                         [{'key': 'gpurouter/localInputEscape', 'before': '0 ', 'after': None}]),
            'unexpected final route settings difference')
    b['settings'] = dict(a['settings'])
    result = proof(docs, selection['producer'], selection['input'])
    result['serialized_settings_differences'] = changes
    result['explicit_additional_route_helper_proofs'] = records
    result['raw_before_cell_count'] = len(documents[0]['modules']['top']['cells'])
    result['raw_after_cell_count'] = len(documents[1]['modules']['top']['cells'])
    result['raw_before_net_count'] = len(documents[0]['modules']['top']['netnames'])
    result['raw_after_net_count'] = len(documents[1]['modules']['top']['netnames'])
    return result, docs


def extra_selftest(documents, selection):
    module = documents[1]['modules']['top']
    cell = module['cells'][STEP1_EXTRA]
    records = []

    def reject(label, mutate, restore):
        mutate()
        try:
            try:
                chain_pair(documents, selection, [STEP1_EXTRA])
            except (ValueError, KeyError) as error:
                records.append({'mutation': label, 'rejected': True, 'reason': str(error)})
            else:
                raise AssertionError(f'extra helper mutation accepted: {label}')
        finally:
            restore()

    saved = cell['attributes']['FES_PINMAP_V1']
    changed = unpack(saved)
    changed['pins']['A'][0] = 3
    reject('extra route helper input inverted', lambda: cell['attributes'].update(FES_PINMAP_V1=pack(changed)),
           lambda: cell['attributes'].update(FES_PINMAP_V1=saved))
    target = STEP1_EXTRA.removesuffix('$ROUTETHRU')
    old = module['cells'][target]['connections']['DATAIN']
    reject('extra route helper bypassed at target FF',
           lambda: module['cells'][target]['connections'].update(DATAIN=cell['connections']['A']),
           lambda: module['cells'][target]['connections'].update(DATAIN=old))
    net = module['netnames'][STEP1_EXTRA+'$conn$Q']
    reject('extra route helper output has undeclared alias',
           lambda: module['netnames'].update({'MUTATED_ALIAS': copy.deepcopy(net)}),
           lambda: module['netnames'].pop('MUTATED_ALIAS'))
    key = next(iter(module['ports']))
    old = module['ports'][key]['bits']
    reject('extra route helper output externally exposed',
           lambda: module['ports'][key].update(bits=cell['connections']['Q']),
           lambda: module['ports'][key].update(bits=old))
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    routes = [ROOT / name for name in ('route-baseline', 'route-step1', 'route-step2')]
    selections = [read(ROOT / stage / 'selection.json') for stage in ('step1', 'step2')]
    prepared_paths = [Path(selections[0]['prior_input']), ROOT / 'step1/placed.json', ROOT / 'step2/placed.json']
    require(Path(selections[1]['prior_input']).resolve() == prepared_paths[1].resolve(), 'chain prepared-input link changed')
    receipts = [read(path / 'receipt.json') for path in routes]
    binary = receipts[0]['binary_sha256']
    normalized_commands = []
    for index, receipt in enumerate(receipts):
        require(receipt['binary_sha256'] == binary, 'chain compiler binary hash changed')
        command = list(receipt['nextpnr_command'])
        require(digest(Path(command[0])) == binary and command.count('--json') == 1, 'compiler identity/command mismatch')
        position = command.index('--json') + 1
        require(Path(command[position]).resolve() == prepared_paths[index].resolve(), 'route selected unexpected prepared graph')
        require(digest(prepared_paths[index]) == receipt['input_sha256'], 'prepared input hash mismatch')
        require(digest(routes[index] / 'routed.json') == receipt['artifacts']['routed.json'], 'final route artifact hash mismatch')
        command[position] = '<verified-prepared-input>'
        normalized_commands.append(command)
    require(normalized_commands[0] == normalized_commands[1] == normalized_commands[2], 'chain route recipe changed')
    documents = [read(path / 'routed.json') for path in routes]
    bridges = []
    for index, path in enumerate(prepared_paths):
        bridge = prepared_bridge(read(path), documents[index])
        bridge.update(prepared_path=str(path), prepared_sha256=digest(path),
                      routed_path=str(routes[index] / 'routed.json'), routed_sha256=digest(routes[index] / 'routed.json'))
        bridges.append(bridge)
    steps, tests = [], []
    for index, selection in enumerate(selections):
        result, normalized = chain_pair(documents[index:index+2], selection, [STEP1_EXTRA] if index == 0 else [])
        result.update(before_sha256=digest(routes[index] / 'routed.json'),
                      after_sha256=digest(routes[index+1] / 'routed.json'),
                      prepared_before_sha256=digest(prepared_paths[index]),
                      prepared_after_sha256=digest(prepared_paths[index+1]))
        steps.append(result)
        if args.self_test:
            tests.append(selftest(normalized, selection['producer'], selection['input']))
    if args.self_test:
        tests.append({'additional_helper_mutations': extra_selftest(documents[:2], selections[0])})
    result = {'schema': 1, 'evidence': 'host-only final routed graph and per-step Boolean composition proof',
              'checker_sha256': digest(Path(__file__).resolve()), 'same_compiler_binary_sha256': binary,
              'identical_recipe_except_verified_prepared_input': True, 'steps': steps,
              'composition': {'from': str(routes[0] / 'routed.json'), 'to': str(routes[2] / 'routed.json'),
                              'consumer_boundary_equivalence_and_unobserved_internal_outputs_proven': True},
              'prepared_route_bridges': bridges,
              'limits': ['Each LUT pair is exhaustively proved at its consumer output; its private producer output may change.',
                         'Every additional route helper is independently proved as a private noninverting FF data buffer.',
                         'Unchanged primitive types, parameters, inputs and logical pin states are assumed to preserve documented semantics.',
                         'This does not decode RBF masks, prove physical routing or primitive-clock margins, or establish timing/hardware acceptance.']}
    (ROOT / 'proof-routed.json').write_text(json.dumps(result, indent=2) + '\n')
    if args.self_test:
        (ROOT / 'proof-routed-selftest.json').write_text(json.dumps({'checker_sha256': result['checker_sha256'],
                                                                  'tests': tests}, indent=2) + '\n')
    print(json.dumps({'steps': [{key: step[key] for key in ('raw_before_cell_count', 'raw_after_cell_count',
                       'assignments_exhaustively_checked', 'consumer_output_equivalent', 'serialized_alm_mode_changes')}
                               for step in steps],
                      'bridge_buffer_counts': [len(bridge['route_generated_buffers_proved']) for bridge in bridges],
                      'composition': result['composition']}, indent=2))


if __name__ == '__main__':
    main()
