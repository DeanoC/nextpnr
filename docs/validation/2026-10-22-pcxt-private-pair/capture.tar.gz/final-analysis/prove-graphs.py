#!/usr/bin/env python3
"""Own-route full logical bridges, explicit helpers, and 128-row transitivity."""
from pathlib import Path
import copy,hashlib,importlib.util,json
R=Path(__file__).resolve().parent;ROOT=R.parent
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
g=module('private_pair_graph_support',R/'graph-support.py')
p=module('private_pair_preparation_proof',ROOT/'analysis/prove.py')
def command_normalize(command):
 out=command[:]
 for flag,width in [('--rbf',2),('--compress-rbf',1),('--routed-endpoints',2),('--no-route',1),('--critical-route-budget',2),('--debug-placer',1)]:
  if flag in out:i=out.index(flag);del out[i:i+width]
 for flag in ['--write','--report','--router']:
  if flag in out:out[out.index(flag)+1]='<'+flag[2:]+'> '
 return out
def complete_differences(before,after,path=()):
 if type(before) is not type(after):return [{'path':path,'before':before,'after':after}]
 if isinstance(before,dict):
  result=[]
  for key in sorted(set(before)|set(after)):
   if key not in before or key not in after:
    result.append({'path':path+(key,),'before_present':key in before,'after_present':key in after,'before':before.get(key),'after':after.get(key)})
   else:result.extend(complete_differences(before[key],after[key],path+(key,)))
  return result
 if isinstance(before,list):
  if len(before)!=len(after):return [{'path':path,'before':before,'after':after}]
  return [v for i,(a,b) in enumerate(zip(before,after)) for v in complete_differences(a,b,path+(i,))]
 return [] if before==after else [{'path':path,'before':before,'after':after}]
def tree(value):
 if value is None:return None
 if value=='':return {}
 tokens=value.split(';');g.require(len(tokens)%3==0,'serialized routing triple shape')
 result={}
 for i in range(0,len(tokens),3):
  wire,pip,strength=tokens[i:i+3];g.require(wire not in result,'repeated serialized route wire');result[wire]=[pip,int(strength)]
 return result
def main():
 saved=p.read(ROOT/'analysis/logical-proof.json');saved_sha=g.digest(ROOT/'analysis/logical-proof.json')
 origin=g.read(R/'support-origin.json');original_support=R/origin['retained_copy']
 g.require(g.digest(original_support)==origin['original_sha256'],'original support digest mismatch')
 g.require((R/'graph-support.py').read_text()==original_support.read_text().replace(
     "            'logical_pin_states_checked': pin_states, 'physical_pinmap_change_count': len(physical),\n",
     "            'logical_pin_states_checked': pin_states, 'physical_pinmap_change_count': len(physical),\n            'all_physical_pinmap_changes': physical,\n"), 'unexpected support predicate or code change')
 prepared=[g.read(ROOT/('prepare-'+n)/'placed.json') for n in ['default','selected-0']]
 logical=p.prove(*prepared)
 for key,value in logical.items():g.require(json.loads(json.dumps(value))==saved[key],'frozen logical proof replay mismatch '+key)
 results=[];routed=[];rec=[]
 for name,pd in zip(['default','selected-0'],prepared):
  pp=ROOT/('prepare-'+name);rp=ROOT/('route-'+name);pr=g.read(pp/'receipt.json');rr=g.read(rp/'receipt.json');rec.append(rr)
  for folder,receipt in [(pp,pr),(rp,rr)]:
   for filename,digest in receipt['artifacts'].items():g.require(g.digest(folder/filename)==digest,'artifact digest '+str(folder/filename))
  g.require(pr['binary_sha256']==rr['binary_sha256']==saved['binary_sha256'],'binary not identical')
  g.require(command_normalize(pr['nextpnr_command'])==command_normalize(rr['nextpnr_command']),'preparation/full route command mismatch')
  g.require(pr['inputs']==rr['inputs'],'preparation/full route input mismatch')
  g.require(rr['logical_preparation_proof_sha256']==saved_sha,'route did not bind frozen proof')
  rd=g.read(rp/'routed.json');routed.append(rd)
  bridge=g.prepared_bridge(pd,rd)
  bridge.update(case=name,prepared_sha256=g.digest(pp/'placed.json'),routed_sha256=g.digest(rp/'routed.json'),
                complete_routed_cells=len(rd['modules']['top']['cells']),complete_routed_alias_records=len(rd['modules']['top']['netnames']),
                complete_routed_module_metadata={k:v for k,v in rd['modules']['top'].items() if k not in ['cells','netnames','ports']})
  results.append(bridge)
 settings=[doc['modules']['top']['settings'] for doc in routed]
 settings_delta=[{'key':key,'before_present':key in settings[0],'after_present':key in settings[1],
                  'before':settings[0].get(key),'after':settings[1].get(key)}
                 for key in sorted(set(settings[0])|set(settings[1])) if key not in settings[0] or key not in settings[1] or settings[0][key]!=settings[1][key]]
 g.require(settings_delta==[{'key':'gpurouter/localInputEscape','before_present':False,'after_present':True,'before':None,'after':'0 '}],
           'unaccounted complete serialized settings difference')
 serialized=complete_differences(*routed);routing=[]
 nets=[doc['modules']['top']['netnames'] for doc in routed]
 for name in sorted(set(nets[0])|set(nets[1])):
  a,b=nets[0].get(name),nets[1].get(name)
  old=a.get('attributes',{}).get('ROUTING') if a else None;new=b.get('attributes',{}).get('ROUTING') if b else None
  if a is None or b is None or old!=new:
   ot,nt=tree(old),tree(new)
   routing.append({'alias':name,'before_present':a is not None,'after_present':b is not None,
                   'before_bits':a['bits'] if a else None,'after_bits':b['bits'] if b else None,
                   'canonical_wire_pip_strength_map_equal':ot==nt,'old_tree':ot,'new_tree':nt})
 raw_difference={'scope':'Every raw serialized graph field difference, without normalization; physical tree strings are decoded syntactically, not validated against device connectivity.',
                 'all_field_differences':serialized,'all_changed_routing_aliases':routing}
 (R/'all-serialized-differences.json').write_text(json.dumps(raw_difference,indent=2)+'\n')
 # Every helper is established independently in its own complete graph. Never
 # assign equivalence to equal helper names or drop unmatched helper identities.
 helper_sets=[{x['cell'] for x in r['route_generated_buffers_proved']} for r in results]
 helper_ledger={'default_all':sorted(helper_sets[0]),'selected_all':sorted(helper_sets[1]),
                'default_only':sorted(helper_sets[0]-helper_sets[1]),'selected_only':sorted(helper_sets[1]-helper_sets[0]),
                'proof_boundary':'All helpers independently have exact noninverting truth tables, actual logical pin states, private nets and their sole FF DATAIN observer verified before substitution.'}
 negatives=[];candidate=routed[1];helper=results[1]['route_generated_buffers_proved'][0]
 def reject(label,mutation):
  changed=copy.deepcopy(candidate);mutation(changed['modules']['top'])
  try:g.prepared_bridge(prepared[1],changed)
  except (ValueError,KeyError,AssertionError) as error:negatives.append({'mutation':label,'rejected':True,'reason':str(error)})
  else:raise ValueError('accepted mutated final graph '+label)
 def inverse(m,name):
  c=m['cells'][name];pins=g.unpack(c['attributes']['FES_PINMAP_V1']);pins['pins']['A'][0]=3-pins['pins']['A'][0];c['attributes']['FES_PINMAP_V1']=g.pack(pins)
 def flip(m,name):
  mask=m['cells'][name]['parameters']['LUT'];m['cells'][name]['parameters']['LUT']=mask[:-1]+('0' if mask[-1]=='1' else '1')
 reject('route helper logical inversion',lambda m:inverse(m,helper['cell']))
 reject('route helper primitive replaced',lambda m:m['cells'][helper['cell']].update(type='MISTRAL_ALUT2'))
 reject('private helper additional net alias',lambda m:m['netnames'].update({'mutation_alias':copy.deepcopy(m['netnames'][helper['private_net']])}))
 reject('private helper exposed at top',lambda m:m['ports'].update({'mutation_observer':{'direction':'output','bits':m['cells'][helper['cell']]['connections']['Q'][:]}}))
 reject('helper FF sink disconnected',lambda m:m['cells'][helper['destination'][0]]['connections'].update(DATAIN=m['cells'][helper['cell']]['connections']['A'][:]))
 reject('selected producer LUT bit changed',lambda m:flip(m,p.PRODUCER))
 reject('selected consumer LUT bit changed',lambda m:flip(m,p.CONSUMER))
 reject('selected producer logical inversion',lambda m:inverse(m,p.PRODUCER))
 outside=next(n for n,c in prepared[1]['modules']['top']['cells'].items() if n not in p.PAIR and c['type'].startswith('MISTRAL_ALUT') and 'LUT' in c['parameters'])
 reject('outside original LUT bit changed',lambda m:flip(m,outside))
 g.require(g.digest(ROOT/'analysis/logical-proof.json')==saved_sha,'frozen proof changed')
 result={'status':'pass','scope':'Complete final serialized Boolean graphs via independently checked own-preparation bridges; no RBF mask, electrical route or hardware proof.',
         'checker_sha256':g.digest(Path(__file__)),'support_sha256':g.digest(R/'graph-support.py'),
         'support_origin':{'path':origin['original_path'],'sha256':g.digest(original_support),'only_code_change':'Return every physical pin-map delta in addition to its existing hash; no predicate changed.'},
         'frozen_preparation_proof_sha256':saved_sha,'preparation_128_row_proof_replayed_in_memory_without_rewriting':True,
         'full_own_preparation_to_route_bridges':results,'all_route_helper_inventory':helper_ledger,
         'every_original_function_connection_alias_top_port_and_logical_pin_state_verified':True,
         'all_original_BELs_and_nonpin_cell_attributes_preserved':True,'complete_final_settings_equal':False,
         'every_final_settings_difference':settings_delta,
         'settings_semantics':'Selected router reached release_soft_plateau, which reads setting<bool>(gpurouter/localInputEscape,false); the accessor inserts std::to_string(false), the string 0. Property::to_string appends a space to distinguish a string containing only binary characters; from_string removes that discriminator. Both the absent default and decoded string 0 return false, leaving escape_local_inputs disabled. The exact serialized absent-to-0-space difference is retained, not normalized away.',
         'settings_semantics_committed_sources':{name:g.digest(R/'settings-source'/name) for name in ['context.h','gpurouter.cc','property.cc','jsonwrite.cc']},
         'complete_raw_serialized_difference_sha256':g.digest(R/'all-serialized-differences.json'),
         'all_raw_serialized_field_differences':len(serialized),'routing_alias_differences':len(routing),
         'routing_alias_order_only_differences':sum(x['canonical_wire_pip_strength_map_equal'] for x in routing),
         'preparation_route_command_boundary':'Only stage/output arguments, final critical-route-budget32 and preparation-only debug-placer differ; every resulting original BEL/function/connection is independently checked.',
         'actual_mutation_tests':negatives,
         'limits':['Route pin allocation changes are retained in full; native allocated mask equality and RBF encoding are not inferred from logical pin states.',
                   'FES_LABSTATE and every final ROUTING string remain preserved in the complete routed artifacts. This script does not decode physical wires or RBF programming.',
                   'Only explicit private noninverting helpers are substituted after a complete topology/function proof; no graph or helper intersection is used.',
                   'Native final endpoint timing, board IO obligations and hardware acceptance are separate gates.']}
 (R/'graph-proof.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'status':'pass','original_cells':[r['prepared_cell_count'] for r in results],
                   'final_cells':[r['complete_routed_cells'] for r in results],
                   'helper_counts':[len(r['route_generated_buffers_proved']) for r in results],
                   'physical_pinmap_changes':[r['physical_pinmap_change_count'] for r in results],
                   'negative_mutations':len(negatives),'physical_acceptance':False},indent=2))
if __name__=='__main__':main()
