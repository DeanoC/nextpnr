#!/usr/bin/env python3
"""Complete final native endpoint/metadata comparison; no intersected evidence."""
from pathlib import Path
from collections import Counter,defaultdict
from decimal import Decimal
import hashlib,json
R=Path(__file__).resolve().parent;ROOT=R.parent
def need(value,message):
 if not value:raise ValueError(message)
def unique(pairs):
 result={}
 for k,v in pairs:need(k not in result,'duplicate JSON key '+k);result[k]=v
 return result
def read(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def verify_input(info):
 if (ROOT/'archive-mode.json').exists():
  archive=read(ROOT/'archive-mode.json');item=archive['external_inputs'][info['path']]
  need(item['sha256']==info['sha256'] and sha(ROOT/item['retained_path'])==info['sha256'],'archived route input changed')
 else:need(sha(Path(info['path']))==info['sha256'],'route input changed')
def index(s):
 out={}
 for identity,values in s['endpoints'].items():
  for value in values:
   key=(identity,tuple(value['launch']),tuple(value['capture']));need(key not in out,'duplicate endpoint/domain identity');out[key]=value
 return out
def metric(values):
 values=list(values);out={'rows':len(values)}
 for field,flag in [('setup','setup_timed'),('hold','hold_related')]:
  margins=[v[field] for v in values if v[flag]]
  out[field]={'checked':len(margins),'failures':sum(x<0 for x in margins),'minimum_ps':min(margins,default=None)}
 return out
def cohorts(rows):
 groups=defaultdict(list)
 for key,value in rows.items():groups[key[1:]].append((key[0],value))
 return [{'launch':k[0],'capture':k[1],**metric(v for _,v in group),
          'CPU_capture_rows':metric(v for ident,v in group if json.loads(ident)[0].startswith('system.machine.cpu.'))}
         for k,group in sorted(groups.items())]
def paths(timing,cpu):
 result=[]
 for path in timing['critical_paths']:
  if path['from']!=path['to'] or path['to']!='posedge clocks[0]':continue
  capture=path['path'][-1]['to']
  if cpu and not capture['cell'].startswith('system.machine.cpu.'):continue
  total=defaultdict(float)
  for segment in path['path']:total[segment['type']]+=segment['delay']
  result.append({'slack_ns':path['max_delay']-sum(s['delay'] for s in path['path']),
                 'segment_sum_ns':dict(total),'complete_path':path})
 return sorted(result,key=lambda p:p['slack_ns'])[:10]
def main():
 names=['default','selected-0'];runs={};reports={};snapshots={};rows={};receipts={}
 for name in names:
  folder=ROOT/('route-'+name);receipt=read(folder/'receipt.json');receipts[name]=receipt
  for artifact,digest in receipt['artifacts'].items():need(sha(folder/artifact)==digest,'route artifact digest '+name+'/'+artifact)
  need(receipt['returncode'] in [0,1],'launch/runtime failure cannot be a timing result')
  for info in receipt['inputs'].values():verify_input(info)
  need(receipt['logical_preparation_proof_sha256']==sha(ROOT/'analysis/logical-proof.json'),'preparation proof changed')
  t=read(folder/'timing.json');s=read(folder/'endpoints.json')
  need(s['final_analogue'] is True and t['timing_summary']['final_analogue_model'] is True,'not final analogue timing')
  reports[name]=t;snapshots[name]=s;rows[name]=index(s)
  runs[name]={'receipt_sha256':sha(folder/'receipt.json'),'artifact_sha256':receipt['artifacts'],
              'returncode':receipt['returncode'],'charged_seconds':receipt['charged_seconds'],
              'schema':s['schema'],'complete':s['complete'],'unsupported_count':len(s['unsupported']),
              **metric(rows[name].values()),'all_clock_pairs':cohorts(rows[name]),
              'all_clock_summaries':t['timing_summary'],'all_fmax':t['fmax'],
              'worst_CPU_system_paths':paths(t,True),'worst_whole_system_paths':paths(t,False)}
 a,b=[receipts[n] for n in names];need(a['binary_sha256']==b['binary_sha256'],'route binary mismatch')
 if (ROOT/'archive-mode.json').exists():need(read(ROOT/'archive-mode.json')['excluded_binary_sha256']==a['binary_sha256'],'archived binary identity mismatch')
 else:need(sha(ROOT/'nextpnr-mistral')==a['binary_sha256'],'frozen binary mismatch')
 report_input=b['inputs']['--remap-private-pair-critical']['path']
 need(b['nextpnr_command']==a['nextpnr_command']+['--remap-private-pair-critical',report_input,'--remap-private-pair-candidate','0'],'unexpected route command difference')
 need({k:v for k,v in b['inputs'].items() if k!='--remap-private-pair-critical'}==a['inputs'],'unexpected input difference')
 need(a['committed_source_verification']==b['committed_source_verification'],'route committed sources differ')
 ar,br=[rows[n] for n in names];deltas=[];counts={m:Counter() for m in ['setup','hold']};cohort_deltas=defaultdict(lambda:{m:Counter() for m in ['setup','hold']})
 identity_equal=ar.keys()==br.keys();flags_equal=True
 for key in sorted(set(ar)|set(br)):
  x,y=ar.get(key),br.get(key);entry={'identity':json.loads(key[0]),'launch':key[1],'capture':key[2],'default':x,'selected':y}
  if x is None or y is None:
   entry['inventory_change']='added' if x is None else 'removed';flags_equal=False
  else:
   entry['all_fields_equal']=x==y
   fields=set(x)|set(y);entry['all_field_deltas']={k:{'before':x.get(k),'after':y.get(k)} for k in sorted(fields) if k not in x or k not in y or x[k]!=y[k]}
   margins={'setup','hold','min_path','max_path'}
   if {k:v for k,v in x.items() if k not in margins}!={k:v for k,v in y.items() if k not in margins}:flags_equal=False
   entry['margin_delta_ps']={m:y[m]-x[m] if type(x.get(m)) in [int,float] and type(y.get(m)) in [int,float] else None for m in margins}
   for margin,flag in [('setup','setup_timed'),('hold','hold_related')]:
    if x[flag] and y[flag]:
     d=y[margin]-x[margin];label='improved' if d>0 else 'regressed' if d<0 else 'unchanged';counts[margin][label]+=1;cohort_deltas[key[1:]][margin][label]+=1
  deltas.append(entry)
 metadata={}
 for key in sorted((set(snapshots[names[0]])|set(snapshots[names[1]]))-{'endpoints'}):
  x,y=snapshots[names[0]].get(key),snapshots[names[1]].get(key)
  metadata[key]={'present_default':key in snapshots[names[0]],'present_selected':key in snapshots[names[1]],'equal':key in snapshots[names[0]] and key in snapshots[names[1]] and x==y,'default':x,'selected':y}
 detailed_margin_summary={}
 for margin,flag in [('setup','setup_timed'),('hold','hold_related')]:
  comparable=[entry for entry in deltas if entry['default'] is not None and entry['selected'] is not None and entry['default'][flag] and entry['selected'][flag]]
  values=[entry['margin_delta_ps'][margin] for entry in comparable]
  detailed_margin_summary[margin]={'largest_improvement_ps':max(values,default=None),'largest_regression_ps':min(values,default=None),
       'positive_margin_regressions':sum(entry['default'][margin]>0 and entry['selected'][margin]<entry['default'][margin] for entry in comparable),
       'previously_negative_now_nonnegative':sum(entry['default'][margin]<0<=entry['selected'][margin] for entry in comparable),
       'previously_nonnegative_now_negative':sum(entry['selected'][margin]<0<=entry['default'][margin] for entry in comparable)}
 def saved_path(report,entry):
  launch=('posedge ' if entry['launch'][1]==0 else 'negedge ')+entry['launch'][0]
  capture=('posedge ' if entry['capture'][1]==0 else 'negedge ')+entry['capture'][0]
  matches=[path for path in report['critical_paths'] if path['from']==launch and path['to']==capture and
           [path['path'][-1]['to']['cell'],path['path'][-1]['to']['port']]==entry['identity']]
  need(len(matches)<=1,'ambiguous bounded path identity')
  if not matches:return None
  path=matches[0];source=next((s['from'] for s in path['path'] if s['type']=='clk-to-q'),None)
  family='other_or_unavailable'
  if source:
   cell=source['cell']
   if cell.startswith('system.machine.cpu.'):family='CPU'
   elif '.mda.' in cell:family='MDA'
   elif '.cga.' in cell:family='CGA'
   elif '.pic_device.' in cell:family='PIC'
  return {'actual_saved_launch_cell_and_pin':source,'family_inferred_from_actual_launch_cell':family,'complete_path':path}
 old_negative=[]
 for entry in deltas:
  if entry['default'] is not None and entry['default']['setup_timed'] and entry['default']['setup']<0:
   old_negative.append({**entry,'default_saved_setup_path':saved_path(reports['default'],entry),'selected_saved_setup_path':saved_path(reports['selected-0'],entry)})
 timing_categories={}
 for key in sorted(set(reports[names[0]])|set(reports[names[1]])):
  x,y=reports[names[0]].get(key),reports[names[1]].get(key)
  entry={'present_default':key in reports[names[0]],'present_selected':key in reports[names[1]],'equal':key in reports[names[0]] and key in reports[names[1]] and x==y}
  if key not in ['critical_paths','detailed_net_timings']:entry.update(default=x,selected=y)
  else:
   def k(v):
    if key=='critical_paths':return v['from'],v['to'],v['path'][-1]['to']['cell'],v['path'][-1]['to']['port']
    return v['driver'],v['port'],v['event'],v['net']
   left={};right={}
   for target,values in [(left,x),(right,y)]:
    for position,value in enumerate(values):
     identity=k(value);need(identity not in target,'duplicate timing record');target[identity]=(position,value)
   entry.update(default_count=len(left),selected_count=len(right),identities_equal=left.keys()==right.keys())
   changes=[];order=[]
   for identity in sorted(set(left)|set(right)):
    old,new=left.get(identity),right.get(identity)
    if old is None or new is None or old[1]!=new[1]:changes.append({'identity':identity,'default':old[1] if old else None,'selected':new[1] if new else None})
    if old and new and old[0]!=new[0]:order.append({'identity':identity,'default_index':old[0],'selected_index':new[0]})
   entry.update(all_changed_records=changes,all_record_order_changes=order)
  timing_categories[key]=entry
 reference=ROOT/'references/prior-fixed-route' if (ROOT/'archive-mode.json').exists() else ROOT.parent/'post-route-checkpoint-20261022/route-only';reference_comparison={}
 prior=read(reference/'receipt.json');need(sha(reference/'receipt.json')==a['reference_receipt_sha256'],'prior reference receipt mismatch')
 for name,digest in prior['artifacts'].items():need(sha(reference/name)==digest,'prior reference artifact mismatch')
 for name in ['diagnostic.rbf','routed.json','timing.json','endpoints.json']:
  reference_comparison[name]={'reference_sha256':sha(reference/name),'default_sha256':sha(ROOT/'route-default'/name),'byte_identical':(reference/name).read_bytes()==(ROOT/'route-default'/name).read_bytes()}
 old_graph,new_graph=read(reference/'routed.json'),read(ROOT/'route-default/routed.json')
 default_graph={'top_level_field_inventory_equal':old_graph.keys()==new_graph.keys(),
                'creator_before':old_graph.get('creator'),'creator_after':new_graph.get('creator'),
                'every_other_serialized_field_equal':{k:v for k,v in old_graph.items() if k!='creator'}=={k:v for k,v in new_graph.items() if k!='creator'}}
 result={'status':'complete_comparison','scope':'Complete final native reports for two fresh routes; physical IO and hardware qualification remain separate.',
         'checker_sha256':sha(Path(__file__)),'runs':runs,'endpoint_identity_inventory_equal':identity_equal,
         'all_row_domain_windows_and_flags_equal':flags_equal,'all_nonendpoint_categories':metadata,
         'all_metadata_categories_equal':all(v['equal'] for v in metadata.values()),'every_endpoint_row':deltas,
         'native_margin_delta_counts':counts,'all_clock_pair_delta_counts':[{'launch':k[0],'capture':k[1],'counts':v} for k,v in sorted(cohort_deltas.items())],
         'margin_extrema_and_positive_regressions':detailed_margin_summary,'every_previously_failing_endpoint_with_actual_saved_source':old_negative,
         'all_emitted_timing_categories':timing_categories,'default_vs_prior_fixed_route_artifact_bytes':reference_comparison,
         'default_vs_prior_fixed_complete_graph':default_graph,
         'pair_charge_seconds':str(sum(Decimal(str(receipts[n]['charged_seconds'])) for n in names)),
         'charge_scope':'Two root-launched routes only; prior reference and CPU preparations are excluded.',
         'limits':['No report or graph intersection hides removed/added identities. All metadata categories and all endpoint rows are retained.',
                   'Critical path lists remain bounded report detail; the complete endpoint ledger determines setup/hold inventory.',
                   'Boolean final-graph proof, native route topology, RBF configuration, board obligations and hardware acceptance are separate.']}
 (R/'route-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'status':result['status'],'runs':{n:{k:runs[n][k] for k in ['returncode','rows','setup','hold','unsupported_count']} for n in names},
                   'identities_equal':identity_equal,'windows_flags_equal':flags_equal,'all_metadata_equal':result['all_metadata_categories_equal'],
                   'delta_counts':counts,'pair_charge_seconds':result['pair_charge_seconds']},indent=2))
if __name__=='__main__':main()
