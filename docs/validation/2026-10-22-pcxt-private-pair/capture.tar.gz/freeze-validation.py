#!/usr/bin/env python3
"""Freeze final tests without altering the original CPU preparation identity."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
BUILD = SOURCE.parent / 'build-candidate'
LOGS = Path('/tmp/pcxt-private-pair')
FIXTURE = 'mistral/tests/private_pair_decomposition_backend.cc'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def command(*args):
    return subprocess.check_output(args, cwd=SOURCE, text=True).strip()


def passed(path):
    return set(re.findall(r'^\[       OK \] (\S+) \(', path.read_text(), re.M))


def main():
    initial_path = ROOT / 'source-identity.json'
    initial_hash = sha(initial_path)
    initial = json.loads(initial_path.read_text())
    stage1 = LOGS / 'private-pair-native-stage1.log'
    stage2 = LOGS / 'private-pair-native-stage2.log'
    first, second = passed(stage1), passed(stage2)
    assert len(first) == 32 and len(second) == 16 and not first & second
    assert '[  PASSED  ] 16 tests.' in stage2.read_text()
    assert '[  FAILED  ]' not in stage2.read_text()
    cli = LOGS / 'private-pair-cli.log'
    assert 'Ran 7 tests' in cli.read_text() and cli.read_text().rstrip().endswith('OK')
    assert sha(ROOT / 'nextpnr-mistral') == initial['binary_sha256']
    assert sha(BUILD / 'nextpnr-mistral') == initial['binary_sha256']
    hashes = {name: sha(SOURCE / name) for name in initial['source_files']}
    changed = [name for name, digest in hashes.items() if initial['source_files'][name] != digest]
    assert changed == [FIXTURE], changed
    subprocess.run(['git', 'diff', '--check'], cwd=SOURCE, check=True)
    target = ROOT / 'final-validation'
    target.mkdir(exist_ok=False)
    for name in hashes:
        dest = target / 'source' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE / name, dest)
    retained_logs = [
        'private-pair-stage6-final-build.log', 'private-pair-stage7-fixture-build.log',
        'private-pair-native-stage1.log', 'private-pair-native-stage2.log',
        'private-pair-cli.log', 'private-pair-pure-test.log',
    ]
    for name in retained_logs:
        shutil.copyfile(LOGS / name, target / name)
    receipts = {}
    for case in ('default', 'list', 'selected-0'):
        path = ROOT / ('prepare-' + case) / 'receipt.json'
        receipt = json.loads(path.read_text())
        assert receipt['returncode'] == 0
        assert receipt['source_identity'] == initial
        assert receipt['binary_sha256'] == initial['binary_sha256']
        receipts[case] = sha(path)
    report = {
        'scope': 'Host-only validation of a default-off private ALUT3-to-ALUT5 decomposition; no routed or hardware acceptance',
        'source_parent_at_validation': command('git', 'rev-parse', 'HEAD'),
        'parent_tree_at_validation': command('git', 'rev-parse', 'HEAD^{tree}'),
        'build_start_parent': initial['build_start_parent'],
        'original_preparation_identity_sha256': initial_hash,
        'source_files': hashes,
        'source_changes_after_cpu_preparations': changed,
        'test_only_correction': 'Connect the M10K B1EN fixture to PIN_1/VCC; assert native registered timing class and reject CFG_ASYNC_READ; format two independent physical oracle branches. Production source and binary are unchanged.',
        'binary_sha256': initial['binary_sha256'],
        'native_test_binary_sha256': sha(BUILD / 'nextpnr-mistral-test'),
        'validation': {
            'unique_native_and_pure_tests_passed': len(first | second),
            'stage1_passed': sorted(first), 'stage2_passed': sorted(second),
            'initial_fixture_failure_preserved': True,
            'cli_tests_passed': 7,
            'git_diff_check_passed': True,
            'logs': {name: sha(target / name) for name in retained_logs},
        },
        'preparation_receipts_sha256': receipts,
        'selected_candidate_flags': ['--remap-private-pair-critical', str(ROOT.parent / 'post-route-checkpoint-20261022/prepare-default/predicted-timing.json'), '--remap-private-pair-candidate', '0'],
        'critical_route_budget_32_compatible': True,
        'full_route_requirements': 'Retain the complete original recipe and fresh raw input; remove --no-route, use --router gpu and --rbf; root owns the full route and acceptance evidence.',
        'frozen_source_and_binary': True,
        'source_commit_pending_parent_review': True,
        'freeze_script_sha256': sha(__file__),
    }
    (ROOT / 'final-validation.json').write_text(json.dumps(report, indent=2) + '\n')
    assert sha(initial_path) == initial_hash
    print(json.dumps({'native_and_pure_passed': 48, 'cli_passed': 7,
                      'binary_sha256': report['binary_sha256'],
                      'final_validation_sha256': sha(ROOT / 'final-validation.json')}, indent=2))


if __name__ == '__main__':
    main()
