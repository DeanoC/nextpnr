#!/usr/bin/env python3
"""Paired fresh full routes of a frozen private-pair compiler; no reloaded placement."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import subprocess
import time
ROOT = Path(__file__).resolve().parent
TASK = ROOT.parent.parent
REFERENCE = ROOT.parent / 'post-route-checkpoint-20261022/route-only'
REPORT = ROOT.parent / 'post-route-checkpoint-20261022/prepare-default/predicted-timing.json'
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def run(case):
    base = json.loads((REFERENCE/'receipt.json').read_text())
    committed = json.loads((ROOT/'committed-source-verification.json').read_text())
    proof = json.loads((ROOT/'analysis/logical-proof.json').read_text())
    assert committed['all_recorded_source_bytes_match_commit'] is True
    assert committed['native_tests_passed'] == 48 and committed['cli_tests_passed'] == 7
    assert proof['status'] == 'pass' and len(proof['all128_rows']) == 128
    assert sha(ROOT/'nextpnr-mistral') == committed['binary_sha256'] == proof['binary_sha256']
    command = base['nextpnr_command'][:]
    command[0] = str(ROOT/'nextpnr-mistral')
    inputs = dict(base['inputs'])
    if case == 'selected-0':
        command += ['--remap-private-pair-critical', str(REPORT), '--remap-private-pair-candidate', '0']
        inputs['--remap-private-pair-critical'] = {'path':str(REPORT), 'sha256':sha(REPORT)}
    assert '--no-route' not in command and '--rbf' in command and '--critical-route-budget' in command
    for item in inputs.values():
        assert sha(item['path']) == item['sha256']
    target = ROOT/('route-'+case)
    target.mkdir(exist_ok=False)
    wrapped = [str(TASK/'scripts/gpu-run'), '--phase-lease', '--owner', 'pcxt-timing', '--label', 'pcxt-private-pair-'+case, '--', *command]
    env = {'NEXTPNR_REQUIRE_GPU':'1','GPU_LEASE_MAX_PER_OWNER':'2'}
    receipt = {'command':wrapped,'nextpnr_command':command,'binary_sha256':committed['binary_sha256'],
               'committed_source_verification':committed,'committed_source_verification_sha256':sha(ROOT/'committed-source-verification.json'),
               'inputs':inputs,'reference_receipt_sha256':sha(REFERENCE/'receipt.json'),
               'logical_preparation_proof_sha256':sha(ROOT/'analysis/logical-proof.json'),
               'env':env,'recipe':'original raw synthesis seed1/native hard-block windows/correct spreading/overflow17/route budget32; '+case,
               'limit':'native router bounds; no external GPU-job termination',
               'evidence':'fresh leased GPU host diagnostic; no timing closure, production seal or hardware acceptance'}
    started = time.monotonic()
    with (target/'nextpnr.log').open('w') as log:
        receipt['returncode'] = subprocess.run(wrapped, cwd=target, env=dict(os.environ, **env), stdout=log, stderr=subprocess.STDOUT).returncode
    receipt['charged_seconds'] = time.monotonic()-started
    for item in inputs.values():
        assert sha(item['path']) == item['sha256']
    assert sha(ROOT/'nextpnr-mistral') == receipt['binary_sha256']
    assert sha(ROOT/'committed-source-verification.json') == receipt['committed_source_verification_sha256']
    assert sha(ROOT/'analysis/logical-proof.json') == receipt['logical_preparation_proof_sha256']
    receipt['artifacts'] = {p.name:sha(p) for p in sorted(target.iterdir()) if p.is_file()}
    (target/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'case':case,'returncode':receipt['returncode'],'charged_seconds':receipt['charged_seconds']}),flush=True)
    return receipt
if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(run,['default','selected-0']))
