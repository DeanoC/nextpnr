# Private-pair candidate 0: independent preparation evidence

Candidate 0 preserves the complete serialized logical graph at its external
boundary and improves four emitted MDA setup estimates by 851 ps. It is eligible
for a fresh route experiment. This preparation is not timing closure or physical
acceptance.

The original and selected CPU preparations use frozen production binary
`57afe29115d5a144243b8d63af2035c1f7e43f65664bc53747e5879fa02381c8`, built from
base `bd87c5304353e1df36e2a4567c19312023fa59e8` plus the receipt-captured private
pair changes. `verify-runtime.py` binds all three preparation receipts to the
same original source identity, verifies every original and final source snapshot,
and confirms that only the later backend test fixture changed. The corrected
fixture and its 48 pure/native and 7 CLI test results are separately preserved
in `../final-validation.json`; this analysis verifies the log hashes, without
claiming to have rerun those tests.

## Complete logical proof

`prove.py` compares every field of all 10,448 cells and the complete module,
net-alias, top-port, clock and settings inventories. It proves the 128 input
assignments of the actual ALUT3/ALUT5 composition, including actual `PIN_INV`
interpretation. Every output row is equal. Producer Q has exactly one consumer
and no top-port observer. All outside functions, logical pin states and users
are unchanged. All original cell identities, types, BELs and strengths remain.

The only logical changes are the two LUT masks and the eight existing input
uses. The eight original signals retain their multiplicities; the private link
remains consumer E. Serialized JSON does not retain native `indexed_store`
slot indices, so this proof makes no independent claim about those indices.
Their preservation is covered by the native transaction tests.

Four serialized physical pin maps differ, confined to the two affected ALMs:
the pair itself and one stationary LUT mate in each ALM. All three stationary
cells in those ALMs are retained in the proof. The original placed JSON stores
placement scaffolds; the accepted transaction stores the native pin allocation.
Consequently, these scaffold-to-native map differences do not independently
prove or disprove a stationary mate mask change. The native baseline allocation,
mate mask guards and focused emitted-RBF tests cover that separate boundary.
No full-board RBF function or route proof is inferred here.

Five actual mutations reject: producer LUT bit, consumer LUT bit, consumer input
inversion, a new top-port observer of the private net, and an outside LUT bit.
All 128 truth rows, aliases, observers, eight uses and four map deltas are retained
in `logical-proof.json`.

## Every emitted timing record

`compare-timing.py` compares all seven report categories, all 3,376 detailed
driver records and their 17,203 rows, all four clock summaries/Fmax records,
all 2,355 bounded setup paths and the complete histogram. Every driver, source,
endpoint identity, check flag and path window is equal. Default and listing
reports are byte-identical. No emitted setup or hold margin regresses.

Only six detailed rows change; full identities and values are in
`timing-comparison.json`:

| Capture endpoint | Setup before → after (ns) | Hold before → after (ns) |
| --- | ---: | ---: |
| ISA RGBI Q5 DATAIN, MDA source | −1.910 → −1.059 | 2.415 → 2.415 |
| ISA RGBI Q7 DATAIN, MDA source | −1.910 → −1.059 | 2.415 → 2.415 |
| ISA RGBI Q DATAIN, MDA source | −1.630 → −0.779 | 2.135 → 2.135 |
| ISA RGBI Q6 DATAIN, MDA source | −1.453 → −0.602 | 2.135 → 2.135 |
| Stationary PIC mate's capture FF | 1.750 → 1.750 | 1.845 → 2.013 |
| MDA dot Q3 DATAIN | 7.068 → 7.068 | 0.985 → 1.348 |

Exactly four critical paths change, matching the four MDA setup rows; their
complete before/after segments are retained. All 570 path-order changes are
recorded separately, together with all six histogram-bin changes. There are
no dropped/intersected path or row identities.

All predicted clock summaries are unchanged:

| Clock | Achieved / required (MHz) | Setup WNS (ns) | Hold WNS (ns) |
| --- | ---: | ---: | ---: |
| pixel | 72.385 / 74.250 | −0.347 | 0.761 |
| clocks[0] | 75.591 / 100 | −3.229 | 0.761 |
| clocks[1] | 341.297 / 100 | 3.535 | 6.111 |
| clocks[2] | 123.885 / 100 | 1.446 | 3.884 |

Both reports contain 17,194 checked detail rows and 9 unchecked rows. Both have
1,006 negative setup estimates and zero negative hold estimates. Every emitted
launch/capture cohort is retained in the JSON. These counts are preparation
report records, not the routed 17,199-row qualification inventory.

The report explicitly sets `final_analogue_model=false`. Its setup paths are
bounded by the configured 1,024 paths per domain pair, and it emits no complete
hold-path list. It does not contain the full unsupported/static/constant contract
metadata or native endpoint domain/window ledger. Thus this comparison establishes
equality and nonregression only for everything actually emitted. The native live
guard source/tests establish their predicate separately; a fresh full route must
provide complete final setup/hold and coverage evidence.

No reload, GPU/full route, compiler edit or hardware operation was performed by
this analysis. CPU preparation has zero route charge. Parent owns source commit,
full route and archival integration. Reproduce the independent checks with
`python3 analysis/prove.py`, `python3 analysis/compare-timing.py` and
`python3 analysis/verify-runtime.py` from the containing experiment directory.
