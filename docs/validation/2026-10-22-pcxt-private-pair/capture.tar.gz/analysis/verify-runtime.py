#!/usr/bin/env python3
"""Bind receipt runtime sources separately from the later test fixture correction."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent;ROOT=R.parent
def need(value,message):
 if not value:raise ValueError(message)
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(path.read_text())
runtime=read(ROOT/'source-identity.json');final=read(ROOT/'final-validation.json')
for name in ['prepare-default','prepare-list','prepare-selected-0']:
 receipt=read(ROOT/name/'receipt.json');need(receipt['source_identity']==runtime,'receipt runtime identity differs')
 need(receipt['binary_sha256']==runtime['binary_sha256'],'receipt binary differs')
need(runtime['binary_sha256']==final['binary_sha256']==sha(ROOT/'nextpnr-mistral'),'binary not identical')
need(final['original_preparation_identity_sha256']==sha(ROOT/'source-identity.json'),'original source identity digest')
need(runtime['source_diff_sha256']==sha(ROOT/'source.diff'),'original source diff digest')
need(runtime['source_files'].keys()==final['source_files'].keys(),'source inventory differs')
changed=[]
for name in runtime['source_files']:
 need(sha(ROOT/'source'/name)==runtime['source_files'][name],'runtime snapshot digest '+name)
 need(sha(ROOT/'final-validation/source'/name)==final['source_files'][name],'final snapshot digest '+name)
 if runtime['source_files'][name]!=final['source_files'][name]:changed.append(name)
need(changed==['mistral/tests/private_pair_decomposition_backend.cc'],'production or unreviewed source change')
need(final['source_changes_after_cpu_preparations']==changed,'final identity change inventory')
for name,digest in final['validation']['logs'].items():need(sha(ROOT/'final-validation'/name)==digest,'validation log digest '+name)
result={'status':'pass','scope':'Frozen source, runtime binary, receipt and later fixture correction identity; does not rerun or extend native tests.',
 'runtime_source_parent':runtime['source_parent'],'runtime_source_identity_sha256':sha(ROOT/'source-identity.json'),
 'final_validation_sha256':sha(ROOT/'final-validation.json'),'binary_sha256':runtime['binary_sha256'],
 'complete_source_inventory':sorted(runtime['source_files']),'all_production_source_bytes_unchanged':True,
 'only_changed_test_source':changed,'receipt_runtime_identity_exact_in_all_three_preparations':True,
 'original_and_final_source_snapshots_all_hashes_verified':True,'validation_logs_all_hashes_verified':True,
 'fixture_correction':final['test_only_correction'],'checker_sha256':sha(Path(__file__))}
(R/'runtime-identity-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
