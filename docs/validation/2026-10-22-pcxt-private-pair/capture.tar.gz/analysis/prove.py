#!/usr/bin/env python3
"""Independent complete graph/Boolean proof; no native timing or physical signoff."""
from pathlib import Path
import collections,copy,hashlib,json,re
R=Path(__file__).resolve().parent;ROOT=R.parent
PRODUCER='system.machine.isa.slots[2].genblk1.mda.card.card.mode_MISTRAL_ALUT5_A_E_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_Q'
CONSUMER='system.machine.isa.slots[2].genblk1.mda.card.card.mode_MISTRAL_ALUT5_A_E_MISTRAL_ALUT5_Q'
PAIR={PRODUCER:3,CONSUMER:5}
def need(b,s):
 if not b:raise ValueError(s)
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'duplicate JSON key '+k);d[k]=v
 return d
def read(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pins(c):
 x=json.loads(bytes.fromhex(c['attributes']['FES_PINMAP_V1']).decode(),object_pairs_hook=unique);need(set(x)=={'count','pins'} and x['count']==len(x['pins']),'pin snapshot shape');return x['pins']
def alm(c):
 m=re.fullmatch(r'MISTRAL_(?:M?COMB|FF)\.(\d+)\.(\d+)\.(\d+)',c['attributes'].get('NEXTPNR_BEL',''))
 return (int(m[1]),int(m[2]),int(m[3])//6) if m else None
def edge_map(m):
 d=collections.defaultdict(list);u=collections.defaultdict(list)
 for name,c in m['cells'].items():
  need(set(c['connections'])==set(c['port_directions']),name+' port inventory')
  for p,bits in c['connections'].items():
   for lane,bit in enumerate(bits):
    if type(bit)!=int:continue
    direction=c['port_directions'][p];need(direction in ('input','output','inout'),'unknown port direction')
    if direction!='input':d[bit].append([name,p,lane])
    if direction!='output':u[bit].append([name,p,lane])
 for x in [d,u]:
  for k in x:x[k].sort()
 return d,u
def prove(a,b):
 need(set(a)==set(b)=={'creator','modules'},'root inventory');need(set(a['modules'])==set(b['modules']) and len(a['modules'])==1,'module inventory')
 am,bm=next(iter(a['modules'].values())),next(iter(b['modules'].values()));need(set(am)==set(bm),'module fields')
 for key in am:
  if key!='cells':need(am[key]==bm[key],'changed complete module field '+key)
 ac,bc=am['cells'],bm['cells'];need(set(ac)==set(bc),'cell inventory');need(set(PAIR)<=set(ac),'missing pair')
 affected={alm(ac[n]) for n in PAIR};need(None not in affected,'pair placement')
 physical=[];logical=[];params=[];mates=[]
 for name in sorted(ac):
  x,y=copy.deepcopy(ac[name]),copy.deepcopy(bc[name]);xp,yp=pins(x),pins(y)
  need(set(xp)==set(yp),'pin inventory '+name)
  if xp!=yp:
   need(alm(ac[name]) in affected,'physical map changed outside affected ALMs '+name)
   physical.append({'cell':name,'alm':alm(ac[name]),'before':xp,'after':yp})
  if name not in PAIR:
   need({k:v[0] for k,v in xp.items()}=={k:v[0] for k,v in yp.items()},'outside logical pin states '+name)
   if alm(ac[name]) in affected:mates.append({'cell':name,'type':x['type'],'before':xp,'after':yp})
  x['attributes'].pop('FES_PINMAP_V1');y['attributes'].pop('FES_PINMAP_V1')
  if name in PAIR:
   width=PAIR[name];need(x['type']==y['type']=='MISTRAL_ALUT'+str(width),'type changed')
   need(set(x['parameters'])==set(y['parameters'])=={'LUT'},'LUT parameters')
   for z in [x,y]:need(len(z['parameters']['LUT'])==1<<width and set(z['parameters']['LUT'])<={'0','1'},'undefined/wrong LUT mask')
   params.append({'cell':name,'before':x['parameters'].pop('LUT'),'after':y['parameters'].pop('LUT')})
   expected={chr(65+i) for i in range(width)}|{'Q'};need(set(x['connections'])==set(y['connections'])==expected,'pair ports')
   need(xp['Q'][0]==yp['Q'][0]==0,'inverted output')
   for port in sorted(expected-{'Q'}):
    need(xp[port][0] in [0,3] and yp[port][0] in [0,3],'constant/unknown pair input')
    old=x['connections'].pop(port);new=y['connections'].pop(port);need(len(old)==len(new)==1 and type(old[0])==type(new[0])==int,'non-scalar net')
    logical.append({'cell':name,'port':port,'before_net':old[0],'after_net':new[0],'before_state':xp[port][0],'after_state':yp[port][0]})
   for protected in ['keep','dont_touch','BEL','FES_SLOT']:need(protected not in x['attributes'] and protected not in y['attributes'],'protected pair')
  need(x==y,'outside allowed full cell fields changed '+name)
 d,u=edge_map(am);nd,nu=edge_map(bm);need(d==nd,'any driver changed')
 internal=ac[PRODUCER]['connections']['Q'][0];output=ac[CONSUMER]['connections']['Q'][0]
 need(internal!=output and d[internal]==[[PRODUCER,'Q',0]],'invalid private link')
 for users in [u,nu]:need(len(users[internal])==1 and users[internal][0][0]==CONSUMER,'producer internal observer')
 topbits={bit for p in am['ports'].values() for bit in p['bits']};need(internal not in topbits,'internal exposed at top')
 before_uses=collections.Counter(x['before_net'] for x in logical);after_uses=collections.Counter(x['after_net'] for x in logical)
 need(before_uses==after_uses and len(before_uses)==8 and all(v==1 for v in before_uses.values()),'eight signal-use multiplicities')
 frontier=sorted(set(before_uses)-{internal});need(len(frontier)==7 and output not in frontier,'seven external independent sources')
 aliases=collections.defaultdict(list)
 for name,v in am['netnames'].items():
  for lane,bit in enumerate(v['bits']):aliases[bit].append([name,lane])
 for bit in before_uses:
  need(bit not in topbits and len(d[bit])==1,'unsafe source/top observer')
  for name,lane in aliases[bit]:
   attr=am['netnames'][name].get('attributes',{});need(not set(attr)&{'keep','dont_touch','BEL','FES_SLOT'},'protected input/link net')
 for bit in set(u)|set(nu):
  left=[p for p in u.get(bit,[]) if p[0] not in PAIR];right=[p for p in nu.get(bit,[]) if p[0] not in PAIR];need(left==right,'outside net observer changed')
 def evaluate(cells,values):
  def cell(name):
   c=cells[name];pm=pins(c);index=0
   for i in range(PAIR[name]):
    p=chr(65+i);bit=c['connections'][p][0];raw=values[bit];index|=(raw^(pm[p][0]==3))<<i
   return (int(c['parameters']['LUT'],2)>>index)&1
  v=dict(values);values=v;v[internal]=cell(PRODUCER);return v[internal],cell(CONSUMER)
 table=[]
 for row in range(128):
  values={bit:(row>>i)&1 for i,bit in enumerate(frontier)};x=evaluate(ac,values);y=evaluate(bc,values);need(x[1]==y[1],'composed output differs at row '+str(row));table.append({'row':row,'external_values':[values[bit] for bit in frontier],'original_internal':x[0],'candidate_internal':y[0],'original_output':x[1],'candidate_output':y[1]})
 return {'scope':'Complete serialized logical graph and exhaustive two-LUT Boolean proof only; native slot indices/physical masks/timing are separate obligations.','complete_cells':len(ac),'complete_alias_records':len(am['netnames']),'complete_top_ports':len(am['ports']),'all_module_clocks_settings_attributes_and_top_ports_equal':True,'all_cells_and_BELs_preserved':True,'all_outside_functions_and_observers_equal':True,'pair_parameter_delta':params,'all_eight_logical_input_uses':logical,'eight_original_native_storage_indices_not_serialized':True,'private_internal_net':{'bit':internal,'aliases':aliases[internal],'driver':d[internal],'before_users':u[internal],'after_users':nu[internal]},'complete_frontier':[{'bit':bit,'aliases':aliases[bit],'driver':d[bit],'before_all_users':u[bit],'after_all_users':nu[bit]} for bit in frontier],'output_boundary':{'bit':output,'aliases':aliases[output],'all_users':u[output]},'all128_rows':table,'affected_ALMs':sorted(affected),'every_physical_map_delta':physical,'all_affected_stationary_cell_maps':mates,'physical_scope':'Physical changes are confined to affected ALMs; placement-scaffold maps are retained separately. This proof does not infer native pre-route mate mask equality or routed timing.'}
def main():
 folders=[ROOT/'prepare-default',ROOT/'prepare-list',ROOT/'prepare-selected-0'];receipts=[]
 for p in folders:
  rec=read(p/'receipt.json');need(rec['returncode']==0 and rec['charged_seconds']==0,'CPU receipt')
  for name,h in rec['artifacts'].items():need(sha(p/name)==h,'artifact digest '+name)
  for info in rec['inputs'].values():need(sha(Path(info['path']))==info['sha256'],'input digest')
  receipts.append(rec)
 need(len({r['binary_sha256'] for r in receipts})==1,'mixed binary');need(sha(ROOT/'nextpnr-mistral')==receipts[0]['binary_sha256'],'binary digest')
 need(receipts[0]['source_identity']==receipts[1]['source_identity']==receipts[2]['source_identity'],'mixed runtime source identity')
 need((folders[0]/'placed.json').read_bytes()==(folders[1]/'placed.json').read_bytes(),'listing modified checkpoint')
 a,b=read(folders[0]/'placed.json'),read(folders[2]/'placed.json');result=prove(a,b);negatives=[]
 def reject(label,mutation):
  changed=copy.deepcopy(b);mutation(changed['modules']['top'])
  try:prove(a,changed)
  except (ValueError,KeyError) as e:negatives.append({'mutation':label,'rejected':True,'reason':str(e)})
  else:raise ValueError('accepted negative '+label)
 def flip(m,name):
  v=m['cells'][name]['parameters']['LUT'];m['cells'][name]['parameters']['LUT']=v[:-1]+('0' if v[-1]=='1' else '1')
 reject('producer LUT bit',lambda m:flip(m,PRODUCER));reject('consumer LUT bit',lambda m:flip(m,CONSUMER))
 def invert(m):
  c=m['cells'][CONSUMER];p=pins(c);p['A'][0]=3-p['A'][0];c['attributes']['FES_PINMAP_V1']=json.dumps({'count':len(p),'pins':p}).encode().hex()
 reject('actual consumer PIN_INV',invert)
 def observer(m):m['ports']['mutation_internal']={'direction':'output','bits':m['cells'][PRODUCER]['connections']['Q']}
 reject('new internal top observer',observer)
 outside=next(n for n,c in a['modules']['top']['cells'].items() if n not in PAIR and c['type'].startswith('MISTRAL_ALUT') and 'LUT' in c['parameters']);reject('outside LUT function',lambda m:flip(m,outside))
 result.update({'status':'pass','negative_mutations':negatives,'binary_sha256':receipts[0]['binary_sha256'],'runtime_source_identity_from_all_three_receipts':receipts[0]['source_identity'],'input_receipts_sha256':{p.name:sha(p/'receipt.json') for p in folders},'checker_sha256':sha(Path(__file__)),'no_route_or_hardware_or_shared_source_change':True})
 (R/'logical-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'pass','rows':128,'cells':result['complete_cells'],'physical_map_changes':len(result['every_physical_map_delta']),'negative_mutations':len(negatives),'timing_signoff':False},indent=2))
if __name__=='__main__':main()
