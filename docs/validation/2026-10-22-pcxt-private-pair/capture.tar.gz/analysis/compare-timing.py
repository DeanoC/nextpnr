#!/usr/bin/env python3
"""Compare every emitted preparation record without inventing endpoint coverage."""
from pathlib import Path
import collections, hashlib, json

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'analysis'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate JSON key ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=unique)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def indexed(values, key, label):
    result = {}
    for index, value in enumerate(values):
        identity = key(value)
        need(identity not in result, 'duplicate ' + label + ' identity')
        result[identity] = (index, value)
    return result


def detail_key(value):
    return value['driver'], value['port'], value['event'], value['net']


def endpoint_key(value):
    return value['cell'], value['port'], value['event']


def path_key(value):
    endpoint = value['path'][-1]
    need(endpoint['type'] == 'setup', 'unrecognized critical path endpoint')
    return value['from'], value['to'], endpoint['to']['cell'], endpoint['to']['port']


def cohort_summary(report):
    cohorts = collections.defaultdict(list)
    for detail in report['detailed_net_timings']:
        for endpoint in detail['endpoints']:
            cohorts[(detail['event'], endpoint['event'])].append(endpoint)
    result = []
    for identity, rows in sorted(cohorts.items()):
        entry = {'launch_event': identity[0], 'capture_event': identity[1], 'emitted_rows': len(rows)}
        for kind in ['setup', 'hold']:
            checked = [row[kind + '_slack_ns'] for row in rows if row[kind + '_checked']]
            entry[kind] = {'checked_rows': len(checked), 'failed_rows': sum(value < 0 for value in checked),
                           'minimum_slack_ns': min(checked) if checked else None}
        result.append(entry)
    return result


def main():
    names = ['prepare-default', 'prepare-list', 'prepare-selected-0']
    files = [ROOT / name / 'predicted-timing.json' for name in names]
    receipts = [read(ROOT / name / 'receipt.json') for name in names]
    for path, receipt in zip(files, receipts):
        need(receipt['returncode'] == 0 and receipt['charged_seconds'] == 0, 'not successful CPU preparation')
        need(receipt['artifacts']['predicted-timing.json'] == sha(path), 'report receipt digest mismatch')
    need(receipts[0]['source_identity'] == receipts[1]['source_identity'] == receipts[2]['source_identity'],
         'CPU runtime source identities differ')
    need(len({receipt['binary_sha256'] for receipt in receipts}) == 1, 'CPU binary identities differ')
    need(sha(ROOT / 'nextpnr-mistral') == receipts[0]['binary_sha256'], 'frozen binary digest mismatch')
    need(files[0].read_bytes() == files[1].read_bytes(), 'listing changed the emitted timing report')
    before, after = read(files[0]), read(files[2])
    expected = {'critical_paths', 'detailed_net_timings', 'fmax', 'slack_histogram_ps',
                'timing_report_paths', 'timing_summary', 'utilization'}
    need(set(before) == set(after) == expected, 'emitted report category inventory changed/unreviewed')
    unchanged = ['fmax', 'timing_report_paths', 'timing_summary', 'utilization']
    for category in unchanged:
        need(before[category] == after[category], 'changed category ' + category)
    need(before['timing_summary']['final_analogue_model'] is False, 'unexpected final timing model')

    detail_before = indexed(before['detailed_net_timings'], detail_key, 'original driver')
    detail_after = indexed(after['detailed_net_timings'], detail_key, 'candidate driver')
    need(detail_before.keys() == detail_after.keys(), 'emitted driver inventory changed')
    deltas, detail_orders, row_orders = [], [], []
    row_count = 0
    for identity in sorted(detail_before):
        bi, bv = detail_before[identity]
        ai, av = detail_after[identity]
        need(set(bv) == set(av) == {'driver', 'endpoints', 'event', 'net', 'port', 'sources'}, 'driver field inventory')
        need({k: v for k, v in bv.items() if k != 'endpoints'} ==
             {k: v for k, v in av.items() if k != 'endpoints'}, 'driver metadata changed')
        if bi != ai:
            detail_orders.append({'identity': identity, 'before_index': bi, 'after_index': ai})
        be = indexed(bv['endpoints'], endpoint_key, 'original endpoint')
        ae = indexed(av['endpoints'], endpoint_key, 'candidate endpoint')
        need(be.keys() == ae.keys(), 'emitted endpoint inventory changed')
        row_count += len(be)
        for endpoint in sorted(be):
            bj, x = be[endpoint]
            aj, y = ae[endpoint]
            need(set(x) == set(y) == {'cell', 'delay', 'event', 'hold_checked', 'hold_slack_ns',
                                     'port', 'setup_checked', 'setup_slack_ns'}, 'endpoint field inventory')
            for field in ['cell', 'event', 'port', 'hold_checked', 'setup_checked']:
                need(x[field] == y[field], 'endpoint identity or check flag changed')
            if bj != aj:
                row_orders.append({'driver': identity, 'endpoint': endpoint, 'before_index': bj, 'after_index': aj})
            if x != y:
                deltas.append({'driver_identity': identity, 'endpoint_identity': endpoint,
                               'before': x, 'after': y,
                               'setup_delta_ns': y['setup_slack_ns'] - x['setup_slack_ns'],
                               'hold_delta_ns': y['hold_slack_ns'] - x['hold_slack_ns']})
            for kind in ['setup', 'hold']:
                need(not x[kind + '_checked'] or y[kind + '_slack_ns'] >= x[kind + '_slack_ns'],
                     'emitted ' + kind + ' margin regression')

    bp = indexed(before['critical_paths'], path_key, 'original path')
    ap = indexed(after['critical_paths'], path_key, 'candidate path')
    need(bp.keys() == ap.keys(), 'bounded path endpoint inventory changed')
    path_deltas, path_orders = [], []
    for identity in sorted(bp):
        bi, x = bp[identity]
        ai, y = ap[identity]
        need(set(x) == set(y) == {'criticality', 'from', 'max_delay', 'path', 'to'}, 'path fields')
        need(x['from'] == y['from'] and x['to'] == y['to'] and x['max_delay'] == y['max_delay'],
             'bounded path clock/window changed')
        if bi != ai:
            path_orders.append({'identity': identity, 'before_index': bi, 'after_index': ai})
        if x != y:
            path_deltas.append({'identity': identity, 'before': x, 'after': y,
                                'before_sum_delay_ns': sum(segment['delay'] for segment in x['path']),
                                'after_sum_delay_ns': sum(segment['delay'] for segment in y['path'])})

    histogram = []
    for key in sorted(set(before['slack_histogram_ps']) | set(after['slack_histogram_ps']), key=int):
        x, y = before['slack_histogram_ps'].get(key), after['slack_histogram_ps'].get(key)
        if x != y:
            histogram.append({'bin_ps': key, 'before_count': x, 'after_count': y})
    result = {
        'status': 'pass', 'scope': 'Every actually emitted predicted-timing category, record and path; not a qualification endpoint ledger.',
        'binary_sha256': receipts[0]['binary_sha256'], 'runtime_source_identity_from_all_three_receipts': receipts[0]['source_identity'],
        'report_sha256': {name: sha(path) for name, path in zip(names, files)},
        'input_receipt_sha256': {name: sha(ROOT / name / 'receipt.json') for name in names},
        'checker_sha256': sha(Path(__file__)), 'complete_top_level_categories': sorted(expected),
        'default_list_report_bytes_identical': True, 'exact_unchanged_categories': {key: before[key] for key in unchanged},
        'detail_records': len(detail_before), 'emitted_detail_rows': row_count,
        'all_driver_endpoint_identities_sources_and_check_flags_equal': True,
        'no_emitted_setup_or_hold_margin_regression': True,
        'all_changed_detail_rows': deltas, 'all_detail_record_order_changes': detail_orders,
        'all_detail_endpoint_order_changes': row_orders,
        'all_emitted_cohorts_before': cohort_summary(before), 'all_emitted_cohorts_after': cohort_summary(after),
        'critical_paths': {'count_before': len(bp), 'count_after': len(ap), 'identities_equal': True,
                           'all_changed_paths': path_deltas, 'all_order_changes': path_orders},
        'slack_histogram': {'bins_before': len(before['slack_histogram_ps']), 'bins_after': len(after['slack_histogram_ps']),
                            'count_before': sum(before['slack_histogram_ps'].values()),
                            'count_after': sum(after['slack_histogram_ps'].values()), 'all_changes': histogram},
        'limits': [
            'The 17203 emitted detailed rows are report records, not the native qualified endpoint ledger. Their count is not the routed 17199-row qualification inventory.',
            'This report has no complete unsupported/static/constant contract metadata or native domain/window inventory. No complete coverage equality is claimed.',
            '2355 setup paths are bounded by timing_report_paths=1024 per report cohort; no full hold-path inventory is emitted.',
            'Clock summaries and detailed setup/hold margins are pre-route placement estimates, final_analogue_model=false.',
            'The in-process native guard source and focused tests establish its predicate separately; a fresh full route must establish final timing and coverage.',
            'No checkpoint reload or native route was run by this analysis.'
        ]}
    (OUT / 'timing-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': 'pass', 'detail_records': len(detail_before), 'emitted_rows': row_count,
                      'changed_rows': len(deltas), 'changed_paths': len(path_deltas),
                      'setup_improvements': sum(x['setup_delta_ns'] > 0 for x in deltas),
                      'hold_improvements': sum(x['hold_delta_ns'] > 0 for x in deltas),
                      'emitted_regressions': 0, 'clock_summaries_equal': True, 'timing_signoff': False}, indent=2))


if __name__ == '__main__':
    main()
