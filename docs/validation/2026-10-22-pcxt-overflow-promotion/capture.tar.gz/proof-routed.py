#!/usr/bin/env python3
"""Complete prepared-to-routed bridges and transitive AX15 Boolean proof.
Every route-added helper is proved before substitution. No graph intersection.
Physical configuration/RBF encoding, electrical timing and hardware are excluded.
"""
from pathlib import Path
import copy,hashlib,importlib.util,json,subprocess,sys
base=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('route_support',base/'proof-routed-support.py');support=importlib.util.module_from_spec(spec);spec.loader.exec_module(support)
read=support.read;sha=support.digest;require=support.require
manifest=read(base/'inputs/manifest.json');binary=Path(manifest['binary']);require(sha(binary)==manifest['binary_sha256'],'frozen compiler changed')
checks=[]
for script,args in [('prove-pair.py',[str(base/'promote-ax15')]),('prove-whole.py',[])]:
 command=[sys.executable,str(base/script),*args];result=subprocess.run(command,capture_output=True,text=True)
 require(result.returncode==0,'prepared proof failed: '+result.stdout+result.stderr)
 checks.append({'command':command,'script_sha256':sha(base/script),'returncode':result.returncode,'output':result.stdout})
prepared_paths=[base/'reload-baseline/placed.json',base/'promote-ax15/placed.json'];routed_paths=[base/'route-baseline/routed.json',base/'route-candidate/routed.json'];bridges=[];commands=[];docs=[];prepared=[]
for label,pp,rp in zip(('baseline','candidate'),prepared_paths,routed_paths):
 receipt=read(rp.parent/'receipt.json');require(receipt['binary_sha256']==manifest['binary_sha256'],'route binary differs')
 require(receipt['input_sha256']==sha(pp),'prepared input hash differs')
 command=receipt['nextpnr_command'][:];i=command.index('--json')+1;require(Path(command[i])==pp,'route input differs');command[i]='<verified-prepared-input>';commands.append(command)
 for name,expected in receipt['artifacts'].items():require(sha(rp.parent/name)==expected,'route artifact differs: '+name)
 require(read(rp.parent/'timing.json')['timing_summary']['final_analogue_model'] is True,'report not final analogue')
 pd,rd=read(pp),read(rp);prepared.append(pd);docs.append(rd)
 bridge=support.prepared_bridge(pd,rd);bridge.update(label=label,prepared_path=str(pp),prepared_sha256=sha(pp),routed_path=str(rp),routed_sha256=sha(rp))
 bridges.append(bridge)
require(commands[0]==commands[1],'route recipes differ beyond proven input')
require(docs[0]['modules']['top']['settings']==docs[1]['modules']['top']['settings'],'final settings differ')
# Prepared bridge independently proves every output helper on both sides. The
# already recomputed complete pair/tree checks then establish transitivity.
negative=[]
original_bridge=bridges[1];helpers=original_bridge['route_generated_buffers_proved'];require(helpers,'no helper available for checker mutation tests')
name=helpers[0]['cell'];dest=helpers[0]['destination'][0];private=helpers[0]['private_net']
def rejects(label,mutate):
 changed=copy.deepcopy(docs[1]);mutate(changed['modules']['top'])
 try:support.prepared_bridge(prepared[1],changed)
 except (ValueError,AssertionError,KeyError) as error:negative.append({'case':label,'rejected':True,'reason':str(error)})
 else:raise AssertionError('checker accepted negative mutation: '+label)
def invert(m):
 cell=m['cells'][name];pins=support.unpack(cell['attributes']['FES_PINMAP_V1']);pins['pins']['A'][0]=3;cell['attributes']['FES_PINMAP_V1']=support.pack(pins)
rejects('route helper input inverted',invert)
rejects('route helper primitive changed',lambda m:m['cells'][name].update(type='MISTRAL_ALUT2'))
rejects('private output gets another alias',lambda m:m['netnames'].update({'proof_mutation_alias':copy.deepcopy(m['netnames'][private])}))
rejects('private output externally exposed',lambda m:m['ports'].update({'proof_mutation_port':{'direction':'output','bits':m['cells'][name]['connections']['Q'][:]}}))
rejects('private helper no longer feeds exact FF DATAIN',lambda m:m['cells'][dest]['connections'].update(DATAIN=m['cells'][name]['connections']['A'][:]))
selection=read(base/'promote-ax15/selection.json');producer=selection['producer']
rejects('original LUT truth table bit changes',lambda m:m['cells'][producer]['parameters'].update(LUT='1'+m['cells'][producer]['parameters']['LUT'][1:]))
def invert_original(m):
 cell=m['cells'][producer];pins=support.unpack(cell['attributes']['FES_PINMAP_V1']);pins['pins']['A'][0]=3;cell['attributes']['FES_PINMAP_V1']=support.pack(pins)
rejects('original logical input inversion changes',invert_original)
result={'status':'pass','evidence':'complete logical graph and Boolean proof of paired final routed JSON; not RBF encoding, physical timing, IO or hardware acceptance','checker_sha256':sha(Path(__file__)),'support_checker_sha256':sha(base/'proof-routed-support.py'),'frozen_binary_sha256':manifest['binary_sha256'],'identical_recipe_except_proven_prepared_input':True,'prepared_proof_rechecks':checks,'prepared_pair_proof':read(base/'promote-ax15/proof.json'),'prepared_whole_tree_proof_sha256':sha(base/'proof-whole.json'),'prepared_whole_tree_assignments':131072,'complete_routed_bridges':bridges,'final_settings_equal':True,'checker_negative_mutations':negative,'limits':['Every added MISTRAL_BUF is separately verified as a private noninverting FF data helper; no cell/net intersection is used.','Every original cell function, connected bit, complete alias partition, top port, logical pin state, placement and nonphysical metadata is checked against its own exact prepared input.','Physical LUT input maps can change during routing while logical states stay equal; electrical wires, RBF/LAB encoding and device behavior are not decoded.','Native final setup/hold and complete endpoint/board qualification remain independent acceptance gates.']}
(base/'proof-routed.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'pass','route_helpers_proved':[len(v['route_generated_buffers_proved']) for v in bridges],'original_cells_checked':[v['prepared_cell_count'] for v in bridges],'physical_pinmap_changes':[v['physical_pinmap_change_count'] for v in bridges],'logical_pin_states_checked':[v['logical_pin_states_checked'] for v in bridges],'negative_mutations_rejected':len(negative)},indent=2))
