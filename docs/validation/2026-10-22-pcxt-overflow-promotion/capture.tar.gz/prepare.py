#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,time
base=Path(__file__).resolve().parent
reference=base.parent/'reduction-balanced-20261022';binary=reference/'nextpnr-mistral'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((base/'inputs/manifest.json').read_text());assert sha(binary)==manifest['binary_sha256']
source=base/'baseline/placed.json';m=json.loads(source.read_text())['modules']['top'];raw=json.loads((base/'inputs/synth.json').read_text())['modules']['top']
cmd=json.loads((base/'baseline/receipt.json').read_text())['command'];root=cmd[cmd.index('--balance-reduction-root')+1]
ax='system.machine.cpu.cpu.u_eu_core.eu_register_ax_MISTRAL_FF_Q_4';assert raw['cells'][ax]['connections']['Q'][0]==raw['netnames']['system.machine.cpu.cpu.u_eu_core.eu_register_ax']['bits'][15]
axbit=m['cells'][ax]['connections']['Q'][0]
users={}
for n,c in m['cells'].items():
 for port,bits in c['connections'].items():
  if c['port_directions'][port]=='input':
   for bit in bits:users.setdefault(bit,[]).append((n,port))
choices=[(n,p) for n,p in users[axbit] if m['cells'][n]['type'].startswith('MISTRAL_ALUT') and users[m['cells'][n]['connections']['Q'][0]]==[(root,'A')]]
assert len(choices)==1,choices
producer,pin=choices[0];assert m['cells'][producer]['type']=='MISTRAL_ALUT6' and pin=='B' and m['cells'][root]['type']=='MISTRAL_ALUT3'
dest=base/'promote-ax15';dest.mkdir(exist_ok=False)
selection={'producer':producer,'input':pin,'consumer':root,'prior_input':str(source),'raw_ax15_driver':ax,'raw_ax15_bit':raw['cells'][ax]['connections']['Q'][0],'placed_ax15_bit':axbit,'purpose':'promote AX15 into balanced overflow root using existing exact two-LUT rewrite; diagnostic only'}
(dest/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
command=[str(binary),'--device','5CSEBA6U23I7','--json',str(source),'--qsf',str(base/'inputs/constraints.qsf'),'--sdc',str(base/'inputs/clocks.sdc'),'--no-pack','--no-place','--no-route','--reassociate-producer',producer,'--reassociate-input',pin,'--write',str(dest/'placed.json'),'--report',str(dest/'predicted-timing.json'),'--detailed-timing-report','--timing-report-paths','1024']
start=time.monotonic()
with (dest/'prepare.log').open('w') as log:code=subprocess.run(command,cwd=dest,stdout=log,stderr=subprocess.STDOUT).returncode
receipt={'command':command,'cwd':str(dest),'returncode':code,'elapsed_seconds':time.monotonic()-start,'binary_sha256':sha(binary),'binary_unchanged':sha(binary)==manifest['binary_sha256'],'input_sha256':sha(source),'source_identity':manifest['source_identity'],'evidence':'Boolean proof and placed/unrouted legality diagnostic; not timing closure or hardware','artifacts':{name:sha(dest/name) for name in ('placed.json','predicted-timing.json') if (dest/name).exists()}}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
