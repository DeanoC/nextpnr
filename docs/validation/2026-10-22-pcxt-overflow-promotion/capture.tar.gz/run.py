#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
base=Path(__file__).resolve().parent
reference=base.parent/'reduction-balanced-20261022'; binary=reference/'nextpnr-mistral'
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
old=json.loads((reference/'route-overflow17/receipt.json').read_text())
mode=sys.argv[1]
if mode=='freeze':
 sources={name:reference/'inputs'/name for name in ('synth.json','constraints.qsf','clocks.sdc')}
 sources['routed-timing.json']=reference/'route-overflow17/timing.json'
 for name,source in sources.items():
  dest=base/'inputs'/name
  if dest.exists():assert sha(dest)==sha(source)
  else:shutil.copyfile(source,dest)
 (base/'inputs/manifest.json').write_text(json.dumps({'binary':str(binary),'binary_sha256':sha(binary),
 'source_identity':json.loads((reference/'source-identity.json').read_text()),
 'inputs':{name:{'source':str(source),'sha256':sha(source)} for name,source in sources.items()},
 'reference_receipt_sha256':sha(reference/'route-overflow17/receipt.json')},indent=2)+'\n');sys.exit(0)
manifest=json.loads((base/'inputs/manifest.json').read_text());assert sha(binary)==manifest['binary_sha256']
for name,entry in manifest['inputs'].items():assert sha(base/'inputs'/name)==entry['sha256']
folder=base/mode;folder.mkdir(exist_ok=False)
command=old['nextpnr_command'][:];command[0]=str(binary)
for option in ('--rbf','--routed-endpoints'):
 index=command.index(option);del command[index:index+2]
for option,name in (('--json','synth.json'),('--qsf','constraints.qsf'),('--sdc','clocks.sdc')):command[command.index(option)+1]=str(base/'inputs'/name)
command[command.index('--write')+1]='placed.json';command[command.index('--report')+1]='predicted-timing.json';command+=['--no-route']
if mode=='list-routed':command+=['--remap-lut-driver-critical',str(base/'inputs/routed-timing.json')]
elif mode=='list-placed':command+=['--remap-lut-driver-critical',str(base/'baseline/predicted-timing.json')]
else:assert mode=='baseline'
env=dict(os.environ)
receipt={'command':command,'cwd':str(folder),'binary_sha256':manifest['binary_sha256'],
 'inputs':manifest['inputs'],'source_identity':manifest['source_identity'],
 'environment_overrides':{},'evidence':'CPU-only fresh overflow17 pack/place; no route or hardware'}
for key in ('NEXTPNR_MISTRAL_PLACED_REDUCTION','NEXTPNR_MISTRAL_CAPTURE_LOCALITY','NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY'):
 assert not env.get(key),('unexpected inherited diagnostic',key)
if mode=='list-placed':receipt['guidance_sha256']=sha(base/'baseline/predicted-timing.json')
start=time.monotonic()
with (folder/'nextpnr.log').open('w') as f:receipt['returncode']=subprocess.run(command,cwd=folder,stdout=f,stderr=subprocess.STDOUT,env=env).returncode
receipt['elapsed_seconds']=time.monotonic()-start
receipt['binary_unchanged']=sha(binary)==manifest['binary_sha256']
receipt['artifacts']={name:sha(folder/name) for name in ('placed.json','predicted-timing.json') if (folder/name).exists()}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
