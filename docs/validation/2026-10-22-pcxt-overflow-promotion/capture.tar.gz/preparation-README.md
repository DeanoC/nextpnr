# AX15 promotion in balanced overflow reduction, 2026-10-22

The existing exact two-LUT reassociation accepts AX15 promotion without a compiler change. This is a proven Boolean/placement candidate for paired routing, not timing qualification. This preparation ran no full route and accessed no hardware.

The frozen cbb compiler (`6834b09bc3ccc63105d3027db0c0415a6dc080cc923645126c3a0fca4ec65fde`) first freshly packs/places the seed-1 overflow17-only raw synthesis recipe. `run.py`, `inputs/manifest.json` and `baseline/receipt.json` retain exact inputs, source/tree identity and command. `prepare.py` then invokes the existing `--reassociate-producer CELL --reassociate-input B --no-pack --no-place --no-route` path on that checkpoint. `promote-ax15/selection.json` identifies the exact long cell names and proves its raw launch FF is `eu_register_ax[15]`.

The native transform changes:

| Object | Before | After | BEL |
| --- | --- | --- | --- |
| AX15-containing leaf | LUT6, mask 0x1 | LUT5, mask 0x1 | MISTRAL_COMB.16.21.54 |
| Overflow root | LUT3, mask 0x80 | LUT4, mask 0x80 | MISTRAL_COMB.16.21.18 |

AX15 moves from leaf logical input B to root logical input D. The new root truth table implements `A & B & C & ~D`; all connected logical pin states remain PIN_SIG. The root and leaf keep their original BELs. The architecture also reassigns physical pins in the root's ALM mate `eu_register_dx_MISTRAL_FF_Q_4_DATAIN_MISTRAL_ALUT3_Q`; its truth table, connections and logical polarity are unchanged. No other cell moves.

## Independent proofs and reload control

* `promote-ax15/proof.json`: all 256 combinations of the pair's eight distinct raw external signals agree. The leaf output remains private to one consumer, both output net identities remain, and complete canonical aliases, top ports, net metadata, clock/settings, all outside cell functions/connections and all logical pin polarities are unchanged.
* `proof-whole.json`: independently evaluates every one of the 131,072 assignments of the complete 17-register-source tree. Before and after equal `~(|DX[15:0]) & ~AX[15]`, using the same four LUT identities. All three leaf outputs are private single-user connections to the root. Raw synthesis bus indices establish DX[15:0] and AX[15] source identity; physical net numbers are not mistaken for logical identity.
* `reload-baseline` is an unchanged serialized control produced with the same flags except reassociation. Its predicted timing report is byte-identical to fresh placement. First reload drops 18 isolated `$iobuf_i` net records, each with no cell connection, top port or surviving alias, and omits 19,060 empty cell-port records. `proof-whole.json` records every omission, verifies the unchanged serialized pin states/maps, and compares every remaining module field exactly after canonical bit mapping. The factor proof is against this explicit reload control rather than silently intersecting the fresh graph.

The candidate passed the existing native ordinary/unrouted placement, movable/unclustered/unprotected cells, protected-occupant exclusion, single private producer user, legal affected LABs, fully defined LUT, real scalar net/pin polarity, exhaustive composition, slot transfer, pin reassignment and final context checks. No guard was bypassed. The native API does not require a timing gain for this Boolean diagnostic; its log states that routed timing remains unqualified. Aggregate placement Fmax remains unchanged, and provides no final-route claim.

For the paired serialized route, use:

* Control: `reload-baseline/placed.json`, SHA256 `efbb32aba3d9d8837d1acfd57cc1a444890bee1091223b8ea8bbb29af3196ff9`.
* Candidate: `promote-ax15/placed.json`, SHA256 `bad4152a4f88ffe0ddce149720e2ee050305107b4aa84703d365bf686af93571`.

Both need the same frozen binary, clock/QSF constraints and route recipe. Compare complete final routed setup/hold/coverage and final logical graph, including route helpers and pin polarity. The original fresh full route is useful context but is not a substitute for the matching serialized control. No clocks, constraints, RTL, module contracts, core lock or acceptance gates changed.
