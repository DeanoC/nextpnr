from pathlib import Path
import hashlib,json,subprocess,time
base=Path(__file__).resolve().parent;src=base/'promote-ax15/receipt.json';receipt=json.loads(src.read_text());command=receipt['command'][:]
for option in ('--reassociate-producer','--reassociate-input'):
 i=command.index(option);del command[i:i+2]
dest=base/'reload-baseline';dest.mkdir(exist_ok=False)
for option,name in (('--write','placed.json'),('--report','predicted-timing.json')):command[command.index(option)+1]=str(dest/name)
receipt['command']=command;receipt['cwd']=str(dest)
start=time.monotonic()
with (dest/'prepare.log').open('w') as f:receipt['returncode']=subprocess.run(command,cwd=dest,stdout=f,stderr=subprocess.STDOUT).returncode
receipt['elapsed_seconds']=time.monotonic()-start
receipt['evidence']='Unchanged placed-checkpoint reload control; no route or hardware'
receipt['artifacts']={name:hashlib.sha256((dest/name).read_bytes()).hexdigest() for name in ('placed.json','predicted-timing.json') if (dest/name).exists()}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
