from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time

root=Path(__file__).resolve().parent
task=root.parents[1]
parent=json.loads((root.parent/'reduction-balanced-20261022/route-overflow17/receipt.json').read_text())
def run(label,source,expected):
    command=parent['nextpnr_command'][:]
    while '--balance-reduction-root' in command:
        at=command.index('--balance-reduction-root');del command[at:at+2]
    command[command.index('--json')+1]=str(root/source/'placed.json')
    for flag,name in [('--qsf','constraints.qsf'),('--sdc','clocks.sdc')]:
        command[command.index(flag)+1]=str(root/'inputs'/name)
    command+=['--no-pack','--no-place']
    input_sha=hashlib.file_digest((root/source/'placed.json').open('rb'),'sha256').hexdigest();assert input_sha==expected
    wrapped=[str(task/'scripts/gpu-run'),'--phase-lease','--owner','pcxt-timing',
             '--label','pcxt-overflow-promote-'+label,'--',*command]
    directory=root/('route-'+label);directory.mkdir(exist_ok=False)
    receipt={'command':wrapped,'nextpnr_command':command,'input_sha256':input_sha,
             'binary_sha256':parent['binary_sha256'],
             'evidence':'leased GPU paired serialized-placement full-route diagnostic; not acceptance',
             'limit':'native bounded router iterations; no external GPU-job termination'}
    assert hashlib.file_digest(open(command[0],'rb'),'sha256').hexdigest()==receipt['binary_sha256']
    env=dict(os.environ);env['NEXTPNR_REQUIRE_GPU']='1';start=time.monotonic()
    with (directory/'nextpnr.log').open('w') as log:
        receipt['returncode']=subprocess.run(wrapped,cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    receipt['charged_seconds']=time.monotonic()-start
    receipt['artifacts']={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in directory.iterdir() if p.suffix in ['.json','.rbf']}
    (directory/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(label,receipt['returncode'],receipt['charged_seconds'],flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures=[pool.submit(run,*case) for case in [
        ('baseline','reload-baseline','efbb32aba3d9d8837d1acfd57cc1a444890bee1091223b8ea8bbb29af3196ff9'),
        ('candidate','promote-ax15','bad4152a4f88ffe0ddce149720e2ee050305107b4aa84703d365bf686af93571')]]
    for future in futures:future.result()
