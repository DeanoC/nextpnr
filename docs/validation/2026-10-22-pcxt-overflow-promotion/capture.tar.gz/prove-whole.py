#!/usr/bin/env python3
from pathlib import Path
import collections,copy,hashlib,json
base=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=[base/'baseline/placed.json',base/'reload-baseline/placed.json',base/'promote-ax15/placed.json']
mods=[read(p)['modules']['top'] for p in files];fresh,before,after=mods
removed=set(fresh['netnames'])-set(before['netnames']);assert len(removed)==18
assert not(set(before['netnames'])-set(fresh['netnames']))
removed_bits={bit for n in removed for bit in fresh['netnames'][n]['bits']}
for n in removed:
 assert n.endswith('$iobuf_i') and fresh['netnames'][n]['attributes']=={'ROUTING':' '}
for c in fresh['cells'].values():
 for bits in c['connections'].values():assert not removed_bits.intersection(bits)
for p in fresh['ports'].values():assert not removed_bits.intersection(p['bits'])
for n,v in fresh['netnames'].items():
 if n not in removed:assert not removed_bits.intersection(v['bits'])
def canon(m,remove=()):
 groups=collections.defaultdict(list)
 for n,v in m['netnames'].items():
  if n in remove:continue
  for i,b in enumerate(v['bits']):groups[b].append((n,i))
 identity={b:sorted(v) for b,v in groups.items()}
 result=copy.deepcopy(m)
 for n in remove:del result['netnames'][n]
 for section in ('netnames','ports'):
  for v in result[section].values():v['bits']=[identity[b] if isinstance(b,int) else b for b in v['bits']]
 for c in result['cells'].values():
  for p,bits in c['connections'].items():c['connections'][p]=[identity[b] if isinstance(b,int) else b for b in bits]
 return result
fresh_canon=canon(fresh,removed);before_canon=canon(before);dropped_empty_ports=[]
for name,cell in fresh_canon['cells'].items():
 other=before_canon['cells'][name]
 assert not(set(other['connections'])-set(cell['connections']))
 for port in set(cell['connections'])-set(other['connections']):
  assert cell['connections'][port]==[],(name,port)
  assert cell['attributes'].get('FES_PINMAP_V1')==other['attributes'].get('FES_PINMAP_V1'),(name,port)
  pins=json.loads(bytes.fromhex(cell['attributes']['FES_PINMAP_V1']))['pins'] if 'FES_PINMAP_V1' in cell['attributes'] else {}
  dropped_empty_ports.append({'cell':name,'type':cell['type'],'port':port,'direction':cell['port_directions'][port],'unchanged_serialized_pin':pins.get(port)})
  del cell['connections'][port];del cell['port_directions'][port]
assert fresh_canon==before_canon,'reload changed more than isolated empty nets and omitted empty ports'
assert sha(base/'baseline/predicted-timing.json')==sha(base/'reload-baseline/predicted-timing.json')
selection=read(base/'promote-ax15/selection.json');root=selection['consumer'];producer=selection['producer']
raw=read(base/'inputs/synth.json')['modules']['top'];rawdrivers={b:(n,p) for n,c in raw['cells'].items() for p,bits in c['connections'].items() if c['port_directions'][p]=='output' for b in bits}
expected=[rawdrivers[b] for b in raw['netnames']['system.machine.cpu.cpu.u_eu_core.eu_register_dx']['bits']]+[rawdrivers[raw['netnames']['system.machine.cpu.cpu.u_eu_core.eu_register_ax']['bits'][15]]]
assert len(expected)==len(set(expected))==17
leaves=sorted(expected);rows=1<<len(leaves);universe=(1<<rows)-1
variables={d:((universe//((1<<(1<<i))+1))<<(1<<i)) for i,d in enumerate(leaves)}
results=[];inventories=[]
for m in (before,after):
 drivers={b:(n,p) for n,c in m['cells'].items() for p,bits in c['connections'].items() if c['port_directions'][p]=='output' for b in bits}
 tree=set();seen_leaves=set();memo={}
 def eval_net(b):
  if b in memo:return memo[b]
  n,p=drivers[b]
  if (n,p) in variables:seen_leaves.add((n,p));result=variables[n,p]
  else:
   c=m['cells'][n];assert p=='Q' and c['type'].startswith('MISTRAL_ALUT'),(n,p,c['type']);tree.add(n)
   width=int(c['type'][-1]);pins=json.loads(bytes.fromhex(c['attributes']['FES_PINMAP_V1']))['pins'];values=[]
   for pin in 'ABCDEF'[:width]:
    assert pins[pin][0] in (0,3);v=eval_net(c['connections'][pin][0]);values.append(v if pins[pin][0]==0 else universe^v)
   result=0;table=int(c['parameters']['LUT'],2)
   for assignment in range(1<<width):
    if not ((table>>assignment)&1):continue
    term=universe
    for i,v in enumerate(values):term&=v if (assignment>>i)&1 else universe^v
    result|=term
  memo[b]=result;return result
 result=eval_net(m['cells'][root]['connections']['Q'][0]);assert seen_leaves==set(leaves) and len(tree)==4
 expected_truth=universe
 for v in variables.values():expected_truth&=universe^v
 assert result==expected_truth
 results.append(result);inventories.append({n:m['cells'][n] for n in sorted(tree)})
 assert set(tree)-{root}==set(inventories[0])-{root}
 for n in tree-{root}:
  bit=m['cells'][n]['connections']['Q'][0];uses=[(cn,p) for cn,c in m['cells'].items() for p,bits in c['connections'].items() if c['port_directions'][p]=='input' and bit in bits]
  assert len(uses)==1 and uses[0][0]==root,(n,uses)
  assert all(bit not in p['bits'] for p in m['ports'].values())
assert results[0]==results[1]
result={'evidence':'independent complete Boolean tree and graph-reload proof; no physical timing acceptance','files':{str(p.relative_to(base)):sha(p) for p in files},'reload_control':{'exactly_removed_isolated_net_records':{n:fresh['netnames'][n] for n in sorted(removed)},'removed_bits_have_no_cell_connections_top_ports_or_other_aliases':True,'dropped_empty_port_records':dropped_empty_ports,'empty_port_pin_states_and_maps_preserved':True,'all_other_complete_module_fields_equal_after_canonical_bit_mapping':True,'predicted_timing_report_bytes_equal':True},'whole_reduction':{'root':root,'same_four_cells':list(inventories[0]),'external_sources':leaves,'exhaustive_assignments':rows,'function':'~(|DX[15:0]) & ~AX[15]','before_after_equal_and_match_expected_function':True,'all_three_leaf_outputs_private_single_user':True,'inventory_before':inventories[0],'inventory_after':inventories[1]},'pair_proof':read(base/'promote-ax15/proof.json')}
(base/'proof-whole.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'assignments':rows,'same_four_cells':len(inventories[0]),'isolated_removed_net_records':len(removed),'dropped_empty_port_records':len(dropped_empty_ports),'all_other_reload_fields_equal':True,'before_after_expected_function':True},indent=2))
