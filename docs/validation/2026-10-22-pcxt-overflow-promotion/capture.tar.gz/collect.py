from pathlib import Path
import hashlib,json,shutil,subprocess
capture=Path(__file__).resolve().parent;source=capture.parent;copied={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def retain(src,name):
 dst=capture/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():assert sha(dst)==sha(src)
 else:shutil.copyfile(src,dst)
 copied[str(dst.relative_to(capture))]={'source':str(src),'sha256':sha(dst),'size':dst.stat().st_size}
for src in sorted(source.rglob('*')):
 if not src.is_file() or capture in src.parents or '__pycache__' in src.parts or src.name.startswith('nextpnr-mistral'):continue
 rel=src.relative_to(source)
 if rel==Path('manifest.json'):rel=Path('preparation-manifest.json')
 if rel==Path('README.md'):rel=Path('preparation-README.md')
 retain(src,rel)
reference=source.parent/'reduction-balanced-20261022/route-overflow17'
for name in ('routed.json','diagnostic.rbf','timing.json','endpoints.json','receipt.json','nextpnr.log'):retain(reference/name,Path('references/original-raw-overflow17')/name)
identity=json.loads((source/'inputs/manifest.json').read_text())['source_identity'];repo=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
files=['mistral/reduction_reassociate.cc','mistral/reduction_reassociate.h','mistral/tests/reduction_reassociate.cc','mistral/tests/reduction_reassociate_backend.cc','mistral/main.cc','mistral/reduction_balance.cc','mistral/reduction_balance_policy.h']
for name in files:
 data=subprocess.check_output(['git','show',identity['commit']+':'+name],cwd=repo);dst=capture/'sources'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
 copied[str(dst.relative_to(capture))]={'source':'git:'+identity['commit']+':'+name,'sha256':sha(dst),'size':dst.stat().st_size}
(capture/'collection.json').write_text(json.dumps({'scope':'AX15 promotion preparation, complete paired final logical proof, and original-raw contextual comparison; no operand-driver routes','source_identity':identity,'files':copied},indent=2)+'\n')
print(json.dumps({'files':len(copied),'bytes':sum(x['size'] for x in copied.values())},indent=2))
