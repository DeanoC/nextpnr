from pathlib import Path
from collections import defaultdict
from decimal import Decimal
import hashlib,json

root=Path(__file__).resolve().parent
def sha(path):
    return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
def rows(snapshot):
    result={}
    for endpoint,values in snapshot['endpoints'].items():
        for row in values:
            key=(endpoint,tuple(row['launch']),tuple(row['capture']))
            assert key not in result;result[key]=row
    return result
all_rows={};snapshots={};result={'runs':{},'comparisons':{}}
charge=Decimal(0)
for seed in [1]:
    for mode in ['baseline','candidate']:
        name=f'route-{mode}';directory=root/name
        receipt=json.loads((directory/'receipt.json').read_text())
        for filename,expected in receipt['artifacts'].items():assert sha(directory/filename)==expected
        timing=json.loads((directory/'timing.json').read_text())
        snapshot=json.loads((directory/'endpoints.json').read_text());snapshots[name]=snapshot
        assert timing['timing_summary']['final_analogue_model'] and snapshot['final_analogue']
        r=rows(snapshot);all_rows[name]=r;groups=defaultdict(list)
        for key,row in r.items():groups[(key[1],key[2])].append(row)
        pairs=[]
        for (launch,capture),values in sorted(groups.items()):
            pairs.append({'launch':launch,'capture':capture,'rows':len(values),
                'setup_wns_ps':min((v['setup'] for v in values if v['setup_timed']),default=None),
                'related_hold_wns_ps':min((v['hold'] for v in values if v['hold_related']),default=None),
                'setup_failures':sum(v['setup_timed'] and v['setup']<0 for v in values),
                'related_hold_failures':sum(v['hold_related'] and v['hold']<0 for v in values)})
        charge+=Decimal(str(receipt['charged_seconds']))
        result['runs'][name]={'returncode':receipt['returncode'],'charged_seconds':receipt['charged_seconds'],
            'artifact_hashes':receipt['artifacts'],'binary_sha256':receipt['binary_sha256'],
            'clock_summary':timing['timing_summary']['clocks'],'clock_pairs':pairs,
            'endpoint_rows':len(r),'endpoint_identities':len(snapshot['endpoints']),
            'setup_failures':sum(v['setup_timed'] and v['setup']<0 for v in r.values()),
            'related_hold_failures':sum(v['hold_related'] and v['hold']<0 for v in r.values()),
            'schema':snapshot['schema'],'complete':snapshot['complete'],
            'unsupported_count':len(snapshot['unsupported']),'primitive_clocks':snapshot['primitive_clocks'],
            'physical_obligations':snapshot['physical_obligations']}
    base='route-baseline'
    for mode in ['candidate']:
        name=f'route-{mode}';a,b=all_rows[base],all_rows[name]
        assert set(a)==set(b)
        for key in a:
            for field in ['setup_timed','hold_related','setup_window']:assert a[key][field]==b[key][field]
        for field in ['clocks','forwarded_clocks','io_constraints','output_contracts','physical_obligations',
                      'primitive_clocks','registered_contracts','reset_contracts','unregistered_contracts','unsupported']:
            assert snapshots[base][field]==snapshots[name][field],(name,field)
        metadata={}
        for field in ['constant_outputs','static_endpoints','unsupported_details']:
            before,after=snapshots[base][field],snapshots[name][field]
            assert set(before)==set(after)
            metadata[field]={'identities_equal':True,'changed_records':sum(before[k]!=after[k] for k in before),
                             'complete_records_equal':before==after}
        margins={}
        for field,flag in [('setup','setup_timed'),('hold','hold_related')]:
            delta=[b[k][field]-a[k][field] for k in a if a[k][flag]]
            margins[field]={'improved':sum(v>0 for v in delta),'regressed':sum(v<0 for v in delta),
                            'unchanged':sum(v==0 for v in delta),'worst_regression_ps':min(delta),
                            'best_improvement_ps':max(delta)}
        result['comparisons'][name]={'timed_endpoint_identities_and_clock_constraints_equal':True,
                                    'margins':margins,'physical_metadata':metadata,
                                    'qualification':'fails setup and has incomplete physical coverage'}
prior=Decimal('13422.19918582588360')
result['accounting']={'prior_cumulative_seconds':str(prior),'two_overflow_promotion_route_seconds':str(charge),
                      'prior_plus_these_two_routes_only_seconds':str(prior+charge),'total_cap':None,
                      'excluded_parallel_routes':'completed operand-driver routes are excluded; this is not the campaign cumulative total'}
result['evidence']='host-only final-route diagnostics, no hardware or production acceptance; complete final logical graph proof retained separately in proof-routed.json; RBF encoding and hardware excluded'
(root/'route-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['accounting'],indent=2))

reference=root.parent/'reduction-balanced-20261022/route-overflow17'
comparison={}
for name in ('diagnostic.rbf','timing.json','endpoints.json','routed.json'):
    x,y=reference/name,root/'route-baseline'/name
    comparison[name]={'original_raw_sha256':sha(x),'serialized_control_sha256':sha(y),'bytes_equal':x.read_bytes()==y.read_bytes()}
result['original_raw_vs_serialized_baseline']={'reference':str(reference),'artifacts':comparison,'meaning':'different execution models; raw original is contextual and cannot substitute for paired serialized control'}
worst={}
for mode in ('baseline','candidate'):
    directory=root/('route-'+mode);timing=json.loads((directory/'timing.json').read_text());groups={}
    for p in timing['critical_paths']:
        if p['from']!=p['to'] or p['to']!='posedge clocks[0]':continue
        endpoint=p['path'][-1]['to']['cell'];group='CPU' if endpoint.startswith('system.machine.cpu.') else 'other'
        margin=p['max_delay']-sum(s['delay'] for s in p['path'])
        if group not in groups or margin<groups[group]['setup_ns']:
            totals=defaultdict(float)
            for segment in p['path']:totals[segment['type']]+=segment['delay']
            groups[group]={'setup_ns':margin,'path':p,'segment_totals_ns':dict(totals)}
    worst[mode]=groups
result['worst_system_paths']=worst
prepared=json.loads((root/'promote-ax15/proof.json').read_text());a,b=[json.loads((root/('route-'+mode)/'routed.json').read_text())['modules']['top'] for mode in ('baseline','candidate')]
helper_sets=[{n for n,c in m['cells'].items() if c['type']=='MISTRAL_BUF'} for m in (a,b)]
assert helper_sets[0]==helper_sets[1]
mates=[n for n in prepared['changed_physical_pinmaps'] if n not in (prepared['producer'],prepared['consumer'])]
result['routed_graph_inventory']={'all_cell_identities_equal':set(a['cells'])==set(b['cells']),'all_named_net_identities_equal':set(a['netnames'])==set(b['netnames']),'cells':[len(m['cells']) for m in (a,b)],'named_nets':[len(m['netnames']) for m in (a,b)],'helper_identities_equal':True,'helpers_each':len(helper_sets[0]),'prepared_mate_cells':{n:{'before':a['cells'][n],'after':b['cells'][n]} for n in mates}}
result['graph_proof_sha256']=sha(root/'proof-routed.json')
(root/'route-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'runs':{name:{k:v for k,v in run.items() if k in ('setup_failures','related_hold_failures','clock_pairs','unsupported_count')} for name,run in result['runs'].items()},'comparisons':result['comparisons'],'raw_baseline_bytes_equal':{n:v['bytes_equal'] for n,v in comparison.items()},'helpers_each':len(helper_sets[0])},indent=2))
endpoint=result['worst_system_paths']['baseline']['CPU']['path']['path'][-1]['to']['cell']
focused=[]
for mode in ('baseline','candidate'):
    t=json.loads((root/('route-'+mode)/'timing.json').read_text())
    paths=[p for p in t['critical_paths'] if p['from']==p['to']=='posedge clocks[0]' and p['path'][-1]['to']['cell']==endpoint]
    assert len(paths)==1;p=paths[0]
    focused.append({'mode':mode,'setup_ns':p['max_delay']-sum(s['delay'] for s in p['path']),'launch':p['path'][1]['from']['cell'],'path':p})
result['original_worst_endpoint_comparison']=focused
(root/'route-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
