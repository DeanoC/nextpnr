module top(input FPGA_CLK1_50, output reg [10:0] SDRAM_A, output reg [1:0] SDRAM_BA);
reg [15:0] beat = 0;
always @(posedge FPGA_CLK1_50) begin
 beat <= beat + 1'b1;
 if (beat[15]) begin SDRAM_A <= beat[10:0]; SDRAM_BA <= beat[12:11]; end
end
endmodule
