create_clock -period 10 -name memory [get_ports FPGA_CLK1_50]
set_output_delay -clock memory -min 0 [all_outputs]
set_output_delay -clock memory -max 1 [all_outputs]
