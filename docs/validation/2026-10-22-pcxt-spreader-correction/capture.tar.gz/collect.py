#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil,subprocess
capture=Path(__file__).resolve().parent;source=capture.parent;out=source.parent
excluded={'nextpnr-mistral','nextpnr-heap-spread-test'};copied={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def retain(src,dest):
 dest=capture/dest;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==sha(src),(str(dest),'existing bytes differ')
 else:shutil.copyfile(src,dest)
 copied[str(dest.relative_to(capture))]={'source':str(src),'sha256':sha(dest),'size':dest.stat().st_size}
for src in sorted(source.rglob('*')):
 if not src.is_file() or capture in src.parents or src.name in excluded:continue
 retain(src,src.relative_to(source))
old=out/'reduction-balanced-20261022'
for name in ('synth.json','constraints.qsf','clocks.sdc','manifest.json'):retain(old/'inputs'/name,Path('inputs')/name)
for name in ('receipt.json','routed.json'):retain(old/'route-baseline'/name,Path('references/route-parent')/name)
prior=out/'placement-phase-audit-20261022/trace'
for name in ('parent-off-cpu/placed.json','parent-off-cpu/receipt.json','parent-off-cpu/nextpnr.log','trace-debug-cpu/nextpnr.log','trace-debug-cpu/receipt.json','microcode-trace.json'):retain(prior/name,Path('references/placement-trace')/name)
identity=json.loads((capture/'source-identity.json').read_text());repo=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
for name,expected in identity['sources'].items():
 assert sha(capture/'sources'/name)==expected
 data=subprocess.check_output(['git','show',identity['result_commit']+':'+name],cwd=repo)
 assert hashlib.sha256(data).hexdigest()==expected,(name,'commit source differs')
route_hash_checks={}
for label in ('default','enabled','overflow17'):
 folder=capture/('route-'+label);receipt=json.loads((folder/'receipt.json').read_text())
 route_hash_checks[label]={name:sha(folder/name)==expected for name,expected in receipt['artifacts'].items()}
 assert all(route_hash_checks[label].values())
 assert json.loads((folder/'timing.json').read_text())['timing_summary']['final_analogue_model'] is True
comparison=json.loads((capture/'default-routed-comparison.json').read_text())
parent=json.loads((capture/'references/route-parent/receipt.json').read_text())
for name in ('diagnostic.rbf','timing.json','endpoints.json'):
 assert sha(capture/'route-default'/name)==parent['artifacts'][name]==comparison[name]['reference_sha256']
a=(capture/'references/route-parent/routed.json').read_bytes();b=(capture/'route-default/routed.json').read_bytes();ja,jb=map(json.loads,(a,b));assert ja['modules']==jb['modules']
assert b.replace(jb['creator'].encode(),ja['creator'].encode())==a
result={'scope':'completed spreader correction diagnostics only; later operand/AX15 routes excluded','files':copied,'excluded_executables':sorted(excluded),'source_bytes_match_result_commit':True,'route_artifact_receipt_hashes_match':route_hash_checks,'all_three_final_analogue_models':True,'default_rbf_timing_endpoints_equal_parent':True,'default_routed_complete_modules_equal_and_creator_only_byte_inverse':True}
(capture/'collection.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'retained_files':len(copied),'retained_bytes':sum(v['size'] for v in copied.values()),'all_source_and_route_checks':True},indent=2))
