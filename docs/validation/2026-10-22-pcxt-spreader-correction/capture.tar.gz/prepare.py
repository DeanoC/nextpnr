from pathlib import Path
import concurrent.futures, hashlib, json, subprocess, time

root=Path(__file__).resolve().parent
repo=Path('/home/deano/harnesses/pcxt-compiler-repair/nextpnr')
parent=root.parent/'placement-phase-audit-20261022/trace'
template=json.loads((parent/'parent-off-cpu/receipt.json').read_text())['nextpnr_command']
files=['common/kernel/command.cc','common/place/CMakeLists.txt','common/place/placer_heap.cc',
       'common/place/placer_heap.h','common/place/heap_spread.h','common/place/tests/heap_spread.cc']
identity={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
          'binary_sha256':hashlib.file_digest((root/'nextpnr-mistral').open('rb'),'sha256').hexdigest(),'sources':{}}
for name in files:
    p=root/'sources'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((repo/name).read_bytes())
    identity['sources'][name]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(root/'source.diff').write_bytes(subprocess.check_output(['git','diff','--',*files],cwd=repo))

def run(label,options):
    command=template[:];command[0]=str(root/'nextpnr-mistral');command+=options
    directory=root/('prepare-'+label);directory.mkdir(exist_ok=False)
    start=time.monotonic()
    with (directory/'nextpnr.log').open('w') as log:
        code=subprocess.run(command,cwd=directory,stdout=log,stderr=subprocess.STDOUT).returncode
    result={'command':command,'returncode':code,'elapsed_seconds':time.monotonic()-start,
            'route_charge_seconds':0,'evidence':'CPU-only fresh pack/place; no routing',
            'binary_sha256':identity['binary_sha256']}
    if (directory/'placed.json').exists():result['placed_sha256']=hashlib.file_digest((directory/'placed.json').open('rb'),'sha256').hexdigest()
    (directory/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(label,code,result['elapsed_seconds'],flush=True)
    return result

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures=[pool.submit(run,label,options) for label,options in [
        ('default',[]),('enabled',['--placer-heap-correct-spread','--debug-placer']),
        ('explicit-zero',['--set','placerHeap/correctSpread=0']),
        ('conflict',['--set','placerHeap/correctSpread=0','--placer-heap-correct-spread'])]]
    results=[future.result() for future in futures]
(root/'prepare-results.json').write_text(json.dumps(results,indent=2)+'\n')
