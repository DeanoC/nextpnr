from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time

root=Path(__file__).resolve().parent
task=root.parents[1]
old=root.parent/'reduction-balanced-20261022'
identity=json.loads((root/'source-identity.json').read_text())

def run(label,source,enabled):
    parent=json.loads((old/('route-'+source)/'receipt.json').read_text())
    command=parent['nextpnr_command'][:];command[0]=str(root/'nextpnr-mistral')
    if enabled:command+=['--placer-heap-correct-spread']
    wrapped=[str(task/'scripts/gpu-run'),'--phase-lease','--owner','pcxt-timing',
             '--label','pcxt-spreader-'+label,'--',*command]
    directory=root/('route-'+label);directory.mkdir(exist_ok=False)
    receipt={'command':wrapped,'nextpnr_command':command,'selected_roots':parent['selected_roots'],
             'spreader_correction':enabled,'binary_sha256':identity['binary_sha256'],
             'evidence':'leased GPU fresh pack/place/route host diagnostic; not acceptance',
             'limit':'native bounded router iterations; no external GPU-job termination'}
    assert hashlib.file_digest(open(command[0],'rb'),'sha256').hexdigest()==receipt['binary_sha256']
    env=dict(os.environ);env['NEXTPNR_REQUIRE_GPU']='1'
    start=time.monotonic()
    with (directory/'nextpnr.log').open('w') as log:
        receipt['returncode']=subprocess.run(wrapped,cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    receipt['charged_seconds']=time.monotonic()-start
    receipt['artifacts']={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in directory.iterdir() if p.suffix in ['.json','.rbf']}
    (directory/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(label,receipt['returncode'],receipt['charged_seconds'],flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures=[pool.submit(run,*case) for case in [('default','baseline',False),
             ('enabled','baseline',True),('overflow17','overflow17',True)]]
    for future in futures:future.result()
